"""Type aliases used across the literalizer package."""

import datetime as dt
from collections.abc import Iterable, Mapping, Sequence
from typing import Protocol, runtime_checkable

from beartype import beartype

type Scalar = (
    str | int | float | bool | dt.date | dt.datetime | dt.time | bytes | None
)
type Value = Scalar | list[Value] | dict[Scalar, Value] | set[Scalar]
type CollectionValue = list[Value] | dict[Scalar, Value] | set[Scalar]


@beartype
class CallStubData(list[Value]):
    """Native operands and the calling convention of their stub
    declarations.
    """

    def __init__(
        self,
        data: Sequence[Value],
        *,
        keyword_arguments: bool,
        call_result_slots: frozenset[int],
    ) -> None:
        """Retain call-result slots and keyword conventions."""
        super().__init__(data)
        self.keyword_arguments = keyword_arguments
        self.call_result_slots = call_result_slots


@beartype
class CallPreambleData(list[Value]):
    """Call-rendering preamble input with its rendered arguments.

    ``literalize_call(per_element=True)`` uses its outer list and any
    nested row lists as call structure, rather than rendering those
    containers as literals.  ``argument_values`` retains the values that
    actually appear in the generated calls for language preambles whose
    type discovery depends on container structure.  ``argument_slots``
    also preserves positional grouping across calls for strategies that
    widen siblings in the same parameter slot. ``argument_types`` keeps
    declaration types selected from opaque native references, keyed by
    argument identity.
    """

    def __init__(
        self,
        data: list[Value],
        *,
        argument_values: tuple[Value, ...],
        argument_slots: tuple[list[Value], ...],
        argument_types: Mapping[int, str | None],
    ) -> None:
        """Store the original preamble data and rendered arguments."""
        super().__init__(data)
        self.argument_values = argument_values
        self.argument_slots = argument_slots
        self.argument_types = argument_types


@runtime_checkable
class ValueItemsMap[K, V](Protocol):
    """Covariant-key read-only view of the mapping arm of ``ValueInput``.

    A plain :class:`~collections.abc.Mapping`'s key parameter is
    invariant, so an inline ``dict`` literal -- inferred with a narrow
    key type such as ``str`` or ``int`` -- is not assignable to
    ``Mapping[Scalar, ValueInput]`` even though every concrete scalar
    key type *is* a ``Scalar``.  The only operation literalizer
    performs on this arm is iterating ``items()`` (see
    ``materialize_value_input``), so representing it as a read-only
    ``items()`` view places ``K``/``V`` solely in an output position;
    PEP 695 then infers them covariant, and any scalar-keyed mapping
    literal is accepted without an explicit annotation.
    """

    def items(self) -> Iterable[tuple[K, V]]:
        """Yield the key/value pairs."""
        ...


type ValueInput = (
    Scalar
    | Sequence[ValueInput]
    | ValueItemsMap[Scalar, ValueInput]
    | set[Scalar]
)


class OrderedMap(dict[Scalar, Value]):
    """An order-significant mapping (a YAML ``!!omap``).

    Literalizer treats a plain :class:`dict` as unordered and therefore
    record-eligible, while an ``OrderedMap`` is always rendered
    positionally and never collapsed into a record. This is the only
    distinction the type carries: it is a bare :class:`dict` subclass
    (every ``dict`` is insertion-ordered since Python 3.7) used purely
    as a nominal tag, so it stays a valid ``Value`` and ``ValueInput``
    while keeping plain ``dict`` equality semantics.

    This type is owned by literalizer so that ordered-map detection does
    not depend on a third-party YAML library's class hierarchy. The YAML
    parser (the only ruamel boundary) converts ``!!omap`` nodes into
    ``OrderedMap``; everything downstream dispatches on this type alone.
    """
