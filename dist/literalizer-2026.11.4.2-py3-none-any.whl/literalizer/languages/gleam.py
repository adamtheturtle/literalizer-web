"""Gleam language specification."""

import dataclasses
import datetime as dt
import enum
import math
import re
import textwrap
from collections.abc import Callable, Sequence
from functools import cached_property
from types import MappingProxyType
from typing import ClassVar

from beartype import beartype

from literalizer._formatters.collection_openers import (
    fixed_open,
)
from literalizer._formatters.format_dates import (
    datetime_epoch_formatter,
    format_date_iso,
    format_datetime_epoch,
    format_datetime_iso,
    format_time_iso,
)
from literalizer._formatters.format_entries import (
    format_bytes_base64,
    format_bytes_hex,
    passthrough_sequence_entry,
    passthrough_set_entry,
    variable_declaration_formatter,
    variable_formatter,
)
from literalizer._formatters.format_floats import (
    format_float_fixed,
    format_float_repr,
    format_float_scientific,
)
from literalizer._formatters.format_integers import (
    format_integer_binary,
    format_integer_hex,
    format_integer_octal,
    format_integer_underscore,
)
from literalizer._formatters.format_strings import (
    format_string_backslash_nul_braced_unicode,
)
from literalizer._formatters.record_strategy import (
    ActiveRecordStrategy,
    RecordDeclarationField,
    RecordFieldType,
    RecordLiteralField,
    RecordRenderer,
    build_record_strategy,
    identity_field_identifier_key,
)
from literalizer._json_native_document import (
    register_json_native_document_fast,
)
from literalizer._language import (
    NO_CALL_PARAMETER_LIMIT,
    NO_HETEROGENEOUS_BEHAVIOR,
    BareIntegerWidthStrategies,
    CallParameterShadowing,
    CallStubResult,
    CallStyle,
    CommentConfig,
    DateFormatConfig,
    DateFormatEnum,
    DatetimeFormatConfig,
    DatetimeFormatEnum,
    DeclarationStyleConfig,
    DictFormatConfig,
    FileWrapperContext,
    FloatSpecialsMixin,
    FormatValueMixin,
    HeterogeneousBehavior,
    IdentifierCase,
    JsonType,
    LanguageCls,
    ModifierCombination,
    NewVariableNameSyntax,
    OrderedMapFormatConfig,
    PositionalCallStyle,
    RenderedRecordLiteral,
    SequenceFormatConfig,
    SetFormatConfig,
    StubReturn,
    TrailingCommaConfig,
    VariantMetadata,
    body_preamble_from_scalars,
    declares_binding,
    default_call_data_dependent_preamble,
    default_consumable_ref_value_inhibits_consuming_form,
    default_format_call_arg_ref_identifier,
    default_format_call_arg_ref_identifier_consumable,
    default_format_call_ref_identifier,
    default_format_call_stub,
    default_format_call_variable_assignment,
    default_format_call_variable_declaration,
    default_sequence_binding_declarations,
    default_type_hint_collection_preamble_lines,
    default_wrap_calls_with_declarations,
    identity_call_arg,
    identity_constructor_target,
    no_call_binding_body_preamble,
    no_call_binding_file_pragmas,
    no_data_preamble,
    no_format_integer_beyond_i64,
    no_format_integer_widened,
    no_leading_preamble,
    no_validate_call_arg,
    prepend_body_preamble,
)
from literalizer._types import CallStubData, OrderedMap, Value
from literalizer.exceptions import (
    IncompatibleFormatsError,
    UnrepresentableInputError,
    UnrepresentableSpecialFloatError,
)


@beartype
def _gleam_discard_call(call: str, /) -> str:
    """Evaluate a call while explicitly discarding its result."""
    return f"let _ = {call}"


@beartype
def _reject_nested_gleam_tuples(data: Value, /) -> None:
    """Reject tuples that cannot inhabit the uniform GVal list carrier."""
    match data:
        case dict():
            children = list(data.values())
        case list() | set():
            children = list(data)
        case _:
            return
    for child in children:
        if isinstance(child, list):
            msg = "Gleam nested sequences require sequence_format=LIST"
            raise UnrepresentableInputError(msg)
        _reject_nested_gleam_tuples(child)


@beartype
def _gleam_signed_base_impl(value: int, base: Callable[[int], str]) -> str:
    """Group a negative base literal for Gleam's unary minus."""
    if value < 0:
        return f"-{{{base(abs(value))}}}"
    return base(value)


@beartype
def _gleam_native_record_declaration(
    name: str, fields: Sequence[RecordDeclarationField], /
) -> str:
    """Declare a one-variant custom type with labeled fields."""
    members = ", ".join(
        f"{field.identifier}: {field.type_name}" for field in fields
    )
    return f"pub type {name} {{\n  {name}({members})\n}}"


@beartype
def _gleam_native_record_literal(
    name: str, fields: Sequence[RecordLiteralField], /
) -> RenderedRecordLiteral:
    """Render a labeled constructor application."""
    return RenderedRecordLiteral(
        head=f"{name}(",
        entries=tuple(
            f"{field.identifier}: {field.formatted}" for field in fields
        ),
        closer=")",
        compact_pad="",
    )


@beartype
def _gleam_native_field_identifier(key: str, /) -> str:
    """Return a validated Gleam field label."""
    return key


@beartype
def _validate_gleam_native_record(
    data: Value, *, reserved_fields: frozenset[str]
) -> None:
    """Reject values that lack a concrete Gleam record representation."""
    if isinstance(data, OrderedMap):
        msg = "Gleam record mode cannot represent ordered maps"
        raise UnrepresentableInputError(msg)
    if isinstance(data, dict):
        if len(data) == 0:
            msg = "Gleam record mode cannot represent empty records"
            raise UnrepresentableInputError(msg)
        for key, value in data.items():
            if (
                not isinstance(key, str)
                or re.fullmatch(pattern=r"[a-z][a-z0-9_]*", string=key) is None
                or key in reserved_fields
            ):
                msg = f"Gleam record mode cannot represent field {key!r}"
                raise UnrepresentableInputError(msg)
            _validate_gleam_native_record(
                data=value, reserved_fields=reserved_fields
            )
    elif isinstance(data, list):
        for value in data:
            _validate_gleam_native_record(
                data=value, reserved_fields=reserved_fields
            )
    elif isinstance(data, (set, type(None))):
        msg = f"Gleam record mode cannot represent {type(data).__name__}"
        raise UnrepresentableInputError(msg)


@beartype
def _reject_gleam_native_call_arg(_value: Value, /) -> None:
    """Reject call stubs whose annotations still require GVal."""
    msg = "Gleam record mode cannot infer concrete call stub types"
    raise IncompatibleFormatsError(msg)


@beartype
def _gleam_signed_base(
    base: Callable[[int], str],
) -> Callable[[int], str]:
    """Build a Gleam-safe signed base formatter."""

    @beartype
    def _format(value: int) -> str:
        """Format using *base* with a valid negative expression."""
        return _gleam_signed_base_impl(value=value, base=base)

    return _format


@beartype
def _apply_gleam_str_wrapped_date(value: dt.date, prefix: str) -> str:
    """Format a date as a Gleam string via ISO 8601."""
    return f"{prefix}Str({format_date_iso(value=value)})"


@beartype
def _build_gleam_date_iso(
    prefix: str,
) -> Callable[[dt.date], str]:
    """Build a date formatter that produces ``{prefix}Str``
    constructors.
    """

    @beartype
    def _format(value: dt.date) -> str:
        """Delegate to module-level implementation."""
        return _apply_gleam_str_wrapped_date(value=value, prefix=prefix)

    return _format


@beartype
def _apply_gleam_str_wrapped_time(value: dt.time, prefix: str) -> str:
    """Format a time as a Gleam string via ISO 8601."""
    return f"{prefix}Str({format_time_iso(value=value)})"


@beartype
def _build_gleam_time_iso(
    prefix: str,
) -> Callable[[dt.time], str]:
    """Build a time formatter that produces ``{prefix}Str``
    constructors.
    """

    @beartype
    def _format(value: dt.time) -> str:
        """Delegate to module-level implementation."""
        return _apply_gleam_str_wrapped_time(value=value, prefix=prefix)

    return _format


@beartype
def _apply_gleam_str_wrapped_datetime(value: dt.datetime, prefix: str) -> str:
    """Format a datetime as a Gleam string via ISO 8601."""
    return f"{prefix}Str({format_datetime_iso(value=value)})"


@beartype
def _build_gleam_datetime_iso(
    prefix: str,
) -> Callable[[dt.datetime], str]:
    """Build a datetime formatter that produces ``{prefix}Str``
    constructors.
    """

    @beartype
    def _format(value: dt.datetime) -> str:
        """Delegate to module-level implementation."""
        return _apply_gleam_str_wrapped_datetime(value=value, prefix=prefix)

    return _format


@beartype
def _build_gleam_datetime_epoch(
    prefix: str,
) -> Callable[[dt.datetime], str]:
    """Build a datetime formatter that produces ``{prefix}Int`` from
    Unix epoch seconds.
    """
    return datetime_epoch_formatter(
        format_integer=_build_gleam_integer_wrapper(prefix=prefix, base=str),
    )


@beartype
def _apply_gleam_bytes_hex(value: bytes, prefix: str) -> str:
    """Format bytes as a Gleam hex string."""
    return f"{prefix}Str({format_bytes_hex(value=value)})"


@beartype
def _build_gleam_bytes_hex(
    prefix: str,
) -> Callable[[bytes], str]:
    """Build a bytes formatter that produces ``{prefix}Str`` hex
    constructors.
    """

    @beartype
    def _format(value: bytes) -> str:
        """Delegate to module-level implementation."""
        return _apply_gleam_bytes_hex(value=value, prefix=prefix)

    return _format


@beartype
def _apply_gleam_bytes_base64(value: bytes, prefix: str) -> str:
    """Format bytes as a Gleam base64 string."""
    return f"{prefix}Str({format_bytes_base64(value=value)})"


@beartype
def _build_gleam_bytes_base64(
    prefix: str,
) -> Callable[[bytes], str]:
    """Build a bytes formatter that produces ``{prefix}Str`` base64
    constructors.
    """

    @beartype
    def _format(value: bytes) -> str:
        """Delegate to module-level implementation."""
        return _apply_gleam_bytes_base64(value=value, prefix=prefix)

    return _format


@beartype
def _format_gleam_raw_string(value: str) -> str:
    """Avoid code points that Erlang rejects in Gleam's generated
    source.
    """
    # ASCII identifiers contain no characters that need escaping.
    if value.isascii() and value.isidentifier():
        return f'"{value}"'
    if "\ufffe" in value or "\uffff" in value:
        byte_values = ", ".join(
            str(object=byte) for byte in value.encode(encoding="utf-8")
        )
        return (
            "{ let assert Ok(decoded) = "
            f"bit_array.to_string(<<{byte_values}>>) "
            "decoded }"
        )
    return format_string_backslash_nul_braced_unicode(value=value)


@beartype
def _gleam_needs_bit_array(data: Value) -> bool:
    """Find strings requiring the UTF-8 decoder, including mapping
    keys.
    """
    pending: list[Value] = [data]
    while len(pending) > 0:
        item = pending.pop()
        match item:
            case str():
                if "\ufffe" in item or "\uffff" in item:
                    return True
            case list() | set():
                pending.extend(item)
            case dict():
                pending.extend(item)
                pending.extend(item.values())
            case _:
                pass
    return False


@beartype
def _apply_gleam_string(value: str, prefix: str) -> str:
    """Format a string with a constructor prefix."""
    escaped = _format_gleam_raw_string(value=value)
    return f"{prefix}Str({escaped})"


@beartype
def _build_gleam_str_formatter(
    prefix: str,
) -> Callable[[str], str]:
    """Build a string formatter that produces ``{prefix}Str``
    constructors.
    """

    @beartype
    def _format(value: str) -> str:
        """Delegate to module-level implementation."""
        return _apply_gleam_string(value=value, prefix=prefix)

    return _format


@beartype
def _apply_gleam_integer_wrapped(
    value: int, prefix: str, base: Callable[[int], str]
) -> str:
    """Format an integer with a ``{prefix}Int`` constructor."""
    return f"{prefix}Int({base(value)})"


@beartype
def _build_gleam_integer_wrapper(
    prefix: str,
    base: Callable[[int], str],
) -> Callable[[int], str]:
    """Build an integer formatter that produces ``{prefix}Int``
    constructors.
    """

    @beartype
    def _format(value: int) -> str:
        """Delegate to module-level implementation."""
        return _apply_gleam_integer_wrapped(
            value=value, prefix=prefix, base=base
        )

    return _format


@beartype
def _apply_gleam_float_wrapped(
    value: float, prefix: str, inner: Callable[[float], str]
) -> str:
    """Format a float with a ``{prefix}Float`` constructor."""
    return f"{prefix}Float({inner(value)})"


@beartype
def _build_gleam_float_wrapper(
    prefix: str,
    inner: Callable[[float], str],
) -> Callable[[float], str]:
    """Build a float formatter that produces ``{prefix}Float``
    constructors.
    """

    @beartype
    def _format(value: float) -> str:
        """Delegate to module-level implementation."""
        return _apply_gleam_float_wrapped(
            value=value, prefix=prefix, inner=inner
        )

    return _format


@beartype
def _gleam_dict_entry(
    key: str, _raw_value: Value, formatted_value: str
) -> str:
    """Format an entry whose key already has dictionary-key syntax."""
    return f"#({key}, {formatted_value})"


# Backward-compatible module-level aliases used by the Enum members.
_format_gleam_date_iso = _build_gleam_date_iso(prefix="G")
_format_gleam_datetime_iso = _build_gleam_datetime_iso(prefix="G")
_format_gleam_bytes_hex = _build_gleam_bytes_hex(prefix="G")
_format_gleam_bytes_base64 = _build_gleam_bytes_base64(prefix="G")
_format_gleam_string = _build_gleam_str_formatter(prefix="G")
_format_gleam_integer_decimal = _build_gleam_integer_wrapper(
    prefix="G",
    base=str,
)
_format_gleam_datetime_epoch = _build_gleam_datetime_epoch(prefix="G")
_gleam_integer_wrapper = _build_gleam_integer_wrapper
_gleam_float_wrapper = _build_gleam_float_wrapper


_GLEAM_INT_BASE: dict[tuple[str, str], Callable[[int], str]] = {
    ("DECIMAL", "NONE"): str,
    ("DECIMAL", "UNDERSCORE"): format_integer_underscore,
    ("HEX", "NONE"): _gleam_signed_base(base=format_integer_hex),
    ("HEX", "UNDERSCORE"): _gleam_signed_base(base=format_integer_hex),
    ("OCTAL", "NONE"): _gleam_signed_base(base=format_integer_octal),
    ("OCTAL", "UNDERSCORE"): _gleam_signed_base(base=format_integer_octal),
    ("BINARY", "NONE"): _gleam_signed_base(base=format_integer_binary),
    ("BINARY", "UNDERSCORE"): _gleam_signed_base(base=format_integer_binary),
}

_GLEAM_FLOAT_BASE: dict[str, Callable[[float], str]] = {
    "REPR": format_float_repr,
    "SCIENTIFIC": format_float_scientific,
    "FIXED": format_float_fixed,
}

_GLEAM_BYTES_FORMATTERS: dict[
    str,
    Callable[[str], Callable[[bytes], str]],
] = {
    "HEX": _build_gleam_bytes_hex,
    "BASE64": _build_gleam_bytes_base64,
}


@beartype
def _gleam_type_var(index: int) -> str:
    """Return a unique lowercase identifier for a type variable.

    Indices ``0``..``25`` map to ``a``..``z``; higher indices append a
    numeric suffix (``a1``..``z1``, ``a2``..``z2``, ...).  The numeric
    suffix avoids collisions with Gleam reserved words like ``as`` and
    ``fn`` that could otherwise appear in a pure-letter scheme.
    """
    letter = chr(ord("a") + index % 26)
    group = index // 26
    if group == 0:
        return letter
    return f"{letter}{group}"


@beartype
def _gleam_call_preamble_stub(
    parts: Sequence[str],
    params: Sequence[str],
    _stub_return: StubReturn,
    _args: Sequence[Value],
    /,
) -> tuple[str, ...]:
    """Return Gleam module-level function stubs for a call target.

    Dotted names are flattened to underscored identifiers — Gleam
    identifiers cannot contain ``.``, so ``app.client.fetch`` becomes
    ``app_client_fetch``.  Each parameter gets a fresh type variable
    so the stub is polymorphic across call sites that pass different
    argument types.  Return type is ``Nil``.
    """
    flat_name = "_".join(parts)
    param_list = ", ".join(
        f"_{p}: {_gleam_type_var(index=i)}"
        for i, p in enumerate(iterable=params)
    )
    return (f"pub fn {flat_name}({param_list}) -> Nil {{ Nil }}",)


@beartype
def _gleam_format_call_target(parts: Sequence[str]) -> str:
    """Flatten a sequence of call target parts to an underscored Gleam
    identifier.
    """
    return "_".join(parts)


@beartype
def _scalar_gleam_type(*, value: Value) -> type:
    """Return the preamble-relevant type bucket for a scalar *value*."""
    match value:
        case dt.datetime():
            return dt.datetime
        case dt.date():
            return dt.date
        case None:
            return type(None)
        case _:
            return type(value)


@beartype
def _collect_gleam_types(*, value: Value) -> frozenset[type]:
    """Return the set of Python types present in *value*.

    Walks lists, dicts, and sets recursively, collecting the scalar
    types needed to decide which ``GVal`` constructors to emit.
    """
    match value:
        case dict():
            child = frozenset[type]()
            for v in value.values():
                child = child | _collect_gleam_types(value=v)
            return frozenset[type]({dict}) | child
        case set():
            child = frozenset[type]()
            for v in value:
                child = child | _collect_gleam_types(value=v)
            return frozenset[type]({set}) | child
        case list():
            child = frozenset[type]()
            for v in value:
                child = child | _collect_gleam_types(value=v)
            return frozenset[type]({list}) | child
        case _:
            return frozenset({_scalar_gleam_type(value=value)})


@beartype
def _gleam_preamble_for_types(
    *,
    types: frozenset[type],
    type_name: str,
    constructor_prefix: str,
    datetime_type_produced: type,
) -> tuple[str, ...]:
    """Render the shared carrier declaration for the collected types."""
    p = constructor_prefix
    int_types: set[type] = {int}
    str_types: set[type] = {str, bytes, dt.date, dt.time}
    if datetime_type_produced is int:
        int_types.add(dt.datetime)
    else:
        str_types.add(dt.datetime)
    constructors = [
        constructor
        for type_set, constructor in (
            (frozenset({type(None)}), f"{p}Null"),
            (frozenset({bool}), f"{p}Bool(Bool)"),
            (frozenset(int_types), f"{p}Int(Int)"),
            (frozenset({float}), f"{p}Float(Float)"),
            (frozenset(str_types), f"{p}Str(String)"),
            (frozenset({list}), f"{p}List(List({type_name}))"),
            (
                frozenset({dict, OrderedMap}),
                f"{p}Dict(List(#(String, {type_name})))",
            ),
            (frozenset({set}), f"{p}Set(List({type_name}))"),
        )
        if len(types & type_set) > 0
    ]
    body = "\n".join(f"  {c}" for c in constructors)
    return (f"pub type {type_name} {{\n{body}\n}}",)


@beartype
def _build_gleam_data_dependent_preamble(
    *,
    type_name: str,
    constructor_prefix: str,
    datetime_type_produced: type,
) -> Callable[[Value], tuple[str, ...]]:
    """Build a ``data_dependent_preamble`` callable for Gleam.

    The callable walks *data* to collect the scalar types present and
    emits a ``pub type`` declaration containing only the constructors
    that are actually needed.
    """

    @beartype
    def _compute(data: Value, /) -> tuple[str, ...]:
        """Return the ``pub type`` declaration for *data*."""
        types = _collect_gleam_types(value=data)
        return _gleam_preamble_for_types(
            types=types,
            type_name=type_name,
            constructor_prefix=constructor_prefix,
            datetime_type_produced=datetime_type_produced,
        )

    return _compute


# ``gleam_json`` builder prefixes for ``json_type=GLEAM_JSON_JSON``.
_GLEAM_JSON_IMPORT: tuple[str, ...] = ("import gleam/json",)
_GLEAM_JSON_TRUE: str = "json.bool(True)"
_GLEAM_JSON_FALSE: str = "json.bool(False)"
_GLEAM_JSON_NULL: str = "json.null()"
_GLEAM_JSON_STRING_OPEN: str = "json.string("


@beartype
def _format_gleam_json_string(value: str) -> str:
    """Format a string as a ``json.string("...")`` builder call."""
    escaped = _format_gleam_raw_string(value=value)
    return f"{_GLEAM_JSON_STRING_OPEN}{escaped})"


@beartype
def _format_gleam_json_integer_factory(
    base: Callable[[int], str],
) -> Callable[[int], str]:
    """Return an integer formatter that emits ``json.int(<n>)`` calls."""

    @beartype
    def _format(value: int) -> str:
        """Format an integer via the underlying base formatter."""
        return f"json.int({base(value)})"

    return _format


@beartype
def _format_gleam_json_float_factory(
    inner: Callable[[float], str],
) -> Callable[[float], str]:
    """Return a float formatter that emits ``json.float(<n>)`` calls."""

    @beartype
    def _format(value: float) -> str:
        """Format a float via the underlying base formatter."""
        return f"json.float({inner(value)})"

    return _format


@beartype
def _format_gleam_json_date(value: dt.date) -> str:
    """Format a date as a ``json.string("...")`` ISO 8601 builder call."""
    return f"{_GLEAM_JSON_STRING_OPEN}{format_date_iso(value=value)})"


@beartype
def _format_gleam_json_time(value: dt.time) -> str:
    """Format a time as a ``json.string("...")`` ISO 8601 builder call."""
    return f"{_GLEAM_JSON_STRING_OPEN}{format_time_iso(value=value)})"


@beartype
def _format_gleam_json_datetime_iso(value: dt.datetime) -> str:
    """Format a datetime as a ``json.string("...")`` ISO 8601 builder
    call.
    """
    return f"{_GLEAM_JSON_STRING_OPEN}{format_datetime_iso(value=value)})"


@beartype
def _format_gleam_json_datetime_epoch(value: dt.datetime) -> str:
    """Format a datetime as a ``json.int(<epoch>)`` builder call."""
    return f"json.int({format_datetime_epoch(value=value)})"


@beartype
def _format_gleam_json_bytes_hex(value: bytes) -> str:
    """Format bytes as a ``json.string("<hex>")`` builder call."""
    return f"{_GLEAM_JSON_STRING_OPEN}{format_bytes_hex(value=value)})"


@beartype
def _format_gleam_json_bytes_base64(value: bytes) -> str:
    """Format bytes as a ``json.string("<base64>")`` builder call."""
    return f"{_GLEAM_JSON_STRING_OPEN}{format_bytes_base64(value=value)})"


_GLEAM_JSON_BYTES_FORMATTERS: dict[str, Callable[[bytes], str]] = {
    "HEX": _format_gleam_json_bytes_hex,
    "BASE64": _format_gleam_json_bytes_base64,
}


@beartype
def _gleam_json_call_preamble_stub(
    parts: Sequence[str],
    params: Sequence[str],
    _stub_return: StubReturn,
    _args: Sequence[Value],
    /,
) -> tuple[str, ...]:
    """Return Gleam module-level function stubs for a call target.

    Data arguments in JSON value mode are ``json.Json`` builder expressions.
    A wrapper's call-result slots retain the generated stub's ``Nil`` type.
    """
    flat_name = "_".join(parts)
    result_slots = (
        _args.call_result_slots
        if isinstance(_args, CallStubData)
        else frozenset[int]()
    )
    param_list = ", ".join(
        f"_{p}: {'Nil' if index in result_slots else 'json.Json'}"
        for index, p in enumerate(iterable=params)
    )
    return (f"pub fn {flat_name}({param_list}) -> Nil {{ Nil }}",)


@beartype
@dataclasses.dataclass(frozen=True, kw_only=True)
class Gleam(metaclass=LanguageCls):
    """Gleam language specification.

    The generated output uses custom constructors (``GNull``, ``GBool``,
    ``GList``, ``GDict``, ``GSet``) that are **not** built-in Gleam types.
    To compile the generated code, a ``GVal`` custom type is emitted in
    the body preamble, containing only the constructors actually used by
    the data.  For example, data consisting solely of an integer yields:

    .. code-block:: gleam

       pub type GVal {
         GInt(Int)
       }

    Args:
        date_format: How to format :class:`datetime.date` values.

            * ``date_formats.ISO`` — ISO 8601 string,
              e.g. ``GStr("2024-01-15")``.

        datetime_format: How to format :class:`datetime.datetime` values.

            * ``datetime_formats.ISO`` — ISO 8601 string,
              e.g. ``GStr("2024-01-15T12:30:00")``.

        dict_format: ``DEFAULT`` keeps the generated ``GVal`` union;
            ``RECORD`` emits concrete one-variant types for valid,
            fixed-shape objects. Generated call stubs are not supported
            in record mode.

        sequence_format: Which Gleam sequence type to use.

            * ``sequence_formats.LIST`` — list literal,
              e.g. ``GList([GInt(1), GInt(2), GInt(3)])``.
            * ``sequence_formats.TUPLE`` — tuple literal,
              e.g. ``#(GInt(1), GInt(2), GInt(3))``.

        type_name: Name of the generated custom type.  Defaults to
            ``"GVal"``.

        constructor_prefix: Prefix for generated constructor names.
            Defaults to ``"G"``, producing constructors like ``GNull``,
            ``GBool``, ``GInt``, etc.
    """

    format_call_class_scope_stub = default_format_call_stub

    reserved_module_identifiers: ClassVar[frozenset[str]] = frozenset()
    immutable_variable_modifiers: ClassVar[frozenset[enum.Enum]] = frozenset()
    wrap_in_file_tolerates_pre_indent = True
    module_name_shares_variable_scope = False
    reserved_variable_identifier_pattern: ClassVar[re.Pattern[str] | None] = (
        None
    )
    reserved_call_parameter_identifiers: ClassVar[frozenset[str]] = frozenset()
    reserved_call_parameter_identifier_pattern: ClassVar[
        re.Pattern[str] | None
    ] = None
    accepts_type_name_call_target = True
    dotted_call_root_shares_entrypoint_namespace = True
    reserved_bare_call_target_identifiers: ClassVar[frozenset[str]] = (
        frozenset()
    )
    reserved_call_target_head_identifiers: ClassVar[frozenset[str]] = (
        frozenset()
    )
    contextual_call_target_identifiers: ClassVar[frozenset[str]] = frozenset()
    call_parameter_shadowing = CallParameterShadowing.ALLOWED
    reserved_call_target_keywords_case_sensitive = True
    module_name_must_start_uppercase = False
    max_variable_identifier_length: ClassVar[int | None] = None
    call_stub_result: ClassVar[CallStubResult | None] = None
    call_literal_syntax: ClassVar[None] = None
    call_target_name_syntax: ClassVar[NewVariableNameSyntax | None] = None
    supports_multiline_dict_layout = True
    pools_map_integer_width = True

    # Gleam spells a variable in snake case: an uppercase letter
    # anywhere is a syntax error, and a leading underscore makes a
    # discard binding the generated file cannot then read back
    # (issue #4540).
    # A wrapped file declares the call target as a function, and a
    # capitalized name is a constructor rather than a function name,
    # so the constructor-target exemption stops there (issue #4525).
    declares_type_name_call_target: ClassVar[bool] = False
    new_variable_name_syntax: ClassVar[NewVariableNameSyntax] = (
        NewVariableNameSyntax.LOWER_SNAKE_ASCII
    )

    format_integer_widened = no_format_integer_widened
    format_integer_beyond_i64 = no_format_integer_beyond_i64
    format_constructor_target: ClassVar["staticmethod[[str], str]"] = (
        staticmethod(identity_constructor_target)
    )
    format_call_variable_declaration = default_format_call_variable_declaration
    format_call_variable_assignment = default_format_call_variable_assignment
    sequence_binding_declarations = default_sequence_binding_declarations
    format_call_binding_body_preamble = no_call_binding_body_preamble
    format_call_binding_file_pragmas = no_call_binding_file_pragmas

    leading_preamble = no_leading_preamble
    extension = ".gleam"
    pygments_name = "gleam"
    stringifies_nested_collections = False
    supports_special_floats = False
    supports_variable_names = True
    supports_no_variable_wrap_in_file = False
    wraps_data_dependent_preamble_in_body = False
    dict_supports_heterogeneous_values = True
    supports_native_invocations = False
    supports_dotted_calls = True
    has_free_function_calls = True
    reserved_identifiers: ClassVar[frozenset[str]] = frozenset()
    declares_call_parameter_names = True
    reserved_variable_identifiers_case_sensitive: bool = True
    reserved_variable_identifiers: frozenset[str] = frozenset(
        {
            "as",
            "assert",
            "auto",
            "case",
            "const",
            "delegate",
            "derive",
            "echo",
            "else",
            "fn",
            "if",
            "implement",
            "import",
            "let",
            "macro",
            "opaque",
            "panic",
            "pub",
            "test",
            "todo",
            "type",
            "use",
        }
    )
    allows_empty_call_parens = True
    supports_dotted_call_stub = False
    call_returns_expression = True
    supports_json_call_result_binding = False
    supports_zero_parameter_calls = True
    max_call_parameters = NO_CALL_PARAMETER_LIMIT
    supports_inline_multiline_dict_args = True
    supports_standalone_comments_in_wrapped_calls = True
    supports_multi_param_call_wrapper_stub = True
    supports_dict_literal_as_free_expression = True
    supports_module_name = False
    supports_empty_dict_key = False
    supports_call_style = True
    supports_default_dict_key_type = False
    supports_default_dict_value_type = False
    supports_default_sequence_element_type = False
    supports_default_set_element_type = False
    supports_default_ordered_map_value_type = False
    json_type_variant_name_suffix: ClassVar[str | None] = None
    supports_non_ascii_string_literals = True
    supports_multiline_string_literals = False
    supports_empty_sibling_sequence_type_hints = True
    supports_typed_dict_open = False
    language_id: ClassVar[str] = "gleam"
    variant_metadata: ClassVar[VariantMetadata] = VariantMetadata(
        round_trip_capabilities=frozenset(),
        modifier_sequence_format_overrides={},
        string_literals_escape_null_byte=True,
        supports_ref_elements_in_tuple_strategy=False,
    )
    supports_record_struct_name_prefix = False
    supports_record_shape_names = False
    record_shape_names_emit_declarations = False
    supports_non_string_dict_keys = False
    checks_raw_control_dict_keys_separately = False

    format_call_arg: ClassVar["staticmethod[[Value, str], str]"] = (
        staticmethod(
            identity_call_arg,
        )
    )
    """Callable that rewrites a formatted direct call argument."""

    class DateFormats(DateFormatEnum):
        """Date format options for Gleam."""

        ISO = DateFormatConfig(
            formatter=_format_gleam_date_iso,
            type_produced=str,
            preamble_lines=(),
        )

    class DatetimeFormats(DatetimeFormatEnum):
        """Datetime format options for Gleam."""

        ISO = DatetimeFormatConfig(
            formatter=_format_gleam_datetime_iso,
            type_produced=str,
            preamble_lines=(),
        )

        EPOCH = DatetimeFormatConfig(
            formatter=_format_gleam_datetime_epoch,
            type_produced=int,
            preamble_lines=(),
        )

    class BytesFormats(FormatValueMixin[Callable[[bytes], str]], enum.Enum):
        """Bytes formatting options."""

        HEX = enum.member(value=_format_gleam_bytes_hex)
        BASE64 = enum.member(value=_format_gleam_bytes_base64)

        def __call__(self, data: bytes, /) -> str:
            """Format bytes."""
            return self.value(data)

    class SequenceFormats(enum.Enum):
        """Sequence type options for Gleam."""

        LIST = SequenceFormatConfig(
            length_is_part_of_type=False,
            sequence_open=fixed_open(open_str="GList(["),
            close="])",
            supports_heterogeneity=True,
            single_element_trailing_comma=False,
            single_element_template=None,
            supports_trailing_comma=True,
            empty_sequence=None,
            preamble_lines=(),
            format_entry=passthrough_sequence_entry,
            typed_opener_fallback=None,
            uses_typed_literal_for_scalars=False,
            requires_uniform_record_shapes=False,
            declared_type=None,
            narrowed_empty_form=None,
        )
        TUPLE = SequenceFormatConfig(
            length_is_part_of_type=False,
            sequence_open=fixed_open(open_str="#("),
            close=")",
            supports_heterogeneity=True,
            single_element_trailing_comma=False,
            single_element_template=None,
            supports_trailing_comma=True,
            empty_sequence="#()",
            preamble_lines=(),
            format_entry=passthrough_sequence_entry,
            typed_opener_fallback=None,
            uses_typed_literal_for_scalars=False,
            requires_uniform_record_shapes=False,
            declared_type=None,
            narrowed_empty_form=None,
        )

    class SetFormats(enum.Enum):
        """Set type options for Gleam."""

        SET = SetFormatConfig(
            set_open=fixed_open(open_str="GSet(["),
            close="])",
            empty_set=None,
            preamble_lines=(),
            set_opener_template="",
            supports_heterogeneity=True,
            supports_trailing_comma=True,
        )

    class CommentFormats(enum.Enum):
        """Comment style options."""

        DOUBLE_SLASH = CommentConfig(
            prefix="//",
            suffix="",
        )

    class DeclarationStyles(enum.Enum):
        """Declaration style options."""

        LET = DeclarationStyleConfig(
            formatter=variable_declaration_formatter(
                template="let {name} = {value}"
            ),
            supports_redefinition=True,
        )

    class DictEntryStyles(enum.Enum):
        """Dict entry style options."""

        DEFAULT = enum.auto()

    class DictFormats(enum.Enum):
        """Dict/map format options."""

        DEFAULT = enum.auto()
        RECORD = enum.auto()

    class EmptyDictKey(enum.Enum):
        """Empty dict key options."""

        ALLOW = enum.auto()

    class FloatFormats(
        FloatSpecialsMixin,
        enum.Enum,
        positive_infinity="GFloat(todo)",
        negative_infinity="GFloat(todo)",
        nan="GFloat(todo)",
    ):
        """Float format options."""

        REPR = enum.member(
            value=_build_gleam_float_wrapper(
                prefix="G",
                inner=format_float_repr,
            )
        )
        SCIENTIFIC = enum.member(
            value=_build_gleam_float_wrapper(
                prefix="G",
                inner=format_float_scientific,
            )
        )
        FIXED = enum.member(
            value=_build_gleam_float_wrapper(
                prefix="G",
                inner=format_float_fixed,
            )
        )

    class IntegerFormats(enum.Enum):
        """Integer format options."""

        DECIMAL = MappingProxyType(
            mapping={
                "NONE": _format_gleam_integer_decimal,
                "UNDERSCORE": _build_gleam_integer_wrapper(
                    prefix="G",
                    base=format_integer_underscore,
                ),
            }
        )
        HEX = MappingProxyType(
            mapping={
                "NONE": _build_gleam_integer_wrapper(
                    prefix="G",
                    base=_gleam_signed_base(base=format_integer_hex),
                ),
                "UNDERSCORE": _build_gleam_integer_wrapper(
                    prefix="G",
                    base=_gleam_signed_base(base=format_integer_hex),
                ),
            }
        )
        OCTAL = MappingProxyType(
            mapping={
                "NONE": _build_gleam_integer_wrapper(
                    prefix="G",
                    base=_gleam_signed_base(base=format_integer_octal),
                ),
                "UNDERSCORE": _build_gleam_integer_wrapper(
                    prefix="G",
                    base=_gleam_signed_base(base=format_integer_octal),
                ),
            }
        )
        BINARY = MappingProxyType(
            mapping={
                "NONE": _build_gleam_integer_wrapper(
                    prefix="G",
                    base=_gleam_signed_base(base=format_integer_binary),
                ),
                "UNDERSCORE": _build_gleam_integer_wrapper(
                    prefix="G",
                    base=_gleam_signed_base(base=format_integer_binary),
                ),
            }
        )

        def get_formatter(
            self,
            numeric_separator: enum.Enum,
        ) -> Callable[[int], str]:
            """Return the integer formatter for the given separator."""
            formatter: Callable[[int], str] = self.value[
                numeric_separator.name
            ]
            return formatter

    class NumericLiteralSuffixes(enum.Enum):
        """Numeric literal suffix options."""

        NONE = enum.auto()

    class NumericSeparators(enum.Enum):
        """Numeric separator options."""

        NONE = enum.auto()
        UNDERSCORE = enum.auto()

    class NumericStyles(enum.Enum):
        """Numeric literal style options."""

        OVERLOADED = enum.auto()

    class StringFormats(enum.Enum):
        """String format options."""

        DOUBLE = enum.auto()

    class TrailingCommas(enum.Enum):
        """Trailing comma options."""

        YES = TrailingCommaConfig(multiline_trailing_comma=True)
        NO = TrailingCommaConfig(multiline_trailing_comma=False)

    date_formats = DateFormats
    datetime_formats = DatetimeFormats
    bytes_formats = BytesFormats
    sequence_formats = SequenceFormats
    set_formats = SetFormats
    comment_formats = CommentFormats

    class VariableTypeHints(enum.Enum):
        """Variable type hint options."""

        NEVER = enum.auto()
        SAFE = enum.auto()

    variable_type_hints_formats = VariableTypeHints
    declaration_styles = DeclarationStyles
    dict_entry_styles = DictEntryStyles
    dict_formats = DictFormats
    empty_dict_keys = EmptyDictKey
    float_formats = FloatFormats
    integer_formats = IntegerFormats
    integer_width_strategies = BareIntegerWidthStrategies
    numeric_literal_suffixes = NumericLiteralSuffixes
    numeric_separators = NumericSeparators
    numeric_styles = NumericStyles
    string_formats = StringFormats
    trailing_commas = TrailingCommas

    class StatementTerminatorStyles(enum.Enum):
        """Statement terminator options."""

        NONE = enum.auto()

    statement_terminator_styles = StatementTerminatorStyles

    class CallStyles(enum.Enum):
        """Gleam call style options."""

        POSITIONAL = PositionalCallStyle(
            arg_separator=", ", parenthesize_each_arg=False
        )

    call_styles = CallStyles

    class Modifiers(enum.Enum):
        """C++/Java/C#-style declaration modifiers: this language has none."""

    modifiers = Modifiers

    class HeterogeneousStrategies(enum.Enum):
        """Heterogeneous-scalar strategy options — this language only
        supports raising.
        """

        ERROR = NO_HETEROGENEOUS_BEHAVIOR

    heterogeneous_strategies = HeterogeneousStrategies

    class BoolFormats(enum.Enum):
        """Empty: this language has no alternative boolean formats."""

    bool_formats = BoolFormats

    class VersionFormats(enum.Enum):
        """Version options for Gleam."""

        V1 = enum.auto()

    version_formats = VersionFormats

    class JsonTypes(JsonType):
        """JSON value type options for Gleam."""

        GLEAM_JSON_JSON = "gleam/json.Json"
        """The ``gleam_json`` package's ``Json`` builder type."""

    json_types = JsonTypes

    modifier_combinations: ClassVar[tuple[ModifierCombination, ...]] = ()
    identifier_cases: ClassVar[tuple[IdentifierCase, ...]] = (
        IdentifierCase.SNAKE,
    )
    supported_ref_cases: ClassVar[frozenset[IdentifierCase]] = frozenset(
        {IdentifierCase.SNAKE}
    )

    def validate_spec_for_data(self, data: Value) -> None:
        """Check that selected values fit the concrete record mode."""
        if self.dict_format is type(self.dict_format).RECORD:
            if (
                re.fullmatch(
                    pattern=r"[A-Z][A-Za-z0-9_]*", string=self.type_name
                )
                is None
            ):
                msg = "Gleam record mode requires a valid type_name"
                raise UnrepresentableInputError(msg)
            if self.json_type is not None:
                msg = "Gleam records cannot be combined with json_type"
                raise IncompatibleFormatsError(msg)
            if self.sequence_format is not type(self.sequence_format).LIST:
                msg = "Gleam records require sequence_format=LIST"
                raise IncompatibleFormatsError(msg)
            _validate_gleam_native_record(
                data=data, reserved_fields=self.reserved_variable_identifiers
            )
        elif (
            self.sequence_format is type(self.sequence_format).TUPLE
            and not self._json_type_active
        ):
            _reject_nested_gleam_tuples(data)

    @cached_property
    @beartype
    def validate_call_arg(self) -> Callable[[Value], None]:
        """Return call-argument validation for this language."""
        if self.dict_format is type(self.dict_format).RECORD:
            return _reject_gleam_native_call_arg
        return no_validate_call_arg

    @cached_property
    @beartype
    def format_call_statement(self) -> Callable[[str], str]:
        """Explicitly discard the value of an unbound call."""
        return _gleam_discard_call

    wrap_calls_with_declarations = default_wrap_calls_with_declarations

    @property
    def call_wrapper_entrypoint_name(self) -> str:
        """Return the generated complete-file entry-point name."""
        return "main"

    def wrap_in_file(
        self,
        content: str,
        context: FileWrapperContext,
    ) -> str:
        """Wrap a Gleam let binding in a main function."""
        variable_name = context.variable_name
        body_preamble = context.body_preamble
        content = prepend_body_preamble(
            content=content,
            body_preamble=body_preamble,
        )
        indented = textwrap.indent(text=content, prefix=self.indent)
        use_line = ""
        if variable_name != "":
            use_line = f"\n{self.indent}let _ = {variable_name}"
        return f"\npub fn main() {{\n{indented}{use_line}\n}}"

    def wrap_combined_in_file(
        self,
        declaration: str,
        assignment: str,
        context: FileWrapperContext,
    ) -> str:
        """Consume both bindings before the second shadows the first."""
        return self.wrap_in_file(
            content=(
                f"{declaration}\nlet _ = {context.variable_name}\n"
                + assignment
            ),
            context=context,
        )

    date_format: DateFormats = DateFormats.ISO
    datetime_format: DatetimeFormats = DatetimeFormats.ISO
    bytes_format: BytesFormats = BytesFormats.HEX
    sequence_format: SequenceFormats = SequenceFormats.LIST
    set_format: SetFormats = SetFormats.SET
    variable_type_hints: VariableTypeHints = VariableTypeHints.NEVER
    comment_format: CommentFormats = CommentFormats.DOUBLE_SLASH
    declaration_style: DeclarationStyles = DeclarationStyles.LET
    dict_entry_style: DictEntryStyles = DictEntryStyles.DEFAULT
    dict_format: DictFormats = DictFormats.DEFAULT
    float_format: FloatFormats = FloatFormats.REPR
    integer_format: IntegerFormats = IntegerFormats.DECIMAL
    integer_width_strategy: BareIntegerWidthStrategies = (
        BareIntegerWidthStrategies.BARE
    )
    numeric_literal_suffix: NumericLiteralSuffixes = (
        NumericLiteralSuffixes.NONE
    )
    numeric_separator: NumericSeparators = NumericSeparators.NONE
    numeric_style: NumericStyles = NumericStyles.OVERLOADED
    string_format: StringFormats = StringFormats.DOUBLE
    trailing_comma: TrailingCommas = TrailingCommas.YES
    statement_terminator_style: StatementTerminatorStyles = (
        StatementTerminatorStyles.NONE
    )
    call_style: CallStyles = CallStyles.POSITIONAL
    heterogeneous_strategy: HeterogeneousStrategies = (
        HeterogeneousStrategies.ERROR
    )
    json_type: JsonTypes | None = None
    language_version: VersionFormats = VersionFormats.V1
    indent: str = "  "
    type_name: str = "GVal"
    constructor_prefix: str = "G"

    indent_closing_delimiter: ClassVar[bool] = False
    element_separator: ClassVar[str] = ", "
    skip_null_dict_values: ClassVar[bool] = False
    supports_collection_comments: ClassVar[bool] = True
    supports_scalar_before_comments: ClassVar[bool] = True
    supports_scalar_inline_comments: ClassVar[bool] = True
    statement_terminator: ClassVar[str] = ""
    static_body_preamble: ClassVar[Sequence[str]] = ()
    special_float_preamble: ClassVar[tuple[str, ...]] = ()

    @cached_property
    @beartype
    def call_style_config(self) -> CallStyle:
        """Configuration for Gleam's call style."""
        return self.call_style.value

    @cached_property
    @beartype
    def format_sequence_entry(self) -> Callable[[Value, str], str]:
        """Format a sequence entry."""
        return passthrough_sequence_entry

    @cached_property
    @beartype
    def format_set_entry(self) -> Callable[[Value, str], str]:
        """Format a set entry."""
        return passthrough_set_entry

    @cached_property
    @beartype
    def _json_type_active(self) -> bool:
        """Return whether the ``gleam_json.Json`` builder mode is set."""
        return self.json_type is not None

    @cached_property
    @beartype
    def static_preamble(self) -> Sequence[str]:
        """File-scope preamble.

        Under :attr:`json_type` an ``import gleam/json`` line is added
        so the rendered builder calls resolve.  The default ``GVal``
        ADT mode needs no static preamble; its tagged ADT declaration
        is emitted by :attr:`data_dependent_preamble` instead.
        """
        if self._json_type_active:
            return _GLEAM_JSON_IMPORT
        return ()

    @cached_property
    @beartype
    def data_dependent_preamble(self) -> Callable[[Value], tuple[str, ...]]:
        """Return the ``pub type`` declaration tailored to *data*.

        Under :attr:`json_type` the rendered values flow through the
        ``gleam_json`` builder API and no ``GVal`` ADT is needed. Strings
        that need UTF-8 decoding add its import in every output mode.
        """
        base: Callable[[Value], tuple[str, ...]]
        if self._json_type_active:
            base = no_data_preamble
        elif self.dict_format is type(self.dict_format).RECORD:
            base = self._native_record_strategy.preamble
        else:
            base = _build_gleam_data_dependent_preamble(
                type_name=self.type_name,
                constructor_prefix=self.constructor_prefix,
                datetime_type_produced=self.datetime_format.value.type_produced,
            )

        @beartype
        def _compute(data: Value, /) -> tuple[str, ...]:
            """Import the UTF-8 decoder only when emitted strings need
            it.
            """
            imports = (
                ("import gleam/bit_array",)
                if _gleam_needs_bit_array(data=data)
                else ()
            )
            return imports + base(data)

        return _compute

    @cached_property
    @beartype
    def bound_reference_data_preamble(
        self,
    ) -> Callable[[tuple[Value, ...]], tuple[str, ...] | None]:
        """Combine default carrier constructors across reference
        bindings.
        """

        @beartype
        def _compute(values: tuple[Value, ...], /) -> tuple[str, ...] | None:
            """Return a shared carrier, retaining native and JSON policies."""
            if (
                self._json_type_active
                or self.dict_format is type(self.dict_format).RECORD
            ):
                return None
            types = frozenset[type]()
            for value in values:
                types |= _collect_gleam_types(value=value)
            imports = (
                ("import gleam/bit_array",)
                if any(_gleam_needs_bit_array(data=value) for value in values)
                else ()
            )
            return imports + _gleam_preamble_for_types(
                types=types,
                type_name=self.type_name,
                constructor_prefix=self.constructor_prefix,
                datetime_type_produced=self.datetime_format.value.type_produced,
            )

        return _compute

    @cached_property
    @beartype
    def heterogeneous_behavior(self) -> HeterogeneousBehavior:
        """Return the heterogeneous-behavior config.

        Under :attr:`json_type` every value is wrapped in a
        ``json.Json`` builder call so scalar uniformity is irrelevant
        across container elements.
        """
        if self._json_type_active:
            return dataclasses.replace(
                NO_HETEROGENEOUS_BEHAVIOR,
                skip_scalar_checks=True,
            )
        if self.dict_format is type(self.dict_format).RECORD:
            return self._native_record_strategy.behavior
        return self.heterogeneous_strategy.value

    def _native_record_field_type(self, request: RecordFieldType, /) -> str:
        """Return a concrete Gleam field type."""
        if request.record_name is not None:
            return request.record_name
        if request.element_record_name is not None:
            return f"List({request.element_record_name})"
        return self._native_value_type(data=request.value)

    def _native_value_type(self, data: Value) -> str:
        """Infer a concrete type for a scalar or homogeneous list."""
        if isinstance(data, list):
            if len(data) == 0:
                msg = "Gleam record mode cannot infer empty list element types"
                raise UnrepresentableInputError(msg)
            return f"List({self._native_value_type(data=data[0])})"
        scalar_types: dict[type, str] = {
            bool: "Bool",
            int: "Int",
            float: "Float",
            str: "String",
            bytes: "String",
            dt.time: "String",
            dt.date: "String",
        }
        scalar_type = scalar_types.get(type(data))
        if scalar_type is not None:
            return scalar_type
        if isinstance(data, dt.datetime):
            if self.datetime_format.value.type_produced is int:
                return "Int"
            return "String"
        msg = f"Gleam record mode cannot type {type(data).__name__}"
        raise UnrepresentableInputError(msg)

    @cached_property
    @beartype
    def _native_record_strategy(self) -> ActiveRecordStrategy:
        """Build shared record naming, rendering, and declarations."""
        return build_record_strategy(
            renderer=RecordRenderer(
                name_prefix=self.type_name,
                record_shape_names={},
                field_identifier=_gleam_native_field_identifier,
                field_identifier_key=identity_field_identifier_key,
                field_type=self._native_record_field_type,
                render_declaration=_gleam_native_record_declaration,
                render_literal=_gleam_native_record_literal,
                field_type_names_nested_records=True,
                suppress_custom_name_declarations=False,
            ),
            widen_unrecordizable_nested_sibling_maps=False,
            derecordized_map_open=None,
        )

    call_data_dependent_preamble = default_call_data_dependent_preamble

    type_hint_collection_preamble_lines = (
        default_type_hint_collection_preamble_lines
    )

    format_call_stub = default_format_call_stub

    @cached_property
    @beartype
    def format_call_preamble_stub(
        self,
    ) -> Callable[
        [Sequence[str], Sequence[str], StubReturn, Sequence[Value]],
        tuple[str, ...],
    ]:
        """Return file-scope stubs for a call expression."""
        if self._json_type_active:
            return _gleam_json_call_preamble_stub
        return _gleam_call_preamble_stub

    @cached_property
    @beartype
    def format_call_target(self) -> Callable[[Sequence[str]], str]:
        """Rewrite a dotted call target into the language's call
        syntax.
        """
        return _gleam_format_call_target

    format_call_ref_identifier = default_format_call_ref_identifier

    format_call_arg_ref_identifier = default_format_call_arg_ref_identifier

    format_call_arg_ref_identifier_consumable = (
        default_format_call_arg_ref_identifier_consumable
    )

    consumable_ref_value_inhibits_consuming_form = (
        default_consumable_ref_value_inhibits_consuming_form
    )

    @cached_property
    @beartype
    def null_literal(self) -> str:
        """Literal representing ``None``."""
        if self._json_type_active:
            return _GLEAM_JSON_NULL
        return f"{self.constructor_prefix}Null"

    @cached_property
    @beartype
    def true_literal(self) -> str:
        """Literal representing ``True``."""
        if self._json_type_active:
            return _GLEAM_JSON_TRUE
        if self.dict_format is type(self.dict_format).RECORD:
            return "True"
        return f"{self.constructor_prefix}Bool(True)"

    @cached_property
    @beartype
    def false_literal(self) -> str:
        """Literal representing ``False``."""
        if self._json_type_active:
            return _GLEAM_JSON_FALSE
        if self.dict_format is type(self.dict_format).RECORD:
            return "False"
        return f"{self.constructor_prefix}Bool(False)"

    @cached_property
    @beartype
    def _dict_entry(self) -> Callable[[str, Value, str], str]:
        """Shared dict-entry formatter used by dict and ordered-map."""
        return _gleam_dict_entry

    @staticmethod
    @beartype
    def format_sequence_expression(expressions: Sequence[str], /) -> str:
        """Construct a native list of arbitrary result expressions."""
        return "[" + ", ".join(expressions) + "]"

    @cached_property
    @beartype
    def sequence_format_config(self) -> SequenceFormatConfig:
        """Configuration for the chosen sequence format.

        Under :attr:`json_type` sequences are rendered as
        ``json.preprocessed_array([...])`` builder calls since each
        element is already a ``json.Json`` value; the typed
        ``json.array(of:)`` overload would require a uniform element
        encoder which the heterogeneous-input case cannot supply.
        """
        if self._json_type_active:
            return SequenceFormatConfig(
                length_is_part_of_type=False,
                sequence_open=fixed_open(
                    open_str="json.preprocessed_array([",
                ),
                close="])",
                supports_heterogeneity=True,
                single_element_trailing_comma=False,
                single_element_template=None,
                supports_trailing_comma=True,
                empty_sequence="json.preprocessed_array([])",
                preamble_lines=(),
                format_entry=passthrough_sequence_entry,
                typed_opener_fallback=None,
                uses_typed_literal_for_scalars=False,
                requires_uniform_record_shapes=False,
                declared_type=None,
                narrowed_empty_form=None,
            )
        if self.dict_format is type(self.dict_format).RECORD:
            return dataclasses.replace(
                self.sequence_format.value,
                sequence_open=fixed_open(open_str="["),
                close="]",
                supports_heterogeneity=False,
                declared_type=None,
            )
        fmt = self.sequence_format.value
        if self.sequence_format is type(self.sequence_format).LIST:
            return dataclasses.replace(
                fmt,
                sequence_open=fixed_open(
                    open_str=f"{self.constructor_prefix}List([",
                ),
            )
        return fmt

    @cached_property
    @beartype
    def sequence_open(self) -> Callable[[list[Value]], str]:
        """Callable that returns the opening delimiter for a sequence."""
        return self.sequence_format_config.sequence_open

    @cached_property
    @beartype
    def set_format_config(self) -> SetFormatConfig:
        """Configuration for the chosen set format.

        Under :attr:`json_type` sets become
        ``json.preprocessed_array([...])`` builder calls; JSON has no
        set type so the closest builder is the heterogeneous array
        constructor.
        """
        if self._json_type_active:
            return SetFormatConfig(
                set_open=fixed_open(
                    open_str="json.preprocessed_array([",
                ),
                close="])",
                empty_set="json.preprocessed_array([])",
                preamble_lines=(),
                set_opener_template="",
                supports_heterogeneity=True,
                supports_trailing_comma=True,
            )
        return dataclasses.replace(
            self.set_format.value,
            set_open=fixed_open(
                open_str=f"{self.constructor_prefix}Set([",
            ),
        )

    @cached_property
    @beartype
    def dict_format_config(self) -> DictFormatConfig:
        """Configuration for dict formatting.

        Under :attr:`json_type` dicts are rendered as
        ``json.object([#("k", v), ...])`` builder calls; the entry
        formatter strips the ``json.string(...)`` wrapping the key
        formatter applied so each pair's key is a bare string literal.
        """
        if self._json_type_active:
            return DictFormatConfig(
                dict_open=fixed_open(open_str="json.object(["),
                close="])",
                format_entry=self._dict_entry,
                empty_dict="json.object([])",
                preamble_lines=(),
                narrowed_open=None,
                supports_trailing_comma=True,
                narrowed_empty_form=None,
            )
        return DictFormatConfig(
            dict_open=fixed_open(
                open_str=f"{self.constructor_prefix}Dict([",
            ),
            close="])",
            format_entry=self._dict_entry,
            empty_dict=None,
            preamble_lines=(),
            narrowed_open=None,
            supports_trailing_comma=True,
            narrowed_empty_form=None,
        )

    @cached_property
    @beartype
    def trailing_comma_config(self) -> TrailingCommaConfig:
        """Configuration for trailing-comma behavior."""
        return self.trailing_comma.value

    @cached_property
    @beartype
    def format_bytes(self) -> Callable[[bytes], str]:
        """Callable that formats a bytes value as a string literal."""
        if self._json_type_active:
            return _GLEAM_JSON_BYTES_FORMATTERS[self.bytes_format.name]
        if self.dict_format is type(self.dict_format).RECORD:
            return {
                "HEX": format_bytes_hex,
                "BASE64": format_bytes_base64,
            }[self.bytes_format.name]
        if self.constructor_prefix == "G":
            return self.bytes_format
        return _GLEAM_BYTES_FORMATTERS[self.bytes_format.name](
            self.constructor_prefix,
        )

    @cached_property
    @beartype
    def format_date(self) -> Callable[[dt.date], str]:
        """Callable that formats a date as a string literal."""
        if self._json_type_active:
            return _format_gleam_json_date
        if self.dict_format is type(self.dict_format).RECORD:
            return format_date_iso
        if self.constructor_prefix == "G":
            return self.date_format
        return _build_gleam_date_iso(prefix=self.constructor_prefix)

    @cached_property
    @beartype
    def format_datetime(self) -> Callable[[dt.datetime], str]:
        """Callable that formats a datetime as a string literal."""
        base_formatter: Callable[[dt.datetime], str] = self.datetime_format
        if self._json_type_active:
            if self.datetime_format is type(self.datetime_format).EPOCH:
                return _format_gleam_json_datetime_epoch
            return _format_gleam_json_datetime_iso
        if self.dict_format is type(self.dict_format).RECORD:
            native_formatters: dict[type, Callable[[dt.datetime], str]] = {
                int: format_datetime_epoch,
                str: format_datetime_iso,
            }
            return native_formatters[self.datetime_format.value.type_produced]
        if self.datetime_format is type(self.datetime_format).EPOCH:
            return _build_gleam_datetime_epoch(prefix=self.constructor_prefix)
        if self.constructor_prefix == "G":
            return base_formatter
        return _build_gleam_datetime_iso(prefix=self.constructor_prefix)

    @cached_property
    @beartype
    def format_time(self) -> Callable[[dt.time], str]:
        """Callable that formats a time as a string literal."""
        if self._json_type_active:
            return _format_gleam_json_time
        if self.dict_format is type(self.dict_format).RECORD:
            return format_time_iso
        return _build_gleam_time_iso(prefix=self.constructor_prefix)

    @cached_property
    @beartype
    def format_dict_key(self) -> Callable[[str], str]:
        """Render a string key without a value constructor."""
        return _format_gleam_raw_string

    @cached_property
    @beartype
    def format_string(self) -> Callable[[str], str]:
        """Callable that formats a string value as a quoted literal."""
        if self._json_type_active:
            return _format_gleam_json_string
        if self.dict_format is type(self.dict_format).RECORD:
            return _format_gleam_raw_string
        if self.constructor_prefix == "G":
            return _format_gleam_string
        return _build_gleam_str_formatter(prefix=self.constructor_prefix)

    @cached_property
    @beartype
    def format_integer(self) -> Callable[[int], str]:
        """Callable that formats an int value as a literal."""
        if self._json_type_active:
            base = _GLEAM_INT_BASE[
                (self.integer_format.name, self.numeric_separator.name)
            ]
            return _format_gleam_json_integer_factory(base=base)
        if self.dict_format is type(self.dict_format).RECORD:
            return _GLEAM_INT_BASE[
                (self.integer_format.name, self.numeric_separator.name)
            ]
        if self.constructor_prefix == "G":
            return self.integer_format.get_formatter(
                numeric_separator=self.numeric_separator,
            )
        base = _GLEAM_INT_BASE[
            (self.integer_format.name, self.numeric_separator.name)
        ]
        return _build_gleam_integer_wrapper(
            prefix=self.constructor_prefix,
            base=base,
        )

    @cached_property
    @beartype
    def format_float(self) -> Callable[[float], str]:
        """Callable that formats a float value as a literal.

        Non-finite values raise :class:`UnrepresentableSpecialFloatError`
        because Gleam's Erlang target has no expression that evaluates
        to a non-finite float.

        The redundant ``+`` Python's ``repr`` emits on positive
        exponents (``1.0e+16``) is stripped because Gleam's parser
        rejects it with ``This float is missing an exponent``.
        """
        finite: Callable[[float], str]
        if self._json_type_active:
            finite = _format_gleam_json_float_factory(
                inner=_GLEAM_FLOAT_BASE[self.float_format.name],
            )
        elif self.dict_format is type(self.dict_format).RECORD:
            finite = _GLEAM_FLOAT_BASE[self.float_format.name]
        elif self.constructor_prefix == "G":
            finite = self.float_format
        else:
            finite = _build_gleam_float_wrapper(
                prefix=self.constructor_prefix,
                inner=_GLEAM_FLOAT_BASE[self.float_format.name],
            )

        @beartype
        def _format(value: float) -> str:
            """Delegate finite values; raise for inf and nan."""
            if not math.isfinite(value):
                msg = (
                    f"Gleam cannot represent special float {value!r} on "
                    "the Erlang target."
                )
                raise UnrepresentableSpecialFloatError(msg)
            return finite(value).replace("e+", "e")

        return _format

    @cached_property
    @beartype
    def comment_config(self) -> CommentConfig:
        """Configuration for the language's comment syntax."""
        return self.comment_format.value

    @cached_property
    @beartype
    def ordered_map_format_config(self) -> OrderedMapFormatConfig:
        """Configuration for ordered-map formatting."""
        if self._json_type_active:
            return OrderedMapFormatConfig(
                ordered_map_open=fixed_open(open_str="json.object(["),
                close="])",
                preamble_lines=(),
            )
        return OrderedMapFormatConfig(
            ordered_map_open=fixed_open(
                open_str=f"{self.constructor_prefix}Dict([",
            ),
            close="])",
            preamble_lines=(),
        )

    @cached_property
    @beartype
    def format_ordered_map_entry(self) -> Callable[[str, Value, str], str]:
        """Callable that formats one ordered-map entry."""
        return self._dict_entry

    @cached_property
    @beartype
    def format_variable_declaration(
        self,
    ) -> Callable[[str, str, Value, frozenset[enum.Enum]], str]:
        """Callable that formats a new variable declaration.

        Under :attr:`json_type` the binding carries an explicit
        ``: json.Json`` annotation so the static type matches the
        ``gleam_json`` builder's return type and downstream encoders
        like ``json.to_string`` resolve without inference.
        """
        if self._json_type_active:
            return variable_declaration_formatter(
                template="let {name}: json.Json = {value}",
            )
        return self.declaration_style.value.formatter

    assignment_declares_binding = declares_binding
    reference_assignment_declares_binding = assignment_declares_binding
    call_assignment_declares_binding = True

    @cached_property
    @beartype
    def format_variable_assignment(
        self,
    ) -> Callable[[str, str, Value], str]:
        """Callable that formats an assignment to an existing variable.

        Under :attr:`json_type` the assignment also carries the
        ``: json.Json`` annotation so a shadowed binding keeps the
        builder static type explicit.
        """
        if self._json_type_active:
            return variable_formatter(
                template="let {name}: json.Json = {value}",
            )
        return variable_formatter(template="let {name} = {value}")

    @cached_property
    @beartype
    def scalar_preamble(self) -> dict[type, tuple[str, ...]]:
        """Per-instance scalar preamble (Gleam needs none)."""
        return {}

    @cached_property
    @beartype
    def scalar_body_preamble(self) -> dict[type, tuple[str, ...]]:
        """Per-instance scalar body preamble (Gleam needs none)."""
        return {}

    @cached_property
    @beartype
    def compute_body_preamble(
        self,
    ) -> Callable[[frozenset[type], Value], tuple[str, ...]]:
        """Compute body-preamble lines from the scalar map."""
        return body_preamble_from_scalars(
            scalar_body_preamble=self.scalar_body_preamble,
            format_lines=tuple,
        )


register_json_native_document_fast(language_cls=Gleam)
