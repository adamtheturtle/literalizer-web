"""Zig language specification."""

import dataclasses
import datetime as dt
import enum
import re
import textwrap
from collections.abc import Callable, Mapping, Sequence
from functools import cached_property
from types import MappingProxyType
from typing import TYPE_CHECKING, ClassVar, override

from beartype import beartype

from literalizer._comments import ControlCharacterFreeCommentPrefix
from literalizer._document_formatting import format_document_fast
from literalizer._formatters.call_stubs import dotted_helper_type_names
from literalizer._formatters.collection_openers import (
    CollectionSignature,
    fixed_open,
    signature_open,
)
from literalizer._formatters.format_dates import (
    format_date_iso,
    format_datetime_epoch,
    format_datetime_iso,
    format_time_iso,
)
from literalizer._formatters.format_entries import (
    dict_entry_with_template,
    format_bytes_base64,
    format_bytes_hex,
    passthrough_sequence_entry,
)
from literalizer._formatters.format_floats import (
    data_has_special_float,
    format_float_fixed,
    format_float_repr,
    format_float_scientific,
)
from literalizer._formatters.format_integers import (
    I64_MAX,
    I64_MIN,
    U64_MAX,
    format_integer_binary,
    format_integer_hex,
    format_integer_octal,
    format_integer_underscore,
)
from literalizer._formatters.format_json_value import format_json_value_text
from literalizer._formatters.format_strings import (
    format_string_backslash_control,
)
from literalizer._formatters.record_strategy import (
    ActiveRecordStrategy,
    RecordDeclarationField,
    RecordFieldType,
    RecordLiteralField,
    RecordRenderer,
    build_record_strategy,
    identity_field_identifier_key,
)
from literalizer._formatters.type_inference import (
    DictType,
    ListType,
    MixedNumeric,
    infer_element_type,
    record_shape_for_dict,
)
from literalizer._json_native_document import (
    format_json_native_document_fast,
)
from literalizer._language import (
    NO_CALL_PARAMETER_LIMIT,
    NO_HETEROGENEOUS_BEHAVIOR,
    NON_KEBAB_REF_CASES,
    BareIntegerWidthStrategies,
    CallParameterShadowing,
    CallStubResult,
    CallStyle,
    CollectionLayout,
    CommentConfig,
    DateFormatConfig,
    DateFormatEnum,
    DatetimeFormatConfig,
    DatetimeFormatEnum,
    DictFormatConfig,
    FileWrapperContext,
    FloatSpecialsMixin,
    FormatValueMixin,
    HeterogeneousBehavior,
    IdentifierCase,
    JsonType,
    Language,
    LanguageCls,
    ModifierCombination,
    NewVariableNameSyntax,
    OrderedMapFormatConfig,
    PositionalCallStyle,
    RenderedRecordLiteral,
    SequenceFormatConfig,
    SetFormatConfig,
    StubReturn,
    TrailingCommaConfig,
    VariantMetadata,
    body_preamble_from_scalars,
    default_call_data_dependent_preamble,
    default_consumable_ref_value_inhibits_consuming_form,
    default_format_call_arg_ref_identifier,
    default_format_call_arg_ref_identifier_consumable,
    default_format_call_ref_identifier,
    default_format_call_statement,
    default_format_call_stub,
    default_format_call_target,
    default_sequence_binding_declarations,
    default_type_hint_collection_preamble_lines,
    default_validate_call_arg,
    default_wrap_calls_with_declarations,
    default_wrap_combined_in_file,
    identity_constructor_target,
    no_call_binding_body_preamble,
    no_call_binding_file_pragmas,
    no_data_preamble,
    no_format_integer_beyond_i64,
    no_format_integer_widened,
    no_leading_preamble,
    prepend_body_preamble,
    requires_declared_binding,
)
from literalizer._statements import (
    CallLiteralSyntax,
    split_statements,
)
from literalizer._types import OrderedMap, Scalar, Value
from literalizer.exceptions import (
    IncompatibleFormatsError,
    UnrepresentableInputError,
    UnrepresentableIntegerError,
    UnrepresentableSpecialFloatError,
)


@beartype
def _zig_discard_call_result(call: str, /) -> str:
    """Explicitly discard a value-returning call result."""
    return f"_ = {call}"


@beartype
def _format_date_zig(value: dt.date) -> str:
    """Format a date as epoch seconds (midnight UTC)."""
    midnight = dt.datetime(
        year=value.year,
        month=value.month,
        day=value.day,
        tzinfo=dt.UTC,
    )
    return str(object=int(midnight.timestamp()))


@beartype
def _make_zig_integer_formatter(
    base: Callable[[int], str],
) -> Callable[[int], str]:
    """Return a Zig formatter bounded by its native ``u64`` maximum.

    Zig integer constants are coerced to the surrounding fixed-width
    type.  A positive value above ``u64::MAX`` therefore cannot form a
    valid scalar, union payload, collection member, or record field.
    """

    @beartype
    def _format(value: int) -> str:
        """Format *value*, rejecting positive values beyond ``u64``."""
        if value > U64_MAX:
            msg = (
                f"Zig cannot represent integer {value} above the unsigned "
                "64-bit range."
            )
            raise UnrepresentableIntegerError(msg)
        return base(value)

    return _format


@beartype
@dataclasses.dataclass(frozen=True)
class _ZigDeclarationStyleConfig:
    """Configuration for a Zig declaration style.

    Unlike :class:`DeclarationStyleConfig`, this carries no
    ``formatter`` slot: Zig builds its declaration formatter
    per-instance in :attr:`Zig.format_variable_declaration` so it can
    close over the chosen date/datetime ``type_produced``.
    """

    keyword: str
    supports_redefinition: bool


@beartype
def _zig_integer_variant(*, original: int) -> str:
    """Choose the union variant that preserves the integer value."""
    if original < I64_MIN:
        msg = (
            f"Zig cannot represent negative integer {original} "
            "below the signed 64-bit range using the ZVal "
            "union's unsigned variant."
        )
        raise UnrepresentableIntegerError(msg)
    tag = "int"
    if original > I64_MAX:
        tag = "uint"
    return tag


@beartype
def _zig_temporal_variant(*, produced_type: type) -> str:
    """Choose the union variant for the selected temporal
    representation.
    """
    if produced_type is str:
        return "str"
    return "int"


@beartype
def _format_zig_entry(
    *,
    original: Value,
    formatted: str,
    date_type: type,
    datetime_type: type,
) -> str:
    """Wrap a formatted entry in the appropriate Zig ``ZVal`` union
    tag.

    The ``str`` vs ``int`` choice for dates/datetimes is driven by the
    parsed :class:`Value` together with the chosen date/datetime
    format's ``type_produced``, rather than by sniffing *formatted*.
    """
    match original:
        case bool():
            return formatted
        case int():
            tag = _zig_integer_variant(original=original)
        case float():
            tag = "float"
        case str() | bytes():
            tag = "str"
        case dt.datetime():
            tag = _zig_temporal_variant(produced_type=datetime_type)
        case dt.time():
            tag = "str"
        case dt.date():
            tag = _zig_temporal_variant(produced_type=date_type)
        case _:
            return formatted
    return f".{{ .{tag} = {formatted} }}"


@beartype
def _close_zig_wrapped_container_ids(
    *, value: Value, parent_wrapped: bool, wrap_ids: set[int]
) -> None:
    """Propagate recursive ``ZVal`` slots through nested collections."""
    if isinstance(value, dict):
        children: list[Value] = list(value.values())
    elif isinstance(value, (list, set)):
        children = list(value)
    else:
        return
    if parent_wrapped:
        wrap_ids.add(id(value))
    for child in children:
        _close_zig_wrapped_container_ids(
            value=child,
            parent_wrapped=id(value) in wrap_ids,
            wrap_ids=wrap_ids,
        )


@beartype
def _zig_method_receiver(*, params: Sequence[str]) -> str:
    """Choose a receiver distinct from every caller parameter."""
    receiver = "self"
    while receiver in params:
        receiver += "_"
    return receiver


@beartype
def _make_zig_call_preamble_stub(
    *,
    record_mode: bool,
) -> Callable[
    [Sequence[str], Sequence[str], StubReturn, Sequence[Value]],
    tuple[str, ...],
]:
    """Build the file-scope Zig call-stub formatter.

    Zig disallows nested function declarations inside ``main``, so
    call stubs are emitted at module scope. Value-returning stubs use
    the default ``ZVal`` carrier, or an integer in record mode.
    Under the default
    ``ZVal`` model a target stub takes ``ZVal`` parameters so anonymous
    union literals like ``.{ .int = 1 }`` coerce to a concrete type at
    the call site; transform wrappers (``["_arg"]``) take ``anytype``
    so they accept both ``ZVal`` and ``void`` arguments.  Under the
    ``RECORD`` strategy (*record_mode*) call arguments are raw Zig
    values (``42``, ``"hello"``, ``null``, ``&.{ ... }``) rather than
    ``ZVal`` union literals, so every parameter is ``anytype``.  Dotted
    targets are realized as a nested ``struct`` chain rooted at a
    module-level constant, so an expression like
    ``app.client.fetch(...)`` resolves to a real method call on a real
    value.
    """

    @beartype
    def _zig_call_preamble_stub(
        parts: Sequence[str],
        params: Sequence[str],
        stub_return: StubReturn,
        _args: Sequence[Value],
        /,
    ) -> tuple[str, ...]:
        """Return file-scope Zig stub declarations for a call name."""
        param_type = "ZVal"
        if record_mode or list(params) == ["_arg"]:
            param_type = "anytype"
        return_type = "void"
        return_statement = ""
        if stub_return is StubReturn.VALUE:
            return_type = "i64" if record_mode else "ZVal"
            return_statement = " return 0;" if record_mode else " return .nil;"
        param_discards = "".join(f" _ = {p};" for p in params)
        method = parts[-1]
        if len(parts) == 1:
            param_list = ", ".join(f"{p}: {param_type}" for p in params)
            return (
                (
                    f"fn {method}({param_list}) {return_type} "
                    f"{{{param_discards}{return_statement} }}"
                ),
            )
        chain = parts[:-1]
        helper_types = dotted_helper_type_names(
            parts=chain,
            suffix="Type_",
            ignore_underscores=False,
            capitalize_parts=False,
        )
        receiver = _zig_method_receiver(params=params)
        holder_type = helper_types[-1]
        type_preamble: tuple[str, ...] = ()
        if method == "ZVal" and (
            param_type == "ZVal" or return_type == "ZVal"
        ):
            # A generated member named ZVal masks the global carrier
            # in its signature. Bare call fragments
            # do not create this stub and retain their caller's scope.
            carrier_type = '@"call value"'
            type_preamble = (f"const {carrier_type} = ZVal;",)
            if param_type == "ZVal":
                param_type = carrier_type
            if stub_return is StubReturn.VALUE:
                return_type = carrier_type
        method_param_list = ", ".join(
            [
                f"{receiver}: {holder_type}",
                *(f"{p}: {param_type}" for p in params),
            ],
        )
        lines: list[str] = [
            (
                f"const {holder_type} = struct {{ "
                f"fn {method}({method_param_list}) {return_type} "
                f"{{ _ = {receiver};{param_discards}{return_statement} }} }};"
            ),
        ]
        prev_type = holder_type
        for i in range(len(chain) - 2, 0, -1):
            curr_type = helper_types[i]
            lines.append(
                f"const {curr_type} = struct {{ "
                f"{chain[i + 1]}: {prev_type} = .{{}} }};",
            )
            prev_type = curr_type
        root = chain[0]
        intermediates = chain[1:]
        if len(intermediates) > 0:
            root_type = helper_types[0]
            lines.append(
                f"const {root_type} = struct {{ "
                f"{intermediates[0]}: {prev_type} = .{{}} }};",
            )
        else:
            root_type = prev_type
        lines.append(f"const {root}: {root_type} = .{{}};")
        return (*type_preamble, *lines)

    return _zig_call_preamble_stub


# The ``RECORD`` strategy supports only auto ``Record0``/``Record1``/...
# names (no ``record_shape_names``), so the shared renderer always gets
# an empty custom-name mapping.
_ZIG_NO_RECORD_SHAPE_NAMES: Mapping[frozenset[str], str] = MappingProxyType[
    frozenset[str], str
](
    mapping={},
)

# A datetime/date whose format produces an ``int`` epoch is a Zig
# ``i64`` record field; an ISO string one is ``[]const u8``.  The
# ``.get`` default keeps the string fallback off coverage's branch
# accounting (only the int key is crossed with ``RECORD`` by the
# datetime-cross corpus; the date axis is never crossed, so an
# ``if``/ternary would leave the string side uncovered).
_ZIG_EPOCH_INT_FIELD_TYPES: Mapping[type, str] = MappingProxyType(
    mapping={int: "i64"},
)

# A list mixing ``int`` and ``float`` infers to :class:`MixedNumeric`;
# its Zig slice element type is ``f64`` (the ``int`` literals coerce to
# ``f64``).  Looked up with a ``.get`` default rather than an ``if`` so
# the mapping needs no corpus case to stay coverage-clean (the same
# ``.get``-default trick used for the epoch field type; the coverage
# tool does not treat a dict lookup default as a branch).
_ZIG_INFERRED_ELEMENT_TYPES: Mapping[type | ListType | DictType, str] = (
    MappingProxyType(mapping={MixedNumeric: "f64"})
)


@beartype
def _zig_int_sort_key(value: Value, /) -> int:
    """Return the ``max`` sort key selecting a list's widest int.

    An ``int`` sorts by its value so :meth:`Zig._zig_list_type` types a
    :class:`WideInt` slice from the element that widens it (``u64``
    once any value passes i64 range), not from ``items[0]``.  Every
    other value sorts equal (``0``), so for a homogeneous non-int list
    ``max`` keeps the first element -- an arbitrary but type-equivalent
    representative -- and the int-vs-other branch is exercised by the
    int and string record-list fixtures alike.
    """
    if isinstance(value, int):
        return value
    return 0


# Zig keywords, shared by the variable-name collision check and the
# ``RECORD`` field-name escaping below.  Keeping one source avoids the
# two lists drifting apart.
_ZIG_RESERVED_IDENTIFIERS: frozenset[str] = frozenset(
    {
        "addrspace",
        "align",
        "allowzero",
        "and",
        "anyframe",
        "anytype",
        "asm",
        "async",
        "await",
        "break",
        "callconv",
        "catch",
        "comptime",
        "const",
        "continue",
        "defer",
        "else",
        "enum",
        "errdefer",
        "error",
        "export",
        "extern",
        "fn",
        "for",
        "if",
        "inline",
        "linksection",
        "no_runtime",
        "noalias",
        "noasync",
        "noinline",
        "nosuspend",
        "opaque",
        "or",
        "orelse",
        "packed",
        "pub",
        "resume",
        "return",
        "struct",
        "suspend",
        "switch",
        "test",
        "threadlocal",
        "try",
        "union",
        "unreachable",
        "usingnamespace",
        "var",
        "volatile",
        "while",
    }
)

# Names a Zig declaration cannot take, beyond the keywords: ``_``, the
# discard identifier, which the compiler rejects as a binding name
# ("'_' used as an identifier without @\"_\" syntax"); the primitive
# types and values, which it reports as "name shadows primitive"; and
# ``main``, the function the wrapped file declares and which a local
# constant may not shadow.  Keys carrying the same names are still
# written as quoted struct members, so this set is separate from the
# escaping set above (issue #3932).
_ZIG_PRIMITIVE_IDENTIFIERS: frozenset[str] = frozenset(
    {
        "anyerror",
        "anyframe",
        "anyopaque",
        "anytype",
        "bool",
        "c_char",
        "c_int",
        "c_long",
        "c_longdouble",
        "c_longlong",
        "c_short",
        "c_uint",
        "c_ulong",
        "c_ulonglong",
        "c_ushort",
        "comptime_float",
        "comptime_int",
        "f128",
        "f16",
        "f32",
        "f64",
        "f80",
        "false",
        "isize",
        "noreturn",
        "null",
        "true",
        "type",
        "undefined",
        "usize",
        "void",
    }
)

_ZIG_RESERVED_VARIABLE_IDENTIFIERS: frozenset[str] = (
    _ZIG_RESERVED_IDENTIFIERS
    | _ZIG_PRIMITIVE_IDENTIFIERS
    | frozenset({"_", "main"})
)

# The arbitrary-width integer primitives are an open set (``u7``,
# ``i33``), so they are matched rather than listed.  The float
# primitives are a fixed set and are listed above.
_ZIG_SIZED_PRIMITIVE = re.compile(pattern=r"[iu][0-9]+")

# A dict key usable verbatim as a Zig ``struct`` member: a plain
# identifier that is not a keyword.  Anything else is escaped as a
# quoted identifier (``@"error"``).
_ZIG_IDENTIFIER = re.compile(pattern=r"^[A-Za-z_][A-Za-z0-9_]*$")


@beartype
def _zig_record_field_identifier(key: str, /) -> str:
    """Return the Zig ``struct`` member name for a dict *key*.

    A key that is a plain, non-keyword identifier names the member
    verbatim (no case conversion), matching the designated-initializer
    literal form ``Record0{ .id = 1, ... }``.  A key that collides with
    a Zig keyword (``error``, ``switch``, ...) or is not identifier-
    shaped text is escaped as a quoted identifier (``@"error"``), which
    is valid in both the ``struct`` declaration (``@"error": T``) and
    its literal (``.@"error" = value``), so the output compiles
    (issue #2963).
    """
    if (
        key in _ZIG_RESERVED_IDENTIFIERS
        or _ZIG_IDENTIFIER.match(string=key) is None
    ):
        return "@" + format_string_backslash_control(
            value=key,
            control_char_fmt="\\x{:02x}",
            escape_delete=True,
        )
    return key


@beartype
def _zig_record_literal(
    name: str,
    fields: Sequence[RecordLiteralField],
    /,
) -> RenderedRecordLiteral:
    """Render a Zig ``Name{ .field = value, ... }`` struct literal as
    structured pieces for the shared compact/multiline layout code.

    A trailing comma after the last initializer is valid in a Zig
    brace-enclosed struct literal, so the language-wide trailing-comma
    config applies unchanged.
    """
    return RenderedRecordLiteral(
        head=f"{name}{{",
        entries=tuple(
            f".{field.identifier} = {field.formatted}" for field in fields
        ),
        closer="}",
        compact_pad=" ",
    )


@beartype
def _zig_render_record_declaration(
    name: str,
    fields: Sequence[RecordDeclarationField],
    /,
) -> str:
    """Render a Zig ``const Name = struct { field: Type, ... };``."""
    members = ", ".join(
        f"{field.identifier}: {field.type_name}" for field in fields
    )
    return f"const {name} = struct {{ {members} }};"


_CALL_LITERAL_SYNTAX = CallLiteralSyntax(
    prefix="//",
    regex_literals=False,
    backtick_strings=False,
    raw_string_prefixes=(),
    verbatim_strings=False,
    interpolation_syntax=None,
    quotes="\"'",
    literal_span_end=None,
)


@beartype
def _format_zig_call_assignment(name: str, value: str, _data: Value) -> str:
    """Format a Zig reassignment binding a call result.

    The call-expression counterpart of
    :attr:`Zig.format_call_variable_declaration`; the variable already
    exists, so the call result is assigned directly with none of the
    ``ZVal`` union tagging a literal-binding assignment applies (a call
    result is not a ``ZVal`` union literal).
    """
    comments = _CALL_LITERAL_SYNTAX.split(value)
    return f"{name} = {comments.code};" + comments.trailing_comments


@beartype
def _zig_mutable_binding_names(*, content: str) -> list[str]:
    """Select mutable outer declarations, excluding nested function locals."""
    statements = split_statements(
        content=content, quotes='"', line_comment_prefixes=("//",)
    )
    return [
        match.group(1)
        for statement in statements
        if (
            match := re.match(
                pattern=r"^[ \t]*var ([A-Za-z_][A-Za-z0-9_]*)\b",
                string=statement,
            )
        )
        is not None
    ]


_STD_JSON_STATIC_PREAMBLE: tuple[str, ...] = ('const std = @import("std");',)

_ZVAL_STATIC_PREAMBLE: tuple[str, ...] = (
    "const ZVal = union(enum) {",
    "    nil,",
    "    bool: bool,",
    "    int: i64,",
    "    uint: u64,",
    "    float: f64,",
    "    str: []const u8,",
    "    arr: []const ZVal,",
    "    map: []const ZKV,",
    "    set: []const ZVal,",
    "};",
    "const ZKV = struct { key: []const u8, val: ZVal };",
)

_ZIG_RECORD_VALUE_NAME = '@"record value"'
_ZIG_RECORD_ENTRY_NAME = '@"record entry"'
_RECORD_ZVAL_STATIC_PREAMBLE = tuple(
    line.replace("ZVal", _ZIG_RECORD_VALUE_NAME).replace(
        "ZKV", _ZIG_RECORD_ENTRY_NAME
    )
    for line in _ZVAL_STATIC_PREAMBLE
)

_STD_JSON_BODY_PREAMBLE: tuple[str, ...] = (
    (
        'var @"JSON arena" = '
        "std.heap.ArenaAllocator.init(std.heap.page_allocator);"
    ),
    'defer @"JSON arena".deinit();',
    'const allocator = @"JSON arena".allocator();',
)


@beartype
def _format_zig_json_entry(original: Value, formatted: str) -> str:
    """Preserve rendered containers and references, parsing other values.

    A set cannot contain a reference marker; parsing it retains the JSON
    conversion's ordering of its scalar members.
    """
    if isinstance(original, (dict, list)):
        return formatted
    return _zig_parse_expression(data=original)


_STD_JSON_ARRAY_OPEN = (
    "std.json.Value{ .array = std.json.Array.fromOwnedSlice(allocator, "
    "allocator.dupe(std.json.Value, &.{"
)
_STD_JSON_ARRAY_CLOSE = "}) catch unreachable) }"
_STD_JSON_OBJECT_OPEN = """(struct {
    fn @"JSON build"(
        @"JSON allocator": std.mem.Allocator,
        @"JSON entries": []const struct {
            key: []const u8,
            value: std.json.Value,
        },
    ) std.json.Value {
        var @"JSON object" =
            std.json.ObjectMap.init(@"JSON allocator");
        for (@"JSON entries") |@"JSON entry"| {
            @"JSON object".put(
                @"JSON entry".key,
                @"JSON entry".value,
            ) catch unreachable;
        }
        return .{ .object = @"JSON object" };
    }
}).@"JSON build"(allocator, &.{"""
_STD_JSON_OBJECT_CLOSE = "})"
_STD_JSON_EMPTY_ARRAY = (
    "std.json.Value{ .array = std.json.Array.init(allocator) }"
)
_STD_JSON_EMPTY_OBJECT = (
    "std.json.Value{ .object = std.json.ObjectMap.init(allocator) }"
)


# Containers copy already rendered JSON values, including references.
# Scalar entries retain the existing JSON parsing conversion semantics.
_STD_JSON_SEQUENCE_CONFIG = SequenceFormatConfig(
    length_is_part_of_type=False,
    sequence_open=fixed_open(open_str=_STD_JSON_ARRAY_OPEN),
    close=_STD_JSON_ARRAY_CLOSE,
    supports_heterogeneity=True,
    single_element_trailing_comma=False,
    single_element_template=None,
    supports_trailing_comma=True,
    empty_sequence=_STD_JSON_EMPTY_ARRAY,
    preamble_lines=(),
    format_entry=_format_zig_json_entry,
    typed_opener_fallback=None,
    uses_typed_literal_for_scalars=False,
    requires_uniform_record_shapes=False,
    declared_type=None,
    narrowed_empty_form=None,
)

_STD_JSON_SET_CONFIG = SetFormatConfig(
    set_open=fixed_open(open_str="["),
    close="]",
    empty_set="[]",
    preamble_lines=(),
    set_opener_template="",
    supports_heterogeneity=True,
    supports_trailing_comma=True,
)

_STD_JSON_DICT_CONFIG = DictFormatConfig(
    dict_open=fixed_open(open_str=_STD_JSON_OBJECT_OPEN),
    close=_STD_JSON_OBJECT_CLOSE,
    format_entry=dict_entry_with_template(
        template=".{{ .key = {key}, .value = {value} }}",
        format_value=_format_zig_json_entry,
    ),
    empty_dict=_STD_JSON_EMPTY_OBJECT,
    preamble_lines=(),
    narrowed_open=None,
    supports_trailing_comma=True,
    narrowed_empty_form=None,
)


@beartype
@dataclasses.dataclass(frozen=True)
class _ZigRecordOrderedMapConfig(OrderedMapFormatConfig):
    """Keep empty ordered maps as slices in native-record fields."""

    @property
    @override
    def empty_ordered_map(self) -> str:
        """Return an empty slice rather than the plain-record empty
        form.
        """
        return "&.{}"


_STD_JSON_ORDERED_MAP_CONFIG = OrderedMapFormatConfig(
    ordered_map_open=fixed_open(open_str=_STD_JSON_OBJECT_OPEN),
    close=_STD_JSON_OBJECT_CLOSE,
    preamble_lines=(),
)


@beartype
def _zig_parse_expression(data: Value) -> str:
    """Render a ``std.json.parseFromSlice(...) catch unreachable`` call.

    ``catch unreachable`` (rather than ``try``) keeps the enclosing
    ``pub fn main() void`` signature unchanged: every JSON literal here
    is generated by :func:`json.dumps` and is guaranteed to parse, so
    the failure arm is statically unreachable.
    """
    if data_has_special_float(data=data):
        msg = (
            "Zig(json_type=STD_JSON_VALUE) cannot represent special floats "
            "because std.json.parseFromSlice accepts only finite numbers."
        )
        raise UnrepresentableSpecialFloatError(msg)
    json_text = format_json_value_text(data=data)
    zig_literal = format_string_backslash_control(
        value=json_text,
        control_char_fmt="\\x{:02x}",
        escape_delete=True,
    )
    return (
        "(std.json.parseFromSlice("
        f"std.json.Value, allocator, {zig_literal}, .{{}}) "
        "catch unreachable).value"
    )


@beartype
def _format_zig_json_declaration(
    name: str,
    value: str,
    data: Value,
    _modifiers: frozenset[enum.Enum],
) -> str:
    """Bind a JSON value while retaining rendered reference
    expressions.
    """
    formatted_json = _format_zig_json_entry(original=data, formatted=value)
    return f"const {name} = {formatted_json};"


@beartype
def _format_zig_json_var_declaration(
    name: str,
    value: str,
    data: Value,
    _modifiers: frozenset[enum.Enum],
) -> str:
    """Format a mutable JSON value binding preserving rendered references.

    The ``var`` form is selected when the caller pairs the declaration
    with a subsequent assignment (the ``combined`` variable form); a
    plain ``const`` cannot be reassigned.
    """
    formatted_json = _format_zig_json_entry(original=data, formatted=value)
    return f"var {name}: std.json.Value = {formatted_json};"


@beartype
def _format_zig_json_assignment(name: str, value: str, data: Value) -> str:
    """Assign a JSON value while retaining rendered reference
    expressions.
    """
    return (
        f"{name} = {_format_zig_json_entry(original=data, formatted=value)};"
    )


@beartype
def _format_zig_json_call_arg(raw_value: Value, formatted: str) -> str:
    """Format a direct call argument as a ``std.json.Value`` literal."""
    return _format_zig_json_entry(original=raw_value, formatted=formatted)


@beartype
def _zig_integer_field_type(*, value: int) -> str:
    """Choose the Zig integer field type covering the value."""
    value_type = "i64"
    if value > I64_MAX:
        value_type = "u64"
    return value_type


# Work around https://github.com/astral-sh/ty/issues/4573.
if TYPE_CHECKING:
    _BytesEnumMember = enum.member[Callable[[bytes], str]]
else:
    _BytesEnumMember = enum.member


@beartype
@dataclasses.dataclass(frozen=True, kw_only=True)
class Zig(metaclass=LanguageCls):
    """Zig language specification."""

    format_call_class_scope_stub = default_format_call_stub

    reserved_module_identifiers: ClassVar[frozenset[str]] = frozenset()
    immutable_variable_modifiers: ClassVar[frozenset[enum.Enum]] = frozenset()
    wrap_in_file_tolerates_pre_indent = True
    module_name_shares_variable_scope = False
    reserved_call_parameter_identifiers: ClassVar[frozenset[str]] = frozenset()
    reserved_call_parameter_identifier_pattern: ClassVar[
        re.Pattern[str] | None
    ] = None
    accepts_type_name_call_target = True
    declares_type_name_call_target = True
    dotted_call_root_shares_entrypoint_namespace = True
    reserved_bare_call_target_identifiers: ClassVar[frozenset[str]] = (
        frozenset()
    )
    reserved_call_target_head_identifiers: ClassVar[frozenset[str]] = (
        frozenset()
    )
    contextual_call_target_identifiers: ClassVar[frozenset[str]] = frozenset()
    reserved_call_target_keywords_case_sensitive = True
    module_name_must_start_uppercase = False
    new_variable_name_syntax = NewVariableNameSyntax.ASCII
    max_variable_identifier_length: ClassVar[int | None] = None
    call_stub_result: ClassVar[CallStubResult | None] = None
    call_literal_syntax: ClassVar[CallLiteralSyntax | None] = (
        _CALL_LITERAL_SYNTAX
    )
    call_target_name_syntax: ClassVar[NewVariableNameSyntax | None] = None
    supports_multiline_dict_layout = True
    pools_map_integer_width = True

    format_integer_widened = no_format_integer_widened
    format_integer_beyond_i64 = no_format_integer_beyond_i64
    format_constructor_target: ClassVar["staticmethod[[str], str]"] = (
        staticmethod(identity_constructor_target)
    )
    sequence_binding_declarations = default_sequence_binding_declarations
    format_call_binding_body_preamble = no_call_binding_body_preamble
    format_call_binding_file_pragmas = no_call_binding_file_pragmas

    leading_preamble = no_leading_preamble
    extension = ".zig"
    pygments_name = "zig"
    stringifies_nested_collections = False
    supports_special_floats = True
    supports_variable_names = True
    supports_no_variable_wrap_in_file = False
    wraps_data_dependent_preamble_in_body = False
    dict_supports_heterogeneous_values = True
    supports_native_invocations = False
    supports_dotted_calls = True
    has_free_function_calls = True
    reserved_identifiers: ClassVar[frozenset[str]] = frozenset()
    # Zig refuses a parameter that shadows any file-scope
    # declaration, which for a dotted target includes the helper
    # each component declares (issue #4528).
    call_parameter_shadowing: ClassVar[CallParameterShadowing] = (
        CallParameterShadowing.ANY_DECLARATION
    )
    declares_call_parameter_names = True
    reserved_variable_identifiers_case_sensitive: bool = True
    reserved_variable_identifiers: frozenset[str] = dataclasses.field(
        default=_ZIG_RESERVED_VARIABLE_IDENTIFIERS,
        init=False,
    )
    reserved_variable_identifier_pattern: ClassVar[re.Pattern[str]] = (
        _ZIG_SIZED_PRIMITIVE
    )
    allows_empty_call_parens = True
    supports_dotted_call_stub = True
    call_returns_expression = True
    supports_json_call_result_binding = False
    supports_zero_parameter_calls = True
    max_call_parameters = NO_CALL_PARAMETER_LIMIT
    supports_inline_multiline_dict_args = True
    supports_standalone_comments_in_wrapped_calls = True
    supports_multi_param_call_wrapper_stub = False
    supports_dict_literal_as_free_expression = True
    supports_module_name = False
    supports_empty_dict_key = False
    supports_call_style = True
    supports_default_dict_key_type = False
    supports_default_dict_value_type = False
    supports_default_sequence_element_type = False
    supports_default_set_element_type = False
    supports_default_ordered_map_value_type = False
    json_type_variant_name_suffix: ClassVar[str | None] = None
    supports_non_ascii_string_literals = True
    supports_multiline_string_literals = False
    supports_empty_sibling_sequence_type_hints = True
    supports_typed_dict_open = False
    language_id: ClassVar[str] = "zig"
    variant_metadata: ClassVar[VariantMetadata] = VariantMetadata(
        round_trip_capabilities=frozenset(),
        modifier_sequence_format_overrides={},
        string_literals_escape_null_byte=True,
        supports_ref_elements_in_tuple_strategy=False,
    )
    supports_record_struct_name_prefix = True
    supports_record_shape_names = False
    record_shape_names_emit_declarations = False
    supports_non_string_dict_keys = False
    checks_raw_control_dict_keys_separately = False

    class DateFormats(DateFormatEnum):
        """Date format options for Zig."""

        ZIG = DateFormatConfig(
            formatter=_format_date_zig,
            type_produced=int,
            preamble_lines=(),
        )
        ISO = DateFormatConfig(
            formatter=format_date_iso, type_produced=str, preamble_lines=()
        )

    class DatetimeFormats(DatetimeFormatEnum):
        """Datetime format options for Zig."""

        ISO = DatetimeFormatConfig(
            formatter=format_datetime_iso,
            type_produced=str,
            preamble_lines=(),
        )

        EPOCH = DatetimeFormatConfig(
            formatter=format_datetime_epoch,
            type_produced=int,
            preamble_lines=(),
        )

    class BytesFormats(FormatValueMixin[Callable[[bytes], str]], enum.Enum):
        """Bytes formatting options."""

        HEX = _BytesEnumMember(value=format_bytes_hex)
        BASE64 = _BytesEnumMember(value=format_bytes_base64)

        def __call__(self, data: bytes, /) -> str:
            """Format bytes."""
            return self.value(data)

    class SequenceFormats(enum.Enum):
        """Sequence type options for Zig."""

        ARRAY = SequenceFormatConfig(
            length_is_part_of_type=False,
            sequence_open=fixed_open(open_str=".{ .arr = &.{"),
            close="}}",
            supports_heterogeneity=True,
            single_element_trailing_comma=False,
            single_element_template=None,
            supports_trailing_comma=True,
            empty_sequence=None,
            preamble_lines=(),
            format_entry=passthrough_sequence_entry,
            typed_opener_fallback=None,
            uses_typed_literal_for_scalars=False,
            requires_uniform_record_shapes=False,
            declared_type=None,
            narrowed_empty_form=None,
        )

    class SetFormats(enum.Enum):
        """Set type options for Zig."""

        SET = SetFormatConfig(
            set_open=fixed_open(open_str=".{ .set = &.{"),
            close="}}",
            empty_set=None,
            preamble_lines=(),
            set_opener_template="",
            supports_heterogeneity=True,
            supports_trailing_comma=True,
        )

    class CommentFormats(enum.Enum):
        """Comment style options."""

        DOUBLE_SLASH = CommentConfig(
            prefix=ControlCharacterFreeCommentPrefix(object="//"),
            suffix="",
        )

    class DeclarationStyles(enum.Enum):
        """Declaration style options."""

        CONST = _ZigDeclarationStyleConfig(
            keyword="const",
            supports_redefinition=False,
        )
        VAR = _ZigDeclarationStyleConfig(
            keyword="var",
            supports_redefinition=True,
        )

    class DictEntryStyles(enum.Enum):
        """Dict entry style options."""

        DEFAULT = enum.auto()

    class DictFormats(enum.Enum):
        """Dict/map format options."""

        DEFAULT = enum.auto()

    class EmptyDictKey(enum.Enum):
        """Empty dict key options."""

        ALLOW = enum.auto()

    class FloatFormats(
        FloatSpecialsMixin,
        enum.Enum,
        positive_infinity='@"float std".math.inf(f64)',
        negative_infinity='-@"float std".math.inf(f64)',
        nan='@"float std".math.nan(f64)',
    ):
        """Float format options."""

        REPR = enum.member(value=format_float_repr)
        SCIENTIFIC = enum.member(value=format_float_scientific)
        FIXED = enum.member(value=format_float_fixed)

    class IntegerFormats(enum.Enum):
        """Integer format options."""

        DECIMAL = MappingProxyType(
            mapping={
                "NONE": str,
                "UNDERSCORE": format_integer_underscore,
            }
        )
        HEX = MappingProxyType(
            mapping={
                "NONE": format_integer_hex,
                "UNDERSCORE": format_integer_hex,
            }
        )
        OCTAL = MappingProxyType(
            mapping={
                "NONE": format_integer_octal,
                "UNDERSCORE": format_integer_octal,
            }
        )
        BINARY = MappingProxyType(
            mapping={
                "NONE": format_integer_binary,
                "UNDERSCORE": format_integer_binary,
            }
        )

        def get_formatter(
            self,
            numeric_separator: enum.Enum,
        ) -> Callable[[int], str]:
            """Return the integer formatter for the given separator."""
            formatter: Callable[[int], str] = self.value[
                numeric_separator.name
            ]
            return formatter

    class NumericLiteralSuffixes(enum.Enum):
        """Numeric literal suffix options."""

        NONE = enum.auto()

    class NumericSeparators(enum.Enum):
        """Numeric separator options."""

        NONE = enum.auto()
        UNDERSCORE = enum.auto()

    class NumericStyles(enum.Enum):
        """Numeric literal style options."""

        OVERLOADED = enum.auto()

    class StringFormats(enum.Enum):
        """String format options."""

        DOUBLE = enum.auto()

    class TrailingCommas(enum.Enum):
        """Trailing comma options."""

        YES = TrailingCommaConfig(multiline_trailing_comma=True)
        NO = TrailingCommaConfig(multiline_trailing_comma=False)

    date_formats = DateFormats
    datetime_formats = DatetimeFormats
    bytes_formats = BytesFormats
    sequence_formats = SequenceFormats
    set_formats = SetFormats
    comment_formats = CommentFormats

    class VariableTypeHints(enum.Enum):
        """Variable type hint options."""

        NEVER = enum.auto()
        SAFE = enum.auto()

    variable_type_hints_formats = VariableTypeHints
    declaration_styles = DeclarationStyles
    dict_entry_styles = DictEntryStyles
    dict_formats = DictFormats
    empty_dict_keys = EmptyDictKey
    float_formats = FloatFormats
    integer_formats = IntegerFormats
    integer_width_strategies = BareIntegerWidthStrategies
    numeric_literal_suffixes = NumericLiteralSuffixes
    numeric_separators = NumericSeparators
    numeric_styles = NumericStyles
    string_formats = StringFormats
    trailing_commas = TrailingCommas

    class StatementTerminatorStyles(enum.Enum):
        """Statement terminator options."""

        SEMICOLON = enum.auto()

    statement_terminator_styles = StatementTerminatorStyles

    class CallStyles(enum.Enum):
        """Zig call style options."""

        POSITIONAL = PositionalCallStyle(
            arg_separator=", ", parenthesize_each_arg=False
        )

    call_styles = CallStyles

    class Modifiers(enum.Enum):
        """C++/Java/C#-style declaration modifiers: this language has none."""

    modifiers = Modifiers

    class HeterogeneousStrategies(enum.Enum):
        """Heterogeneous-scalar strategy options.

        ``ERROR`` keeps the default ``ZVal`` union model (a
        record-shaped dict that mixes scalars with a container is
        rendered as a homogeneous-typed ``.{ .map = &.{ ... } }``).
        ``RECORD`` instead renders each record-shaped dict (non-empty,
        string-keyed) as a generated ``const Record0 = struct { ... };``
        declared in the preamble plus a matching
        ``Record0{ .field = value, ... }`` literal whose fields are raw
        Zig values, so a field may mix scalars and containers that the
        homogeneous ``ZVal`` map cannot.
        """

        ERROR = enum.auto()
        RECORD = enum.auto()

    heterogeneous_strategies = HeterogeneousStrategies

    class BoolFormats(enum.Enum):
        """Empty: this language has no alternative boolean formats."""

    bool_formats = BoolFormats

    class VersionFormats(enum.Enum):
        """Version options for Zig."""

        V0_12 = enum.auto()

    version_formats = VersionFormats

    class JsonTypes(JsonType):
        """JSON value type options for Zig."""

        STD_JSON_VALUE = "std.json.Value"
        """Zig's standard library dynamic JSON value type."""

    json_types = JsonTypes

    modifier_combinations: ClassVar[tuple[ModifierCombination, ...]] = ()
    identifier_cases: ClassVar[tuple[IdentifierCase, ...]] = (
        IdentifierCase.SNAKE,
        IdentifierCase.PASCAL,
        IdentifierCase.CAMEL,
    )
    supported_ref_cases: ClassVar[frozenset[IdentifierCase]] = (
        NON_KEBAB_REF_CASES
    )

    def validate_spec_for_data(self, data: Value) -> None:
        """Raise if the spec cannot produce valid code for *data*.

        When :attr:`json_type` is active, walk *data* to reject non-string
        dict keys, which JSON objects cannot represent.
        """
        if self._json_type_active:
            self._validate_json_value_keys(data)

    validate_call_arg = default_validate_call_arg

    format_call_statement = default_format_call_statement

    @cached_property
    @beartype
    def format_identity_transformed_call_statement(
        self,
    ) -> Callable[[str], str]:
        """Explicitly discard an unchanged transformed call's return value."""
        return _zig_discard_call_result

    wrap_calls_with_declarations = default_wrap_calls_with_declarations

    def wrap_in_file(
        self,
        content: str,
        context: FileWrapperContext,
    ) -> str:
        """Wrap a Zig declaration in a main function."""
        variable_name = context.variable_name
        body_preamble = context.body_preamble
        json_mode = self._json_type_active
        # Inspect caller declarations before adding the JSON arena preamble.
        mutable_names = _zig_mutable_binding_names(content=content)
        is_var = variable_name in mutable_names
        content = "\n".join(
            (
                content,
                *(
                    f"_ = &{name};"
                    for name in mutable_names
                    if name != variable_name
                ),
            ),
        )
        effective_body_preamble = body_preamble
        if json_mode:
            effective_body_preamble = _STD_JSON_BODY_PREAMBLE + body_preamble
        content = prepend_body_preamble(
            content=content,
            body_preamble=effective_body_preamble,
        )
        indented = textwrap.indent(text=content, prefix=self.indent)
        if variable_name == "":
            return f"pub fn main() void {{\n{indented}\n}}"
        match json_mode, self._record_strategy_active, is_var:
            case True, _, True:
                # A ``var x: std.json.Value`` may have been reassigned;
                # take its address so the final discard does not trip
                # the "pointless discard of local variable" error.
                use = f"{self.indent}_ = &{variable_name};"
            case True, _, False:
                use = f"{self.indent}_ = {variable_name};"
            case _, True, _:
                # A raw value is not a ``ZVal``, so a redefinition ``var``
                # cannot be reset to ``.nil``; take its address instead so
                # the final statement uses the variable without tripping
                # the Zig "pointless discard of local variable" error
                # after a preceding write.
                ref = variable_name
                if is_var:
                    ref = f"&{variable_name}"
                use = f"{self.indent}_ = {ref};"
            case _, False, True:
                use = f"{self.indent}{variable_name} = .nil;"
            case _:
                use = f"{self.indent}_ = {variable_name};"
        return f"pub fn main() void {{\n{indented}\n{use}\n}}"

    wrap_combined_in_file = default_wrap_combined_in_file

    date_format: DateFormats = DateFormats.ZIG
    datetime_format: DatetimeFormats = DatetimeFormats.EPOCH
    bytes_format: BytesFormats = BytesFormats.HEX
    sequence_format: SequenceFormats = SequenceFormats.ARRAY
    set_format: SetFormats = SetFormats.SET
    variable_type_hints: VariableTypeHints = VariableTypeHints.NEVER
    comment_format: CommentFormats = CommentFormats.DOUBLE_SLASH
    declaration_style: DeclarationStyles = DeclarationStyles.CONST
    dict_entry_style: DictEntryStyles = DictEntryStyles.DEFAULT
    dict_format: DictFormats = DictFormats.DEFAULT
    float_format: FloatFormats = FloatFormats.REPR
    integer_format: IntegerFormats = IntegerFormats.DECIMAL
    integer_width_strategy: BareIntegerWidthStrategies = (
        BareIntegerWidthStrategies.BARE
    )
    numeric_literal_suffix: NumericLiteralSuffixes = (
        NumericLiteralSuffixes.NONE
    )
    numeric_separator: NumericSeparators = NumericSeparators.NONE
    numeric_style: NumericStyles = NumericStyles.OVERLOADED
    string_format: StringFormats = StringFormats.DOUBLE
    trailing_comma: TrailingCommas = TrailingCommas.YES
    statement_terminator_style: StatementTerminatorStyles = (
        StatementTerminatorStyles.SEMICOLON
    )
    heterogeneous_strategy: HeterogeneousStrategies = (
        HeterogeneousStrategies.ERROR
    )
    json_type: JsonTypes | None = None
    record_struct_name_prefix: str = "Record"
    language_version: VersionFormats = VersionFormats.V0_12
    indent: str = "    "

    indent_closing_delimiter: ClassVar[bool] = False
    element_separator: ClassVar[str] = ", "
    skip_null_dict_values: ClassVar[bool] = False
    supports_scalar_inline_comments: ClassVar[bool] = False
    statement_terminator: ClassVar[str] = ";"
    static_body_preamble: ClassVar[Sequence[str]] = ()
    special_float_preamble: ClassVar[tuple[str, ...]] = (
        'const @"float std" = @import("std");',
    )
    call_style: CallStyles = CallStyles.POSITIONAL

    @cached_property
    @beartype
    def call_style_config(self) -> CallStyle:
        """Configuration for the chosen call style."""
        return self.call_style.value

    @cached_property
    @beartype
    def _format_entry(self) -> Callable[[Value, str], str]:
        """Shared entry formatter closing over date/datetime
        ``type_produced``.

        Under the ``RECORD`` strategy every value is emitted as a raw
        Zig literal (no ``ZVal`` union tag), so the entry formatter is
        the identity: sequence/set elements, call arguments, and
        variable bindings all pass their already-formatted literal
        through unchanged.
        """
        if self._record_strategy_active:

            @beartype
            def _identity(_original: Value, formatted: str) -> str:
                """Pass the raw Zig literal through unchanged."""
                return formatted

            return _identity

        date_type = self.date_format.value.type_produced
        datetime_type = self.datetime_format.value.type_produced

        @beartype
        def _formatter(original: Value, formatted: str) -> str:
            """Adapt :func:`_format_zig_entry` to the positional
            entry-formatter interface.
            """
            return _format_zig_entry(
                original=original,
                formatted=formatted,
                date_type=date_type,
                datetime_type=datetime_type,
            )

        return _formatter

    @cached_property
    @beartype
    def format_sequence_entry(self) -> Callable[[Value, str], str]:
        """Format a sequence entry."""
        if self._json_type_active:
            return _format_zig_json_entry
        return self._format_entry

    @cached_property
    @beartype
    def format_set_entry(self) -> Callable[[Value, str], str]:
        """Format a set entry."""
        if self._json_type_active:
            return passthrough_sequence_entry
        return self._format_entry

    assignment_declares_binding = requires_declared_binding
    reference_assignment_declares_binding = assignment_declares_binding
    call_assignment_declares_binding = False

    @cached_property
    @beartype
    def format_variable_assignment(self) -> Callable[[str, str, Value], str]:
        """Format an assignment to an existing variable."""
        if self._json_type_active:
            return _format_zig_json_assignment
        format_entry = self._format_entry

        @beartype
        def _format_assign(name: str, value: str, data: Value) -> str:
            """Format a Zig assignment to an existing ``ZVal``
            variable.
            """
            wrapped = format_entry(data, value)
            return f"{name} = {wrapped};"

        return _format_assign

    @cached_property
    @beartype
    def _record_strategy_active(self) -> bool:
        """Return whether the ``RECORD`` heterogeneous strategy is set."""
        return (
            self.heterogeneous_strategy
            is type(self.heterogeneous_strategy).RECORD
        )

    @cached_property
    @beartype
    def uses_resolved_ref_declaration_data(self) -> bool:
        """Infer native declaration types from the values behind refs."""
        return self._record_strategy_active

    @cached_property
    @beartype
    def supports_scalar_before_comments(self) -> bool:
        """Whether a comment can sit above the rendered value.

        JSON scalar bindings retain their parsed-value conversion, so
        their comments go above the declaration (issue #4546).
        """
        return not self._json_type_active

    @cached_property
    @beartype
    def supports_collection_comments(self) -> bool:
        """Whether a comment can sit inside the rendered value.

        JSON bindings retain the policy of placing comments above the
        declaration, including parsed scalar leaves (issue #4546).
        """
        return not self._json_type_active

    @cached_property
    @beartype
    def _json_type_active(self) -> bool:
        """Return whether Zig should render via ``std.json.Value``."""
        return self.json_type is not None

    def __post_init__(self) -> None:
        """Reject ``json_type`` combinations the generator cannot emit."""
        self._validate_json_type_spec()
        # Reserve the declarations this mode always emits.  The arena
        # uses a quoted internal name so a bare JSON fragment can still
        # assign to the caller's ordinary ``arena`` binding.
        helper_names = frozenset[str]()
        if self._json_type_active:
            helper_names = frozenset({"std", "allocator"})
        elif not self._record_strategy_active:
            helper_names = frozenset({"ZVal", "ZKV"})
        object.__setattr__(
            self,
            "reserved_variable_identifiers",
            self.reserved_variable_identifiers | helper_names,
        )

    def _validate_json_type_spec(self) -> None:
        """Reject ``json_type`` combinations the generator cannot emit.

        JSON values use their standard carrier rather than the native
        structs generated by ``heterogeneous_strategy=RECORD``.
        """
        if not self._json_type_active:
            return
        if self.heterogeneous_strategy is self.heterogeneous_strategies.RECORD:
            msg = (
                "Zig json_type renders data through "
                "std.json.parseFromSlice(...) and is incompatible with "
                "heterogeneous_strategy=RECORD, which generates typed "
                "struct declarations. Use heterogeneous_strategy=ERROR."
            )
            raise IncompatibleFormatsError(msg)

    def _validate_json_value_keys(self, data: Value, /) -> None:
        """Reject non-string object keys for ``std.json.Value``."""
        match data:
            case OrderedMap() | dict():
                for key, value in data.items():
                    if not isinstance(key, str):
                        msg = (
                            "Zig json_type can only represent dict keys "
                            "as JSON object strings, not "
                            f"{type(key).__name__}"
                        )
                        raise UnrepresentableInputError(msg)
                    self._validate_json_value_keys(value)
            case list() | set():
                for item in data:
                    self._validate_json_value_keys(item)
            case _:
                return

    @cached_property
    @beartype
    def null_literal(self) -> str:
        """The literal representing null.

        The default ``ZVal`` model uses the union tag ``.nil``; under
        ``RECORD`` a null record field is a raw Zig ``null`` (its field
        type is the optional ``?i64``).
        """
        if self._record_strategy_active:
            return "null"
        return ".nil"

    @cached_property
    @beartype
    def true_literal(self) -> str:
        """The literal representing true.

        Raw Zig ``true`` under ``RECORD`` (a ``bool`` field), the
        ``ZVal`` union literal otherwise.
        """
        if self._record_strategy_active:
            return "true"
        return ".{ .bool = true }"

    @cached_property
    @beartype
    def false_literal(self) -> str:
        """The literal representing false.

        Raw Zig ``false`` under ``RECORD`` (a ``bool`` field), the
        ``ZVal`` union literal otherwise.
        """
        if self._record_strategy_active:
            return "false"
        return ".{ .bool = false }"

    @beartype
    def _zig_ordered_map_type(self, *, value: OrderedMap) -> str:
        """Infer a slice for uniform entries or a tuple for mixed
        entries.
        """
        value_types = [
            self._zig_resolved_value_type(item) for item in value.values()
        ]
        if len(set(value_types)) > 1:
            # Like heterogeneous sequence fields, ordered entries retain
            # each value's concrete type and their original position.
            entries = ", ".join(
                f"struct {{ key: []const u8, val: {value_type} }}"
                for value_type in value_types
            )
            return f"*const struct {{ {entries} }}"
        val_type = next(iter(value_types), "i64")
        return f"[]const struct {{ key: []const u8, val: {val_type} }}"

    def _zig_resolved_value_type(self, value: Value, /) -> str:
        """Resolve native record identities within a structural field type."""
        name_for_value = self._record_strategy.record_name_for_value
        record_name = name_for_value(value)
        if record_name is not None:
            return record_name
        return self._zig_value_type(value)

    def _zig_value_type(self, value: Value, /) -> str:
        """Return the Zig type for a raw record field *value*.

        Derived structurally from the value (never by re-parsing the
        formatted literal): scalars map to their Zig primitive, a
        homogeneous list to ``[]const <elem>``, a heterogeneous list to
        a Zig tuple ``struct { T0, ... }``, and an ordered map to a
        slice of ``key``/``val`` ``struct`` values.  A nested
        record-shaped dict never reaches here -- the shared strategy
        resolves it to its generated name in
        :meth:`_zig_record_field_type`.
        """
        match value:
            case bool():
                value_type = "bool"
            case int():
                value_type = _zig_integer_field_type(value=value)
            case float():
                value_type = "f64"
            case None:
                value_type = "?i64"
            case dt.date():
                value_type = self._zig_temporal_field_type(value)
            case OrderedMap():
                value_type = self._zig_ordered_map_type(value=value)
            case list():
                value_type = self._zig_list_type(items=value)
            case dict() if len(value) == 0:
                value_type = "@TypeOf(.{})"
            case _:
                value_type = "[]const u8"
        return value_type

    def _zig_temporal_field_type(self, value: dt.date, /) -> str:
        """Use each temporal format's produced type for record fields."""
        produced = (
            self.datetime_format.value.type_produced
            if isinstance(value, dt.datetime)
            else self.date_format.value.type_produced
        )
        return _ZIG_EPOCH_INT_FIELD_TYPES.get(produced, "[]const u8")

    def _zig_list_type(self, *, items: list[Value]) -> str:
        """Return the Zig type for a list record field.

        An empty list has no element type to infer, so it is typed as a
        ``[]const i64`` slice (``&.{}`` coerces to any slice type).  A
        list whose elements share a type is a ``[]const <elem>`` slice;
        a list mixing ``int`` and ``float`` widens to ``[]const f64``
        (its int literals coerce to ``f64``); a heterogeneous list is a
        Zig tuple ``struct { T0, T1, ... }`` (its literal is the
        anonymous tuple ``.{ ... }``, matching :attr:`sequence_open`).

        An int list with a value outside i32 range infers to
        :class:`WideInt`; its element type is taken from the *widest*
        element (``max`` keyed by :func:`_zig_int_sort_key`) via
        :meth:`_zig_value_type`, so a list whose later element exceeds
        i64 range is ``[]const u64`` rather than the ``[]const i64``
        that typing from ``items[0]`` alone would wrongly produce for
        e.g. ``[1, 1 << 63]``.  For every non-int homogeneous list the
        key ties on every element, so ``max`` keeps ``items[0]`` -- an
        arbitrary but type-equivalent representative.
        """
        if len(items) == 0:
            return "[]const i64"
        inferred = infer_element_type(items=items)
        if inferred is None:
            members = ", ".join(
                self._zig_resolved_value_type(element) for element in items
            )
            return f"struct {{ {members} }}"
        if isinstance(inferred, ListType):
            # Empty siblings provide no element-type evidence. Resolve all
            # populated descendants before assigning the enclosing slice type.
            nested_items = [
                child
                for item in items
                if isinstance(item, list)
                for child in item
            ]
            element_type = self._zig_list_type(items=nested_items)
        else:
            element_type = _ZIG_INFERRED_ELEMENT_TYPES.get(
                inferred,
                self._zig_resolved_value_type(
                    max(items, key=_zig_int_sort_key)
                ),
            )
        return f"[]const {element_type}"

    def _zig_record_field_type(self, request: RecordFieldType, /) -> str:
        """Return the Zig ``struct`` field type for a record field.

        A field whose value is itself a nested record-shaped dict uses
        that record's generated name; a field whose value is a list of
        record-shaped dicts is a ``[]const RecordN`` slice of that
        element record (its literal is ``&.{ RecordN{ ... }, ... }``);
        every other value is typed structurally from the raw value by
        :meth:`_zig_value_type`.
        """
        if request.record_name is not None:
            return request.record_name
        if request.element_record_name is not None:
            return f"[]const {request.element_record_name}"
        if (
            isinstance(request.value, dict)
            and not isinstance(request.value, OrderedMap)
            and record_shape_for_dict(value=request.value) is not None
        ):
            return _ZIG_RECORD_VALUE_NAME
        return self._zig_resolved_value_type(request.value)

    @cached_property
    @beartype
    def _record_renderer(self) -> RecordRenderer:
        """Zig syntax hooks for the ``RECORD`` strategy."""
        return RecordRenderer(
            name_prefix=self.record_struct_name_prefix,
            record_shape_names=_ZIG_NO_RECORD_SHAPE_NAMES,
            field_identifier=_zig_record_field_identifier,
            field_identifier_key=identity_field_identifier_key,
            field_type=self._zig_record_field_type,
            render_declaration=_zig_render_record_declaration,
            render_literal=_zig_record_literal,
            field_type_names_nested_records=True,
            suppress_custom_name_declarations=False,
        )

    @cached_property
    @beartype
    def _record_strategy(self) -> ActiveRecordStrategy:
        """Behavior + ``struct``-declaration preamble for ``RECORD``."""
        strategy = build_record_strategy(
            renderer=self._record_renderer,
            widen_unrecordizable_nested_sibling_maps=True,
            derecordized_map_open=".{ .map = &.{",
        )

        @beartype
        def _wrap_scalar(raw_value: Scalar, formatted: str) -> str:
            """Tag a scalar stored in a widened ``ZVal`` map."""
            if raw_value is None:
                return ".nil"
            if isinstance(raw_value, bool):
                return f".{{ .bool = {formatted} }}"
            return _format_zig_entry(
                original=raw_value,
                formatted=formatted,
                date_type=self.date_format.value.type_produced,
                datetime_type=self.datetime_format.value.type_produced,
            )

        @beartype
        def _wrap_non_scalar(raw_value: Value, formatted: str) -> str:
            """Tag a sequence payload stored in a widened ``ZVal`` map."""
            if isinstance(raw_value, list):
                return f".{{ .arr = {formatted} }}"
            return formatted

        base_compute_wrap_ids = strategy.behavior.compute_wrap_ids

        @beartype
        def _compute_wrap_ids(data: Value, /) -> frozenset[int]:
            """Tag every nested value inside a fallback map payload."""
            wrap_ids = set(base_compute_wrap_ids(data))

            _close_zig_wrapped_container_ids(
                value=data, parent_wrapped=False, wrap_ids=wrap_ids
            )
            return frozenset(wrap_ids)

        return dataclasses.replace(
            strategy,
            behavior=dataclasses.replace(
                strategy.behavior,
                compute_wrap_ids=_compute_wrap_ids,
                wrap_scalar=_wrap_scalar,
                wrap_non_scalar=_wrap_non_scalar,
                widens_nested_maps_by_wrapping_scalars=True,
            ),
        )

    @cached_property
    @beartype
    def static_preamble(self) -> Sequence[str]:
        """File-scope preamble.

        Under :attr:`json_type` only ``const std = @import("std");`` is
        emitted for the JSON value and memory allocation operations.
        The default ``ZVal`` model needs its tagged-union declaration;
        the ``RECORD`` strategy emits raw Zig values and generated
        ``struct`` declarations instead, so it needs no static
        preamble.
        """
        if self._json_type_active:
            return _STD_JSON_STATIC_PREAMBLE
        if self._record_strategy_active:
            return ()
        return _ZVAL_STATIC_PREAMBLE

    @cached_property
    @beartype
    def data_dependent_preamble(self) -> Callable[[Value], tuple[str, ...]]:
        """Return data-dependent preamble lines.

        JSON value construction needs no per-data preamble.
        Under ``RECORD`` this
        is the generated ``const Record0 = struct { ... };`` block,
        emitted in dependency order so a nested record is declared
        before its parent.
        """
        if self._json_type_active:
            return no_data_preamble
        if self._record_strategy_active:
            record_preamble = self._record_strategy.preamble
            compute_wrap_ids = self._record_strategy.behavior.compute_wrap_ids

            @beartype
            def _record_preamble(data: Value, /) -> tuple[str, ...]:
                """Emit ``ZVal`` when a nested map needs that carrier."""
                value_preamble = _RECORD_ZVAL_STATIC_PREAMBLE
                if len(compute_wrap_ids(data)) == 0:
                    value_preamble = ()
                return (*value_preamble, *record_preamble(data))

            return _record_preamble
        return no_data_preamble

    @cached_property
    @beartype
    def heterogeneous_behavior(self) -> HeterogeneousBehavior:
        """Return the heterogeneous-behavior config.

        Under :attr:`json_type` heterogeneous scalars share the JSON value
        carrier, so scalar-uniformity checks are skipped.
        ``RECORD`` resolves to the shared record behavior (its value
        needs the per-instance renderer, so it cannot be stored on the
        enum member); ``ERROR`` keeps the default ``ZVal`` model.
        """
        if self._json_type_active:
            return dataclasses.replace(
                NO_HETEROGENEOUS_BEHAVIOR,
                skip_scalar_checks=True,
            )
        if self._record_strategy_active:
            return self._record_strategy.behavior
        return NO_HETEROGENEOUS_BEHAVIOR

    call_data_dependent_preamble = default_call_data_dependent_preamble

    type_hint_collection_preamble_lines = (
        default_type_hint_collection_preamble_lines
    )

    format_call_stub = default_format_call_stub

    @cached_property
    @beartype
    def format_call_preamble_stub(
        self,
    ) -> Callable[
        [Sequence[str], Sequence[str], StubReturn, Sequence[Value]],
        tuple[str, ...],
    ]:
        """Return file-scope stubs for a call expression.

        Under :attr:`json_type` call arguments are ``std.json.Value``
        expressions rather than ``ZVal`` union literals, so the stub
        accepts ``anytype`` parameters just as the ``RECORD`` strategy
        does.
        """
        return _make_zig_call_preamble_stub(
            record_mode=self._record_strategy_active or self._json_type_active,
        )

    @cached_property
    @beartype
    def format_call_arg(self) -> Callable[[Value, str], str]:
        """Wrap each call argument in the ``ZVal`` union so call sites
        match the parameter shape emitted by
        :func:`_zig_call_preamble_stub`.

        Under :attr:`json_type` the argument is a rendered container or
        a parsed scalar ``std.json.Value`` instead.
        """
        if self._json_type_active:
            return _format_zig_json_call_arg
        return self._format_entry

    format_call_target = default_format_call_target

    format_call_ref_identifier = default_format_call_ref_identifier

    format_call_arg_ref_identifier = default_format_call_arg_ref_identifier

    format_call_arg_ref_identifier_consumable = (
        default_format_call_arg_ref_identifier_consumable
    )

    consumable_ref_value_inhibits_consuming_form = (
        default_consumable_ref_value_inhibits_consuming_form
    )

    @cached_property
    @beartype
    def sequence_format_config(self) -> SequenceFormatConfig:
        """Configuration for the chosen sequence format.

        JSON lists contain already rendered values.
        Under ``RECORD`` a list is a raw Zig literal -- a ``&.{ ... }`` slice
        (homogeneous / empty) or a ``.{ ... }`` tuple (heterogeneous),
        both closed by a single ``}`` rather than the ``ZVal``
        ``.{ .arr = &.{ ... }}`` form.  Only the closer changes here;
        the opener is chosen per list by :attr:`sequence_open`.
        """
        if self._json_type_active:
            return _STD_JSON_SEQUENCE_CONFIG
        base = self.sequence_format.value
        if self._record_strategy_active:
            return dataclasses.replace(base, close="}")
        return base

    @cached_property
    @beartype
    def set_format_config(self) -> SetFormatConfig:
        """Configuration for the chosen set format."""
        if self._json_type_active:
            return _STD_JSON_SET_CONFIG
        return self.set_format.value

    @cached_property
    @beartype
    def sequence_open(self) -> Callable[[list[Value]], str]:
        """Callable that returns the opening delimiter for a sequence.

        Under ``RECORD`` a homogeneous or empty list opens ``&.{`` so
        the literal coerces to a ``[]const T`` slice; a heterogeneous
        list opens ``.{`` so it is a Zig tuple (matching the
        ``struct { T0, ... }`` field type :meth:`_zig_value_type`
        derives).  Every other strategy keeps the ``ZVal`` array
        opener.
        """
        if self._json_type_active:
            return _STD_JSON_SEQUENCE_CONFIG.sequence_open
        if not self._record_strategy_active:
            return self.sequence_format.value.sequence_open

        @beartype
        def _open(items: list[Value]) -> str:
            """Return the slice opener, or the tuple opener for a
            heterogeneous list.
            """
            if len(items) > 0 and infer_element_type(items=items) is None:
                return ".{"
            return "&.{"

        @beartype
        def _signature(items: list[Value], /) -> CollectionSignature:
            """Retain the producer's array representation choice."""
            tuple_items = (
                len(items) > 0 and infer_element_type(items=items) is None
            )
            return CollectionSignature(
                type_key="tuple" if tuple_items else "slice",
                arity=None,
                arity_decision=False,
                fallback_decision=False,
                narrowing_decision=True,
                uses_fallback_decision=not tuple_items,
            )

        return signature_open(render=_open, infer=_signature)

    @cached_property
    @beartype
    def dict_format_config(self) -> DictFormatConfig:
        """Configuration for dict formatting.

        JSON dicts contain already rendered values.
        Under ``RECORD`` every non-empty string-keyed dict is a record
        (rendered as a generated ``struct``); the only plain dict that
        still reaches the dict formatter is the empty dict, emitted as
        the raw empty struct ``.{}`` instead of the ``ZVal``
        ``.{ .map = &.{}}`` form.
        """
        if self._json_type_active:
            return _STD_JSON_DICT_CONFIG
        base = DictFormatConfig(
            dict_open=fixed_open(open_str=".{ .map = &.{"),
            close="}}",
            format_entry=dict_entry_with_template(
                template=".{{ .key = {key}, .val = {value} }}",
                format_value=self._format_entry,
            ),
            empty_dict=None,
            preamble_lines=(),
            narrowed_open=None,
            supports_trailing_comma=True,
            narrowed_empty_form=None,
        )
        if self._record_strategy_active:
            return dataclasses.replace(base, empty_dict=".{}")
        return base

    @cached_property
    @beartype
    def trailing_comma_config(self) -> TrailingCommaConfig:
        """Configuration for trailing-comma behavior."""
        return self.trailing_comma.value

    @cached_property
    @beartype
    def format_bytes(self) -> Callable[[bytes], str]:
        """Callable that formats a bytes value as a string literal."""
        return self.bytes_format

    @cached_property
    @beartype
    def format_date(self) -> Callable[[dt.date], str]:
        """Callable that formats a date as a string literal."""
        return self.date_format

    @cached_property
    @beartype
    def format_datetime(self) -> Callable[[dt.datetime], str]:
        """Callable that formats a datetime as a string literal."""
        return self.datetime_format

    @cached_property
    @beartype
    def format_time(self) -> Callable[[dt.time], str]:
        """Callable that formats a time as a string literal."""
        return format_time_iso

    @cached_property
    @beartype
    def format_string(self) -> Callable[[str], str]:
        """Callable that formats a string value as a quoted literal."""

        @beartype
        def _format(value: str) -> str:
            """Format a string as a Zig quoted literal."""
            return format_string_backslash_control(
                value=value,
                control_char_fmt="\\x{:02x}",
                escape_delete=True,
            )

        return _format

    @cached_property
    @beartype
    def format_float(self) -> Callable[[float], str]:
        """Callable that formats a float value as a literal."""
        return self.float_format

    @cached_property
    @beartype
    def format_integer(self) -> Callable[[int], str]:
        """Callable that formats an int value as a native literal.

        Positive values above ``u64::MAX`` have no valid fixed-width Zig
        target, so reject them before formatting rather than emitting an
        overflowing literal or ``ZVal.uint`` payload.
        """
        return _make_zig_integer_formatter(
            base=self.integer_format.get_formatter(
                numeric_separator=self.numeric_separator,
            ),
        )

    @cached_property
    @beartype
    def comment_config(self) -> CommentConfig:
        """Configuration for the language's comment syntax."""
        return self.comment_format.value

    @cached_property
    @beartype
    def ordered_map_format_config(self) -> OrderedMapFormatConfig:
        """Configuration for ordered-map formatting.

        Under :attr:`json_type` ordered maps retain their entry order in a
        JSON object. An ordered map is never record-eligible, so under
        ``RECORD`` it stays a raw
        ``&.{ .{ .key = ..., .val = ... }, ... }`` collection. Its field
        type is a slice for uniform values or a tuple retaining each mixed
        entry's type, rather than the ``ZVal`` ``.{ .map = &.{ ... }}`` form.
        """
        if self._json_type_active:
            return _STD_JSON_ORDERED_MAP_CONFIG
        if self._record_strategy_active:
            return _ZigRecordOrderedMapConfig(
                ordered_map_open=fixed_open(open_str="&.{"),
                close="}",
                preamble_lines=(),
            )
        return OrderedMapFormatConfig(
            ordered_map_open=fixed_open(open_str=".{ .map = &.{"),
            close="}}",
            preamble_lines=(),
        )

    @cached_property
    @beartype
    def format_ordered_map_entry(self) -> Callable[[str, Value, str], str]:
        """Callable that formats one ordered-map entry."""
        if self._json_type_active:
            return dict_entry_with_template(
                template=".{{ .key = {key}, .value = {value} }}",
                format_value=_format_zig_json_entry,
            )
        return dict_entry_with_template(
            template=".{{ .key = {key}, .val = {value} }}",
            format_value=self._format_entry,
        )

    def reference_binding_data_dependent_preamble(
        self, data: Value, /
    ) -> tuple[str, ...]:
        """Preserve the ordinary preamble for a reference binding."""
        return self.data_dependent_preamble(data)

    @staticmethod
    def reference_declaration_imports(
        _entries: Sequence[str], /
    ) -> tuple[str, ...]:
        """Zig has no declaration-local data-dependent imports."""
        return ()

    def format_reference_variable_declaration(
        self,
        name: str,
        value: str,
        data: Value,
        modifiers: frozenset[enum.Enum],
        /,
    ) -> str:
        """Bind an existing JSON value without serializing its marker."""
        if self._json_type_active:
            keyword = self.declaration_style.value.keyword
            return f"{keyword} {name}: std.json.Value = {value};"
        return self.format_variable_declaration(name, value, data, modifiers)

    def format_reference_variable_assignment(
        self, name: str, value: str, data: Value, /
    ) -> str:
        """Assign an existing JSON value without parsing a marker."""
        if self._json_type_active:
            return _format_zig_call_assignment(
                name=name, value=value, _data=data
            )
        return self.format_variable_assignment(name, value, data)

    @cached_property
    @beartype
    def format_variable_declaration(
        self,
    ) -> Callable[[str, str, Value, frozenset[enum.Enum]], str]:
        """Callable that formats a new variable declaration.

        Under :attr:`json_type` the declaration binds a rendered container or
        parsed scalar. A ``const`` binding is emitted with an
        inferred type; a ``var`` binding gets an explicit
        ``: std.json.Value`` annotation so a subsequent assignment can
        compile against the same static type.

        Otherwise this closes over the chosen date/datetime
        ``type_produced`` so the ``ZVal`` tag selection can be driven by
        the parsed :class:`Value` rather than the rendered text.
        """
        if self._json_type_active:
            if self.declaration_style.value.keyword == "var":
                return _format_zig_json_var_declaration
            return _format_zig_json_declaration
        keyword = self.declaration_style.value.keyword
        format_entry = self._format_entry
        record_mode = self._record_strategy_active
        list_type = self._zig_list_type

        @beartype
        def _format_decl(
            name: str,
            value: str,
            data: Value,
            _modifiers: frozenset[enum.Enum],
        ) -> str:
            """Format a Zig declaration.

            The default ``ZVal`` model declares an explicit ``: ZVal``
            type; under ``RECORD`` the value is a raw Zig literal
            (a ``Record0{ ... }`` struct, slice, tuple or scalar) whose
            type is inferred. Mutable numeric scalars carry their runtime
            type. Compatible mutable nested lists carry their
            slice type so reassignment avoids inferred pointers to tuples
            of pointers in the pinned LLVM backend (issue #5469).
            """
            wrapped = format_entry(data, value)
            if record_mode:
                if (
                    keyword == "var"
                    and isinstance(data, int | float)
                    and not isinstance(data, bool)
                ):
                    value_type = self._zig_value_type(data)
                    return f"{keyword} {name}: {value_type} = {wrapped};"
                if keyword == "var" and isinstance(data, list):
                    nested = [item for item in data if isinstance(item, list)]
                    if len(nested) > 0 and len(nested) == len(data):
                        element_types = {
                            list_type(items=items)
                            for items in nested
                            if len(items) > 0
                        }
                        if len(element_types) <= 1:
                            element_type = next(
                                iter(element_types), "[]const i64"
                            )
                            return (
                                f"{keyword} {name}: []const {element_type} "
                                f"= {wrapped};"
                            )
                return f"{keyword} {name} = {wrapped};"
            return f"{keyword} {name}: ZVal = {wrapped};"

        return _format_decl

    @cached_property
    @beartype
    def format_call_variable_declaration(
        self,
    ) -> Callable[[str, str, Value, frozenset[enum.Enum]], str]:
        """Callable that formats a declaration binding a call result.

        A Zig literal binding wraps the right-hand side in a
        designated-initializer ``ZVal`` projection (``.{ .int = 42 }``),
        or a generated ``Record0{ .field = value, ... }`` struct literal
        under the ``RECORD`` strategy, and declares an explicit value
        type (``: ZVal``).  A call's return type is opaque to the
        renderer and is neither, so the call result is bound with a
        plain inferred declaration (``const my_data = make_widget(...);``
        / ``var my_data = make_widget(...);``): the Zig ``const``/``var``
        type inference means no caller-supplied return-type hint is
        needed, and the value-wrapping and ``: ZVal`` annotation are
        dropped.
        """
        keyword = self.declaration_style.value.keyword

        @beartype
        def _format_call_decl(
            name: str,
            value: str,
            _data: Value,
            _modifiers: frozenset[enum.Enum],
        ) -> str:
            """Format an inferred Zig declaration binding a call."""
            comments = _CALL_LITERAL_SYNTAX.split(value)
            return (
                f"{keyword} {name} = {comments.code};"
                + comments.trailing_comments
            )

        return _format_call_decl

    @cached_property
    @beartype
    def format_call_variable_assignment(
        self,
    ) -> Callable[[str, str, Value], str]:
        """Callable that formats an assignment binding a call result.

        The call-expression counterpart of
        :attr:`format_call_variable_declaration`; the ``ZVal`` tagging a
        literal-binding assignment applies is dropped since a call
        result is not a ``ZVal`` union literal.
        """
        return _format_zig_call_assignment

    @cached_property
    @beartype
    def scalar_preamble(self) -> dict[type, tuple[str, ...]]:
        """Per-instance scalar preamble (Zig needs none)."""
        return {}

    @cached_property
    @beartype
    def scalar_body_preamble(self) -> dict[type, tuple[str, ...]]:
        """Per-instance scalar body preamble (Zig needs none)."""
        return {}

    @cached_property
    @beartype
    def compute_body_preamble(
        self,
    ) -> Callable[[frozenset[type], Value], tuple[str, ...]]:
        """Compute body-preamble lines from the scalar map."""
        return body_preamble_from_scalars(
            scalar_body_preamble=self.scalar_body_preamble,
            format_lines=tuple,
        )


_PLAIN_JSON_SCALAR_TYPES = frozenset({str, int, float, bool, type(None)})


@beartype
def _zig_json_document_is_plain(*, data: Value) -> bool:
    """Return whether a document contains only plain JSON values."""
    pending = [data]
    while len(pending) > 0:
        value = pending.pop()
        if type(value) in _PLAIN_JSON_SCALAR_TYPES:
            if isinstance(value, int) and value > U64_MAX:
                return False
            continue
        if isinstance(value, dict) and not isinstance(value, OrderedMap):
            if any(not isinstance(key, str) for key in value):
                return False
            pending.extend(value.values())
        elif isinstance(value, list):
            pending.extend(value)
        else:
            return False
    return True


@beartype
def _format_zig_document_fast(
    language: Language,
    data: Value,
    *,
    line_prefix: str,
    include_delimiters: bool,
    collection_layout: CollectionLayout,
) -> str | None:
    """Parse reference-free JSON documents as one value.

    The document dispatch is reached only when reference handling and
    source comments are disabled. Non-JSON values still use their configured
    scalar formatters. Other rendering contexts retain the container builders
    so their already rendered child expressions survive.
    """
    is_builtin_json = (
        isinstance(language, Zig)
        and language.__class__ is Zig
        and language.json_type is Zig.JsonTypes["STD_JSON_VALUE"]
    )
    if (
        is_builtin_json
        and isinstance(data, (dict, list))
        and include_delimiters
        and collection_layout is CollectionLayout.COMPACT
        and _zig_json_document_is_plain(data=data)
    ):
        return line_prefix + _zig_parse_expression(data=data)
    return format_json_native_document_fast(
        language=language,
        data=data,
        line_prefix=line_prefix,
        include_delimiters=include_delimiters,
        collection_layout=collection_layout,
    )


_registered_zig_document_formatter: Callable[..., str | None] = (
    format_document_fast.register(cls=Zig, func=_format_zig_document_fast)
)
