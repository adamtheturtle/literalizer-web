"""OCaml language specification."""

import dataclasses
import datetime as dt
import enum
import math
import re
from collections.abc import Callable, Sequence
from functools import cached_property
from types import MappingProxyType
from typing import TYPE_CHECKING, ClassVar

from beartype import beartype

from literalizer._comments import NestingCommentSuffix
from literalizer._formatters.collection_openers import (
    fixed_open,
)
from literalizer._formatters.format_dates import (
    date_ymd_formatter,
    datetime_epoch_seconds,
    datetime_ymdhms_formatter,
    format_date_iso,
    format_datetime_epoch,
    format_datetime_iso,
    format_time_iso,
)
from literalizer._formatters.format_entries import (
    assignment_formatter_from_declaration,
    declaration_formatter_ignoring_modifiers,
    format_bytes_base64,
    format_bytes_hex,
    passthrough_sequence_entry,
    tuple_dict_entry,
    variable_declaration_formatter,
)
from literalizer._formatters.format_floats import (
    format_float_fixed,
    format_float_repr,
    format_float_scientific,
)
from literalizer._formatters.format_integers import (
    format_integer_binary,
    format_integer_hex,
    format_integer_octal,
    format_integer_underscore,
    make_overflow_fallback_formatter,
    raise_for_unrepresentable_int,
)
from literalizer._formatters.format_strings import (
    format_string_backslash_nul_octal,
)
from literalizer._formatters.record_strategy import (
    ActiveRecordStrategy,
    RecordDeclarationField,
    RecordFieldType,
    RecordLiteralField,
    RecordRenderer,
    build_record_strategy,
    identity_field_identifier_key,
)
from literalizer._json_native_document import (
    register_json_native_document_fast,
)
from literalizer._language import (
    NO_CALL_PARAMETER_LIMIT,
    NO_HETEROGENEOUS_BEHAVIOR,
    NON_KEBAB_REF_CASES,
    BareIntegerWidthStrategies,
    CallParameterShadowing,
    CallStubResult,
    CallStyle,
    CommandCallStyle,
    CommentConfig,
    DateFormatConfig,
    DateFormatEnum,
    DatetimeFormatConfig,
    DatetimeFormatEnum,
    DeclarationStyleConfig,
    DictFormatConfig,
    FileWrapperContext,
    FloatSpecialsMixin,
    FormatValueMixin,
    HeterogeneousBehavior,
    IdentifierCase,
    JsonType,
    LanguageCls,
    ModifierCombination,
    NewVariableNameSyntax,
    OrderedMapFormatConfig,
    PositionalCallStyle,
    RenderedRecordLiteral,
    SequenceFormatConfig,
    SetFormatConfig,
    StubReturn,
    TrailingCommaConfig,
    VariantMetadata,
    body_preamble_from_scalars,
    declares_binding,
    default_call_data_dependent_preamble,
    default_consumable_ref_value_inhibits_consuming_form,
    default_format_call_arg_ref_identifier,
    default_format_call_arg_ref_identifier_consumable,
    default_format_call_ref_identifier,
    default_format_call_stub,
    default_sequence_binding_declarations,
    default_type_hint_collection_preamble_lines,
    default_wrap_calls_with_declarations,
    identity_constructor_target,
    no_call_binding_body_preamble,
    no_call_binding_file_pragmas,
    no_data_preamble,
    no_format_integer_beyond_i64,
    no_format_integer_widened,
    no_leading_preamble,
    no_validate_call_arg,
    prepend_body_preamble,
    unsupported_wrap_combined_in_file_static,
)
from literalizer._types import OrderedMap, Value
from literalizer.exceptions import (
    IncompatibleFormatsError,
    UnrepresentableInputError,
)

_OCAML_SCALAR_ENTRY_TAGS: dict[type[object], str] = {
    int: "Int",
    float: "Float",
    str: "Str",
    bytes: "Str",
    dt.time: "Str",
}


@beartype
def _ocaml_native_record_declaration(
    name: str, fields: Sequence[RecordDeclarationField], /
) -> str:
    """Declare one concrete OCaml record type."""
    members = "; ".join(
        f"{field.identifier} : {field.type_name}" for field in fields
    )
    return f"type {name} = {{ {members} }}"


@beartype
def _ocaml_native_record_literal(
    name: str, fields: Sequence[RecordLiteralField], /
) -> RenderedRecordLiteral:
    """Render an annotated record to disambiguate shared labels."""
    return RenderedRecordLiteral(
        head="({",
        entries=tuple(
            f"{field.identifier} = {field.formatted}" for field in fields
        ),
        closer=f"}} : {name})",
        compact_pad=" ",
    )


@beartype
def _ocaml_native_field_identifier(key: str, /) -> str:
    """Return a validated OCaml field label."""
    return key


@beartype
def _validate_ocaml_native_record(
    data: Value, *, reserved_fields: frozenset[str]
) -> None:
    """Reject values outside the concrete OCaml record subset."""
    if isinstance(data, OrderedMap):
        msg = "OCaml record mode cannot represent ordered maps"
        raise UnrepresentableInputError(msg)
    if isinstance(data, dict):
        if len(data) == 0:
            msg = "OCaml record mode cannot represent empty records"
            raise UnrepresentableInputError(msg)
        for key, value in data.items():
            if (
                not isinstance(key, str)
                or re.fullmatch(pattern=r"[a-z][A-Za-z0-9_']*", string=key)
                is None
                or key in reserved_fields
            ):
                msg = f"OCaml record mode cannot represent field {key!r}"
                raise UnrepresentableInputError(msg)
            _validate_ocaml_native_record(
                data=value, reserved_fields=reserved_fields
            )
    elif isinstance(data, list):
        for value in data:
            _validate_ocaml_native_record(
                data=value, reserved_fields=reserved_fields
            )
    elif isinstance(data, (set, type(None))):
        msg = f"OCaml record mode cannot represent {type(data).__name__}"
        raise UnrepresentableInputError(msg)


@beartype
def _reject_ocaml_native_call_arg(_value: Value, /) -> None:
    """Reject call stubs whose argument types still assume val_t."""
    msg = "OCaml record mode cannot infer concrete call stub types"
    raise IncompatibleFormatsError(msg)


@beartype
def _ocaml_entry_tag(
    original: Value,
    date_type: type,
    datetime_type: type,
) -> str | None:
    """Return the ``val_t`` tag required for a source value."""
    if isinstance(original, dt.datetime):
        if datetime_type is dt.datetime:
            return None
        if datetime_type is int:
            return "Int"
        return "Str"
    if isinstance(original, dt.date):
        if date_type is dt.date:
            return None
        return "Str"
    return _OCAML_SCALAR_ENTRY_TAGS.get(type(original))


@beartype
def _ocaml_constructor_argument(
    original: Value, formatted: str, /, *, epoch_datetimes: bool
) -> str:
    """Parenthesize a negative numeric constructor argument."""
    match original:
        case int():
            negative = original < 0
        case float():
            negative = (
                math.isfinite(original) and math.copysign(1, original) < 0
            )
        case dt.datetime() if epoch_datetimes:
            negative = datetime_epoch_seconds(value=original) < 0
        case _:
            negative = False
    return f"({formatted})" if negative else formatted


@beartype
def _apply_ocaml_entry(
    original: Value,
    formatted: str,
    prefix: str,
    date_type: type,
    datetime_type: type,
) -> str:
    """Wrap a formatted entry in the appropriate OCaml ``val_t``
    constructor.
    """
    tag = _ocaml_entry_tag(
        original=original,
        date_type=date_type,
        datetime_type=datetime_type,
    )
    if tag is None:
        return formatted
    literal = _ocaml_constructor_argument(
        original, formatted, epoch_datetimes=datetime_type is int
    )
    return f"{prefix}{tag} {literal}"


@beartype
def _build_ocaml_entry_formatter(
    prefix: str, date_type: type, datetime_type: type
) -> Callable[[Value, str], str]:
    """Build an entry formatter that wraps values in OCaml ``val_t``
    constructors using the given *prefix*.
    """

    @beartype
    def _format(original: Value, formatted: str) -> str:
        """Delegate to module-level implementation."""
        return _apply_ocaml_entry(
            original=original,
            formatted=formatted,
            prefix=prefix,
            date_type=date_type,
            datetime_type=datetime_type,
        )

    return _format


_YOJSON_SAFE_T = "Yojson.Safe.t"

# OCaml integers use one bit for runtime tagging, so a 64-bit target has
# 63-bit signed ``int`` values.  Literalizer's supported OCaml toolchain and
# lint job target 64-bit OCaml 5.
_OCAML_INT_MIN = -(2**62)
_OCAML_INT_MAX = 2**62 - 1


@beartype
def _apply_yojson_entry(original: Value, formatted: str) -> str:
    """Wrap a formatted entry in the appropriate ``Yojson.Safe.t``
    polymorphic-variant constructor.

    Pre-wrapped literals (null, booleans, collections, and the
    arbitrary-precision ``Intlit`` fallback for integers that overflow
    the native ``int`` range) are identified from the source value and
    passed through untouched.  Other scalars get a leading
    ``Int``/``Float``/``String`` tag here.
    """
    if (
        original is None
        or isinstance(original, (bool, list, dict, set, OrderedMap))
        or (
            isinstance(original, int)
            and not _OCAML_INT_MIN <= original <= _OCAML_INT_MAX
        )
    ):
        return formatted
    match original:
        case int():
            tag = "Int"
        case float():
            tag = "Float"
        case _:
            tag = "String"
    literal = _ocaml_constructor_argument(
        original, formatted, epoch_datetimes=False
    )
    return f"`{tag} {literal}"


@beartype
def _yojson_intlit_fallback(value: int) -> str:
    """Return the ``Intlit`` poly-variant for an arbitrary-precision
    integer in ``Yojson.Safe.t`` rendering.
    """
    return f'`Intlit "{value}"'


@beartype
def _build_ocaml_call_stub_lines(
    *,
    parts: Sequence[str],
    params: Sequence[str],
    curried: bool,
) -> tuple[str, ...]:
    """Return OCaml stub declarations for a call name.

    For dotted names like ``app.client.fetch``, nested OCaml modules
    are emitted so that ``App.Client.fetch arg`` is valid at the call
    site.  The innermost name becomes a ``let`` declaration that accepts
    any argument and returns unit.  Each module-path component has its
    first character in uppercase, as OCaml requires module names to begin
    with an uppercase letter.

    Under curried calling, each parameter is bound separately
    (``let f _ _ = ()``) so that space-separated arguments at the call
    site are accepted; under positional calling, a single placeholder
    accepts the whole tuple (``let f _ = ()``).
    """
    method = parts[-1]
    if curried:
        wildcards = " ".join("_" for _ in params)
        lines: list[str] = [f"let {method} {wildcards} = ()"]
    else:
        lines = [f"let {method} _ = ()"]
    for part in reversed(parts[:-1]):
        cap = part[0].upper() + part[1:]
        lines = [f"module {cap} = struct", *lines, "end"]
    return tuple(lines)


@beartype
def _ocaml_call_stub(
    parts: Sequence[str],
    params: Sequence[str],
    _stub_return: StubReturn,
    _args: Sequence[Value],
    /,
) -> tuple[str, ...]:
    """Return OCaml positional (tuple-form) stub declarations."""
    return _build_ocaml_call_stub_lines(
        parts=parts, params=params, curried=False
    )


@beartype
def _ocaml_curried_call_stub(
    parts: Sequence[str],
    params: Sequence[str],
    _stub_return: StubReturn,
    _args: Sequence[Value],
    /,
) -> tuple[str, ...]:
    """Return OCaml curried stub declarations."""
    return _build_ocaml_call_stub_lines(
        parts=parts, params=params, curried=True
    )


@beartype
def _ocaml_format_call_arg(_original: Value, formatted: str, /) -> str:
    """Wrap a formatted OCaml value in parentheses for curried application."""
    return f"({formatted})"


@beartype
def _ocaml_call_target(parts: Sequence[str], /) -> str:
    """Return the dotted OCaml call target for a sequence of name parts.

    Module components (all but the last) have their first character
    converted to uppercase because OCaml requires module names to begin
    with an uppercase letter.
    """
    if len(parts) == 1:
        return parts[0]
    modules = [p[0].upper() + p[1:] for p in parts[:-1]]
    return ".".join([*modules, parts[-1]])


@beartype
def _apply_ocaml_declaration(
    *,
    name: str,
    value: str,
    data: Value,
    sequence_declared_type: str,
    scalar_declared_type: str,
    entry_formatter: Callable[[Value, str], str],
) -> str:
    """Format a variable declaration."""
    decl_type = scalar_declared_type
    if isinstance(data, list):
        decl_type = sequence_declared_type
    wrapped = entry_formatter(data, value)
    return f"let {name} : {decl_type} = {wrapped}"


@beartype
def _build_ocaml_declaration(
    *,
    sequence_declared_type: str,
    scalar_declared_type: str,
    entry_formatter: Callable[[Value, str], str],
) -> Callable[[str, str, Value], str]:
    """Build an OCaml variable declaration formatter."""

    @beartype
    def _format(name: str, value: str, data: Value) -> str:
        """Delegate to module-level implementation."""
        return _apply_ocaml_declaration(
            name=name,
            value=value,
            data=data,
            sequence_declared_type=sequence_declared_type,
            scalar_declared_type=scalar_declared_type,
            entry_formatter=entry_formatter,
        )

    return _format


# Work around https://github.com/astral-sh/ty/issues/4573.
if TYPE_CHECKING:
    _BytesEnumMember = enum.member[Callable[[bytes], str]]
else:
    _BytesEnumMember = enum.member


@beartype
def _ocaml_call_statement(statement: str, /) -> str:
    """Bind a call result to the wildcard identifier."""
    return f"let _ = {statement}"


@beartype
def _ocaml_record_declaration(name: str, value: str, _data: Value, /) -> str:
    """Declare an inferred native record."""
    return f"let {name} = {value}"


@beartype
@dataclasses.dataclass(frozen=True, kw_only=True)
class OCaml(metaclass=LanguageCls):
    """OCaml language specification.

    Args:
        date_format: How to format :class:`datetime.date` values.

            * ``date_formats.OCAML`` — tuple literal,
              e.g. ``(2024, 1, 15)``.
            * ``date_formats.ISO`` — ISO 8601 quoted string,
              e.g. ``"2024-01-15"``.

        datetime_format: How to format :class:`datetime.datetime` values.

            * ``datetime_formats.OCAML`` — pair of tuples,
              e.g. ``((2024, 1, 15), (12, 30, 0))``.
            * ``datetime_formats.ISO`` — ISO 8601 quoted string,
              e.g. ``"2024-01-15T12:30:00"``.

        dict_format: ``DEFAULT`` keeps the generated ``val_t`` union;
            ``RECORD`` emits concrete annotated records for valid,
            fixed-shape objects. Generated call stubs are not supported
            in record mode.

        type_name: Name of the generated custom type.  Defaults to
            ``"val_t"``.

        constructor_prefix: Prefix for generated constructor names.
            Defaults to ``"O"``, producing constructors like ``ONull``,
            ``OBool``, ``OInt``, etc.

        json_type: Opt into rendering through a JSON value type instead
            of the generated tagged ADT.

            * ``None`` (default) --- emit the custom ``val_t`` ADT.
            * ``json_types.YOJSON_SAFE_T`` --- emit ``Yojson.Safe.t``
              polymorphic-variant literals using the standard
              ``yojson`` tag set (``Bool``, ``Int``, ``Float``,
              ``String``, ``Null``, ``List``, ``Assoc``, ``Intlit``).  Dates,
              datetimes, times, and bytes reformat to JSON-friendly
              strings; integers outside the native OCaml ``int`` range
              route through the ``Intlit`` escape hatch; the ``type val_t``
              preamble is dropped.
    """

    format_call_class_scope_stub = default_format_call_stub

    reserved_module_identifiers: ClassVar[frozenset[str]] = frozenset()
    immutable_variable_modifiers: ClassVar[frozenset[enum.Enum]] = frozenset()
    wrap_in_file_tolerates_pre_indent = True
    module_name_shares_variable_scope = False
    reserved_variable_identifier_pattern: ClassVar[re.Pattern[str] | None] = (
        None
    )
    reserved_call_parameter_identifiers: ClassVar[frozenset[str]] = frozenset()
    reserved_call_parameter_identifier_pattern: ClassVar[
        re.Pattern[str] | None
    ] = None
    accepts_type_name_call_target = True
    dotted_call_root_shares_entrypoint_namespace = True
    reserved_bare_call_target_identifiers: ClassVar[frozenset[str]] = (
        frozenset()
    )
    reserved_call_target_head_identifiers: ClassVar[frozenset[str]] = (
        frozenset()
    )
    contextual_call_target_identifiers: ClassVar[frozenset[str]] = frozenset()
    call_parameter_shadowing = CallParameterShadowing.ALLOWED
    reserved_call_target_keywords_case_sensitive = True
    module_name_must_start_uppercase = False
    max_variable_identifier_length: ClassVar[int | None] = None
    supports_multiline_dict_layout = True
    pools_map_integer_width = True

    # An OCaml value name begins with a lowercase letter or an
    # underscore; a capitalized name is a constructor, so ``let
    # Module ...`` is a pattern rather than a binding
    # (issue #4525).
    # A wrapped file declares the call target as a function, and a
    # capitalized name is a constructor rather than a function name,
    # so the constructor-target exemption stops there (issue #4525).
    declares_type_name_call_target: ClassVar[bool] = False
    new_variable_name_syntax: ClassVar[NewVariableNameSyntax] = (
        NewVariableNameSyntax.LOWER_ASCII
    )
    # A qualified target names a module, which OCaml spells with
    # an initial capital; the declaration grammar above governs
    # what a wrapped file can declare (issue #4525).
    call_stub_result: ClassVar[CallStubResult | None] = None
    call_literal_syntax: ClassVar[None] = None
    call_target_name_syntax: ClassVar[NewVariableNameSyntax] = (
        NewVariableNameSyntax.ASCII
    )

    format_integer_widened = no_format_integer_widened
    format_integer_beyond_i64 = no_format_integer_beyond_i64
    format_constructor_target: ClassVar["staticmethod[[str], str]"] = (
        staticmethod(identity_constructor_target)
    )
    sequence_binding_declarations = default_sequence_binding_declarations
    format_call_binding_body_preamble = no_call_binding_body_preamble
    format_call_binding_file_pragmas = no_call_binding_file_pragmas

    leading_preamble = no_leading_preamble
    extension = ".ml"
    pygments_name = "ocaml"
    stringifies_nested_collections = False
    supports_special_floats = True
    supports_variable_names = True
    supports_no_variable_wrap_in_file = False
    wraps_data_dependent_preamble_in_body = False
    dict_supports_heterogeneous_values = True
    supports_native_invocations = False
    supports_dotted_calls = True
    has_free_function_calls = True
    declares_call_parameter_names = True
    reserved_variable_identifiers_case_sensitive: bool = True
    reserved_variable_identifiers: frozenset[str] = frozenset(
        {
            "and",
            "as",
            "assert",
            "begin",
            "class",
            "constraint",
            "do",
            "done",
            "downto",
            "else",
            "end",
            "exception",
            "external",
            "false",
            "for",
            "fun",
            "function",
            "functor",
            "if",
            "in",
            "include",
            "inherit",
            "initializer",
            "lazy",
            "let",
            "match",
            "method",
            "module",
            "mutable",
            "new",
            "object",
            "of",
            "open",
            "or",
            "private",
            "rec",
            "sig",
            "struct",
            "then",
            "to",
            "true",
            "try",
            "type",
            "val",
            "virtual",
            "when",
            "while",
            "with",
        }
    )
    reserved_identifiers: ClassVar[frozenset[str]] = (
        reserved_variable_identifiers
    )
    allows_empty_call_parens = True
    supports_dotted_call_stub = False
    call_returns_expression = True
    supports_json_call_result_binding = False
    supports_zero_parameter_calls = True
    max_call_parameters = NO_CALL_PARAMETER_LIMIT
    supports_inline_multiline_dict_args = True
    supports_standalone_comments_in_wrapped_calls = True
    supports_multi_param_call_wrapper_stub = True
    supports_dict_literal_as_free_expression = True
    supports_module_name = False
    supports_empty_dict_key = False
    supports_call_style = True
    supports_default_dict_key_type = False
    supports_default_dict_value_type = False
    supports_default_sequence_element_type = False
    supports_default_set_element_type = False
    supports_default_ordered_map_value_type = False
    json_type_variant_name_suffix: ClassVar[str | None] = None
    supports_non_ascii_string_literals = True
    supports_multiline_string_literals = False
    supports_empty_sibling_sequence_type_hints = True
    supports_typed_dict_open = False
    language_id: ClassVar[str] = "ocaml"
    variant_metadata: ClassVar[VariantMetadata] = VariantMetadata(
        round_trip_capabilities=frozenset(),
        modifier_sequence_format_overrides={},
        string_literals_escape_null_byte=True,
        supports_ref_elements_in_tuple_strategy=False,
    )
    supports_record_struct_name_prefix = False
    supports_record_shape_names = False
    record_shape_names_emit_declarations = False
    supports_non_string_dict_keys = False
    checks_raw_control_dict_keys_separately = False

    class DateFormats(DateFormatEnum):
        """Date format options for OCaml."""

        OCAML = DateFormatConfig(
            formatter=date_ymd_formatter(
                template="ODate ({year}, {month}, {day})",
            ),
            preamble_lines=(),
            type_produced=dt.date,
        )
        ISO = DateFormatConfig(
            formatter=format_date_iso, type_produced=str, preamble_lines=()
        )

    class DatetimeFormats(DatetimeFormatEnum):
        """Datetime format options for OCaml."""

        OCAML = DatetimeFormatConfig(
            formatter=datetime_ymdhms_formatter(
                template="ODatetime (({year}, {month}, {day}), "
                "({hour}, {minute}, {second}))",
                millisecond_template=None,
            ),
            preamble_lines=(),
            type_produced=dt.datetime,
        )
        ISO = DatetimeFormatConfig(
            formatter=format_datetime_iso,
            type_produced=str,
            preamble_lines=(),
        )

        EPOCH = DatetimeFormatConfig(
            formatter=format_datetime_epoch,
            type_produced=int,
            preamble_lines=(),
        )

    class BytesFormats(FormatValueMixin[Callable[[bytes], str]], enum.Enum):
        """Bytes formatting options."""

        HEX = _BytesEnumMember(value=format_bytes_hex)
        BASE64 = _BytesEnumMember(value=format_bytes_base64)

        def __call__(self, data: bytes, /) -> str:
            """Format bytes."""
            return self.value(data)

    class SequenceFormats(enum.Enum):
        """Sequence type options for OCaml."""

        LIST = SequenceFormatConfig(
            length_is_part_of_type=False,
            sequence_open=fixed_open(open_str="OList ["),
            close="]",
            supports_heterogeneity=True,
            single_element_trailing_comma=False,
            single_element_template=None,
            supports_trailing_comma=False,
            empty_sequence=None,
            preamble_lines=(),
            format_entry=passthrough_sequence_entry,
            typed_opener_fallback=None,
            uses_typed_literal_for_scalars=False,
            requires_uniform_record_shapes=False,
            declared_type="val_t",
            narrowed_empty_form=None,
        )
        ARRAY = SequenceFormatConfig(
            length_is_part_of_type=False,
            sequence_open=fixed_open(open_str="[|"),
            close="|]",
            supports_heterogeneity=True,
            single_element_trailing_comma=False,
            single_element_template=None,
            supports_trailing_comma=False,
            empty_sequence=None,
            preamble_lines=(),
            format_entry=passthrough_sequence_entry,
            typed_opener_fallback=None,
            uses_typed_literal_for_scalars=False,
            requires_uniform_record_shapes=False,
            declared_type="val_t array",
            narrowed_empty_form=None,
        )

    class SetFormats(enum.Enum):
        """Set type options for OCaml."""

        SET = SetFormatConfig(
            set_open=fixed_open(open_str="OSet ["),
            close="]",
            empty_set=None,
            preamble_lines=(),
            set_opener_template="",
            supports_heterogeneity=True,
            supports_trailing_comma=True,
        )

    class CommentFormats(enum.Enum):
        """Comment style options."""

        PAREN_STAR = CommentConfig(
            prefix="(*",
            suffix=NestingCommentSuffix(object=" *)"),
        )

    class DeclarationStyles(enum.Enum):
        """Declaration style options."""

        LET = DeclarationStyleConfig(
            formatter=variable_declaration_formatter(
                template="let {name} = {value}",
            ),
            supports_redefinition=False,
        )

    class DictEntryStyles(enum.Enum):
        """Dict entry style options."""

        DEFAULT = enum.auto()

    class DictFormats(enum.Enum):
        """Dict/map format options."""

        DEFAULT = enum.auto()
        RECORD = enum.auto()

    class EmptyDictKey(enum.Enum):
        """Empty dict key options."""

        ALLOW = enum.auto()

    class FloatFormats(
        FloatSpecialsMixin,
        enum.Enum,
        positive_infinity="infinity",
        negative_infinity="neg_infinity",
        nan="nan",
    ):
        """Float format options."""

        REPR = enum.member(value=format_float_repr)
        SCIENTIFIC = enum.member(value=format_float_scientific)
        FIXED = enum.member(value=format_float_fixed)

    class IntegerFormats(enum.Enum):
        """Integer format options."""

        DECIMAL = MappingProxyType(
            mapping={
                "NONE": str,
                "UNDERSCORE": format_integer_underscore,
            }
        )
        HEX = MappingProxyType(
            mapping={
                "NONE": format_integer_hex,
                "UNDERSCORE": format_integer_hex,
            }
        )
        OCTAL = MappingProxyType(
            mapping={
                "NONE": format_integer_octal,
                "UNDERSCORE": format_integer_octal,
            }
        )
        BINARY = MappingProxyType(
            mapping={
                "NONE": format_integer_binary,
                "UNDERSCORE": format_integer_binary,
            }
        )

        def get_formatter(
            self,
            numeric_separator: enum.Enum,
        ) -> Callable[[int], str]:
            """Return the integer formatter for the given separator."""
            formatter: Callable[[int], str] = self.value[
                numeric_separator.name
            ]
            return formatter

    class NumericLiteralSuffixes(enum.Enum):
        """Numeric literal suffix options."""

        NONE = enum.auto()

    class NumericSeparators(enum.Enum):
        """Numeric separator options."""

        NONE = enum.auto()
        UNDERSCORE = enum.auto()

    class NumericStyles(enum.Enum):
        """Numeric literal style options."""

        OVERLOADED = enum.auto()

    class StringFormats(enum.Enum):
        """String format options."""

        DOUBLE = enum.auto()

    class TrailingCommas(enum.Enum):
        """Trailing comma options."""

        NO = TrailingCommaConfig(multiline_trailing_comma=False)

    date_formats = DateFormats
    datetime_formats = DatetimeFormats
    bytes_formats = BytesFormats
    sequence_formats = SequenceFormats
    set_formats = SetFormats
    comment_formats = CommentFormats

    class VariableTypeHints(enum.Enum):
        """Variable type hint options."""

        NEVER = enum.auto()
        SAFE = enum.auto()

    variable_type_hints_formats = VariableTypeHints
    declaration_styles = DeclarationStyles
    dict_entry_styles = DictEntryStyles
    dict_formats = DictFormats
    empty_dict_keys = EmptyDictKey
    float_formats = FloatFormats
    integer_formats = IntegerFormats
    integer_width_strategies = BareIntegerWidthStrategies
    numeric_literal_suffixes = NumericLiteralSuffixes
    numeric_separators = NumericSeparators
    numeric_styles = NumericStyles
    string_formats = StringFormats
    trailing_commas = TrailingCommas

    class StatementTerminatorStyles(enum.Enum):
        """Statement terminator options."""

        SEMICOLON = enum.auto()

    statement_terminator_styles = StatementTerminatorStyles

    class CallStyles(enum.Enum):
        """OCaml call style options."""

        POSITIONAL = PositionalCallStyle(
            arg_separator=", ", parenthesize_each_arg=False
        )
        CURRIED = CommandCallStyle(
            arg_separator=" ",
        )

    call_styles = CallStyles

    class Modifiers(enum.Enum):
        """C++/Java/C#-style declaration modifiers: this language has none."""

    modifiers = Modifiers

    class HeterogeneousStrategies(enum.Enum):
        """Heterogeneous-scalar strategy options — this language only
        supports raising.
        """

        ERROR = NO_HETEROGENEOUS_BEHAVIOR

    heterogeneous_strategies = HeterogeneousStrategies

    class BoolFormats(enum.Enum):
        """Empty: this language has no alternative boolean formats."""

    bool_formats = BoolFormats

    class VersionFormats(enum.Enum):
        """Version options for OCaml."""

        V5 = enum.auto()

    version_formats = VersionFormats

    class JsonTypes(JsonType):
        """JSON value type options for OCaml."""

        YOJSON_SAFE_T = _YOJSON_SAFE_T
        """``Yojson.Safe.t`` --- the polymorphic-variant JSON value type
        from the ``yojson`` package.
        """

    json_types = JsonTypes

    modifier_combinations: ClassVar[tuple[ModifierCombination, ...]] = ()
    identifier_cases: ClassVar[tuple[IdentifierCase, ...]] = (
        IdentifierCase.SNAKE,
        IdentifierCase.PASCAL,
    )
    supported_ref_cases: ClassVar[frozenset[IdentifierCase]] = (
        NON_KEBAB_REF_CASES
    )

    def validate_spec_for_data(self, data: Value) -> None:
        """Check values and formats for the native record mode."""
        if self.dict_format is type(self.dict_format).RECORD:
            if (
                re.fullmatch(
                    pattern=r"[a-z][A-Za-z0-9_']*",
                    string=self.type_name,
                )
                is None
                or self.type_name in self.reserved_variable_identifiers
            ):
                msg = "OCaml record mode requires a valid type_name"
                raise UnrepresentableInputError(msg)
            if self.json_type is not None:
                msg = "OCaml records cannot be combined with json_type"
                raise IncompatibleFormatsError(msg)
            if self.sequence_format is not type(self.sequence_format).LIST:
                msg = "OCaml records require sequence_format=LIST"
                raise IncompatibleFormatsError(msg)
            _validate_ocaml_native_record(
                data=data, reserved_fields=self.reserved_variable_identifiers
            )

    @cached_property
    @beartype
    def validate_call_arg(self) -> Callable[[Value], None]:
        """Return call-argument validation for this language."""
        if self.dict_format is type(self.dict_format).RECORD:
            return _reject_ocaml_native_call_arg
        return no_validate_call_arg

    wrap_calls_with_declarations = default_wrap_calls_with_declarations

    @staticmethod
    def wrap_in_file(
        content: str,
        context: FileWrapperContext,
    ) -> str:
        """Wrap an OCaml let declaration in a module."""
        body_preamble = context.body_preamble
        content = prepend_body_preamble(
            content=content,
            body_preamble=body_preamble,
        )
        return "module Check = struct\n\n" + content + "\n\nend"

    wrap_combined_in_file: ClassVar[
        "staticmethod[[str, str, FileWrapperContext], str]"
    ] = unsupported_wrap_combined_in_file_static

    date_format: DateFormats = DateFormats.OCAML
    datetime_format: DatetimeFormats = DatetimeFormats.OCAML
    bytes_format: BytesFormats = BytesFormats.HEX
    sequence_format: SequenceFormats = SequenceFormats.LIST
    set_format: SetFormats = SetFormats.SET
    variable_type_hints: VariableTypeHints = VariableTypeHints.NEVER
    comment_format: CommentFormats = CommentFormats.PAREN_STAR
    declaration_style: DeclarationStyles = DeclarationStyles.LET
    dict_entry_style: DictEntryStyles = DictEntryStyles.DEFAULT
    dict_format: DictFormats = DictFormats.DEFAULT
    float_format: FloatFormats = FloatFormats.REPR
    integer_format: IntegerFormats = IntegerFormats.DECIMAL
    integer_width_strategy: BareIntegerWidthStrategies = (
        BareIntegerWidthStrategies.BARE
    )
    numeric_literal_suffix: NumericLiteralSuffixes = (
        NumericLiteralSuffixes.NONE
    )
    numeric_separator: NumericSeparators = NumericSeparators.NONE
    numeric_style: NumericStyles = NumericStyles.OVERLOADED
    string_format: StringFormats = StringFormats.DOUBLE
    trailing_comma: TrailingCommas = TrailingCommas.NO
    statement_terminator_style: StatementTerminatorStyles = (
        StatementTerminatorStyles.SEMICOLON
    )
    call_style: CallStyles = CallStyles.POSITIONAL
    heterogeneous_strategy: HeterogeneousStrategies = (
        HeterogeneousStrategies.ERROR
    )
    # Keep in sync with the ``ocaml-compiler`` input of the
    # ``Install OCaml`` step in ``.github/workflows/lint.yml``, which
    # pins ``5`` (latest OCaml 5.x), satisfying this ``V5`` default.
    language_version: VersionFormats = VersionFormats.V5
    indent: str = "    "
    type_name: str = "val_t"
    constructor_prefix: str = "O"
    json_type: JsonTypes | None = None

    indent_closing_delimiter: ClassVar[bool] = False
    element_separator: ClassVar[str] = "; "
    skip_null_dict_values: ClassVar[bool] = False
    supports_collection_comments: ClassVar[bool] = True
    supports_scalar_before_comments: ClassVar[bool] = True
    supports_scalar_inline_comments: ClassVar[bool] = True
    statement_terminator: ClassVar[str] = ""
    static_preamble: ClassVar[Sequence[str]] = ()
    static_body_preamble: ClassVar[Sequence[str]] = ()
    special_float_preamble: ClassVar[tuple[str, ...]] = ()

    @cached_property
    @beartype
    def format_string(self) -> Callable[[str], str]:
        """Format a string value as a quoted literal."""
        return format_string_backslash_nul_octal

    @cached_property
    @beartype
    def data_dependent_preamble(self) -> Callable[[Value], tuple[str, ...]]:
        """Return data-dependent preamble lines."""
        return no_data_preamble

    @cached_property
    @beartype
    def heterogeneous_behavior(self) -> HeterogeneousBehavior:
        """Return the heterogeneous-behavior config."""
        if self.dict_format is type(self.dict_format).RECORD:
            return self._native_record_strategy.behavior
        return self.heterogeneous_strategy.value

    def _native_record_field_type(self, request: RecordFieldType, /) -> str:
        """Return the concrete type of a record field."""
        if request.record_name is not None:
            return request.record_name
        if request.element_record_name is not None:
            return f"{request.element_record_name} list"
        return self._native_value_type(data=request.value)

    def _native_value_type(self, data: Value) -> str:
        """Infer the OCaml type of a scalar or list."""
        if isinstance(data, list):
            if len(data) == 0:
                msg = "OCaml record mode cannot infer empty list element types"
                raise UnrepresentableInputError(msg)
            return f"{self._native_value_type(data=data[0])} list"
        scalar_types: dict[type, str] = {
            bool: "bool",
            int: "int",
            float: "float",
            str: "string",
            bytes: "string",
            dt.time: "string",
        }
        scalar_type = scalar_types.get(type(data))
        if scalar_type is not None:
            return scalar_type
        if isinstance(data, dt.datetime):
            datetime_types: dict[type, str] = {
                int: "int",
                str: "string",
                dt.datetime: ("((int * int * int) * (int * int * int))"),
            }
            return datetime_types[self.datetime_format.value.type_produced]
        if isinstance(data, dt.date):
            date_types: dict[type, str] = {
                str: "string",
                dt.date: "(int * int * int)",
            }
            return date_types[self.date_format.value.type_produced]
        msg = f"OCaml record mode cannot type {type(data).__name__}"
        raise UnrepresentableInputError(msg)

    @cached_property
    @beartype
    def _native_record_strategy(self) -> ActiveRecordStrategy:
        """Build shared record naming, rendering, and declarations."""
        return build_record_strategy(
            renderer=RecordRenderer(
                name_prefix=self.type_name,
                record_shape_names={},
                field_identifier=_ocaml_native_field_identifier,
                field_identifier_key=identity_field_identifier_key,
                field_type=self._native_record_field_type,
                render_declaration=_ocaml_native_record_declaration,
                render_literal=_ocaml_native_record_literal,
                field_type_names_nested_records=True,
                suppress_custom_name_declarations=False,
            ),
            widen_unrecordizable_nested_sibling_maps=False,
            derecordized_map_open=None,
        )

    call_data_dependent_preamble = default_call_data_dependent_preamble

    type_hint_collection_preamble_lines = (
        default_type_hint_collection_preamble_lines
    )

    @cached_property
    @beartype
    def call_style_config(self) -> CallStyle:
        """Configuration for the chosen call style."""
        config: CallStyle = self.call_style.value
        return config

    @cached_property
    @beartype
    def format_call_stub(
        self,
    ) -> Callable[
        [Sequence[str], Sequence[str], StubReturn, Sequence[Value]],
        tuple[str, ...],
    ]:
        """Return stub declarations for a call expression."""
        if isinstance(self.call_style.value, CommandCallStyle):
            return _ocaml_curried_call_stub
        return _ocaml_call_stub

    @cached_property
    @beartype
    def format_call_arg(self) -> Callable[[Value, str], str]:
        """Callable that rewrites a formatted direct call argument.

        Curried calls parenthesize each argument so that constructor
        applications are not parsed as additional arguments to the outer
        call.
        """
        entry_formatter = self._entry_formatter
        if isinstance(self.call_style.value, CommandCallStyle):

            @beartype
            def _curried_arg(original: Value, formatted: str) -> str:
                """Tag the value and parenthesize the curried argument."""
                tagged = entry_formatter(original, formatted)
                return _ocaml_format_call_arg(original, tagged)

            return _curried_arg
        return entry_formatter

    format_call_preamble_stub = default_format_call_stub

    @cached_property
    @beartype
    def format_call_statement(self) -> Callable[[str], str]:
        """Wrap a call expression as a let binding."""
        return _ocaml_call_statement

    @cached_property
    @beartype
    def format_call_target(self) -> Callable[[Sequence[str]], str]:
        """Rewrite a dotted call target into the language's call
        syntax.
        """
        return _ocaml_call_target

    format_call_ref_identifier = default_format_call_ref_identifier

    format_call_arg_ref_identifier = default_format_call_arg_ref_identifier

    format_call_arg_ref_identifier_consumable = (
        default_format_call_arg_ref_identifier_consumable
    )

    def format_nested_ref_identifier(
        self, identifier: str, value: Value | None, /
    ) -> str:
        """Box native arrays when embedding their bindings in val_t."""
        if self.sequence_format is type(
            self.sequence_format
        ).ARRAY and isinstance(value, list):
            return self.format_sequence_entry(value, identifier)
        return identifier

    consumable_ref_value_inhibits_consuming_form = (
        default_consumable_ref_value_inhibits_consuming_form
    )

    @cached_property
    @beartype
    def _json_type_active(self) -> bool:
        """Return whether OCaml should render as ``Yojson.Safe.t``."""
        return self.json_type is not None

    @cached_property
    @beartype
    def null_literal(self) -> str:
        """Null literal using the configured constructor prefix."""
        if self._json_type_active:
            return "`Null"
        return f"{self.constructor_prefix}Null"

    @cached_property
    @beartype
    def true_literal(self) -> str:
        """True literal using the configured constructor prefix."""
        if self._json_type_active:
            return "`Bool true"
        if self.dict_format is type(self.dict_format).RECORD:
            return "true"
        return f"{self.constructor_prefix}Bool true"

    @cached_property
    @beartype
    def false_literal(self) -> str:
        """False literal using the configured constructor prefix."""
        if self._json_type_active:
            return "`Bool false"
        if self.dict_format is type(self.dict_format).RECORD:
            return "false"
        return f"{self.constructor_prefix}Bool false"

    @cached_property
    @beartype
    def _entry_formatter(self) -> Callable[[Value, str], str]:
        """Entry formatter built from the configured prefix."""
        if self._json_type_active:
            return _apply_yojson_entry
        return _build_ocaml_entry_formatter(
            prefix=self.constructor_prefix,
            date_type=self.date_format.value.type_produced,
            datetime_type=self.datetime_format.value.type_produced,
        )

    @cached_property
    @beartype
    def _nested_entry_formatter(self) -> Callable[[Value, str], str]:
        """Wrap nested arrays in the selected value carrier
        constructor.
        """
        base = self._entry_formatter
        if (
            self._json_type_active
            or self.sequence_format is not type(self.sequence_format).ARRAY
        ):
            return base
        prefix = self.constructor_prefix

        @beartype
        def _format(original: Value, formatted: str) -> str:
            """Tag array entries while leaving root arrays unwrapped."""
            if isinstance(original, list):
                return f"{prefix}Array {formatted}"
            return base(original, formatted)

        return _format

    @staticmethod
    @beartype
    def format_sequence_expression(expressions: Sequence[str], /) -> str:
        """Construct a native list of arbitrary result expressions."""
        return "[" + "; ".join(expressions) + "]"

    @cached_property
    @beartype
    def sequence_format_config(self) -> SequenceFormatConfig:
        """Configuration for the chosen sequence format."""
        fmt: SequenceFormatConfig = self.sequence_format.value
        if self._json_type_active:
            _yojson_open = fixed_open(open_str="`List [")
            return dataclasses.replace(fmt, sequence_open=_yojson_open)
        if self.dict_format is type(self.dict_format).RECORD:
            return dataclasses.replace(
                fmt,
                sequence_open=fixed_open(open_str="["),
                supports_heterogeneity=False,
                declared_type=None,
            )
        if self.sequence_format is type(self.sequence_format).LIST:
            _seq_open = fixed_open(
                open_str=f"{self.constructor_prefix}List [",
            )
            return dataclasses.replace(fmt, sequence_open=_seq_open)
        return fmt

    @cached_property
    @beartype
    def sequence_open(self) -> Callable[[list[Value]], str]:
        """Callable that returns the opening delimiter for a sequence."""
        fmt = self.sequence_format.value
        if self._json_type_active:
            return fixed_open(open_str="`List [")
        if self.dict_format is type(self.dict_format).RECORD:
            return fixed_open(open_str="[")
        if self.sequence_format is type(self.sequence_format).LIST:
            return fixed_open(
                open_str=f"{self.constructor_prefix}List [",
            )
        return fmt.sequence_open

    @cached_property
    @beartype
    def set_format_config(self) -> SetFormatConfig:
        """Configuration for the chosen set format."""
        # ``Yojson.Safe.t`` has no set constructor: render sets as JSON
        # arrays (``\`List``) the same as sequences.
        set_open_str = "`List ["
        if not self._json_type_active:
            set_open_str = f"{self.constructor_prefix}Set ["
        return dataclasses.replace(
            self.set_format.value,
            set_open=fixed_open(open_str=set_open_str),
        )

    @cached_property
    @beartype
    def dict_format_config(self) -> DictFormatConfig:
        """Configuration for dict formatting."""
        dict_open_str = "`Assoc ["
        if not self._json_type_active:
            dict_open_str = f"{self.constructor_prefix}Map ["
        return DictFormatConfig(
            dict_open=fixed_open(open_str=dict_open_str),
            close="]",
            format_entry=tuple_dict_entry(
                format_value=self._nested_entry_formatter,
            ),
            empty_dict=None,
            preamble_lines=(),
            narrowed_open=None,
            supports_trailing_comma=True,
            narrowed_empty_form=None,
        )

    @cached_property
    @beartype
    def trailing_comma_config(self) -> TrailingCommaConfig:
        """Configuration for trailing-comma behavior."""
        return self.trailing_comma.value

    @cached_property
    @beartype
    def format_bytes(self) -> Callable[[bytes], str]:
        """Callable that formats a bytes value as a string literal."""
        return self.bytes_format

    @cached_property
    @beartype
    def format_date(self) -> Callable[[dt.date], str]:
        """Callable that formats a date as a string literal."""
        base_formatter: Callable[[dt.date], str] = self.date_format
        if self._json_type_active:
            return format_date_iso
        if self.date_format is type(self.date_format).OCAML:
            if self.dict_format is type(self.dict_format).RECORD:
                return date_ymd_formatter(template="({year}, {month}, {day})")
            return date_ymd_formatter(
                template=(
                    f"{self.constructor_prefix}Date "
                    "({year}, {month}, {day})"
                ),
            )
        return base_formatter

    @cached_property
    @beartype
    def format_datetime(self) -> Callable[[dt.datetime], str]:
        """Callable that formats a datetime as a string literal."""
        base_formatter: Callable[[dt.datetime], str] = self.datetime_format
        if self._json_type_active:
            return format_datetime_iso
        if self.datetime_format is type(self.datetime_format).OCAML:
            if self.dict_format is type(self.dict_format).RECORD:
                return datetime_ymdhms_formatter(
                    template="(({year}, {month}, {day}), "
                    "({hour}, {minute}, {second}))",
                    millisecond_template=None,
                )
            return datetime_ymdhms_formatter(
                template=(
                    f"{self.constructor_prefix}Datetime "
                    f"(({{year}}, {{month}}, {{day}}), "
                    f"({{hour}}, {{minute}}, {{second}}))"
                ),
                millisecond_template=None,
            )
        return base_formatter

    @cached_property
    @beartype
    def format_time(self) -> Callable[[dt.time], str]:
        """Callable that formats a time as a string literal."""
        return format_time_iso

    @cached_property
    @beartype
    def format_float(self) -> Callable[[float], str]:
        """Callable that formats a float value as a literal."""
        return self.float_format

    @cached_property
    @beartype
    def format_integer(self) -> Callable[[int], str]:
        """Callable that formats an int value as a literal."""
        fallback: Callable[[int], str]
        fallback = _yojson_intlit_fallback
        if not self._json_type_active:
            fallback = raise_for_unrepresentable_int(language_name="OCaml")
        return make_overflow_fallback_formatter(
            base=self.integer_format.get_formatter(
                numeric_separator=self.numeric_separator,
            ),
            fallback=fallback,
            min_value=_OCAML_INT_MIN,
            max_value=_OCAML_INT_MAX,
        )

    @cached_property
    @beartype
    def format_set_entry(self) -> Callable[[Value, str], str]:
        """Callable that formats a set entry."""
        return self._nested_entry_formatter

    @cached_property
    @beartype
    def format_sequence_entry(self) -> Callable[[Value, str], str]:
        """Callable that formats a sequence entry."""
        if self.dict_format is type(self.dict_format).RECORD:
            return passthrough_sequence_entry
        return self._nested_entry_formatter

    @cached_property
    @beartype
    def comment_config(self) -> CommentConfig:
        """Configuration for the language's comment syntax."""
        return self.comment_format.value

    @cached_property
    @beartype
    def ordered_map_format_config(self) -> OrderedMapFormatConfig:
        """Configuration for ordered-map formatting."""
        ordered_open_str = "`Assoc ["
        if not self._json_type_active:
            ordered_open_str = f"{self.constructor_prefix}Map ["
        return OrderedMapFormatConfig(
            ordered_map_open=fixed_open(open_str=ordered_open_str),
            close="]",
            preamble_lines=(),
        )

    @cached_property
    @beartype
    def format_ordered_map_entry(self) -> Callable[[str, Value, str], str]:
        """Callable that formats one ordered-map entry."""
        return tuple_dict_entry(format_value=self._nested_entry_formatter)

    @cached_property
    @beartype
    def _ocaml_declaration(self) -> Callable[[str, str, Value], str]:
        """Declaration formatter built from the configured type name."""
        if self.dict_format is type(self.dict_format).RECORD:
            return _ocaml_record_declaration
        if self._json_type_active:
            return _build_ocaml_declaration(
                sequence_declared_type=_YOJSON_SAFE_T,
                scalar_declared_type=_YOJSON_SAFE_T,
                entry_formatter=self._entry_formatter,
            )
        _sequence_declared_type = (
            self.sequence_format.value.declared_type.replace(
                "val_t", self.type_name
            )
        )
        return _build_ocaml_declaration(
            sequence_declared_type=_sequence_declared_type,
            scalar_declared_type=self.type_name,
            entry_formatter=self._entry_formatter,
        )

    @cached_property
    @beartype
    def format_variable_declaration(
        self,
    ) -> Callable[[str, str, Value, frozenset[enum.Enum]], str]:
        """Callable that formats a new variable declaration."""
        return declaration_formatter_ignoring_modifiers(
            formatter=self._ocaml_declaration
        )

    assignment_declares_binding = declares_binding
    reference_assignment_declares_binding = assignment_declares_binding
    call_assignment_declares_binding = True

    @cached_property
    @beartype
    def format_variable_assignment(
        self,
    ) -> Callable[[str, str, Value], str]:
        """Callable that formats an assignment to an existing variable."""
        return self._ocaml_declaration

    @cached_property
    @beartype
    def format_call_variable_declaration(
        self,
    ) -> Callable[[str, str, Value, frozenset[enum.Enum]], str]:
        """Callable that formats a declaration binding a call expression.

        The literal-binding declaration annotates the binding with the
        custom type and wraps the value in a tag constructor derived
        from its runtime type (``let x : val_t = OInt 42``); a call
        expression has no such tag, so both the annotation and the tag
        are omitted and OCaml infers the call's return type instead
        (``let x = make_widget(42)``).
        """
        return self.declaration_style.value.formatter

    @cached_property
    @beartype
    def format_call_variable_assignment(
        self,
    ) -> Callable[[str, str, Value], str]:
        """Callable that formats an existing-variable binding of a call
        expression.

        OCaml has no mutable reassignment, so an
        :class:`~literalizer.ExistingVariable` binding is just another
        ``let``.  Like :attr:`format_call_variable_declaration`, the
        ``: val_t`` annotation and tag constructor are omitted so OCaml
        infers the call's return type instead of the literal-binding
        formatter producing ``let x : val_t = OInt make_widget(42)``.
        """
        return assignment_formatter_from_declaration(
            formatter=self.format_call_variable_declaration
        )

    @cached_property
    @beartype
    def scalar_preamble(self) -> dict[type, tuple[str, ...]]:
        """Per-instance scalar preamble (OCaml needs none)."""
        return {}

    @cached_property
    @beartype
    def scalar_body_preamble(self) -> dict[type, tuple[str, ...]]:
        """Per-instance scalar body preamble for OCaml."""
        if self._json_type_active:
            return {}
        p = self.constructor_prefix
        _h = f"type {self.type_name} ="
        if self.date_format.value.type_produced is str:
            _date_constructor = f"  | {p}Str of string"
        else:
            _date_constructor = f"  | {p}Date of (int * int * int)"
        if self.datetime_format.value.type_produced is int:
            _datetime_constructor = f"  | {p}Int of int"
        elif self.datetime_format.value.type_produced is str:
            _datetime_constructor = f"  | {p}Str of string"
        else:
            _datetime_constructor = (
                f"  | {p}Datetime of ((int * int * int) * (int * int * int))"
            )
        return {
            type(None): (_h, f"  | {p}Null"),
            bool: (_h, f"  | {p}Bool of bool"),
            int: (_h, f"  | {p}Int of int"),
            float: (_h, f"  | {p}Float of float"),
            str: (_h, f"  | {p}Str of string"),
            bytes: (_h, f"  | {p}Str of string"),
            dt.time: (_h, f"  | {p}Str of string"),
            dt.date: (_h, _date_constructor),
            dt.datetime: (_h, _datetime_constructor),
            list: (
                _h,
                f"  | {p}Array of {self.type_name} array"
                if self.sequence_format is type(self.sequence_format).ARRAY
                else f"  | {p}List of {self.type_name} list",
            ),
            dict: (_h, f"  | {p}Map of (string * {self.type_name}) list"),
            OrderedMap: (
                _h,
                f"  | {p}Map of (string * {self.type_name}) list",
            ),
            set: (_h, f"  | {p}Set of {self.type_name} list"),
        }

    @cached_property
    @beartype
    def compute_body_preamble(
        self,
    ) -> Callable[[frozenset[type], Value], tuple[str, ...]]:
        """Compute body-preamble lines from the scalar map."""
        if self.dict_format is type(self.dict_format).RECORD:

            @beartype
            def _native_body_preamble(
                _types: frozenset[type], data: Value, /
            ) -> tuple[str, ...]:
                """Declare concrete record types inside the module."""
                return self._native_record_strategy.preamble(data)

            return _native_body_preamble
        return body_preamble_from_scalars(
            scalar_body_preamble=self.scalar_body_preamble,
            format_lines=tuple,
        )


register_json_native_document_fast(language_cls=OCaml)
