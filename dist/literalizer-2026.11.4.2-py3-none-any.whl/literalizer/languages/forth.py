"""Forth language specification."""

import base64
import dataclasses
import datetime as dt
import enum
import re
from collections.abc import Callable, Sequence
from functools import cached_property
from typing import TYPE_CHECKING, ClassVar

from beartype import beartype

from literalizer._formatters.collection_openers import (
    fixed_open,
)
from literalizer._formatters.format_dates import (
    format_datetime_epoch,
)
from literalizer._formatters.format_entries import (
    assignment_formatter_from_declaration,
)
from literalizer._formatters.format_floats import format_float_repr
from literalizer._formatters.format_integers import (
    I64_MAX,
    I64_MIN,
    make_overflow_fallback_formatter,
    raise_for_unrepresentable_int,
)
from literalizer._language import (
    NO_CALL_PARAMETER_LIMIT,
    NO_HETEROGENEOUS_BEHAVIOR,
    NON_KEBAB_REF_CASES,
    BareIntegerWidthStrategies,
    CallParameterShadowing,
    CallStubResult,
    CallStyle,
    CallSupport,
    CommentConfig,
    DateFormatConfig,
    DateFormatEnum,
    DatetimeFormatConfig,
    DatetimeFormatEnum,
    DeclarationStyleConfig,
    DictFormatConfig,
    FileWrapperContext,
    FloatSpecialsMixin,
    FormatValueMixin,
    HeterogeneousBehavior,
    IdentifierCase,
    JsonType,
    LanguageCls,
    ModifierCombination,
    NewVariableNameSyntax,
    OrderedMapFormatConfig,
    PostfixCallStyle,
    SequenceFormatConfig,
    SetFormatConfig,
    StubReturn,
    TrailingCommaConfig,
    VariantMetadata,
    body_preamble_from_scalars,
    declares_binding,
    default_call_data_dependent_preamble,
    default_consumable_ref_value_inhibits_consuming_form,
    default_format_call_arg_ref_identifier,
    default_format_call_arg_ref_identifier_consumable,
    default_format_call_ref_identifier,
    default_format_call_statement,
    default_format_call_stub,
    default_format_call_target,
    default_format_call_variable_assignment,
    default_format_call_variable_declaration,
    default_sequence_binding_declarations,
    default_type_hint_collection_preamble_lines,
    default_validate_call_arg,
    default_wrap_calls_with_declarations,
    identity_call_arg,
    identity_constructor_target,
    no_call_binding_body_preamble,
    no_call_binding_file_pragmas,
    no_data_preamble,
    no_format_integer_beyond_i64,
    no_format_integer_widened,
    no_leading_preamble,
    no_validate_spec_for_data,
    wrap_combined_in_file_noop_static,
    wrap_in_file_noop_static,
)
from literalizer._types import Value


@beartype
def _format_string_forth(value: str) -> str:
    r"""Format a string as a Forth ``s\"`` literal.

    Example: ``"hello"`` -> ``s\" hello"``.
    """
    escaped = (
        value.replace("\\", "\\\\")
        .replace('"', '\\"')
        .replace("\n", "\\n")
        .replace("\r", "\\r")
        .replace("\t", "\\t")
        .replace("\0", "\\x00")
    )
    return f's\\" {escaped}"'


@beartype
def _format_float_forth(value: float) -> str:
    """Format a float as a Forth floating-point literal.

    Forth requires the ``e`` exponent marker to distinguish floats
    from integers.  Uses scientific notation so every value includes
    the marker.

    Example: ``1.5`` -> ``1.5e0``.
    """
    result = format_float_repr(value=value)
    if "e" not in result:
        return f"{result}e0"
    return result


@beartype
def _format_date_forth(value: dt.date) -> str:
    r"""Format a date as a Forth ``s\"`` ISO 8601 string.

    Example: ``datetime.date(2024, 1, 15)`` -> ``s\" 2024-01-15"``.
    """
    return f's\\" {value.isoformat()}"'


@beartype
def _format_datetime_forth(value: dt.datetime) -> str:
    r"""Format a datetime as a Forth ``s\"`` ISO 8601 string.

    Example: ``datetime.datetime(2024, 1, 15, 12, 30)`` ->
    ``s\" 2024-01-15T12:30:00"``.
    """
    return f's\\" {value.isoformat()}"'


@beartype
def _format_time_forth(value: dt.time) -> str:
    r"""Format a time as a Forth ``s\"`` ISO 8601 string.

    Example: ``datetime.time(9, 30)`` -> ``s\" 09:30:00"``.
    """
    return f's\\" {value.isoformat()}"'


@beartype
def _format_bytes_hex_forth(value: bytes) -> str:
    r"""Format bytes as a Forth hex ``s\"`` string.

    Example: ``b"Hello"`` -> ``s\" 48656c6c6f"``.
    """
    return f's\\" {value.hex()}"'


@beartype
def _format_bytes_base64_forth(value: bytes) -> str:
    r"""Format bytes as a Forth base64 ``s\"`` string.

    Example: ``b"Hello"`` -> ``s\" SGVsbG8="``.
    """
    encoded = base64.b64encode(s=value)
    return f's\\" {encoded.decode(encoding="ascii")}"'


@beartype
def _forth_scalar_marker(value: Value, *, datetime_as_int: bool) -> str:
    """Return the visitor marker word from source and format metadata."""
    match value:
        case bool():
            return "+bool"
        case float():
            return "+float"
        case dt.datetime():
            if datetime_as_int:
                return "+int"
            return "+str"
        case str() | bytes() | dt.date() | dt.time():
            return "+str"
        case _:
            return "+int"


@beartype
def _forth_mark_value(
    value: Value, formatted: str, *, datetime_as_int: bool
) -> str:
    r"""Append a visitor marker after a formatted leaf value.

    Container values already carry their own ``+obj``/``+arr`` brackets,
    so they pass through unchanged.  ``null`` collapses to a bare
    ``+null`` (the visitor word takes no operand), dropping the ``0``
    null literal.

    Example: ``42`` -> ``42 +int``; ``s\" x"`` -> ``s\" x" +str``.
    """
    match value:
        case dict() | list() | set():
            return formatted
        case None:
            return "+null"
        case _:
            marker = _forth_scalar_marker(
                value=value, datetime_as_int=datetime_as_int
            )
            return f"{formatted} {marker}"


@beartype
def _build_forth_value_formatter(
    *, datetime_as_int: bool
) -> Callable[[Value, str], str]:
    """Build a value formatter from datetime output metadata."""

    @beartype
    def _format(value: Value, formatted: str) -> str:
        """Append the matching visitor marker."""
        return _forth_mark_value(
            value=value,
            formatted=formatted,
            datetime_as_int=datetime_as_int,
        )

    return _format


@beartype
def _build_forth_declaration(
    *, format_value: Callable[[Value, str], str]
) -> Callable[[str, str, Value, frozenset[enum.Enum]], str]:
    """Build a Forth colon-definition formatter."""

    @beartype
    def _format(
        name: str,
        value: str,
        data: Value,
        _modifiers: frozenset[enum.Enum],
    ) -> str:
        """Format a Forth colon definition emitting a visitor stream."""
        body = format_value(data, value)
        stripped = body.strip("\n")
        if "\n" in stripped:
            return f": {name}\n{stripped}\n;"
        return f": {name} {stripped} ;"

    return _format


@beartype
def _build_forth_dict_entry(
    *, format_value: Callable[[Value, str], str]
) -> Callable[[str, Value, str], str]:
    """Build a Forth key/value entry formatter."""

    @beartype
    def _format(key: str, raw_value: Value, formatted_value: str) -> str:
        """Format a ``+key`` token followed by a marked value."""
        marked = format_value(raw_value, formatted_value)
        return f"{key} +key {marked}"

    return _format


_format_forth_value_iso = _build_forth_value_formatter(datetime_as_int=False)
_format_forth_declaration_iso = _build_forth_declaration(
    format_value=_format_forth_value_iso
)


@beartype
def _forth_call_stub(
    parts: Sequence[str],
    _params: Sequence[str],
    _stub_return: StubReturn,
    _args: Sequence[Value],
    /,
) -> tuple[str, ...]:
    """Return Forth stub word definitions for a call name.

    For dotted names like ``throttler.check``, stubs are generated for
    each prefix so that the root and intermediate names are defined.
    """
    stubs: list[str] = []
    for i in range(len(parts)):
        word = ".".join(parts[: i + 1])
        stubs.append(f": {word} ;")
    return tuple(stubs)


# Work around https://github.com/astral-sh/ty/issues/4573.
if TYPE_CHECKING:
    _BytesEnumMember = enum.member[Callable[[bytes], str]]
    _StringEnumMember = enum.member[Callable[[str], str]]
else:
    _BytesEnumMember = enum.member
    _StringEnumMember = enum.member


@beartype
@dataclasses.dataclass(frozen=True, kw_only=True)
class Forth(metaclass=LanguageCls):
    """Forth language specification."""

    format_call_class_scope_stub = default_format_call_stub

    reserved_module_identifiers: ClassVar[frozenset[str]] = frozenset()
    immutable_variable_modifiers: ClassVar[frozenset[enum.Enum]] = frozenset()
    wrap_in_file_tolerates_pre_indent = True
    module_name_shares_variable_scope = False
    reserved_variable_identifier_pattern: ClassVar[re.Pattern[str] | None] = (
        None
    )
    reserved_call_parameter_identifiers: ClassVar[frozenset[str]] = frozenset()
    reserved_call_parameter_identifier_pattern: ClassVar[
        re.Pattern[str] | None
    ] = None
    accepts_type_name_call_target = True
    declares_type_name_call_target = True
    dotted_call_root_shares_entrypoint_namespace = True
    reserved_bare_call_target_identifiers: ClassVar[frozenset[str]] = (
        frozenset()
    )
    reserved_call_target_head_identifiers: ClassVar[frozenset[str]] = (
        frozenset()
    )
    contextual_call_target_identifiers: ClassVar[frozenset[str]] = frozenset()
    call_parameter_shadowing = CallParameterShadowing.ALLOWED
    reserved_call_target_keywords_case_sensitive = True
    module_name_must_start_uppercase = False
    new_variable_name_syntax = NewVariableNameSyntax.ASCII
    max_variable_identifier_length: ClassVar[int | None] = None
    call_stub_result: ClassVar[CallStubResult | None] = None
    call_literal_syntax: ClassVar[None] = None
    call_target_name_syntax: ClassVar[NewVariableNameSyntax | None] = None
    supports_multiline_dict_layout = True
    pools_map_integer_width = True

    format_integer_widened = no_format_integer_widened
    format_integer_beyond_i64 = no_format_integer_beyond_i64
    format_constructor_target: ClassVar["staticmethod[[str], str]"] = (
        staticmethod(identity_constructor_target)
    )
    format_call_variable_declaration = default_format_call_variable_declaration
    format_call_variable_assignment = default_format_call_variable_assignment
    sequence_binding_declarations = default_sequence_binding_declarations
    format_call_binding_body_preamble = no_call_binding_body_preamble
    format_call_binding_file_pragmas = no_call_binding_file_pragmas

    leading_preamble = no_leading_preamble
    extension = ".fth"
    pygments_name = "forth"
    stringifies_nested_collections = False
    supports_special_floats = True
    supports_variable_names = True
    supports_no_variable_wrap_in_file = True
    wraps_data_dependent_preamble_in_body = False
    dict_supports_heterogeneous_values = True
    supports_native_invocations = False
    supports_dotted_calls = True
    has_free_function_calls = True
    reserved_identifiers: ClassVar[frozenset[str]] = frozenset()
    declares_call_parameter_names = True
    reserved_variable_identifiers_case_sensitive: bool = False
    reserved_variable_identifiers: frozenset[str] = frozenset(
        {
            "BEGIN",
            "DO",
            "ELSE",
            "EXIT",
            "IF",
            "LOOP",
            "REPEAT",
            "THEN",
            "UNTIL",
            "WHILE",
        }
    )
    allows_empty_call_parens = True
    supports_dotted_call_stub = True
    call_returns_expression = True
    supports_json_call_result_binding = False
    supports_zero_parameter_calls = True
    max_call_parameters = NO_CALL_PARAMETER_LIMIT
    supports_inline_multiline_dict_args = True
    supports_standalone_comments_in_wrapped_calls = True
    supports_multi_param_call_wrapper_stub = True
    supports_dict_literal_as_free_expression = True
    supports_module_name = False
    supports_empty_dict_key = False
    supports_call_style = False
    supports_default_dict_key_type = False
    supports_default_dict_value_type = False
    supports_default_sequence_element_type = False
    supports_default_set_element_type = False
    supports_default_ordered_map_value_type = False
    json_type_variant_name_suffix: ClassVar[str | None] = None
    supports_non_ascii_string_literals = True
    supports_multiline_string_literals = False
    supports_empty_sibling_sequence_type_hints = True
    supports_typed_dict_open = False
    language_id: ClassVar[str] = "forth"
    variant_metadata: ClassVar[VariantMetadata] = VariantMetadata(
        round_trip_capabilities=frozenset(),
        modifier_sequence_format_overrides={},
        string_literals_escape_null_byte=True,
        supports_ref_elements_in_tuple_strategy=False,
    )
    supports_record_struct_name_prefix = False
    supports_record_shape_names = False
    record_shape_names_emit_declarations = False
    supports_non_string_dict_keys = False
    checks_raw_control_dict_keys_separately = False

    format_call_arg: ClassVar["staticmethod[[Value, str], str]"] = (
        staticmethod(
            identity_call_arg,
        )
    )
    """Callable that rewrites a formatted direct call argument."""

    class DateFormats(DateFormatEnum):
        """Date format options."""

        ISO = DateFormatConfig(
            formatter=_format_date_forth,
            type_produced=str,
            preamble_lines=(),
        )

    class DatetimeFormats(DatetimeFormatEnum):
        """Datetime format options."""

        ISO = DatetimeFormatConfig(
            formatter=_format_datetime_forth,
            type_produced=str,
            preamble_lines=(),
        )

        EPOCH = DatetimeFormatConfig(
            formatter=format_datetime_epoch,
            type_produced=int,
            preamble_lines=(),
        )

    class BytesFormats(FormatValueMixin[Callable[[bytes], str]], enum.Enum):
        """Bytes formatting options."""

        HEX = _BytesEnumMember(value=_format_bytes_hex_forth)
        BASE64 = _BytesEnumMember(value=_format_bytes_base64_forth)

        def __call__(self, data: bytes, /) -> str:
            """Format bytes."""
            return self.value(data)

    class SequenceFormats(enum.Enum):
        """Sequence type options."""

        LIST = SequenceFormatConfig(
            length_is_part_of_type=False,
            sequence_open=fixed_open(open_str="+arr "),
            close=" -arr",
            supports_heterogeneity=True,
            single_element_trailing_comma=False,
            single_element_template=None,
            supports_trailing_comma=False,
            empty_sequence="+arr -arr",
            preamble_lines=(),
            format_entry=_format_forth_value_iso,
            typed_opener_fallback=None,
            uses_typed_literal_for_scalars=False,
            requires_uniform_record_shapes=False,
            declared_type=None,
            narrowed_empty_form=None,
        )

    class SetFormats(enum.Enum):
        """Set type options."""

        SET = SetFormatConfig(
            set_open=fixed_open(open_str="+arr "),
            close=" -arr",
            empty_set="+arr -arr",
            preamble_lines=(),
            set_opener_template="",
            supports_heterogeneity=True,
            supports_trailing_comma=True,
        )

    class CommentFormats(enum.Enum):
        """Comment style options."""

        BACKSLASH = CommentConfig(
            prefix="\\",
            suffix="",
        )
        PAREN = CommentConfig(
            prefix="(",
            suffix=" )",
        )

    class DeclarationStyles(enum.Enum):
        """Declaration style options."""

        COLON = DeclarationStyleConfig(
            formatter=_format_forth_declaration_iso,
            supports_redefinition=True,
        )

    class DictEntryStyles(enum.Enum):
        """Dict entry style options."""

        DEFAULT = enum.auto()

    class DictFormats(enum.Enum):
        """Dict/map format options."""

        DEFAULT = enum.auto()

    class EmptyDictKey(enum.Enum):
        """Empty dict key options."""

        ALLOW = enum.auto()

    class FloatFormats(
        FloatSpecialsMixin,
        enum.Enum,
        positive_infinity="1.0e0 0.0e0 f/",
        negative_infinity="-1.0e0 0.0e0 f/",
        nan="0.0e0 0.0e0 f/",
    ):
        """Float format options."""

        REPR = enum.member(value=_format_float_forth)

    class IntegerFormats(enum.Enum):
        """Integer format options."""

        DECIMAL = enum.auto()

    class NumericLiteralSuffixes(enum.Enum):
        """Numeric literal suffix options."""

        NONE = enum.auto()

    class NumericSeparators(enum.Enum):
        """Numeric separator options."""

        NONE = enum.auto()

    class NumericStyles(enum.Enum):
        """Numeric literal style options."""

        OVERLOADED = enum.auto()

    class StringFormats(FormatValueMixin[Callable[[str], str]], enum.Enum):
        """String format options."""

        ESCAPED = _StringEnumMember(value=_format_string_forth)

        def __call__(self, value: str, /) -> str:
            """Format a string."""
            return self.value(value)

    class TrailingCommas(enum.Enum):
        """Trailing comma options."""

        NO = TrailingCommaConfig(multiline_trailing_comma=False)

    date_formats = DateFormats
    datetime_formats = DatetimeFormats
    bytes_formats = BytesFormats
    sequence_formats = SequenceFormats
    set_formats = SetFormats
    comment_formats = CommentFormats

    class VariableTypeHints(enum.Enum):
        """Variable type hint options."""

        NEVER = enum.auto()
        SAFE = enum.auto()

    variable_type_hints_formats = VariableTypeHints
    declaration_styles = DeclarationStyles
    dict_entry_styles = DictEntryStyles
    dict_formats = DictFormats
    empty_dict_keys = EmptyDictKey
    float_formats = FloatFormats
    integer_formats = IntegerFormats
    integer_width_strategies = BareIntegerWidthStrategies
    numeric_literal_suffixes = NumericLiteralSuffixes
    numeric_separators = NumericSeparators
    numeric_styles = NumericStyles
    string_formats = StringFormats
    trailing_commas = TrailingCommas

    class StatementTerminatorStyles(enum.Enum):
        """Statement terminator options."""

        NONE = enum.auto()

    statement_terminator_styles = StatementTerminatorStyles

    class CallStyles(enum.Enum):
        """Forth call style options."""

        POSTFIX = PostfixCallStyle(arg_separator=" ")

    call_styles = CallStyles

    class Modifiers(enum.Enum):
        """C++/Java/C#-style declaration modifiers: this language has none."""

    modifiers = Modifiers

    class HeterogeneousStrategies(enum.Enum):
        """Heterogeneous-scalar strategy options — this language only
        supports raising.
        """

        ERROR = NO_HETEROGENEOUS_BEHAVIOR

    heterogeneous_strategies = HeterogeneousStrategies

    class JsonTypes(JsonType):
        """Empty: this language has no JSON value-type variants."""

    json_types = JsonTypes

    class BoolFormats(enum.Enum):
        """Empty: this language has no alternative boolean formats."""

    bool_formats = BoolFormats

    class VersionFormats(enum.Enum):
        """Version options for Forth."""

        ANS = enum.auto()

    version_formats = VersionFormats

    modifier_combinations: ClassVar[tuple[ModifierCombination, ...]] = ()
    identifier_cases: ClassVar[tuple[IdentifierCase, ...]] = (
        IdentifierCase.UPPER_SNAKE,
        IdentifierCase.SNAKE,
    )
    supported_ref_cases: ClassVar[frozenset[IdentifierCase]] = (
        NON_KEBAB_REF_CASES
    )

    validate_spec_for_data = no_validate_spec_for_data

    validate_call_arg = default_validate_call_arg

    format_call_statement = default_format_call_statement

    wrap_calls_with_declarations = default_wrap_calls_with_declarations

    wrap_in_file: ClassVar["staticmethod[[str, FileWrapperContext], str]"] = (
        wrap_in_file_noop_static
    )

    wrap_combined_in_file: ClassVar[
        "staticmethod[[str, str, FileWrapperContext], str]"
    ] = wrap_combined_in_file_noop_static

    date_format: DateFormats = DateFormats.ISO
    datetime_format: DatetimeFormats = DatetimeFormats.ISO
    bytes_format: BytesFormats = BytesFormats.HEX
    sequence_format: SequenceFormats = SequenceFormats.LIST
    set_format: SetFormats = SetFormats.SET
    variable_type_hints: VariableTypeHints = VariableTypeHints.NEVER
    comment_format: CommentFormats = CommentFormats.BACKSLASH
    declaration_style: DeclarationStyles = DeclarationStyles.COLON
    dict_entry_style: DictEntryStyles = DictEntryStyles.DEFAULT
    dict_format: DictFormats = DictFormats.DEFAULT
    float_format: FloatFormats = FloatFormats.REPR
    integer_format: IntegerFormats = IntegerFormats.DECIMAL
    integer_width_strategy: BareIntegerWidthStrategies = (
        BareIntegerWidthStrategies.BARE
    )
    numeric_literal_suffix: NumericLiteralSuffixes = (
        NumericLiteralSuffixes.NONE
    )
    numeric_separator: NumericSeparators = NumericSeparators.NONE
    numeric_style: NumericStyles = NumericStyles.OVERLOADED
    string_format: StringFormats = StringFormats.ESCAPED
    trailing_comma: TrailingCommas = TrailingCommas.NO
    statement_terminator_style: StatementTerminatorStyles = (
        StatementTerminatorStyles.NONE
    )
    heterogeneous_strategy: HeterogeneousStrategies = (
        HeterogeneousStrategies.ERROR
    )
    # The `Install apt packages` step in `.github/workflows/lint.yml`
    # pins a `gforth` build implementing ANS Forth, matching this
    # default (`ANS`). The pin is for reproducible builds, not
    # language selection. Keep the two in sync.
    language_version: VersionFormats = VersionFormats.ANS
    indent: str = "    "

    null_literal: ClassVar[str] = "0"
    true_literal: ClassVar[str] = "true"
    false_literal: ClassVar[str] = "false"
    indent_closing_delimiter: ClassVar[bool] = False
    element_separator: ClassVar[str] = " "
    skip_null_dict_values: ClassVar[bool] = False
    supports_collection_comments: ClassVar[bool] = False
    supports_scalar_before_comments: ClassVar[bool] = False
    supports_scalar_inline_comments: ClassVar[bool] = False
    statement_terminator: ClassVar[str] = ""
    static_preamble: ClassVar[Sequence[str]] = ()
    static_body_preamble: ClassVar[Sequence[str]] = ()
    special_float_preamble: ClassVar[tuple[str, ...]] = ()
    call_style_config: ClassVar[CallStyle | CallSupport] = (
        CallStyles.POSTFIX.value
    )

    @cached_property
    @beartype
    def format_integer(self) -> Callable[[int], str]:
        """Format an int value as a literal.

        A Forth cell is a signed 64-bit machine word and the prelude's
        ``+int`` reads it as one, so a wider value is parsed back as a
        negative or wrapped number rather than represented
        (issue #4501).
        """
        return make_overflow_fallback_formatter(
            base=str,
            min_value=I64_MIN,
            max_value=I64_MAX,
            fallback=raise_for_unrepresentable_int(language_name="Forth"),
        )

    @cached_property
    @beartype
    def _value_formatter(self) -> Callable[[Value, str], str]:
        """Value formatter built from datetime output metadata."""
        return _build_forth_value_formatter(
            datetime_as_int=self.datetime_format.value.type_produced is int
        )

    @cached_property
    @beartype
    def _dict_entry(self) -> Callable[[str, Value, str], str]:
        """Dictionary entry formatter using the configured value
        marker.
        """
        return _build_forth_dict_entry(format_value=self._value_formatter)

    @cached_property
    @beartype
    def format_sequence_entry(self) -> Callable[[Value, str], str]:
        """Format a sequence entry."""
        return self._value_formatter

    @cached_property
    @beartype
    def format_set_entry(self) -> Callable[[Value, str], str]:
        """Format a set entry."""
        return self._value_formatter

    @cached_property
    @beartype
    def format_ordered_map_entry(self) -> Callable[[str, Value, str], str]:
        """Format one ordered-map entry."""
        return self._dict_entry

    @cached_property
    @beartype
    def data_dependent_preamble(self) -> Callable[[Value], tuple[str, ...]]:
        """Return data-dependent preamble lines."""
        return no_data_preamble

    @cached_property
    @beartype
    def heterogeneous_behavior(self) -> HeterogeneousBehavior:
        """Return the heterogeneous-behavior config."""
        return self.heterogeneous_strategy.value

    call_data_dependent_preamble = default_call_data_dependent_preamble

    type_hint_collection_preamble_lines = (
        default_type_hint_collection_preamble_lines
    )

    @cached_property
    @beartype
    def format_call_stub(
        self,
    ) -> Callable[
        [Sequence[str], Sequence[str], StubReturn, Sequence[Value]],
        tuple[str, ...],
    ]:
        """Return stub declarations for a call expression."""
        return _forth_call_stub

    format_call_preamble_stub = default_format_call_stub

    format_call_target = default_format_call_target

    format_call_ref_identifier = default_format_call_ref_identifier

    format_call_arg_ref_identifier = default_format_call_arg_ref_identifier

    format_call_arg_ref_identifier_consumable = (
        default_format_call_arg_ref_identifier_consumable
    )

    consumable_ref_value_inhibits_consuming_form = (
        default_consumable_ref_value_inhibits_consuming_form
    )

    @cached_property
    @beartype
    def sequence_format_config(self) -> SequenceFormatConfig:
        """Configuration for the chosen sequence format."""
        return self.sequence_format.value

    @cached_property
    @beartype
    def set_format_config(self) -> SetFormatConfig:
        """Configuration for the chosen set format."""
        return self.set_format.value

    @cached_property
    @beartype
    def sequence_open(self) -> Callable[[list[Value]], str]:
        """Callable that returns the opening delimiter for a sequence."""
        return self.sequence_format.value.sequence_open

    @cached_property
    @beartype
    def dict_format_config(self) -> DictFormatConfig:
        """Configuration for dict formatting."""
        return DictFormatConfig(
            dict_open=fixed_open(open_str="+obj "),
            close=" -obj",
            format_entry=self._dict_entry,
            empty_dict="+obj -obj",
            preamble_lines=(),
            narrowed_open=None,
            supports_trailing_comma=True,
            narrowed_empty_form=None,
        )

    @cached_property
    @beartype
    def trailing_comma_config(self) -> TrailingCommaConfig:
        """Configuration for trailing-comma behavior."""
        return self.trailing_comma.value

    @cached_property
    @beartype
    def format_bytes(self) -> Callable[[bytes], str]:
        """Callable that formats a bytes value as a string literal."""
        return self.bytes_format

    @cached_property
    @beartype
    def format_date(self) -> Callable[[dt.date], str]:
        """Callable that formats a date as a string literal."""
        return self.date_format

    @cached_property
    @beartype
    def format_datetime(self) -> Callable[[dt.datetime], str]:
        """Callable that formats a datetime as a string literal."""
        return self.datetime_format

    @cached_property
    @beartype
    def format_time(self) -> Callable[[dt.time], str]:
        """Callable that formats a time as a string literal."""
        return _format_time_forth

    @cached_property
    @beartype
    def format_string(self) -> Callable[[str], str]:
        """Callable that formats a string value as a quoted literal."""
        return self.string_format

    @cached_property
    @beartype
    def format_float(self) -> Callable[[float], str]:
        """Callable that formats a float value as a literal."""
        return self.float_format

    @cached_property
    @beartype
    def comment_config(self) -> CommentConfig:
        """Configuration for the language's comment syntax."""
        return self.comment_format.value

    @cached_property
    @beartype
    def ordered_map_format_config(self) -> OrderedMapFormatConfig:
        """Configuration for ordered-map formatting."""
        return OrderedMapFormatConfig(
            ordered_map_open=fixed_open(open_str="+obj "),
            close=" -obj",
            preamble_lines=(),
        )

    @cached_property
    @beartype
    def format_variable_declaration(
        self,
    ) -> Callable[[str, str, Value, frozenset[enum.Enum]], str]:
        """Callable that formats a new variable declaration."""
        return _build_forth_declaration(format_value=self._value_formatter)

    assignment_declares_binding = declares_binding
    reference_assignment_declares_binding = assignment_declares_binding
    call_assignment_declares_binding = True

    @cached_property
    @beartype
    def format_variable_assignment(
        self,
    ) -> Callable[[str, str, Value], str]:
        """Callable that formats an assignment to an existing variable."""
        return assignment_formatter_from_declaration(
            formatter=self.format_variable_declaration,
        )

    @cached_property
    @beartype
    def scalar_preamble(self) -> dict[type, tuple[str, ...]]:
        """Per-instance scalar preamble (Forth needs none)."""
        return {}

    @cached_property
    @beartype
    def scalar_body_preamble(self) -> dict[type, tuple[str, ...]]:
        """Per-instance scalar body preamble (Forth needs none)."""
        return {}

    @cached_property
    @beartype
    def compute_body_preamble(
        self,
    ) -> Callable[[frozenset[type], Value], tuple[str, ...]]:
        """Compute body-preamble lines from the scalar map."""
        return body_preamble_from_scalars(
            scalar_body_preamble=self.scalar_body_preamble,
            format_lines=tuple,
        )
