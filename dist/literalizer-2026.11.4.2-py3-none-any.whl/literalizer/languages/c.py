"""C language specification."""

import collections.abc
import dataclasses
import datetime as dt
import enum
import itertools
import re
from collections.abc import Callable, Iterator, Mapping, Sequence
from functools import cached_property, partial
from types import MappingProxyType
from typing import TYPE_CHECKING, ClassVar, Self, TypeGuard

from beartype import beartype

from literalizer._checks import reject_cjson_unrepresentable
from literalizer._formatters.collection_openers import (
    CollectionSignature,
    fixed_open,
    signature_open,
)
from literalizer._formatters.format_dates import (
    format_date_iso,
    format_datetime_epoch,
    format_datetime_iso,
    format_time_iso,
)
from literalizer._formatters.format_entries import (
    braced_dict_entry,
    format_bytes_base64,
    format_bytes_hex,
    passthrough_sequence_entry,
    variable_declaration_formatter,
)
from literalizer._formatters.format_floats import (
    format_float_fixed,
    format_float_repr,
    format_float_scientific,
)
from literalizer._formatters.format_integers import (
    I64_MAX,
    I64_MIN,
    format_integer_hex,
    make_i64_min_safe_formatter,
    make_long_suffix_formatter,
    make_negative_nondecimal_i64_formatter,
    make_overflow_fallback_formatter,
    make_ull_fallback,
)
from literalizer._formatters.format_json_value import (
    JsonValue,
    to_jsonable,
)
from literalizer._formatters.format_strings import (
    format_string_c,
)
from literalizer._formatters.preamble_roles import (
    import_preamble,
    join_preamble,
    preamble_imports,
)
from literalizer._formatters.record_strategy import (
    ActiveRecordStrategy,
    RecordDeclarationField,
    RecordFieldType,
    RecordLiteralField,
    RecordRenderer,
    build_record_strategy,
    identity_field_identifier_key,
)
from literalizer._formatters.type_inference import (
    record_shape_for_dict,
)
from literalizer._json_native_document import (
    register_json_native_document_fast,
)
from literalizer._language import (
    NO_CALL_PARAMETER_LIMIT,
    NO_HETEROGENEOUS_BEHAVIOR,
    NON_KEBAB_REF_CASES,
    BareIntegerWidthStrategies,
    CallParameterShadowing,
    CallStubResult,
    CommentConfig,
    DateFormatConfig,
    DateFormatEnum,
    DatetimeFormatConfig,
    DatetimeFormatEnum,
    DeclarationStyleConfig,
    DictFormatConfig,
    FileWrapperContext,
    FloatSpecialsMixin,
    FormatValueMixin,
    HeterogeneousBehavior,
    IdentifierCase,
    JsonType,
    LanguageCls,
    ModifierCombination,
    NewVariableNameSyntax,
    OrderedMapFormatConfig,
    PositionalCallStyle,
    RenderedRecordLiteral,
    RoundTripCapability,
    SequenceFormatConfig,
    SetFormatConfig,
    StubReturn,
    TrailingCommaConfig,
    VariantMetadata,
    body_preamble_from_scalars,
    default_call_data_dependent_preamble,
    default_consumable_ref_value_inhibits_consuming_form,
    default_format_call_arg_ref_identifier,
    default_format_call_arg_ref_identifier_consumable,
    default_format_call_ref_identifier,
    default_format_call_statement,
    default_format_call_stub,
    default_format_call_target,
    default_sequence_binding_declarations,
    default_type_hint_collection_preamble_lines,
    default_wrap_calls_with_declarations,
    identity_constructor_target,
    no_call_binding_body_preamble,
    no_call_binding_file_pragmas,
    no_data_preamble,
    no_format_integer_beyond_i64,
    no_format_integer_widened,
    no_leading_preamble,
    no_validate_call_arg,
    prepend_body_preamble,
    requires_declared_binding,
)
from literalizer._statements import (
    CallLiteralSyntax,
)
from literalizer._types import OrderedMap, Scalar, Value
from literalizer.exceptions import (
    IncompatibleFormatsError,
    UnrepresentableInputError,
)


@beartype
def _stub_parameter_signature(*, parameters: str) -> str:
    """Use the C void parameter spelling for an empty stub signature."""
    if parameters == "":
        return "void"
    return parameters


@beartype
def _apply_format_c_entry(
    *,
    original: Value,
    formatted: str,
    int_field: str,
    uint_field: str,
    float_field: str,
    string_field: str,
    datetime_as_int: bool,
) -> str:
    """Wrap a formatted entry in the appropriate union literal."""
    match original:
        case dt.datetime():
            field = string_field
            if datetime_as_int:
                field = int_field
        case str() | bytes() | dt.date() | dt.time():
            field = string_field
        case bool():
            return formatted
        # Values above ``LLONG_MAX`` cannot be assigned to the signed
        # ``long long`` field without an implementation-defined
        # narrowing conversion; route them to the unsigned field.
        case int() if original > I64_MAX:
            field = uint_field
        case int():
            field = int_field
        case float():
            field = float_field
        case _:
            return formatted
    return f"((CVal){{.{field} = {formatted}}})"


@beartype
def _make_format_c_entry(
    *,
    int_field: str,
    uint_field: str,
    float_field: str,
    string_field: str,
    datetime_as_int: bool,
) -> collections.abc.Callable[[Value, str], str]:
    """Return a formatter that wraps values in the appropriate
    ``CVal`` union literal using the given field names.
    """

    @beartype
    def _format_c_entry(original: Value, formatted: str) -> str:
        """Delegate to module-level implementation."""
        return _apply_format_c_entry(
            original=original,
            formatted=formatted,
            int_field=int_field,
            uint_field=uint_field,
            float_field=float_field,
            string_field=string_field,
            datetime_as_int=datetime_as_int,
        )

    return _format_c_entry


# The ``RECORD`` strategy auto-names generated ``struct`` types
# ``Record0``, ``Record1``, ...  C exposes no ``record_shape_names``
# (see issue #2476), so the shared renderer always gets an empty
# custom-name mapping and the document-order auto counter.
_C_RECORD_PREFIX = "Record"
_C_NO_RECORD_SHAPE_NAMES: Mapping[frozenset[str], str] = MappingProxyType[
    frozenset[str], str
](
    mapping={},
)


@beartype
def _apply_format_c_entry_record(
    *,
    original: Value,
    formatted: str,
    int_field: str,
    uint_field: str,
    float_field: str,
    string_field: str,
    bool_field: str,
    array_field: str,
    datetime_as_int: bool,
) -> str:
    """Wrap a formatted entry in the appropriate ``CVal`` union literal
    under the ``RECORD`` strategy.

    Only three element kinds differ from :func:`_apply_format_c_entry`,
    and ``RECORD`` handles them here before delegating the rest:

    * ``bool`` / ``None`` -- ``RECORD`` makes the bare ``true`` /
      ``false`` / ``NULL`` literals (so a ``bool`` / null record field
      is a clean scalar), so one reached as a *collection element* must
      be wrapped here instead of arriving pre-wrapped.
    * ``list`` -- only a list now opens with the bare ``CVal`` array
      form, so a list element is wrapped into a ``CVal`` so the
      enclosing array is well-typed.

    Every other element is wrapped (or passed through, for a record
    ``struct`` literal or an already-complete dict / ordered map / set
    ``CVal`` expression) exactly as the default strategy does.
    """
    match original:
        case bool():
            return f"((CVal){{.{bool_field} = {formatted}}})"
        case None:
            return f"((CVal){{.{string_field} = {formatted}}})"
        case list():
            return f"((CVal){{.{array_field} = {formatted}}})"
        case _:
            return _apply_format_c_entry(
                original=original,
                formatted=formatted,
                int_field=int_field,
                uint_field=uint_field,
                float_field=float_field,
                string_field=string_field,
                datetime_as_int=datetime_as_int,
            )


@beartype
def _make_format_c_entry_record(
    *,
    int_field: str,
    uint_field: str,
    float_field: str,
    string_field: str,
    bool_field: str,
    array_field: str,
    datetime_as_int: bool,
) -> collections.abc.Callable[[Value, str], str]:
    """Return the ``RECORD``-strategy ``CVal``-wrapping entry
    formatter.
    """

    @beartype
    def _format_c_entry(original: Value, formatted: str) -> str:
        """Delegate to module-level implementation."""
        return _apply_format_c_entry_record(
            original=original,
            formatted=formatted,
            int_field=int_field,
            uint_field=uint_field,
            float_field=float_field,
            string_field=string_field,
            bool_field=bool_field,
            array_field=array_field,
            datetime_as_int=datetime_as_int,
        )

    return _format_c_entry


@beartype
def _c_record_field_identifier(
    key: str, /, *, reserved_identifiers: frozenset[str]
) -> str:
    """Return the C ``struct`` member name for a dict *key*.

    C member identifiers are the dict keys verbatim (no case
    conversion), matching the designated-initializer literal form
    ``(struct Record0){.id = 1, ...}``.
    """
    if key in reserved_identifiers:
        msg = f"C record field name {key!r} is reserved"
        raise UnrepresentableInputError(msg)
    return key


@beartype
def _all_record_shaped(items: list[Value], /) -> bool:
    """Return whether *items* is a non-empty list whose every element
    is a record-shaped dict (non-empty, all-string-keyed, not an
    ordered map).

    Under the ``RECORD`` strategy such a list renders each element as a
    generated ``(struct RecordN){...}`` literal, so the C sequence
    opener emits a bare ``{`` (a brace-enclosed initializer for the
    enclosing ``struct RecordN`` array member or array variable) rather
    than the ``(CVal[]){`` opener every other list keeps.

    Uniformity of shape need not be checked here: a sibling list whose
    record-shaped dicts do not all share one shape is rejected for
    every ``RECORD`` language by the shared
    :func:`literalizer._checks.check_data` guard before any value is
    formatted, so a list reaching this predicate is single-shape and
    the deduced ``struct RecordN[N]`` member is well-formed.
    """
    if len(items) == 0:
        return False
    return all(_c_record_dict(item) for item in items)


@beartype
def _c_record_dict(value: Value, /) -> TypeGuard[dict[Scalar, Value]]:
    """Return whether *value* is a record-shaped dict.

    A record-shaped dict (non-empty, all-string-keyed, not an ordered
    map) renders as a ``(struct RecordN){...}`` literal under the
    ``RECORD`` strategy.
    """
    return (
        isinstance(value, dict)
        and not isinstance(value, OrderedMap)
        and record_shape_for_dict(value=value) is not None
    )


_C_RECORD_IN_CVAL_MSG = (
    "C cannot represent a record-shaped dict (or a list whose every "
    "element is one) nested under a non-record container -- a "
    "non-all-record list, a non-record dict, an ordered map, or a set "
    "-- under the RECORD heterogeneous strategy: it renders as a "
    "generated struct, which is not a CVal union member, so it is "
    "representable only as a record-field value, an element of such a "
    "field's struct array, or the document root (cf. the set / "
    "non-record-dict field boundary tracked in #2317)"
)


_C_RECORD_ARRAY_LEN_MSG = (
    "C cannot represent two record-shaped dicts of one shape whose "
    "shared all-record-list field has differing lengths under the "
    "RECORD heterogeneous strategy: that field becomes a fixed-size "
    "struct RecordN [len] member sized from the shape's first-seen "
    "instance, so a later instance with a different-length list would "
    "overflow the array (excess initializers fail to compile) or "
    "silently under-fill it -- neither faithfully represents the input "
    "(cf. the set / non-record-dict field boundary tracked in #2317)"
)


@beartype
def _check_c_record_array_field_lengths(
    *,
    node: dict[Scalar, Value],
    array_lengths_by_shape: dict[tuple[Scalar, ...], dict[Scalar, int]],
) -> None:
    """Raise :class:`UnrepresentableInputError` if a record-shaped dict
    shares a shape with an earlier one but its all-record-list field
    has a different length.

    An all-record-list record field becomes a fixed-size
    ``struct RecordN[len]`` member sized from the shape's first-seen
    instance (``record_strategy`` caches the first-seen field-type
    request per shape, in document order).  A later same-shape instance
    whose list has a different length would overflow that fixed array
    (excess initializers fail to compile) or silently under-fill it, so
    neither faithfully represents the data.  Rejecting it here keeps
    the boundary explicit rather than emitting C that fails to compile
    or misrepresents the input (cf. the set / non-record-dict field
    boundary tracked in #2317).

    A shape is keyed by its ordered key tuple: C does not unify record
    shapes, so identical-keyed dicts (and only those) share one
    generated ``struct``, exactly as
    :func:`literalizer._formatters.type_inference.record_shape_for_dict`
    deduces.  *array_lengths_by_shape* accumulates the first-seen
    length per shape and field across the whole walk.
    """
    field_lengths = array_lengths_by_shape.setdefault(tuple(node), {})
    for field_name, field_value in node.items():
        if isinstance(field_value, list) and _all_record_shaped(field_value):
            first_length = field_lengths.setdefault(
                field_name,
                len(field_value),
            )
            if first_length != len(field_value):
                raise UnrepresentableInputError(_C_RECORD_ARRAY_LEN_MSG)


@beartype
def _check_c_record_nesting(
    *,
    node: Value,
    cval_context: bool,
    array_lengths_by_shape: dict[tuple[Scalar, ...], dict[Scalar, int]],
) -> None:
    """Raise :class:`UnrepresentableInputError` if a record-shaped dict
    (or an all-record list) is reachable only through a ``CVal``
    context.

    Under C's ``RECORD`` strategy a record-shaped dict renders as a
    ``(struct RecordN){...}`` literal and a list whose elements are all
    record-shaped dicts as a ``struct RecordN[]`` array; neither is a
    ``CVal`` union member.  Either is therefore representable only as a
    record-field value, an element of such a field's struct array, or
    the document root.  *cval_context* is ``True`` once the walk has
    descended through a non-record container, where the value must
    occupy a ``CVal`` slot and a record there cannot be represented.
    """
    if _c_record_dict(node):
        if cval_context:
            raise UnrepresentableInputError(_C_RECORD_IN_CVAL_MSG)
        _check_c_record_array_field_lengths(
            node=node,
            array_lengths_by_shape=array_lengths_by_shape,
        )
        for field_value in node.values():
            _check_c_record_field(
                field_value,
                array_lengths_by_shape=array_lengths_by_shape,
            )
        return
    match node:
        case OrderedMap() | dict():
            for value in node.values():
                _check_c_record_nesting(
                    node=value,
                    cval_context=True,
                    array_lengths_by_shape=array_lengths_by_shape,
                )
        case list():
            records = _all_record_shaped(node)
            if records and cval_context:
                raise UnrepresentableInputError(_C_RECORD_IN_CVAL_MSG)
            for element in node:
                _check_c_record_nesting(
                    node=element,
                    cval_context=not records,
                    array_lengths_by_shape=array_lengths_by_shape,
                )
        case _:
            return


@beartype
def _check_c_record_field(
    field_value: Value,
    /,
    *,
    array_lengths_by_shape: dict[tuple[Scalar, ...], dict[Scalar, int]],
) -> None:
    """Validate one field value of a record-shaped dict.

    A nested record dict stays a ``struct`` member and an all-record
    list a ``struct`` array (neither a ``CVal``), so those descend
    without entering a ``CVal`` context.  Every other field value is a
    ``CVal`` slot.  *array_lengths_by_shape* is threaded through so the
    walk can reject same-shape records whose shared all-record-list
    field has differing lengths.
    """
    if _c_record_dict(field_value):
        _check_c_record_nesting(
            node=field_value,
            cval_context=False,
            array_lengths_by_shape=array_lengths_by_shape,
        )
    elif isinstance(field_value, list) and _all_record_shaped(field_value):
        for element in field_value:
            _check_c_record_nesting(
                node=element,
                cval_context=False,
                array_lengths_by_shape=array_lengths_by_shape,
            )
    else:
        _check_c_record_nesting(
            node=field_value,
            cval_context=True,
            array_lengths_by_shape=array_lengths_by_shape,
        )


class _CPointerType(str):
    """A pointer type selected by a C type producer."""

    __slots__ = ()


@beartype
def _c_pointer_type(*, base: str) -> str:
    """Select a pointer while retaining its identifier placement rule."""
    return _CPointerType(object=f"{base} *")


@beartype
class _CArrayType(str):
    """An array declaration type with an explicit base and dimension."""

    __slots__ = ("_base", "_dimension")

    _base: str
    _dimension: int | None

    def __new__(
        cls, code: str, /, *, base: str, dimension: int | None
    ) -> Self:
        """Allocate text; the initializer retains producer metadata."""
        del base, dimension
        return super().__new__(cls, object=code)

    def __init__(
        self, _code: str, /, *, base: str, dimension: int | None
    ) -> None:
        """Retain identifier placement before spelling the declaration."""
        self._base = base
        self._dimension = dimension

    @property
    def base(self) -> str:
        """The array's element type, without its dimensions."""
        return self._base

    @property
    def dimension(self) -> int | None:
        """The fixed field length, or no length for a root array."""
        return self._dimension


@beartype
def _c_render_record_declaration(
    name: str,
    fields: Sequence[RecordDeclarationField],
    /,
) -> str:
    """Render a C aggregate ``struct`` declaration block.

    A pointer type abuts its identifier (the type already ends in
    ``*``); a fixed-size record-array field carries its dimension after
    the identifier (the type ends in a bracketed length); every other
    type takes a single separating space.
    """
    members: list[str] = []
    for field in fields:
        type_name = field.type_name
        if isinstance(type_name, _CArrayType):
            members.append(
                f"{type_name.base} {field.identifier}[{type_name.dimension}];"
            )
        elif isinstance(type_name, _CPointerType):
            members.append(f"{type_name}{field.identifier};")
        else:
            members.append(f"{type_name} {field.identifier};")
    return f"struct {name} {{ {' '.join(members)} }};"


@beartype
def _c_record_literal(
    name: str,
    fields: Sequence[RecordLiteralField],
    /,
) -> RenderedRecordLiteral:
    """Render a C designated-initializer compound literal ``(struct
    Name){.field = value, ...}`` as structured pieces for the shared
    compact/multiline layout code.

    The shared strategy iterates the shape's keys in document order for
    both the declaration and the literal, so designated initializers
    appear in declaration order.  A trailing comma after the last
    initializer is valid in a brace-enclosed initializer list, so the
    language-wide trailing-comma config applies unchanged.
    """
    return RenderedRecordLiteral(
        head=f"(struct {name}){{",
        entries=tuple(
            f".{field.identifier} = {field.formatted}" for field in fields
        ),
        closer="}",
        compact_pad="",
    )


@beartype
def _c_stub_param(value_type: str, ident: str, /) -> str:
    """Return a stub parameter declaration, abutting a pointer ``*``.

    A value type such as ``CVal`` takes a separating space before its
    identifier; a pointer type already ends in ``*`` and abuts the
    identifier directly.
    """
    if isinstance(value_type, _CPointerType):
        return f"{value_type}{ident}"
    return f"{value_type} {ident}"


@beartype
def _c_call_parameter_types(
    *,
    args: Sequence[Value],
    parameter_count: int,
    value_type: str,
    record_name_for_value: Callable[[Value], str | None] | None,
) -> list[str]:
    """Keep native record types in the resolved call argument columns."""
    parameter_types = [value_type] * parameter_count
    if record_name_for_value is not None:
        for row in args:
            values = row if isinstance(row, list) else [row]
            for index, value in enumerate(iterable=values):
                record_name = record_name_for_value(value)
                if record_name is not None:
                    parameter_types[index] = f"struct {record_name}"
    return parameter_types


@beartype
def _c_call_stub(
    parts: Sequence[str],
    params: Sequence[str],
    stub_return: StubReturn,
    args: Sequence[Value],
    /,
    *,
    value_type: str,
    value_zero: str,
    record_name_for_value: Callable[[Value], str | None] | None,
) -> tuple[str, ...]:
    """Return C stub declarations for a call name.

    *value_type* is the universal value type a call argument or result
    carries: ``CVal`` (the tagged-union default) or ``cJSON *`` (under
    ``json_type=CJSON``).  *value_zero* is the zero literal a
    value-returning stub returns (the zero ``CVal`` or ``NULL``).

    C has no member functions and no type-generic function templates,
    so dotted targets are modeled as a nested chain of ``struct`` types
    whose leaf field is a function pointer.  Each prototype declares
    one *value_type* parameter per call argument so call sites pass
    values through the universal value type; this avoids the K&R
    unspecified-parameter syntax (and the ``-Wdeprecated-non-prototype``
    clang warning it triggers) while still letting the same stub accept
    any mix of argument types. Known native records instead use their
    assigned ``struct`` type in each parameter position.

    Single-name calls emit a ``static`` definition so the fixture links
    under the lint workflow's run step — a bare prototype without a body
    would otherwise fail at link time.
    """
    is_value = stub_return is StubReturn.VALUE
    return_keyword = "void"
    return_stmt = ""
    if is_value:
        return_keyword = value_type
        return_stmt = f" return {value_zero};"
    parameter_types = _c_call_parameter_types(
        args=args,
        parameter_count=len(params),
        value_type=value_type,
        record_name_for_value=record_name_for_value,
    )
    proto = "void"
    if len(params) > 0:
        proto = ", ".join(parameter_types)
    stub_params = ", ".join(
        _c_stub_param(parameter_type, f"_a{i}")
        for i, parameter_type in enumerate(iterable=parameter_types)
    )
    stub_signature = _stub_parameter_signature(parameters=stub_params)
    # Discard the parameters together: the stub treats every argument alike.
    discards = ""
    if len(params) > 0:
        expressions = ", ".join(f"(void)_a{i}" for i in range(len(params)))
        discards = f" {expressions};"
    has_body = discards != "" or is_value
    stub_body = "{}"
    if has_body:
        stub_body = f"{{{discards}{return_stmt} }}"
    match parts:
        case [single]:
            return (
                (
                    f"static {return_keyword} {single}({stub_signature}) "
                    f"{stub_body}"
                ),
            )
        case [root, method]:
            stub_fn = f"{root}_{method}_stub_"
            type_name = f"{root}Type_"
            return (
                (
                    f"static {return_keyword} {stub_fn}({stub_signature}) "
                    f"{stub_body}"
                ),
                (
                    f"struct {type_name} "
                    f"{{ {return_keyword} (*{method})({proto}); }};"
                ),
                (
                    f"static const struct {type_name} {root} = "
                    f"{{ .{method} = {stub_fn} }};"
                ),
            )
        case _:
            pass
    root = parts[0]
    method = parts[-1]
    fields = parts[1:-1]
    stub_fn = "_".join((*parts, "stub_"))
    lines: list[str] = [
        f"static {return_keyword} {stub_fn}({stub_signature}) {stub_body}",
    ]
    inner_type = f"{fields[-1]}Type_"
    lines.append(
        f"struct {inner_type} {{ {return_keyword} (*{method})({proto}); }};",
    )
    prev_type = inner_type
    for i in range(len(fields) - 2, -1, -1):
        curr_type = f"{fields[i]}Type_"
        lines.append(
            f"struct {curr_type} {{ struct {prev_type} {fields[i + 1]}; }};",
        )
        prev_type = curr_type
    root_type = f"{root}Type_"
    lines.append(
        f"struct {root_type} {{ struct {prev_type} {fields[0]}; }};",
    )
    init = f"{{ .{method} = {stub_fn} }}"
    for field in reversed(fields):
        init = f"{{ .{field} = {init} }}"
    lines.append(f"static const struct {root_type} {root} = {init};")
    return tuple(lines)


_CALL_LITERAL_SYNTAX = CallLiteralSyntax(
    prefix="//",
    regex_literals=False,
    backtick_strings=False,
    raw_string_prefixes=(),
    verbatim_strings=False,
    interpolation_syntax=None,
    quotes="\"'",
    literal_span_end=None,
)


@beartype
def _format_c_call_declaration(
    name: str,
    value: str,
    _data: Value,
    _modifiers: frozenset[enum.Enum],
) -> str:
    """Format a C declaration binding a call result.

    A literal binding wraps the right-hand side in a designated-
    initializer compound literal that encodes the value's runtime type:
    a tagged-union projection for the default strategy, or
    ``struct Record0 my_data = (struct Record0){...};`` under the
    ``RECORD`` strategy.  That is wrong for a call, whose return type is
    opaque to the renderer and is neither a union-field projection nor a
    generated ``struct``.

    C has no type inference, so the binding still needs an explicit
    declared type.  No caller-supplied return-type hint is required:
    every generated call stub returns the universal tagged ``CVal``
    union (a ``StubReturn.VALUE`` stub returns ``CVal``), so the call
    result's static type is always ``CVal`` -- exactly the type a C
    literal binding already declares.  The only call-vs-literal
    difference is dropping the value-wrapping compound literal, so the
    call result is bound directly with a plain ``CVal`` declaration.
    """
    comments = _CALL_LITERAL_SYNTAX.split(value)
    return f"CVal {name} = {comments.code};{comments.trailing_comments}"


@beartype
def _format_c_call_assignment(name: str, value: str, _data: Value) -> str:
    """Format a C reassignment binding a call result.

    The call-expression counterpart of :func:`_format_c_call_declaration`;
    the variable is already declared ``CVal``, so the call result is
    assigned directly with no compound-literal wrapping.
    """
    comments = _CALL_LITERAL_SYNTAX.split(value)
    return f"{name} = {comments.code};{comments.trailing_comments}"


# Static preamble emitted under ``json_type=CJSON``: the cJSON header
# replaces the default ``CVal`` / ``CKV`` type declarations, since every
# value is built from cJSON's own ``cJSON *`` node type.
_CJSON_STATIC_PREAMBLE: tuple[str, ...] = (
    import_preamble(code="#include <cjson/cJSON.h>"),
)

_CJSON_RECORD_REJECTED_MSG = (
    "C json_type renders data as a cJSON_Create*(...) node tree and is "
    "incompatible with heterogeneous_strategy=RECORD, which generates "
    "struct declarations. Use heterogeneous_strategy=ERROR."
)

_CJSON_NON_SCALAR_ARG_MSG = (
    "C json_type can only render a scalar (or temporal / bytes) call "
    "argument inline as a single cJSON_Create*(...) expression; a "
    "container call argument is not supported in this slice"
)


@beartype
def _reject_cjson_call_arg(value: Value, /) -> None:
    """Reject a call argument the cJSON representation would change."""
    reject_cjson_unrepresentable(data=value, language_name="C")


@beartype
def _check_c_json_value_keys(*, data: Value) -> None:
    """Reject non-string object keys under ``json_type=CJSON``.

    A dict renders as a ``cJSON_CreateObject`` whose members are added
    with ``cJSON_AddItemToObject(obj, "key", ...)``, so every key must be
    a JSON object string.  ``OrderedMap`` is a :class:`dict` subclass, so
    the ``dict`` arm covers it too.
    """
    match data:
        case dict():
            for key, value in data.items():
                if not isinstance(key, str):
                    msg = (
                        "C json_type can only represent dict keys as JSON "
                        f"object strings, not {type(key).__name__}"
                    )
                    raise UnrepresentableInputError(msg)
                _check_c_json_value_keys(data=value)
        case list() | set():
            for item in data:
                _check_c_json_value_keys(data=item)
        case _:
            return


@beartype
@dataclasses.dataclass(frozen=True, kw_only=True)
class _CJsonBindingSource:
    """JSON data and reference syntax retained until node construction."""

    data: JsonValue
    ref_key: str | None
    ref_case: IdentifierCase | None


class _CJsonReferenceLiteral(str):
    """A rendered initializer with its original reference-bearing tree."""

    __slots__ = ("source",)

    source: _CJsonBindingSource

    def __new__(cls, value: str, /, *, source: _CJsonBindingSource) -> Self:
        """Attach source metadata after generic indentation is removed."""
        del source
        return super().__new__(cls, object=value)

    def __init__(self, _value: str, /, *, source: _CJsonBindingSource) -> None:
        """Initialize the retained source after allocating the string."""
        self.source = source


@beartype
def _cjson_binding_source(*, value: str, data: Value) -> _CJsonBindingSource:
    """Use retained references or the ordinary normalized JSON data."""
    if isinstance(value, _CJsonReferenceLiteral):
        return value.source
    return _CJsonBindingSource(
        data=to_jsonable(data=data), ref_key=None, ref_case=None
    )


@beartype
def _cjson_reference_name(
    *, node: JsonValue, ref_key: str | None, ref_case: IdentifierCase | None
) -> str | None:
    """Read a validated source reference without inspecting rendered
    text.
    """
    if ref_key is None or not isinstance(node, dict) or len(node) != 1:
        return None
    name = node.get(ref_key)
    if not isinstance(name, str):
        return None
    return name if ref_case is None else ref_case.convert(name=name)


@beartype
@dataclasses.dataclass(frozen=True, kw_only=True)
class _CJsonBuild:
    """The statements that build a cJSON node tree, plus its root name.

    Pre-order allocation always names the outermost node ``{prefix}0``,
    so the binding line can reference :attr:`root` without the builder
    and the binding formatter sharing state.
    """

    lines: tuple[str, ...]
    root: str


@beartype
def _c_json_object_key(key: Scalar, /) -> str:
    """Return a JSON object *key* as a C string literal.

    A ``cJSON`` object is keyed by JSON strings.
    :meth:`C.validate_spec_for_data` (and the language's
    ``supports_non_string_dict_keys = False``) reject a non-string key
    before any value is rendered, so *key* is a string here; ``str``
    narrows its static :data:`~literalizer._types.Scalar` type to
    :class:`str` without a redundant runtime branch.
    """
    return format_string_c(value=str(object=key))


@beartype
def _c_cjson_scalar_create(
    value: JsonValue,
    /,
    *,
    format_integer: Callable[[int], str],
    format_float: Callable[[float], str],
) -> str:
    """Return the ``cJSON_Create*`` expression for one JSON scalar.

    *value* is a JSON-able value (see
    :func:`~literalizer._formatters.format_json_value.to_jsonable`):
    temporal and bytes values have already been folded into strings.
    cJSON has no integer constructor, so an integer is widened to
    ``double`` at the call site (``cJSON_CreateNumber((double)42)``);
    :func:`format_integer` supplies the ``ULL`` suffix that keeps a
    value above ``LLONG_MAX`` a well-formed constant before the cast.

    A container *value* has no single-expression cJSON form (its nodes
    must be built across statements), so one reaching here -- only via a
    container call argument -- is rejected.
    """
    match value:
        case bool():
            effective_value = 0
            if value:
                effective_value = 1
            return f"cJSON_CreateBool({effective_value})"
        case int():
            return f"cJSON_CreateNumber((double){format_integer(value)})"
        case float():
            return f"cJSON_CreateNumber({format_float(value)})"
        case str():
            literal = format_string_c(value=value)
            return f"cJSON_CreateString({literal})"
        case None:
            return "cJSON_CreateNull()"
        case _:
            raise UnrepresentableInputError(_CJSON_NON_SCALAR_ARG_MSG)


@beartype
def _c_cjson_build(
    jsonable: JsonValue,
    /,
    *,
    prefix: str,
    node_indices: Iterator[int],
    format_integer: Callable[[int], str],
    format_float: Callable[[float], str],
    ref_key: str | None,
    ref_case: IdentifierCase | None,
) -> _CJsonBuild:
    """Walk a JSON-able tree and return its portable cJSON build.

    cJSON's ``cJSON_AddItemTo*`` helpers return ``cJSON_bool``, not the
    item, so a container cannot be composed as a single nested
    expression.  Each node is therefore bound to its own
    ``cJSON *{prefix}{n}``
    variable and added to its parent in a following statement -- the
    portable standard-C form every cJSON tutorial shows.  Nodes are
    numbered in pre-order using the document-wide node index sequence,
    including builds for other bindings in the same document.
    """
    lines: list[str] = []

    @beartype
    def _emit(node: JsonValue, /) -> str:
        """Emit the build statements for *node*; return its variable."""
        name = f"{prefix}{next(node_indices)}"
        reference = _cjson_reference_name(
            node=node, ref_key=ref_key, ref_case=ref_case
        )
        if reference is not None:
            lines.append(f"cJSON *{name} = cJSON_Duplicate({reference}, 1);")
            return name
        match node:
            case dict():
                lines.append(f"cJSON *{name} = cJSON_CreateObject();")
                for key, child_value in node.items():
                    child = _emit(child_value)
                    lines.append(
                        f"cJSON_AddItemToObject({name}, "
                        f"{_c_json_object_key(key)}, {child});"
                    )
            case list():
                lines.append(f"cJSON *{name} = cJSON_CreateArray();")
                for item in node:
                    child = _emit(item)
                    lines.append(f"cJSON_AddItemToArray({name}, {child});")
            case _:
                scalar = _c_cjson_scalar_create(
                    node,
                    format_integer=format_integer,
                    format_float=format_float,
                )
                lines.append(f"cJSON *{name} = {scalar};")
        return name

    root = _emit(jsonable)
    return _CJsonBuild(lines=tuple(lines), root=root)


@beartype
def _c_integer_field_type(*, value: int) -> str:
    """Return the C field type covering the integer value."""
    field_type = "long long"
    if value > I64_MAX:
        field_type = "unsigned long long"
    return field_type


@beartype
def _c_temporal_field_type(
    *, value: str | bytes | dt.date | dt.time, epoch: bool
) -> str:
    """Choose the C field type for string and temporal values."""
    field_type: str = _c_pointer_type(base="const char")
    if epoch and isinstance(value, dt.datetime):
        field_type = "long long"
    return field_type


# Work around https://github.com/astral-sh/ty/issues/4573.
if TYPE_CHECKING:
    _BytesEnumMember = enum.member[Callable[[bytes], str]]
    _IntegerEnumMember = enum.member[Callable[[int], str]]
else:
    _BytesEnumMember = enum.member
    _IntegerEnumMember = enum.member


@beartype
@dataclasses.dataclass(frozen=True, kw_only=True)
class C(metaclass=LanguageCls):
    """C language specification."""

    format_call_class_scope_stub = default_format_call_stub

    immutable_variable_modifiers: ClassVar[frozenset[enum.Enum]] = frozenset()
    wrap_in_file_tolerates_pre_indent = True
    uses_resolved_ref_declaration_data = True
    module_name_shares_variable_scope = False
    reserved_variable_identifier_pattern: ClassVar[re.Pattern[str] | None] = (
        None
    )
    reserved_call_parameter_identifiers: ClassVar[frozenset[str]] = frozenset()
    reserved_call_parameter_identifier_pattern: ClassVar[
        re.Pattern[str] | None
    ] = None
    accepts_type_name_call_target = True
    declares_type_name_call_target = True
    dotted_call_root_shares_entrypoint_namespace = True
    reserved_bare_call_target_identifiers: ClassVar[frozenset[str]] = (
        frozenset()
    )
    reserved_call_target_head_identifiers: ClassVar[frozenset[str]] = (
        frozenset()
    )
    contextual_call_target_identifiers: ClassVar[frozenset[str]] = frozenset()
    call_parameter_shadowing = CallParameterShadowing.ALLOWED
    reserved_call_target_keywords_case_sensitive = True
    module_name_must_start_uppercase = False
    new_variable_name_syntax = NewVariableNameSyntax.ASCII
    max_variable_identifier_length: ClassVar[int | None] = None
    call_stub_result: ClassVar[CallStubResult | None] = None
    call_literal_syntax: ClassVar[CallLiteralSyntax | None] = (
        _CALL_LITERAL_SYNTAX
    )
    call_target_name_syntax: ClassVar[NewVariableNameSyntax | None] = None
    supports_multiline_dict_layout = True
    pools_map_integer_width = True

    format_integer_widened = no_format_integer_widened
    format_integer_beyond_i64 = no_format_integer_beyond_i64
    format_constructor_target: ClassVar["staticmethod[[str], str]"] = (
        staticmethod(identity_constructor_target)
    )
    sequence_binding_declarations = default_sequence_binding_declarations
    format_call_binding_body_preamble = no_call_binding_body_preamble
    format_call_binding_file_pragmas = no_call_binding_file_pragmas

    module_name: str = "Module"

    leading_preamble = no_leading_preamble
    extension = ".c"
    pygments_name = "c"
    stringifies_nested_collections = False
    supports_special_floats = True
    supports_variable_names = True
    supports_no_variable_wrap_in_file = False
    wraps_data_dependent_preamble_in_body = False
    dict_supports_heterogeneous_values = True
    supports_native_invocations = False
    supports_dotted_calls = True
    has_free_function_calls = True
    reserved_identifiers: ClassVar[frozenset[str]] = frozenset()
    declares_call_parameter_names = True
    reserved_variable_identifiers_case_sensitive: bool = True
    reserved_variable_identifiers: frozenset[str] = frozenset(
        {
            "_Alignas",
            "_Alignof",
            "_Atomic",
            "_Bool",
            "_Complex",
            "_Generic",
            "_Imaginary",
            "_Noreturn",
            "_Static_assert",
            "_Thread_local",
            "auto",
            "break",
            "case",
            "char",
            "const",
            "continue",
            "default",
            "do",
            "double",
            "else",
            "enum",
            "extern",
            "float",
            "for",
            "goto",
            "if",
            "inline",
            "int",
            "long",
            "register",
            "restrict",
            "return",
            "short",
            "signed",
            "sizeof",
            "static",
            "struct",
            "switch",
            "typedef",
            "typeof",
            "union",
            "unsigned",
            "void",
            "volatile",
            "while",
        }
    )
    allows_empty_call_parens = True
    supports_dotted_call_stub = True
    call_returns_expression = True
    supports_json_call_result_binding = False
    supports_zero_parameter_calls = True
    max_call_parameters = NO_CALL_PARAMETER_LIMIT
    supports_inline_multiline_dict_args = True
    supports_standalone_comments_in_wrapped_calls = True
    supports_multi_param_call_wrapper_stub = True
    supports_dict_literal_as_free_expression = True
    reserved_module_identifiers: ClassVar[frozenset[str]] = frozenset(
        {
            "begin",
            "end",
        }
    )
    supports_module_name = True
    supports_empty_dict_key = False
    supports_call_style = True
    supports_default_dict_key_type = False
    supports_default_dict_value_type = False
    supports_default_sequence_element_type = False
    supports_default_set_element_type = False
    supports_default_ordered_map_value_type = False
    json_type_variant_name_suffix: ClassVar[str | None] = None
    supports_non_ascii_string_literals = True
    supports_multiline_string_literals = False
    supports_empty_sibling_sequence_type_hints = True
    supports_typed_dict_open = False
    language_id: ClassVar[str] = "c"
    variant_metadata: ClassVar[VariantMetadata] = VariantMetadata(
        round_trip_capabilities=frozenset(
            {
                RoundTripCapability.INTERPOLATION_STRINGS,
            }
        ),
        modifier_sequence_format_overrides={},
        string_literals_escape_null_byte=True,
        supports_ref_elements_in_tuple_strategy=False,
    )
    supports_record_struct_name_prefix = False
    supports_record_shape_names = False
    record_shape_names_emit_declarations = False
    supports_non_string_dict_keys = False
    checks_raw_control_dict_keys_separately = False

    class DateFormats(DateFormatEnum):
        """Date format options for C."""

        ISO = DateFormatConfig(
            formatter=format_date_iso, type_produced=str, preamble_lines=()
        )

    class DatetimeFormats(DatetimeFormatEnum):
        """Datetime format options for C."""

        ISO = DatetimeFormatConfig(
            formatter=format_datetime_iso,
            type_produced=str,
            preamble_lines=(),
        )

        EPOCH = DatetimeFormatConfig(
            formatter=format_datetime_epoch,
            type_produced=int,
            preamble_lines=(),
        )

    class BytesFormats(FormatValueMixin[Callable[[bytes], str]], enum.Enum):
        """Bytes formatting options."""

        HEX = _BytesEnumMember(value=format_bytes_hex)
        BASE64 = _BytesEnumMember(value=format_bytes_base64)

        def __call__(self, data: bytes, /) -> str:
            """Format bytes."""
            return self.value(data)

    class SequenceFormats(enum.Enum):
        """Sequence type options for C."""

        ARRAY = SequenceFormatConfig(
            length_is_part_of_type=False,
            sequence_open=fixed_open(
                open_str="((CVal){.a = (CVal[]){",
            ),
            close="}})",
            supports_heterogeneity=True,
            single_element_trailing_comma=False,
            single_element_template=None,
            supports_trailing_comma=True,
            empty_sequence=None,
            preamble_lines=(),
            format_entry=passthrough_sequence_entry,
            typed_opener_fallback=None,
            uses_typed_literal_for_scalars=False,
            requires_uniform_record_shapes=False,
            declared_type=None,
            narrowed_empty_form=None,
        )

    class SetFormats(enum.Enum):
        """Set type options for C."""

        SET = SetFormatConfig(
            set_open=fixed_open(open_str="((CVal){.a = (CVal[]){"),
            close="}})",
            empty_set=None,
            preamble_lines=(),
            set_opener_template="",
            supports_heterogeneity=True,
            supports_trailing_comma=True,
        )

    class CommentFormats(enum.Enum):
        """Comment style options."""

        DOUBLE_SLASH = CommentConfig(
            prefix="//",
            suffix="",
        )
        BLOCK = CommentConfig(
            prefix="/*",
            suffix=" */",
        )

    class DeclarationStyles(enum.Enum):
        """Declaration style options."""

        TYPED = DeclarationStyleConfig(
            formatter=variable_declaration_formatter(
                template="CVal {name} = {value};",
            ),
            supports_redefinition=True,
        )

    class DictEntryStyles(enum.Enum):
        """Dict entry style options."""

        DEFAULT = enum.auto()

    class DictFormats(enum.Enum):
        """Dict/map format options."""

        DEFAULT = enum.auto()

    class EmptyDictKey(enum.Enum):
        """Empty dict key options."""

        ALLOW = enum.auto()

    class FloatFormats(
        FloatSpecialsMixin,
        enum.Enum,
        positive_infinity="INFINITY",
        negative_infinity="-INFINITY",
        nan="NAN",
    ):
        """Float format options."""

        REPR = enum.member(value=format_float_repr)
        SCIENTIFIC = enum.member(value=format_float_scientific)
        FIXED = enum.member(value=format_float_fixed)

    class IntegerFormats(FormatValueMixin[Callable[[int], str]], enum.Enum):
        """Integer format options."""

        DECIMAL = _IntegerEnumMember(value=str)
        HEX = _IntegerEnumMember(value=format_integer_hex)

        def __call__(self, value: int, /) -> str:
            """Format an integer."""
            formatter: Callable[[int], str] = self.value
            return formatter(value)

    class NumericLiteralSuffixes(enum.Enum):
        """Numeric literal suffix options."""

        NONE = enum.auto()
        AUTO = enum.auto()

    class NumericSeparators(enum.Enum):
        """Numeric separator options."""

        NONE = enum.auto()

    class NumericStyles(enum.Enum):
        """Numeric literal style options."""

        OVERLOADED = enum.auto()

    class StringFormats(enum.Enum):
        """String format options."""

        DOUBLE = enum.auto()

    class TrailingCommas(enum.Enum):
        """Trailing comma options."""

        YES = TrailingCommaConfig(multiline_trailing_comma=True)
        NO = TrailingCommaConfig(multiline_trailing_comma=False)

    date_formats = DateFormats
    datetime_formats = DatetimeFormats
    bytes_formats = BytesFormats
    sequence_formats = SequenceFormats
    set_formats = SetFormats
    comment_formats = CommentFormats

    class VariableTypeHints(enum.Enum):
        """Variable type hint options."""

        NEVER = enum.auto()
        SAFE = enum.auto()

    variable_type_hints_formats = VariableTypeHints
    declaration_styles = DeclarationStyles
    dict_entry_styles = DictEntryStyles
    dict_formats = DictFormats
    empty_dict_keys = EmptyDictKey
    float_formats = FloatFormats
    integer_formats = IntegerFormats
    integer_width_strategies = BareIntegerWidthStrategies
    numeric_literal_suffixes = NumericLiteralSuffixes
    numeric_separators = NumericSeparators
    numeric_styles = NumericStyles
    string_formats = StringFormats
    trailing_commas = TrailingCommas

    class StatementTerminatorStyles(enum.Enum):
        """Statement terminator options."""

        SEMICOLON = enum.auto()

    statement_terminator_styles = StatementTerminatorStyles

    class CallStyles(enum.Enum):
        """C call style options."""

        POSITIONAL = PositionalCallStyle(
            arg_separator=", ", parenthesize_each_arg=False
        )

    call_styles = CallStyles

    class Modifiers(enum.Enum):
        """C++/Java/C#-style declaration modifiers: this language has none."""

    modifiers = Modifiers

    class HeterogeneousStrategies(enum.Enum):
        """Heterogeneous-scalar strategy options.

        C represents heterogeneous scalar collections with its tagged
        ``CVal`` union by default (``ERROR``).  ``RECORD`` instead
        renders each record-shaped dict (non-empty, string-keyed) as a
        generated aggregate ``struct`` declared in the preamble plus a
        matching ``(struct Record0){.field = value, ...}``
        designated-initializer compound literal, so a field may be a
        cleanly-typed scalar or a nested ``struct`` rather than a
        ``CVal`` union slot.
        """

        ERROR = enum.auto()
        RECORD = enum.auto()

    heterogeneous_strategies = HeterogeneousStrategies

    class JsonTypes(JsonType):
        """JSON value type options for C."""

        CJSON = "cJSON"
        """The ``cJSON`` library's ``cJSON *`` dynamic JSON value type
        from ``<cjson/cJSON.h>``.
        """

    json_types = JsonTypes

    class BoolFormats(enum.Enum):
        """Empty: this language has no alternative boolean formats."""

    bool_formats = BoolFormats

    class VersionFormats(enum.Enum):
        """Version options for C."""

        C99 = enum.auto()

    version_formats = VersionFormats

    module_name_case: ClassVar[IdentifierCase] = IdentifierCase.SNAKE

    modifier_combinations: ClassVar[tuple[ModifierCombination, ...]] = ()
    identifier_cases: ClassVar[tuple[IdentifierCase, ...]] = (
        IdentifierCase.SNAKE,
        IdentifierCase.UPPER_SNAKE,
        IdentifierCase.PASCAL,
    )
    supported_ref_cases: ClassVar[frozenset[IdentifierCase]] = (
        NON_KEBAB_REF_CASES
    )

    def __post_init__(self) -> None:
        """Reject ``json_type`` combinations the generator cannot emit.

        Under ``json_type=CJSON`` the data is rendered as a
        ``cJSON_Create*(...)`` node tree, which is incompatible with the
        ``RECORD`` heterogeneous strategy (it generates ``struct``
        declarations that the cJSON renderer would silently drop).
        """
        if (
            self._json_type_active
            and self.heterogeneous_strategy
            is type(self.heterogeneous_strategy).RECORD
        ):
            raise IncompatibleFormatsError(_CJSON_RECORD_REJECTED_MSG)

    def validate_spec_for_data(self, data: Value) -> None:
        """Raise if the spec cannot produce valid C for *data*.

        Under ``json_type=CJSON`` a dict becomes a
        ``cJSON_CreateObject`` whose members are keyed by JSON object
        strings, so non-string dict keys are rejected.

        Under the ``RECORD`` strategy a record-shaped dict renders as a
        ``(struct RecordN){...}`` literal (and a list whose elements are
        all record-shaped dicts as a ``struct RecordN[]`` array); a
        ``struct`` is not a ``CVal`` union member, so a record reachable
        only through a non-record container would have to occupy a
        ``CVal`` slot and cannot compile.  The same walk rejects two
        same-shape records whose shared all-record-list field has
        differing lengths (the field's fixed-size ``struct`` array is
        sized from the first-seen instance).  Rejecting here keeps the
        boundary explicit rather than emitting C that fails to build
        (cf. the set / non-record-dict field boundary tracked in
        #2317).  The default (``ERROR``) strategy is unconstrained.
        """
        if self._json_type_active:
            _check_c_json_value_keys(data=data)
            reject_cjson_unrepresentable(data=data, language_name="C")
            return
        if self._record_strategy_active:
            _check_c_record_nesting(
                node=data,
                cval_context=False,
                array_lengths_by_shape={},
            )

    @cached_property
    @beartype
    def supports_scalar_before_comments(self) -> bool:
        """Whether a comment can sit above the rendered value.

        Under :attr:`json_type` the declaration is built from the
        document rather than from the formatted value, so a comment
        written into that value never reaches the output; it goes
        above the declaration instead (issue #4546).
        """
        return not self._json_type_active

    @cached_property
    @beartype
    def supports_collection_comments(self) -> bool:
        """Whether a comment can sit inside the rendered value.

        ``cJSON_Parse`` is handed one JSON document, and JSON has no
        comments, so a comment written inside
        it would be text the parser refuses.  The comments go
        before the declaration instead (issue #4546).
        """
        return not self._json_type_active

    @cached_property
    @beartype
    def _json_type_active(self) -> bool:
        """Return whether C should render via cJSON's ``cJSON *`` type."""
        return self.json_type is not None

    @cached_property
    @beartype
    def validate_call_arg(self) -> Callable[[Value], None]:
        """Return call-argument validation for this language.

        Under ``json_type=CJSON`` an argument goes into the same tree
        a declared value does, so it faces the same limits from the C
        library; ``validate_spec_for_data`` covers only the
        ``literalize`` path (issue #4469).
        """
        if self._json_type_active:
            return _reject_cjson_call_arg
        return no_validate_call_arg

    format_call_statement = default_format_call_statement

    wrap_calls_with_declarations = default_wrap_calls_with_declarations

    @property
    def call_wrapper_entrypoint_name(self) -> str:
        """Return the generated complete-file entry-point name."""
        return self.module_name

    def wrap_in_file(
        self,
        content: str,
        context: FileWrapperContext,
    ) -> str:
        """Wrap a C declaration in a main function."""
        variable_name = context.variable_name
        body_preamble = context.body_preamble
        content = prepend_body_preamble(
            content=content,
            body_preamble=body_preamble,
        )
        use_line = ""
        if variable_name != "":
            use_line = f"\n{self.indent}(void){variable_name};"
        return (
            f"int {self.module_name}(void) {{\n{content}{use_line}\n"
            f"{self.indent}return 0;\n}}"
        )

    def wrap_combined_in_file(
        self,
        declaration: str,
        assignment: str,
        context: FileWrapperContext,
    ) -> str:
        """Wrap C declaration + assignment in a function.

        Reads ``variable_name`` between the declaration and the
        assignment so the initial value is not a dead store flagged by
        clang-tidy's ``clang-analyzer-deadcode.DeadStores`` check.
        """
        variable_name = context.variable_name
        mid_use = f"(void){variable_name};\n"
        return self.wrap_in_file(
            content=f"{declaration}\n{mid_use}{assignment}",
            context=context,
        )

    date_format: DateFormats = DateFormats.ISO
    datetime_format: DatetimeFormats = DatetimeFormats.ISO
    bytes_format: BytesFormats = BytesFormats.HEX
    sequence_format: SequenceFormats = SequenceFormats.ARRAY
    set_format: SetFormats = SetFormats.SET
    variable_type_hints: VariableTypeHints = VariableTypeHints.NEVER
    comment_format: CommentFormats = CommentFormats.DOUBLE_SLASH
    declaration_style: DeclarationStyles = DeclarationStyles.TYPED
    dict_entry_style: DictEntryStyles = DictEntryStyles.DEFAULT
    dict_format: DictFormats = DictFormats.DEFAULT
    float_format: FloatFormats = FloatFormats.REPR
    integer_format: IntegerFormats = IntegerFormats.DECIMAL
    integer_width_strategy: BareIntegerWidthStrategies = (
        BareIntegerWidthStrategies.BARE
    )
    numeric_literal_suffix: NumericLiteralSuffixes = (
        NumericLiteralSuffixes.NONE
    )
    numeric_separator: NumericSeparators = NumericSeparators.NONE
    numeric_style: NumericStyles = NumericStyles.OVERLOADED
    string_format: StringFormats = StringFormats.DOUBLE
    trailing_comma: TrailingCommas = TrailingCommas.YES
    statement_terminator_style: StatementTerminatorStyles = (
        StatementTerminatorStyles.SEMICOLON
    )
    heterogeneous_strategy: HeterogeneousStrategies = (
        HeterogeneousStrategies.ERROR
    )
    json_type: JsonTypes | None = None
    # Keep in sync with the ``-std=`` flag passed to clang and clang-tidy
    # in ``.github/workflows/lint.yml``.
    language_version: VersionFormats = VersionFormats.C99
    indent: str = "    "
    bool_field: str = "b"
    int_field: str = "i"
    uint_field: str = "u"
    float_field: str = "f"
    string_field: str = "s"
    array_field: str = "a"
    map_field: str = "m"
    key_field: str = "k"
    value_field: str = "v"

    indent_closing_delimiter: ClassVar[bool] = False
    element_separator: ClassVar[str] = ", "
    skip_null_dict_values: ClassVar[bool] = False
    supports_scalar_inline_comments: ClassVar[bool] = False
    statement_terminator: ClassVar[str] = ";"
    static_body_preamble: ClassVar[Sequence[str]] = ()
    special_float_preamble: ClassVar[tuple[str, ...]] = (
        import_preamble(code="#include <math.h>"),
    )
    call_style: CallStyles = CallStyles.POSITIONAL

    @cached_property
    @beartype
    def call_style_config(self) -> PositionalCallStyle:
        """Configuration for the chosen call style."""
        return self.call_style.value

    @cached_property
    @beartype
    def _record_strategy_active(self) -> bool:
        """Return whether the ``RECORD`` heterogeneous strategy is set."""
        return (
            self.heterogeneous_strategy
            is type(self.heterogeneous_strategy).RECORD
        )

    def _c_record_field_type(
        self,
        request: RecordFieldType,
        /,
    ) -> str:
        """Return the C ``struct`` member type for one record field.

        A field whose value is itself a nested record-shaped dict uses
        that record's generated ``struct`` type.  A field whose value
        is a list whose every element is a record-shaped dict of one
        shared shape becomes a fixed-size ``struct`` array member
        (records are the uniform, exactly-representable container
        case).  Every scalar maps to its exact C type.

        A scalar or heterogeneous list, or an empty list, is typed a
        pointer to ``CVal`` and rendered as a ``CVal`` array literal:
        C's tagged ``CVal`` union already represents arbitrary
        heterogeneity, so reusing it for these fields keeps every
        literal and type pair valid (a fixed-size scalar array would be
        the wrong length when two same-shape records carry
        different-length lists, and is ill-formed -- a zero-length
        array -- for an empty list).  This is the recorded answer to
        the issue's "fixed-size array versus pointer" container-field
        design call.

        A set, an ordered map, or a non-record dict field (out of
        scope for the base port, #2476/#2317) keeps its own
        self-wrapping ``CVal`` form and is typed ``CVal``.
        """
        if request.record_name is not None:
            return f"struct {request.record_name}"
        value = request.value
        if request.element_record_name is not None and isinstance(
            value,
            list,
        ):
            return _CArrayType(
                f"struct {request.element_record_name} [{len(value)}]",
                base=f"struct {request.element_record_name}",
                dimension=len(value),
            )
        epoch = self.datetime_format.value.type_produced is int
        field_type: str
        match value:
            case bool():
                field_type = "bool"
            case int():
                field_type = _c_integer_field_type(value=value)
            case float():
                field_type = "double"
            case None:
                return _c_pointer_type(base="const void")
            case str() | bytes() | dt.date() | dt.time():
                return _c_temporal_field_type(value=value, epoch=epoch)
            case list():
                return _c_pointer_type(base="const CVal")
            case _:
                field_type = "CVal"
        return field_type

    @cached_property
    @beartype
    def _record_renderer(self) -> RecordRenderer:
        """C syntax hooks for the ``RECORD`` strategy."""
        return RecordRenderer(
            name_prefix=_C_RECORD_PREFIX,
            record_shape_names=_C_NO_RECORD_SHAPE_NAMES,
            field_identifier=partial(
                _c_record_field_identifier,
                reserved_identifiers=self.reserved_variable_identifiers,
            ),
            field_identifier_key=identity_field_identifier_key,
            field_type=self._c_record_field_type,
            render_declaration=_c_render_record_declaration,
            render_literal=_c_record_literal,
            field_type_names_nested_records=False,
            suppress_custom_name_declarations=False,
        )

    @cached_property
    @beartype
    def _record_strategy(self) -> ActiveRecordStrategy:
        """Behavior + ``struct``-declaration preamble for ``RECORD``."""
        return build_record_strategy(
            renderer=self._record_renderer,
            widen_unrecordizable_nested_sibling_maps=True,
            derecordized_map_open=self._map_open_str,
        )

    @cached_property
    @beartype
    def data_dependent_preamble(self) -> Callable[[Value], tuple[str, ...]]:
        """Return data-dependent preamble lines.

        Under ``RECORD`` these are the generated ``struct RecordN``
        declarations, emitted after the static ``CVal`` / ``CKV`` type
        declarations (a record field may itself be ``const CVal *``).
        """
        if self._record_strategy_active:
            return self._record_strategy.preamble
        return no_data_preamble

    @cached_property
    @beartype
    def heterogeneous_behavior(self) -> HeterogeneousBehavior:
        """Return the heterogeneous-behavior config.

        ``RECORD`` resolves to the shared record behavior (its value
        needs the per-instance renderer, so it cannot be stored on the
        enum member); ``ERROR`` keeps the ``CVal``-union default.
        """
        if self._record_strategy_active:
            return self._record_strategy.behavior
        return NO_HETEROGENEOUS_BEHAVIOR

    call_data_dependent_preamble = default_call_data_dependent_preamble

    type_hint_collection_preamble_lines = (
        default_type_hint_collection_preamble_lines
    )

    format_call_stub = default_format_call_stub

    @cached_property
    @beartype
    def format_call_preamble_stub(
        self,
    ) -> Callable[
        [Sequence[str], Sequence[str], StubReturn, Sequence[Value]],
        tuple[str, ...],
    ]:
        """Return file-scope stubs for a call expression.

        Under ``json_type=CJSON`` the universal value type is
        ``cJSON *`` (zero value ``NULL``) rather than the tagged
        ``CVal`` union, so the stub prototypes and bodies use it.
        """
        if self._json_type_active:
            return partial(
                _c_call_stub,
                value_type=_c_pointer_type(base="cJSON"),
                value_zero="NULL",
                record_name_for_value=None,
            )
        record_name_for_value = None
        if self._record_strategy_active:
            record_name_for_value = self._record_strategy.record_name_for_value
        return partial(
            _c_call_stub,
            value_type="CVal",
            value_zero="(CVal){0}",
            record_name_for_value=record_name_for_value,
        )

    format_call_target = default_format_call_target

    format_call_ref_identifier = default_format_call_ref_identifier

    format_call_arg_ref_identifier = default_format_call_arg_ref_identifier

    format_call_arg_ref_identifier_consumable = (
        default_format_call_arg_ref_identifier_consumable
    )

    consumable_ref_value_inhibits_consuming_form = (
        default_consumable_ref_value_inhibits_consuming_form
    )

    @cached_property
    @beartype
    def format_call_arg(self) -> Callable[[Value, str], str]:
        """Wrap each call argument in the ``CVal`` union so call sites
        match the concrete prototype emitted by :func:`_c_call_stub`.

        Under ``json_type=CJSON`` a scalar argument is rendered inline as
        a single ``cJSON_Create*(...)`` expression instead (the rendered
        ``CVal`` text is discarded), matching the ``cJSON *`` stub
        prototype.
        """
        if self._json_type_active:
            format_integer = self.format_integer
            format_float = self.format_float

            @beartype
            def _format_cjson_call_arg(
                raw_value: Value,
                _formatted: str,
            ) -> str:
                """Render a scalar call argument as a cJSON expression."""
                return _c_cjson_scalar_create(
                    to_jsonable(data=raw_value),
                    format_integer=format_integer,
                    format_float=format_float,
                )

            return _format_cjson_call_arg
        format_entry = self._format_entry
        string_field = self.string_field

        @beartype
        def _format_c_call_arg(
            raw_value: Value,
            formatted: str,
        ) -> str:
            """Wrap time arguments omitted by the shared entry
            formatter.
            """
            if isinstance(raw_value, dt.time):
                return f"((CVal){{.{string_field} = {formatted}}})"
            return format_entry(raw_value, formatted)

        return _format_c_call_arg

    @cached_property
    @beartype
    def format_string(self) -> Callable[[str], str]:
        """Format a string value as a quoted literal."""
        return format_string_c

    @cached_property
    @beartype
    def _format_entry(self) -> Callable[[Value, str], str]:
        """Shared entry formatter that wraps values in ``CVal``
        literals.

        Under ``RECORD`` the bare ``true`` / ``false`` / ``NULL``
        literals reach this hook unwrapped (so a scalar record field is
        clean), so the ``RECORD`` variant additionally wraps ``bool`` /
        ``None`` and passes a record-shaped dict (already a ``struct``
        literal) through untouched.
        """
        if self._record_strategy_active:
            return _make_format_c_entry_record(
                int_field=self.int_field,
                uint_field=self.uint_field,
                float_field=self.float_field,
                string_field=self.string_field,
                bool_field=self.bool_field,
                array_field=self.array_field,
                datetime_as_int=(
                    self.datetime_format.value.type_produced is int
                ),
            )
        return _make_format_c_entry(
            int_field=self.int_field,
            uint_field=self.uint_field,
            float_field=self.float_field,
            string_field=self.string_field,
            datetime_as_int=self.datetime_format.value.type_produced is int,
        )

    @cached_property
    @beartype
    def _seq_open_str(self) -> str:
        """Opening string for a C sequence literal."""
        return f"((CVal){{.{self.array_field} = (CVal[]){{"

    @cached_property
    @beartype
    def _map_open_str(self) -> str:
        """Opening string for a C map literal."""
        return f"((CVal){{.{self.map_field} = (CKV[]){{"

    @cached_property
    @beartype
    def null_literal(self) -> str:
        """Literal representing ``None``.

        Bare ``NULL`` under ``RECORD`` (a clean ``const void *`` record
        field); ``_format_entry`` re-wraps it for ``CVal`` contexts.
        """
        if self._record_strategy_active:
            return "NULL"
        return f"((CVal){{.{self.string_field} = NULL}})"

    @cached_property
    @beartype
    def true_literal(self) -> str:
        """Literal representing ``True``.

        Bare ``true`` under ``RECORD`` (a clean ``bool`` record field);
        ``_format_entry`` re-wraps it for ``CVal`` contexts.
        """
        if self._record_strategy_active:
            return "true"
        return f"((CVal){{.{self.bool_field} = true}})"

    @cached_property
    @beartype
    def false_literal(self) -> str:
        """Literal representing ``False``.

        Bare ``false`` under ``RECORD`` (a clean ``bool`` record
        field); ``_format_entry`` re-wraps it for ``CVal`` contexts.
        """
        if self._record_strategy_active:
            return "false"
        return f"((CVal){{.{self.bool_field} = false}})"

    @cached_property
    @beartype
    def _record_sequence_open(self) -> Callable[[list[Value]], str]:
        """Return the ``RECORD``-strategy sequence opener.

        A list whose every element is a record-shaped dict opens with a
        bare ``{`` -- the enclosing ``struct RecordN`` array member (or
        array variable) supplies the type and the elements are
        ``(struct RecordN){...}`` literals.  Every other list opens with
        ``(CVal[]){`` and closes with ``}`` (the paired close is set on
        the config), reusing C's tagged union for arbitrary
        heterogeneity; ``_format_entry`` wraps each element so the
        compound-literal array is a valid ``const CVal *`` field value.
        """

        @beartype
        def _open(items: list[Value]) -> str:
            """Return the bare-brace or ``(CVal[]){`` opener."""
            if _all_record_shaped(items):
                return "{"
            return "(CVal[]){"

        @beartype
        def _signature(items: list[Value], /) -> CollectionSignature:
            """Retain the producer's array representation choice."""
            record_items = _all_record_shaped(items)
            return CollectionSignature(
                type_key="record-array" if record_items else "CVal-array",
                arity=None,
                arity_decision=False,
                fallback_decision=True,
                narrowing_decision=True,
                uses_fallback_decision=not record_items,
            )

        return signature_open(render=_open, infer=_signature)

    @cached_property
    @beartype
    def sequence_format_config(self) -> SequenceFormatConfig:
        """Configuration for the chosen sequence format.

        Under ``RECORD`` the asymmetric ``((CVal){.a = (CVal[]){`` ...
        ``}})`` wrapper is dropped: every list is a ``(CVal[]){...}`` /
        ``{...}`` initializer closing with a single ``}`` (a record
        field or a ``struct`` array, never a free-standing ``CVal``), so
        the close pairs with :attr:`_record_sequence_open`.
        """
        fmt = self.sequence_format.value
        if self._record_strategy_active:
            return SequenceFormatConfig(
                length_is_part_of_type=False,
                sequence_open=self._record_sequence_open,
                close="}",
                supports_heterogeneity=fmt.supports_heterogeneity,
                single_element_trailing_comma=(
                    fmt.single_element_trailing_comma
                ),
                single_element_template=fmt.single_element_template,
                supports_trailing_comma=fmt.supports_trailing_comma,
                empty_sequence=fmt.empty_sequence,
                preamble_lines=fmt.preamble_lines,
                format_entry=fmt.format_entry,
                typed_opener_fallback=fmt.typed_opener_fallback,
                uses_typed_literal_for_scalars=(
                    fmt.uses_typed_literal_for_scalars
                ),
                requires_uniform_record_shapes=(
                    fmt.requires_uniform_record_shapes
                ),
                declared_type=fmt.declared_type,
                narrowed_empty_form=None,
            )
        return SequenceFormatConfig(
            length_is_part_of_type=False,
            sequence_open=fixed_open(open_str=self._seq_open_str),
            close="}})",
            supports_heterogeneity=fmt.supports_heterogeneity,
            single_element_trailing_comma=(fmt.single_element_trailing_comma),
            single_element_template=fmt.single_element_template,
            supports_trailing_comma=fmt.supports_trailing_comma,
            empty_sequence=fmt.empty_sequence,
            preamble_lines=fmt.preamble_lines,
            format_entry=fmt.format_entry,
            typed_opener_fallback=fmt.typed_opener_fallback,
            uses_typed_literal_for_scalars=(
                fmt.uses_typed_literal_for_scalars
            ),
            requires_uniform_record_shapes=(
                fmt.requires_uniform_record_shapes
            ),
            declared_type=fmt.declared_type,
            narrowed_empty_form=None,
        )

    @cached_property
    @beartype
    def set_format_config(self) -> SetFormatConfig:
        """Configuration for the chosen set format."""
        return SetFormatConfig(
            set_open=fixed_open(open_str=self._seq_open_str),
            close="}})",
            empty_set=self.set_format.value.empty_set,
            preamble_lines=self.set_format.value.preamble_lines,
            set_opener_template=self.set_format.value.set_opener_template,
            supports_heterogeneity=self.set_format.value.supports_heterogeneity,
            supports_trailing_comma=True,
        )

    @cached_property
    @beartype
    def sequence_open(self) -> Callable[[list[Value]], str]:
        """Callable that returns the opening delimiter for a sequence."""
        return self.sequence_format_config.sequence_open

    @cached_property
    @beartype
    def dict_format_config(self) -> DictFormatConfig:
        """Configuration for dict formatting."""
        return DictFormatConfig(
            dict_open=fixed_open(open_str=self._map_open_str),
            close="}})",
            format_entry=braced_dict_entry(
                format_value=self._format_entry,
            ),
            empty_dict=None,
            preamble_lines=(),
            narrowed_open=None,
            supports_trailing_comma=True,
            narrowed_empty_form=None,
        )

    @cached_property
    @beartype
    def trailing_comma_config(self) -> TrailingCommaConfig:
        """Configuration for trailing-comma behavior."""
        return self.trailing_comma.value

    @cached_property
    @beartype
    def format_bytes(self) -> Callable[[bytes], str]:
        """Callable that formats a bytes value as a string literal."""
        return self.bytes_format

    @cached_property
    @beartype
    def format_date(self) -> Callable[[dt.date], str]:
        """Callable that formats a date as a string literal."""
        return self.date_format

    @cached_property
    @beartype
    def format_datetime(self) -> Callable[[dt.datetime], str]:
        """Callable that formats a datetime as a string literal."""
        return self.datetime_format

    @cached_property
    @beartype
    def format_time(self) -> Callable[[dt.time], str]:
        """Callable that formats a time as a string literal."""
        return format_time_iso

    @cached_property
    @beartype
    def format_float(self) -> Callable[[float], str]:
        """Callable that formats a float value as a literal."""
        return self.float_format

    @cached_property
    @beartype
    def format_integer(self) -> Callable[[int], str]:
        """Callable that formats an int value as a literal."""
        suffix_is_auto = (
            self.numeric_literal_suffix
            is type(self.numeric_literal_suffix).AUTO
        )
        base: Callable[[int], str]
        if suffix_is_auto:
            base = make_long_suffix_formatter(base=self.integer_format)
        else:
            base = self.integer_format
        if self.integer_format is not type(self.integer_format).DECIMAL:
            base = make_negative_nondecimal_i64_formatter(
                base=base,
                suffix="LL",
                base_suffix="L" if suffix_is_auto else "",
            )
        return make_overflow_fallback_formatter(
            base=make_i64_min_safe_formatter(base=base),
            fallback=make_ull_fallback(language_name="C"),
            min_value=I64_MIN,
            max_value=I64_MAX,
        )

    @cached_property
    @beartype
    def format_sequence_entry(self) -> Callable[[Value, str], str]:
        """Callable that formats one sequence entry."""
        return self._format_entry

    @cached_property
    @beartype
    def format_set_entry(self) -> Callable[[Value, str], str]:
        """Callable that formats one set entry."""
        return self._format_entry

    @cached_property
    @beartype
    def comment_config(self) -> CommentConfig:
        """Configuration for the language's comment syntax."""
        return self.comment_format.value

    @cached_property
    @beartype
    def ordered_map_format_config(self) -> OrderedMapFormatConfig:
        """Configuration for ordered-map formatting."""
        return OrderedMapFormatConfig(
            ordered_map_open=fixed_open(open_str=self._map_open_str),
            close="}})",
            preamble_lines=(),
        )

    @cached_property
    @beartype
    def format_ordered_map_entry(self) -> Callable[[str, Value, str], str]:
        """Callable that formats one ordered-map entry."""
        return braced_dict_entry(format_value=self._format_entry)

    def _record_binding_lhs(self, data: Value, /) -> str | None:
        """Return the typed left-hand side for a ``RECORD`` top-level
        binding, or ``None`` to fall back to the ``CVal`` form.

        Record dictionaries use the name assigned by the shared rendering
        schema, including bound values whose record is not the document's
        root. An all-record-list root remains a ``Record0`` array; other
        values keep the ``CVal`` union.
        """
        if not self._record_strategy_active:
            return None
        root = f"struct {_C_RECORD_PREFIX}0"
        record_name = self._record_strategy.record_name_for_value(data)
        if record_name is not None:
            return f"struct {record_name}"
        if isinstance(data, list) and _all_record_shaped(data):
            return _CArrayType(f"{root}[]", base=root, dimension=None)
        return None

    @staticmethod
    def reference_binding_data_dependent_preamble(
        _data: Value, /
    ) -> tuple[str, ...]:
        """Reference copies need no additional declarations."""
        return ()

    @staticmethod
    def reference_declaration_imports(
        entries: Sequence[str], /
    ) -> tuple[str, ...]:
        """Keep headers required by the rendered bound values."""
        return preamble_imports(entries)

    def format_reference_variable_declaration(
        self,
        name: str,
        value: str,
        data: Value,
        _modifiers: frozenset[enum.Enum],
        /,
    ) -> str:
        """Copy a reference using its resolved representation's type."""
        lhs = self._record_binding_lhs(data)
        if isinstance(lhs, _CArrayType):
            return f"const {lhs.base} * {name} = {value};"
        if lhs is None:
            lhs = "cJSON *" if self._json_type_active else "CVal"
        return f"{lhs} {name} = {value};"

    @staticmethod
    def format_reference_variable_assignment(
        name: str, value: str, _data: Value, /
    ) -> str:
        """Assign an already rendered reference directly."""
        return f"{name} = {value};"

    def prepare_reference_literal(
        self,
        value: str,
        data: Value,
        ref_key: str,
        ref_case: IdentifierCase | None,
        /,
    ) -> str:
        """Retain source bindings before declaration inference expands
        them.
        """
        if not self._json_type_active:
            return value
        return _CJsonReferenceLiteral(
            value,
            source=_CJsonBindingSource(
                data=to_jsonable(data=data),
                ref_key=ref_key,
                ref_case=ref_case,
            ),
        )

    @cached_property
    @beartype
    def _cjson_node_indices(self) -> Iterator[int]:
        """Allocate cJSON helper names across every build in one
        render.
        """
        return itertools.count()

    @cached_property
    @beartype
    def format_variable_declaration(
        self,
    ) -> Callable[[str, str, Value, frozenset[enum.Enum]], str]:
        """Callable that formats a new variable declaration.

        Under ``RECORD`` a record-shaped root is declared with its
        generated ``struct`` type (``struct Record0 my_data = (struct
        Record0){...};``) and an all-record-list root as an array
        (``struct Record0 my_data[] = {...};``); every other value keeps
        the ``CVal``-wrapped form.

        Under ``json_type=CJSON`` the rendered ``CVal`` value is
        discarded: the data is built as a ``cJSON_Create*(...)`` node
        tree (one statement per node) and the binding declares the root
        ``cJSON *my_data = literalizer_my_data_n0;``.
        """
        if self._json_type_active:
            format_integer = self.format_integer
            format_float = self.format_float

            @beartype
            def _format_cjson_decl(
                name: str,
                value: str,
                data: Value,
                _modifiers: frozenset[enum.Enum],
            ) -> str:
                """Build a cJSON node tree and declare its root."""
                source = _cjson_binding_source(value=value, data=data)
                build = _c_cjson_build(
                    source.data,
                    prefix=f"literalizer_{name}_n",
                    node_indices=self._cjson_node_indices,
                    format_integer=format_integer,
                    format_float=format_float,
                    ref_key=source.ref_key,
                    ref_case=source.ref_case,
                )
                return join_preamble(
                    entries=(*build.lines, f"cJSON *{name} = {build.root};")
                )

            return _format_cjson_decl
        format_entry = self._format_entry

        @beartype
        def _format_decl(
            name: str,
            value: str,
            data: Value,
            _modifiers: frozenset[enum.Enum],
        ) -> str:
            """Format a C variable declaration."""
            lhs = self._record_binding_lhs(data)
            if isinstance(lhs, _CArrayType):
                return f"{lhs.base} {name}[] = {value};"
            if lhs is not None:
                return f"{lhs} {name} = {value};"
            wrapped = format_entry(data, value)
            return f"CVal {name} = {wrapped};"

        return _format_decl

    assignment_declares_binding = requires_declared_binding
    reference_assignment_declares_binding = assignment_declares_binding
    call_assignment_declares_binding = False

    @cached_property
    @beartype
    def format_variable_assignment(
        self,
    ) -> Callable[[str, str, Value], str]:
        """Callable that formats an assignment to an existing variable.

        Record-shaped dictionaries use a plain struct copy. Native arrays
        of records cannot be assigned in C; reject these rather than
        wrapping their struct elements as incompatible ``CVal`` entries.

        Under ``json_type=CJSON`` the value is rebuilt as a fresh
        ``cJSON`` node tree and the existing binding is reassigned to its
        root.
        A binding-specific ``_m`` prefix (declarations use ``_n``)
        keeps separately rendered declarations and assignments free of
        duplicate ``cJSON *`` definitions in one scope.
        """
        if self._json_type_active:
            format_integer = self.format_integer
            format_float = self.format_float

            @beartype
            def _format_cjson_assign(
                name: str,
                value: str,
                data: Value,
            ) -> str:
                """Build a cJSON node tree and reassign the binding."""
                source = _cjson_binding_source(value=value, data=data)
                build = _c_cjson_build(
                    source.data,
                    prefix=f"literalizer_{name}_m",
                    node_indices=self._cjson_node_indices,
                    format_integer=format_integer,
                    format_float=format_float,
                    ref_key=source.ref_key,
                    ref_case=source.ref_case,
                )
                return join_preamble(
                    entries=(*build.lines, f"{name} = {build.root};")
                )

            return _format_cjson_assign
        format_entry = self._format_entry

        @beartype
        def _format_assign(name: str, value: str, data: Value) -> str:
            """Format a C variable assignment."""
            lhs = self._record_binding_lhs(data)
            if isinstance(lhs, _CArrayType):
                msg = (
                    "C cannot reassign a native record array under the "
                    "RECORD heterogeneous strategy"
                )
                raise UnrepresentableInputError(msg)
            if lhs is not None:
                return f"{name} = {value};"
            wrapped = format_entry(data, value)
            return f"{name} = {wrapped};"

        return _format_assign

    @cached_property
    @beartype
    def format_call_variable_declaration(
        self,
    ) -> Callable[[str, str, Value, frozenset[enum.Enum]], str]:
        """Callable that formats a declaration binding a call result.

        A literal binding wraps the right-hand side in a designated-
        initializer compound literal that encodes the value's runtime
        type; a call's return type is opaque to the renderer and is
        always the universal ``CVal`` union (the type every generated
        call stub returns), so the call result is bound directly with a
        plain ``CVal`` declaration and no compound-literal wrapping.
        """
        return _format_c_call_declaration

    @cached_property
    @beartype
    def format_call_variable_assignment(
        self,
    ) -> Callable[[str, str, Value], str]:
        """Callable that formats an assignment binding a call result.

        The call-expression counterpart of
        :attr:`format_variable_assignment`; the compound-literal
        wrapping is dropped since the call already yields a ``CVal``.
        """
        return _format_c_call_assignment

    @cached_property
    @beartype
    def static_preamble(self) -> Sequence[str]:
        """Static preamble lines emitted once per file.

        Under ``json_type=CJSON`` the ``cJSON`` header replaces the
        default ``CVal`` / ``CKV`` type declarations: every value is a
        ``cJSON *`` node built with the library's own constructors.
        """
        if self._json_type_active:
            return _CJSON_STATIC_PREAMBLE
        return (
            import_preamble(code="#include <stdbool.h>"),
            import_preamble(code="#include <stddef.h>"),
            "typedef struct CVal CVal;",
            "typedef struct CKV CKV;",
            "struct CVal {",
            "    union {",
            f"        _Bool {self.bool_field};",
            f"        long long {self.int_field};",
            f"        unsigned long long {self.uint_field};",
            f"        double {self.float_field};",
            f"        const char *{self.string_field};",
            f"        const CVal *{self.array_field};",
            f"        const CKV *{self.map_field};",
            "    };",
            "};",
            (
                f"struct CKV {{ const char *{self.key_field}; "
                f"CVal {self.value_field}; }};"
            ),
        )

    @cached_property
    @beartype
    def scalar_preamble(self) -> dict[type, tuple[str, ...]]:
        """Per-instance scalar preamble (C needs none)."""
        return {}

    @cached_property
    @beartype
    def scalar_body_preamble(self) -> dict[type, tuple[str, ...]]:
        """Per-instance scalar body preamble (C needs none)."""
        return {}

    @cached_property
    @beartype
    def compute_body_preamble(
        self,
    ) -> Callable[[frozenset[type], Value], tuple[str, ...]]:
        """Compute body-preamble lines from the scalar map."""
        return body_preamble_from_scalars(
            scalar_body_preamble=self.scalar_body_preamble,
            format_lines=tuple,
        )


register_json_native_document_fast(language_cls=C)
