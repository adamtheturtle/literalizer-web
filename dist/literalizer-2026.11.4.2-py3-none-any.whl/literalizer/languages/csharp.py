"""C# language specification."""

import dataclasses
import datetime as dt
import enum
import re
from collections.abc import Callable, Mapping, Sequence
from functools import cached_property
from types import MappingProxyType
from typing import TYPE_CHECKING, ClassVar, Final

from beartype import beartype

from literalizer._checks import reject_aware_datetimes
from literalizer._formatters.call_stubs import dotted_helper_type_names
from literalizer._formatters.collection_openers import (
    CollectionType,
    TypedOpenerConfig,
    TypeOpeners,
    collection_type_open,
    fixed_open,
    infer_collection_type,
)
from literalizer._formatters.format_dates import (
    date_ymd_formatter,
    datetime_epoch_seconds,
    datetime_ymdhms_formatter,
    format_date_iso,
    format_datetime_epoch,
    format_datetime_iso,
    format_time_csharp,
    format_time_iso,
)
from literalizer._formatters.format_entries import (
    dict_entry_with_template,
    format_bytes_base64,
    format_bytes_hex,
    passthrough_sequence_entry,
    passthrough_set_entry,
    variable_declaration_formatter,
    variable_formatter,
)
from literalizer._formatters.format_factories import (
    ordered_map_format_factory,
    sequence_format_factory,
    set_format_factory,
)
from literalizer._formatters.format_floats import (
    format_float_fixed,
    format_float_repr,
    format_float_scientific,
)
from literalizer._formatters.format_integers import (
    I64_MAX,
    I64_MIN,
    format_integer_binary,
    format_integer_hex,
    format_integer_underscore,
    make_overflow_fallback_formatter,
    make_unsigned_overflow_fallback,
    raise_for_unrepresentable_int,
)
from literalizer._formatters.format_strings import (
    make_backslash_string_formatter,
)
from literalizer._formatters.record_strategy import (
    RecordDeclarationField,
    RecordFieldType,
    RecordLiteralField,
    RecordRenderer,
    RecordStrategy,
    build_record_strategy,
    identity_field_identifier_key,
)
from literalizer._formatters.type_inference import (
    DictType,
    ListType,
    MixedNumeric,
    record_shape_for_dict,
    single_concrete_type,
)
from literalizer._heterogeneous import iter_wrapped_scalars
from literalizer._language import (
    NO_CALL_PARAMETER_LIMIT,
    NO_HETEROGENEOUS_BEHAVIOR,
    NON_KEBAB_REF_CASES,
    BareIntegerWidthStrategies,
    CallParameterShadowing,
    CallStubResult,
    CallStyle,
    CommentConfig,
    DateFormatConfig,
    DateFormatEnum,
    DatetimeFormatConfig,
    DatetimeFormatEnum,
    DeclarationStyleConfig,
    DictFormatConfig,
    FileWrapperContext,
    FloatSpecialsMixin,
    FormatValueMixin,
    HeterogeneousBehavior,
    IdentifierCase,
    JsonType,
    KeywordCallStyle,
    LanguageCls,
    ModifierCombination,
    NewVariableNameSyntax,
    NullableObjectCallStubResult,
    OrderedMapFormatConfig,
    PositionalCallStyle,
    RenderedRecordLiteral,
    RoundTripCapability,
    SequenceFormatConfig,
    SetFormatConfig,
    StubReturn,
    TrailingCommaConfig,
    VariantMetadata,
    body_preamble_from_scalars,
    date_scalar_preamble,
    default_call_data_dependent_preamble,
    default_consumable_ref_value_inhibits_consuming_form,
    default_format_call_arg_ref_identifier,
    default_format_call_arg_ref_identifier_consumable,
    default_format_call_statement,
    default_format_call_stub,
    default_format_call_target,
    default_sequence_binding_declarations,
    default_type_hint_collection_preamble_lines,
    default_validate_call_arg,
    default_wrap_calls_with_declarations,
    empty_record_shape_names,
    identity_call_arg,
    identity_call_ref_identifier,
    line_comment_call_variable_assignment,
    new_constructor_target,
    no_call_binding_body_preamble,
    no_call_binding_file_pragmas,
    no_data_preamble,
    no_format_integer_widened,
    no_leading_preamble,
    prepend_body_preamble,
    requires_declared_binding,
    wrap_in_file_noop,
)
from literalizer._statements import (
    CallLiteralSyntax,
)
from literalizer._types import OrderedMap, Scalar, Value, ValueInput
from literalizer.exceptions import (
    ConflictingVariableModifiersError,
    IncompatibleFormatsError,
    InvalidRecordNameError,
    UnrepresentableInputError,
)

_NULL_OBJECT_STUB = NullableObjectCallStubResult(
    type_name="object?",
    value="null",
    conditional_template=(
        "{call} != {null} ?\n{call}{inner_comment}\n: {null}{trailing_comment}"
    ),
    comment_prefix="//",
)

_format_string_backslash_nul = make_backslash_string_formatter(
    quote_char='"',
    extra_replacements=[
        ("\0", r"\0"),
        ("\x85", r"\u0085"),
        ("\u2028", r"\u2028"),
        ("\u2029", r"\u2029"),
    ],
)


_CSHARP_EMITTED_TYPE_NAMES: Final[frozenset[str]] = frozenset(
    {
        "DateOnly",
        "DateTime",
        "System",
        "TimeOnly",
    }
)
"""Type names the generated code can reference.

A record named after one of these either shadows the
type the same file uses or clashes with what its import line brings
in, so the compiler rejects the output (issue #4536).
"""


@beartype
def _format_string_verbatim(value: str) -> str:
    r"""Format a string as a C# verbatim string literal.

    Backslashes are kept verbatim. Double quotes are doubled per C#
    verbatim-string rules.
    """
    if any(character in value for character in "\0\x85\u2028\u2029"):
        return _format_string_backslash_nul(value=value)
    escaped = value.replace('"', '""')
    return f'@"{escaped}"'


class _CSharpModifiers(enum.Enum):
    """Declaration modifiers supported by C#.

    Each member's value is the C# keyword it renders to.  Declaration
    order matches canonical C# modifier order.

    Exposed as :attr:`CSharp.Modifiers` / :attr:`CSharp.modifiers`.
    """

    PUBLIC = "public"
    """Visibility: publicly accessible."""

    PRIVATE = "private"
    """Visibility: private to the enclosing type."""

    PROTECTED = "protected"
    """Visibility: protected (accessible from subclasses)."""

    STATIC = "static"
    """Storage: associated with the enclosing type rather than an
    instance.
    """

    CONST = "const"
    """Immutability: compile-time constant."""

    READONLY = "readonly"
    """Immutability: cannot be reassigned after initialization."""


@beartype
def _is_csharp_class_field(modifiers: frozenset[enum.Enum], /) -> bool:
    """Return whether a declaration requires class-member scope."""
    return not modifiers.isdisjoint(
        {
            _CSharpModifiers.PUBLIC,
            _CSharpModifiers.PRIVATE,
            _CSharpModifiers.PROTECTED,
            _CSharpModifiers.STATIC,
            _CSharpModifiers.READONLY,
        }
    )


@beartype
def _reject_conflicting_csharp_modifiers(
    modifiers: frozenset[enum.Enum],
) -> None:
    """Reject modifier combinations that would not compile.

    A field has one accessibility level; C# spells the combined
    ``private protected`` level with two keywords. ``const`` is implicitly
    static and immutable so it cannot also be ``readonly``.

    Raises:
        ConflictingVariableModifiersError: If a group has several members.
    """
    visibility = tuple(
        modifier.value
        for modifier in (
            _CSharpModifiers.PUBLIC,
            _CSharpModifiers.PRIVATE,
            _CSharpModifiers.PROTECTED,
        )
        if modifier in modifiers
    )
    private_protected = (
        _CSharpModifiers.PRIVATE.value,
        _CSharpModifiers.PROTECTED.value,
    )
    if len(visibility) > 1 and visibility != private_protected:
        raise ConflictingVariableModifiersError(
            language_name="CSharp",
            group_name="visibility",
            keywords=visibility,
        )
    mutability = tuple(
        modifier.value
        for modifier in (_CSharpModifiers.CONST, _CSharpModifiers.READONLY)
        if modifier in modifiers
    )
    if len(mutability) > 1:
        raise ConflictingVariableModifiersError(
            language_name="CSharp",
            group_name="mutability",
            keywords=mutability,
        )
    storage = tuple(
        modifier.value
        for modifier in (_CSharpModifiers.STATIC, _CSharpModifiers.CONST)
        if modifier in modifiers
    )
    if len(storage) > 1:
        raise ConflictingVariableModifiersError(
            language_name="CSharp",
            group_name="storage",
            keywords=storage,
        )


@beartype
def _csharp_modifier_prefix(modifiers: frozenset[enum.Enum]) -> str:
    """Return the ``public static readonly `` prefix for a C#
    declaration, including a trailing space when non-empty.

    Values that are not :class:`_CSharpModifiers` members are ignored.
    """
    _reject_conflicting_csharp_modifiers(modifiers=modifiers)
    keywords = [m.value for m in _CSharpModifiers if m in modifiers]
    if len(keywords) == 0:
        return ""
    return " ".join(keywords) + " "


@beartype
def _csharp_scalar_type(
    *,
    value: Value,
    date_hint: str,
    datetime_hint: str,
) -> str:
    """Return the C# type name for a scalar value."""
    match value:
        case dt.datetime():
            return datetime_hint
        case dt.date():
            return date_hint
        case dt.time():
            return "TimeOnly"
        case bool():
            result = "bool"
        case int():
            result = "int"
        case float():
            result = "double"
        case str() | bytes():
            result = "string"
        case _:
            result = "object?"
    return result


@beartype
def _csharp_object_fallback(*, items: Sequence[Value], fallback: str) -> str:
    """Narrow the built-in object carrier when its values cannot be null.

    Inspect only this collection level. A container remains non-null even
    when one of its children is null. Empty inputs and custom fallback
    types retain the caller's configured uncertainty.
    """
    if (
        fallback == "object?"
        and len(items) > 0
        and all(item is not None for item in items)
    ):
        return "object"
    return fallback


@beartype
def _csharp_common_element_type(
    *,
    items: list[Value],
    date_hint: str,
    datetime_hint: str,
    dict_value_type: str,
    tuple_sequences: bool,
    preserve_numeric_kinds: bool,
) -> str:
    """Return the common C# type for a list of elements."""
    if len(items) == 0:
        return "object?"
    types = {
        _csharp_type_hint(
            data=item,
            date_hint=date_hint,
            datetime_hint=datetime_hint,
            dict_value_type=dict_value_type,
            tuple_sequences=tuple_sequences,
        )
        for item in items
    }
    if len(types) == 1:
        return next(iter(types))
    if types == {"int", "double"}:
        return "object" if preserve_numeric_kinds else "double"
    return _csharp_object_fallback(items=items, fallback="object?")


@beartype
def _csharp_type_hint(
    *,
    data: Value,
    date_hint: str,
    datetime_hint: str,
    dict_value_type: str,
    tuple_sequences: bool,
) -> str:
    """Return the C# declared type for *data*."""
    match data:
        case dict():
            val_type = _csharp_common_element_type(
                items=list(data.values()),
                date_hint=date_hint,
                datetime_hint=datetime_hint,
                dict_value_type=dict_value_type,
                tuple_sequences=tuple_sequences,
                preserve_numeric_kinds=False,
            )
            return f"Dictionary<string, {val_type}>"
        case set():
            elem = _csharp_common_element_type(
                items=list(data),
                date_hint=date_hint,
                datetime_hint=datetime_hint,
                dict_value_type=dict_value_type,
                tuple_sequences=tuple_sequences,
                preserve_numeric_kinds=True,
            )
            return f"HashSet<{elem}>"
        case list() if tuple_sequences:
            element_types = [
                _csharp_type_hint(
                    data=item,
                    date_hint=date_hint,
                    datetime_hint=datetime_hint,
                    dict_value_type=dict_value_type,
                    tuple_sequences=tuple_sequences,
                )
                for item in data
            ]
            match len(element_types):
                case 0:
                    hint = "ValueTuple"
                case 1:
                    hint = f"ValueTuple<{element_types[0]}>"
                case _:
                    hint = f"({', '.join(element_types)})"
            return hint
        case list():
            elem = _csharp_common_element_type(
                items=data,
                date_hint=date_hint,
                datetime_hint=datetime_hint,
                dict_value_type=dict_value_type,
                tuple_sequences=tuple_sequences,
                preserve_numeric_kinds=False,
            )
            return f"{elem}[]"
        case _:
            return _csharp_scalar_type(
                value=data,
                date_hint=date_hint,
                datetime_hint=datetime_hint,
            )


@beartype
def _format_csharp_declaration(
    *,
    name: str,
    value: str,
    data: Value,
    modifiers: frozenset[enum.Enum],
    date_hint: str,
    datetime_hint: str,
    dict_value_type: str,
    tuple_sequences: bool,
    record_type: str | None,
) -> str:
    """Format a C# variable declaration, applying modifiers when set.

    Falls back to ``var {name} = {value};`` when *modifiers* is empty.
    """
    if _CSharpModifiers.CONST in modifiers and isinstance(
        data,
        (list, dict, set, dt.date, dt.datetime),
    ):
        msg = (
            "C# 'const' requires a compile-time constant initializer, "
            "but collection and date/datetime literals are not constant "
            "expressions. Use 'readonly' or remove the 'const' modifier."
        )
        raise IncompatibleFormatsError(msg)
    prefix = _csharp_modifier_prefix(modifiers=modifiers)
    if prefix == "":
        return f"var {name} = {value};"
    hint = record_type
    if hint is None:
        hint = _csharp_type_hint(
            data=data,
            date_hint=date_hint,
            datetime_hint=datetime_hint,
            dict_value_type=dict_value_type,
            tuple_sequences=tuple_sequences,
        )
    return f"{prefix}{hint} {name} = {value};"


@beartype
@dataclasses.dataclass(frozen=True)
class _CSharpDictSpec:
    """Per-format dict config pieces resolved at init time."""

    opener_template: str


_CSHARP_JSON_USING = "using System.Text.Json.Nodes;"
_CSHARP_JSON_OBJECT_OPEN = "new JsonObject {"
_CSHARP_JSON_ARRAY_OPEN = "new JsonArray {"
_CSHARP_JSON_EMPTY_OBJECT = "new JsonObject()"
_CSHARP_JSON_EMPTY_ARRAY = "new JsonArray()"


@beartype
def _csharp_json_value_expression(raw_value: Value, value: str, /) -> str:
    """Cast a scalar literal to ``JsonNode?``.

    The cast triggers ``System.Text.Json.Nodes``'s implicit operators
    that convert primitives (``int``, ``string``, ``bool``, ``double``)
    to ``JsonValue`` so scalars become ``JsonNode``-typed without an
    explicit ``JsonValue.Create(...)`` call.
    """
    if raw_value is None or isinstance(raw_value, (dict, list, set)):
        return value
    return f"(JsonNode?)({value})"


@beartype
def _format_csharp_json_call_arg(raw_value: Value, formatted: str) -> str:
    """Format a direct C# call argument as ``JsonNode?``."""
    return _csharp_json_value_expression(raw_value, formatted)


@beartype
def _format_csharp_json_assignment(name: str, value: str, data: Value) -> str:
    """Assign a rendered literal to a C# ``JsonNode?`` binding."""
    return f"{name} = {_csharp_json_value_expression(data, value)};"


@beartype
def _csharp_json_declaration_formatter(
    *,
    json_type: str,
) -> Callable[[str, str, Value, frozenset[enum.Enum]], str]:
    """Return a declaration formatter for ``JsonNode?`` output.

    A ``const`` modifier is rejected because ``new JsonObject``/
    ``new JsonArray`` expressions and the ``(JsonNode?)`` cast applied
    to scalars are runtime constructors / user-defined conversions,
    not C# compile-time constant expressions.
    """

    @beartype
    def _formatter(
        name: str,
        value: str,
        data: Value,
        modifiers: frozenset[enum.Enum],
    ) -> str:
        """Format a JSON-backed declaration."""
        if _CSharpModifiers.CONST in modifiers:
            msg = (
                "C# 'const' requires a compile-time constant initializer, "
                f"but {json_type} expressions are not constant. Use "
                "'readonly' or remove the 'const' modifier."
            )
            raise IncompatibleFormatsError(msg)
        prefix = _csharp_modifier_prefix(modifiers=modifiers)
        expr = _csharp_json_value_expression(data, value)
        return f"{prefix}{json_type}? {name} = {expr};"

    return _formatter


@beartype
def _csharp_call_stub(
    parts: Sequence[str],
    params: Sequence[str],
    _stub_return: StubReturn,
    _args: Sequence[Value],
    /,
) -> tuple[str, ...]:
    """Return C# stub declarations for a call name.

    For a single-name target the stub is a static method whose
    parameter list matches the given names; for a dotted target a
    chain of nested stub classes is emitted so ``a.b.c.d(...)``
    dispatches to a real method whose body returns ``null``.  Every
    argument is spelled out by name with a ``null`` default so
    named-argument call styles bind to real parameters instead of
    failing at runtime.
    """
    return_type = _NULL_OBJECT_STUB.type_name
    return_value = _NULL_OBJECT_STUB.value
    param_list = ", ".join(f"object? {p} = null" for p in params)
    if len(parts) == 1 and parts[0].startswith("new "):
        class_name = parts[0].removeprefix("new ")
        return (
            f"class {class_name} {{ public {class_name}({param_list}) {{}} }}",
        )
    if len(parts) == 1:
        return (
            (
                f"static {return_type}"
                f" {parts[0]}({param_list}) => {return_value};"
            ),
        )
    root = parts[0]
    method = parts[-1]
    fields = parts[1:-1]
    type_names = dotted_helper_type_names(
        parts=parts[:-1],
        suffix="Type_",
        ignore_underscores=False,
        capitalize_parts=False,
    )
    if len(fields) == 0:
        type_name = type_names[0]
        return (
            (
                f"class {type_name} {{"
                f" public {return_type} {method}({param_list})"
                f" => {return_value}; }}"
            ),
            f"static {type_name} {root} = new {type_name}();",
        )
    lines: list[str] = []
    inner_type = type_names[-1]
    lines.append(
        f"class {inner_type} {{"
        f" public {return_type} {method}({param_list}) => {return_value}; }}"
    )
    prev_type = inner_type
    for i in range(len(fields) - 2, -1, -1):
        curr_type = type_names[i + 1]
        lines.append(
            f"class {curr_type} {{"
            f" public {prev_type} {fields[i + 1]} = new {prev_type}(); }}"
        )
        prev_type = curr_type
    root_type = type_names[0]
    lines.append(
        f"class {root_type} {{"
        f" public {prev_type} {fields[0]} = new {prev_type}(); }}"
    )
    lines.append(f"static {root_type} {root} = new {root_type}();")
    return tuple(lines)


# Signed 32-bit range.  An integer record field inside it is declared
# ``int``; a wider one is declared ``long`` to match the literal C#
# infers for the same value.  Keep these bounds in sync with
# ``_I32_MIN`` / ``_I32_MAX`` in
# :mod:`literalizer._formatters.type_inference` (the widening threshold
# the value formatter uses, which has a back-reference to here).
_CSHARP_I32_MIN = -(2**31)
_CSHARP_I32_MAX = 2**31 - 1
_PASCAL_CASE_IDENTIFIER = re.compile(pattern=r"^[A-Z][A-Za-z0-9_]*$")


@beartype
def _csharp_epoch_array_item(value: Value, /) -> Value:
    """Size epoch containers from their rendered integer values."""
    match value:
        case dt.datetime():
            return datetime_epoch_seconds(value=value)
        case list():
            return [_csharp_epoch_array_item(item) for item in value]
        case dict():
            return {
                key: _csharp_epoch_array_item(item)
                for key, item in value.items()
            }
        case _:
            return value


@beartype
def _csharp_record_sequence_type(
    *,
    value: Value,
    record_name_for_value: Callable[[ValueInput], str | None],
) -> tuple[int, str] | None:
    """Infer a uniform record array, letting empty siblings adopt its type."""
    record_name = record_name_for_value(value)
    if record_name is not None:
        return (0, record_name)
    if not isinstance(value, list):
        return None
    child_types = {
        _csharp_record_sequence_type(
            value=item, record_name_for_value=record_name_for_value
        )
        for item in value
        if not isinstance(item, list) or len(item) > 0
    }
    if len(child_types) != 1:
        return None
    (child_type,) = child_types
    if child_type is None:
        return None
    depth, name = child_type
    # An empty array can adopt an array type, but cannot become a record.
    if depth == 0 and any(
        isinstance(item, list) and len(item) == 0 for item in value
    ):
        return None
    return (depth + 1, name)


@beartype
def _csharp_record_field_identifier(key: str, /) -> str:
    """Return the C# record component name for a dict *key*.

    C# conventions name record components in PascalCase; the literal is
    positional so the name only labels the declaration.
    """
    return IdentifierCase.PASCAL.convert(name=key)


@beartype
def _csharp_record_literal(
    name: str,
    fields: Sequence[RecordLiteralField],
    /,
) -> RenderedRecordLiteral:
    """Render a C# ``new Name(value, ...)`` positional record literal as
    structured pieces for the shared compact/multiline layout code.

    C# positional records are constructed by their primary constructor,
    so the literal emits arguments in declaration order with no field
    names (the PascalCase identifiers label only the declaration).
    """
    return RenderedRecordLiteral(
        head=f"new {name}(",
        entries=tuple(field.formatted for field in fields),
        closer=")",
        compact_pad="",
    )


@beartype
def _csharp_render_record_declaration(
    name: str,
    fields: Sequence[RecordDeclarationField],
    /,
) -> str:
    """Render a C# ``record Name(Type Id, ...);`` positional record.

    A positional ``record`` (reference type, value equality, mirroring
    the Java port) is used rather than a ``struct``; its primary
    constructor matches the positional literal
    :func:`_csharp_record_literal` emits.
    """
    components = ", ".join(
        f"{field.type_name} {field.identifier}" for field in fields
    )
    return f"record {name}({components});"


@beartype
def _format_csharp_ulong_positive(value: int) -> str:
    """Format a non-negative integer as a C# ``ulong`` literal.

    The ``UL`` suffix forces unsigned 64-bit typing so a homogeneous
    ``ulong`` collection can include values that would otherwise be
    inferred as signed ``long``.
    """
    return f"{value}UL"


@beartype
def _csharp_int_field_type(*, value: int) -> str:
    """Return the C# record-component type for an integer.

    A value inside signed 32-bit range is declared ``int``; a wider one
    is declared ``long``.  C# types a literal that carries no type
    suffix by magnitude (signed 32-bit, then unsigned 32-bit, then
    signed 64-bit), and each of those converts implicitly to the chosen
    field type, so the declared type accepts the rendered literal.  A
    value beyond signed 64-bit range uses the unsigned 64-bit type,
    matching the literal C# infers there.
    """
    if not I64_MIN <= value <= I64_MAX:
        return "ulong"
    if _CSHARP_I32_MIN <= value <= _CSHARP_I32_MAX:
        return "int"
    return "long"


@beartype
@dataclasses.dataclass
class _CSharpWidenedMapNarrowing:
    """Per-pass concrete value type for widened record fallback maps."""

    value_type: str | None


# Work around https://github.com/astral-sh/ty/issues/4573.
if TYPE_CHECKING:
    _BytesEnumMember = enum.member[Callable[[bytes], str]]
    _StringEnumMember = enum.member[Callable[[str], str]]
else:
    _BytesEnumMember = enum.member
    _StringEnumMember = enum.member


_CALL_LITERAL_SYNTAX = CallLiteralSyntax(
    prefix="//",
    regex_literals=False,
    raw_string_prefixes=(),
    verbatim_strings=True,
    interpolation_syntax=("{", '"'),
    quotes="\"'",
    literal_span_end=None,
    backtick_strings=False,
)


@beartype
@dataclasses.dataclass(frozen=True, kw_only=True)
class CSharp(metaclass=LanguageCls):
    """C# language specification.

    Args:
        date_format: How to format :class:`datetime.date` values.

            * ``date_formats.CSHARP`` — ``new DateOnly(...)`` call,
              e.g. ``new DateOnly(2024, 1, 15)``.
            * ``date_formats.ISO`` — ISO 8601 quoted string,
              e.g. ``"2024-01-15"``.

        datetime_format: How to format :class:`datetime.datetime` values.

            * ``datetime_formats.CSHARP`` — ``new DateTime(...)`` call,
              e.g. ``new DateTime(2024, 1, 15, 12, 30, 0)``.
            * ``datetime_formats.ISO`` — ISO 8601 quoted string,
              e.g. ``"2024-01-15T12:30:00"``.

        json_type: When set to
            ``json_types.SYSTEM_TEXT_JSON_NODE``, render values through
            ``System.Text.Json.Nodes.JsonNode`` (``JsonObject`` /
            ``JsonArray`` / typed scalars) instead of C#'s narrow
            collection types.  Dates / datetimes / times switch to ISO
            8601 strings (unless ``datetime_format`` is ``EPOCH``) and
            the ``const`` modifier is rejected because the JSON
            constructors are not constant expressions.
    """

    reserved_module_identifiers: ClassVar[frozenset[str]] = frozenset()
    wrap_in_file_tolerates_pre_indent = True
    uses_resolved_ref_declaration_data = True
    module_name_shares_variable_scope = False
    reserved_variable_identifier_pattern: ClassVar[re.Pattern[str] | None] = (
        None
    )
    reserved_call_parameter_identifiers: ClassVar[frozenset[str]] = frozenset()
    reserved_call_parameter_identifier_pattern: ClassVar[
        re.Pattern[str] | None
    ] = None
    accepts_type_name_call_target = True
    declares_type_name_call_target = True
    dotted_call_root_shares_entrypoint_namespace = True
    reserved_bare_call_target_identifiers: ClassVar[frozenset[str]] = (
        frozenset()
    )
    reserved_call_target_head_identifiers: ClassVar[frozenset[str]] = (
        frozenset()
    )
    contextual_call_target_identifiers: ClassVar[frozenset[str]] = frozenset()
    call_parameter_shadowing = CallParameterShadowing.ALLOWED
    reserved_call_target_keywords_case_sensitive = True
    module_name_must_start_uppercase = False
    new_variable_name_syntax = NewVariableNameSyntax.ASCII
    max_variable_identifier_length: ClassVar[int | None] = None
    call_stub_result: ClassVar[CallStubResult | None] = _NULL_OBJECT_STUB
    call_literal_syntax: ClassVar[CallLiteralSyntax | None] = (
        _CALL_LITERAL_SYNTAX
    )
    call_target_name_syntax: ClassVar[NewVariableNameSyntax | None] = None
    supports_multiline_dict_layout = True
    pools_map_integer_width = True

    format_integer_widened = no_format_integer_widened

    @staticmethod
    def format_call_variable_declaration(
        name: str,
        value: str,
        _data: Value,
        modifiers: frozenset[enum.Enum],
        /,
    ) -> str:
        """Type the call result according to its stub's object return."""
        if _CSharpModifiers.CONST in modifiers:
            msg = "C# 'const' cannot bind a runtime call result."
            raise IncompatibleFormatsError(msg)
        comments = _CALL_LITERAL_SYNTAX.split(value)
        prefix = _csharp_modifier_prefix(modifiers=modifiers)
        if prefix == "":
            return (
                f"var {name} = {comments.code};" + comments.trailing_comments
            )
        return (
            f"{prefix}object? {name} = {comments.code};"
            + comments.trailing_comments
        )

    format_call_variable_assignment: ClassVar[property] = (
        line_comment_call_variable_assignment(syntax=_CALL_LITERAL_SYNTAX)
    )
    format_constructor_target: ClassVar["staticmethod[[str], str]"] = (
        staticmethod(new_constructor_target)
    )
    sequence_binding_declarations = default_sequence_binding_declarations
    format_call_binding_body_preamble = no_call_binding_body_preamble
    format_call_binding_file_pragmas = no_call_binding_file_pragmas

    leading_preamble = no_leading_preamble

    extension = ".cs"
    pygments_name = "csharp"
    stringifies_nested_collections = False
    supports_special_floats = True
    supports_variable_names = True
    supports_no_variable_wrap_in_file = False
    wraps_data_dependent_preamble_in_body = False
    dict_supports_heterogeneous_values = True
    supports_native_invocations = False
    supports_dotted_calls = True
    has_free_function_calls = True
    declares_call_parameter_names = True
    reserved_variable_identifiers_case_sensitive: bool = True
    reserved_variable_identifiers: frozenset[str] = frozenset(
        {
            "Boolean",
            "Dictionary",
            "Int32",
            "List",
            "String",
            "abstract",
            "as",
            "base",
            "bool",
            "break",
            "byte",
            "case",
            "catch",
            "char",
            "checked",
            "class",
            "const",
            "continue",
            "decimal",
            "default",
            "delegate",
            "do",
            "double",
            "else",
            "enum",
            "event",
            "explicit",
            "extern",
            "false",
            "finally",
            "fixed",
            "float",
            "for",
            "foreach",
            "goto",
            "if",
            "implicit",
            "in",
            "int",
            "interface",
            "internal",
            "is",
            "lock",
            "long",
            "namespace",
            "new",
            "null",
            "object",
            "operator",
            "out",
            "override",
            "params",
            "private",
            "protected",
            "public",
            "readonly",
            "ref",
            "return",
            "sbyte",
            "sealed",
            "short",
            "sizeof",
            "stackalloc",
            "static",
            "string",
            "struct",
            "switch",
            "this",
            "throw",
            "true",
            "try",
            "typeof",
            "uint",
            "ulong",
            "unchecked",
            "unsafe",
            "ushort",
            "using",
            "virtual",
            "void",
            "volatile",
            "while",
            "with",
            "yield",
        }
    )
    reserved_identifiers: ClassVar[frozenset[str]] = (
        reserved_variable_identifiers - (frozenset({"Main"}))
    )
    allows_empty_call_parens = True
    supports_dotted_call_stub = True
    call_returns_expression = True
    supports_json_call_result_binding = False
    supports_zero_parameter_calls = True
    max_call_parameters = NO_CALL_PARAMETER_LIMIT
    supports_inline_multiline_dict_args = True
    supports_standalone_comments_in_wrapped_calls = True
    supports_multi_param_call_wrapper_stub = True
    supports_dict_literal_as_free_expression = True
    supports_module_name = False
    supports_empty_dict_key = False
    supports_call_style = True
    supports_default_dict_key_type = True
    supports_default_dict_value_type = True
    supports_default_sequence_element_type = True
    supports_default_set_element_type = True
    supports_default_ordered_map_value_type = False
    json_type_variant_name_suffix = "json_node"
    supports_non_ascii_string_literals = True
    supports_multiline_string_literals = False
    supports_empty_sibling_sequence_type_hints = True
    supports_typed_dict_open = True
    language_id: ClassVar[str] = "csharp"
    variant_metadata: ClassVar[VariantMetadata] = VariantMetadata(
        round_trip_capabilities=frozenset(
            {
                RoundTripCapability.I64_BOUNDARIES,
                RoundTripCapability.INTERPOLATION_STRINGS,
                RoundTripCapability.EMBEDDED_NUL,
            }
        ),
        modifier_sequence_format_overrides={"READONLY": "ARRAY"},
        string_literals_escape_null_byte=True,
        supports_ref_elements_in_tuple_strategy=False,
    )
    supports_record_struct_name_prefix = False
    supports_record_shape_names = True
    record_shape_names_emit_declarations = True
    supports_non_string_dict_keys = False
    checks_raw_control_dict_keys_separately = False

    _opener_config = TypedOpenerConfig(
        str_type="string",
        bool_type="bool",
        int_type="int",
        wide_int_type="long",
        beyond_i64_type="ulong",
        float_type="double",
        mixed_numeric_type="double",
        bytes_type="string",
        date_type="DateOnly",
        datetime_type="DateTime",
        time_type="TimeOnly",
        list_template="{inner}[]",
        sequence_opener_template="new {type_name}[] {{",
        dict_opener_template="new Dictionary<{key_type}, {type_name}> {{",
        set_opener_template="new HashSet<{type_name}> {{",
        dict_type_template="Dictionary<{key_type}, {inner}>",
        fallback_value_type="object?",
    )

    class DateFormats(DateFormatEnum):
        """Date format options for C#."""

        CSHARP = DateFormatConfig(
            formatter=date_ymd_formatter(
                template="new DateOnly({year}, {month}, {day})",
            ),
            preamble_lines=("using System;",),
            type_produced=dt.date,
        )
        ISO = DateFormatConfig(
            formatter=format_date_iso, type_produced=str, preamble_lines=()
        )

    class DatetimeFormats(DatetimeFormatEnum):
        """Datetime format options for C#."""

        CSHARP = DatetimeFormatConfig(
            formatter=datetime_ymdhms_formatter(
                template="new DateTime({year}, {month}, {day}, "
                "{hour}, {minute}, {second})",
                millisecond_template=None,
            ),
            preamble_lines=("using System;",),
            type_produced=dt.datetime,
        )
        ISO = DatetimeFormatConfig(
            formatter=format_datetime_iso,
            type_produced=str,
            preamble_lines=(),
        )

        EPOCH = DatetimeFormatConfig(
            formatter=format_datetime_epoch,
            type_produced=int,
            preamble_lines=(),
        )

    class BytesFormats(FormatValueMixin[Callable[[bytes], str]], enum.Enum):
        """Bytes formatting options."""

        HEX = _BytesEnumMember(value=format_bytes_hex)
        BASE64 = _BytesEnumMember(value=format_bytes_base64)

        def __call__(self, data: bytes, /) -> str:
            """Format bytes."""
            return self.value(data)

    class SequenceFormats(
        FormatValueMixin[Callable[[str], SequenceFormatConfig]], enum.Enum
    ):
        """Sequence type options for C#."""

        TUPLE = enum.member(
            value=sequence_format_factory(
                open_template="(",
                close=")",
                supports_heterogeneity=True,
                single_element_trailing_comma=False,
                # ``(x)`` is a parenthesized expression rather than a
                # one-element tuple, so a single element takes the
                # factory call the empty case already uses
                # (issue #3928).
                single_element_template="ValueTuple.Create({items})",
                supports_trailing_comma=False,
                empty_template="ValueTuple.Create()",
                preamble_lines=("using System;",),
                format_entry=passthrough_sequence_entry,
                typed_opener_fallback_template=None,
            )
        )
        ARRAY = enum.member(
            value=sequence_format_factory(
                open_template="new {type}[] {{",
                close="}",
                supports_heterogeneity=True,
                single_element_trailing_comma=False,
                single_element_template=None,
                supports_trailing_comma=True,
                empty_template="new {type}[] {{}}",
                preamble_lines=(),
                format_entry=passthrough_sequence_entry,
                typed_opener_fallback_template=("new {type}[] {{"),
            )
        )

        def __call__(self, default_type: str) -> SequenceFormatConfig:
            """Create a sequence format config for the given type."""
            return self.value(default_type)

    class SetFormats(
        FormatValueMixin[Callable[[str], SetFormatConfig]], enum.Enum
    ):
        """Set type options for C#."""

        HASH_SET = enum.member(
            value=set_format_factory(
                open_template="new HashSet<{type}> {{",
                close="}}",
                empty_template="new HashSet<{type}>()",
                preamble_lines=("using System.Collections.Generic;",),
                set_opener_template="",
                supports_heterogeneity=True,
                supports_trailing_comma=True,
            )
        )
        SORTED_SET = enum.member(
            value=set_format_factory(
                open_template="new SortedSet<{type}> {{",
                close="}}",
                empty_template="new SortedSet<{type}>()",
                preamble_lines=("using System.Collections.Generic;",),
                set_opener_template="new SortedSet<{type_name}> {{",
                supports_heterogeneity=False,
                supports_trailing_comma=True,
            )
        )

        def __call__(self, default_type: str) -> SetFormatConfig:
            """Create a set format config for the given type."""
            return self.value(default_type)

    class CommentFormats(enum.Enum):
        """Comment style options."""

        DOUBLE_SLASH = CommentConfig(
            prefix="//",
            suffix="",
        )
        BLOCK = CommentConfig(
            prefix="/*",
            suffix=" */",
        )

    class DeclarationStyles(enum.Enum):
        """Declaration style options."""

        VAR = DeclarationStyleConfig(
            formatter=variable_declaration_formatter(
                template="var {name} = {value};",
            ),
            supports_redefinition=True,
        )

    class DictEntryStyles(enum.Enum):
        """Dict entry style options."""

        DEFAULT = enum.auto()

    class DictFormats(enum.Enum):
        """Dict/map format options."""

        DICTIONARY = _CSharpDictSpec(
            opener_template="new Dictionary<{key_type}, {type_name}> {{",
        )
        SORTED_DICTIONARY = _CSharpDictSpec(
            opener_template="new SortedDictionary<{key_type}, {type_name}> {{",
        )

    class EmptyDictKey(enum.Enum):
        """Empty dict key options."""

        ALLOW = enum.auto()

    class FloatFormats(
        FloatSpecialsMixin,
        enum.Enum,
        positive_infinity="double.PositiveInfinity",
        negative_infinity="double.NegativeInfinity",
        nan="double.NaN",
    ):
        """Float format options."""

        REPR = enum.member(value=format_float_repr)
        SCIENTIFIC = enum.member(value=format_float_scientific)
        FIXED = enum.member(value=format_float_fixed)

    class IntegerFormats(enum.Enum):
        """Integer format options."""

        DECIMAL = MappingProxyType(
            mapping={
                "NONE": str,
                "UNDERSCORE": format_integer_underscore,
            }
        )
        HEX = MappingProxyType(
            mapping={
                "NONE": format_integer_hex,
                "UNDERSCORE": format_integer_hex,
            }
        )
        BINARY = MappingProxyType(
            mapping={
                "NONE": format_integer_binary,
                "UNDERSCORE": format_integer_binary,
            }
        )

        def get_formatter(
            self,
            numeric_separator: enum.Enum,
        ) -> Callable[[int], str]:
            """Return the integer formatter for the given separator."""
            formatter: Callable[[int], str] = self.value[
                numeric_separator.name
            ]
            return formatter

    class NumericLiteralSuffixes(enum.Enum):
        """Numeric literal suffix options."""

        NONE = enum.auto()

    class NumericSeparators(enum.Enum):
        """Numeric separator options."""

        NONE = enum.auto()
        UNDERSCORE = enum.auto()

    class NumericStyles(enum.Enum):
        """Numeric literal style options."""

        OVERLOADED = enum.auto()

    class StringFormats(FormatValueMixin[Callable[[str], str]], enum.Enum):
        """String format options."""

        DOUBLE = enum.member(value=_format_string_backslash_nul)
        VERBATIM = _StringEnumMember(value=_format_string_verbatim)

        def __call__(self, value: str, /) -> str:
            """Format a string."""
            return self.value(value)

    class TrailingCommas(enum.Enum):
        """Trailing comma options."""

        YES = TrailingCommaConfig(multiline_trailing_comma=True)
        NO = TrailingCommaConfig(multiline_trailing_comma=False)

    immutable_variable_modifiers: ClassVar[frozenset[enum.Enum]] = frozenset(
        {
            _CSharpModifiers.CONST,
            _CSharpModifiers.READONLY,
        }
    )
    Modifiers = _CSharpModifiers

    date_formats = DateFormats
    datetime_formats = DatetimeFormats
    bytes_formats = BytesFormats
    sequence_formats = SequenceFormats
    set_formats = SetFormats
    comment_formats = CommentFormats
    modifiers = _CSharpModifiers

    class HeterogeneousStrategies(enum.Enum):
        """Heterogeneous-scalar strategy options.

        ``ERROR`` raises on any value that cannot be represented.
        ``RECORD`` renders each record-shaped dict (non-empty,
        string-keyed) as a generated positional ``record`` declared in
        the preamble plus a matching positional literal, rather than a
        homogeneous ``Dictionary``.
        """

        ERROR = enum.auto()
        RECORD = enum.auto()

    heterogeneous_strategies = HeterogeneousStrategies

    class BoolFormats(enum.Enum):
        """Empty: this language has no alternative boolean formats."""

    bool_formats = BoolFormats

    class VersionFormats(enum.Enum):
        """Version options for C#."""

        V10 = enum.auto()

    version_formats = VersionFormats

    identifier_cases: ClassVar[tuple[IdentifierCase, ...]] = (
        IdentifierCase.PASCAL,
        IdentifierCase.CAMEL,
        IdentifierCase.UPPER_SNAKE,
    )
    supported_ref_cases: ClassVar[frozenset[IdentifierCase]] = (
        NON_KEBAB_REF_CASES
    )

    modifier_combinations: ClassVar[tuple[ModifierCombination, ...]] = (
        ModifierCombination(
            name="private_protected",
            modifiers=frozenset(
                {_CSharpModifiers.PRIVATE, _CSharpModifiers.PROTECTED},
            ),
        ),
        ModifierCombination(
            name="public_static_readonly",
            modifiers=frozenset(
                {
                    _CSharpModifiers.PUBLIC,
                    _CSharpModifiers.STATIC,
                    _CSharpModifiers.READONLY,
                },
            ),
        ),
    )

    def validate_spec_for_data(self, data: Value) -> None:
        """Validate C#-specific data / format combinations.

        Under ``json_type`` only dict keys that are strings can be
        represented as JSON object keys, so a non-string dict key is
        rejected up-front rather than emitted as a ``[<non-string>]
        = ...`` initializer that the C# compiler would reject.
        """
        if self._json_type_active:
            self._validate_json_value_keys(data)
        if (
            not self._json_type_active
            and self.datetime_format.value.type_produced is dt.datetime
        ):
            reject_aware_datetimes(
                data=data, language_name="C#", allow_utc_offset=False
            )

    def _validate_json_value_keys(self, data: Value, /) -> None:
        """Reject non-string object keys for ``JsonNode`` output."""
        match data:
            case dict():
                for key, value in data.items():
                    if not isinstance(key, str):
                        msg = (
                            "C# json_type can only represent dict keys "
                            f"as JSON object strings, not {type(key).__name__}"
                        )
                        raise UnrepresentableInputError(msg)
                    self._validate_json_value_keys(value)
            case list() | set():
                for item in data:
                    self._validate_json_value_keys(item)
            case _:
                return

    def __post_init__(self) -> None:
        """Force ``sequence_format=ARRAY`` for the ``RECORD`` strategy.

        Under ``RECORD`` a list-valued record component is declared from
        the array opener (``new <Type>[] {``) the value formatter emits,
        so its declared type matches the rendered literal.  The default
        tuple sequence format carries no element type in its opener and
        no fixed-length component type, so it cannot back a generated
        record component.  Coercing here (rather than rejecting a
        non-array spec) keeps the golden harness simple: every ``RECORD``
        spec, however constructed, renders.
        """
        strategies = type(self.heterogeneous_strategy)
        formats = type(self.sequence_format)
        if (
            self.heterogeneous_strategy is strategies.RECORD
            and self.sequence_format is not formats.ARRAY
        ):
            object.__setattr__(
                self,
                "sequence_format",
                formats.ARRAY,
            )
        self._validate_record_naming()

    def _validate_record_naming(self) -> None:
        """Validate custom C# record names before rendering."""
        auto_name_pattern = re.compile(pattern=r"^Record\d+$")
        seen_names: set[str] = set()
        for keys, name in self.record_shape_names.items():
            if _PASCAL_CASE_IDENTIFIER.match(string=name) is None:
                msg = (
                    f"record_shape_names entry for keys {sorted(keys)!r} "
                    f"maps to {name!r}, which is not a PascalCase C# "
                    f"identifier."
                )
                raise InvalidRecordNameError(msg)
            if name in _CSHARP_EMITTED_TYPE_NAMES:
                msg = (
                    f"record_shape_names entry for keys {sorted(keys)!r} "
                    f"maps to {name!r}, which names a type the generated "
                    f"code itself uses."
                )
                raise InvalidRecordNameError(msg)
            if auto_name_pattern.match(string=name) is not None:
                msg = (
                    f"record_shape_names entry for keys {sorted(keys)!r} "
                    f"maps to {name!r}, which collides with the "
                    f"auto-generated 'Record'-prefixed record names."
                )
                raise InvalidRecordNameError(msg)
            if name == "Check":
                msg = (
                    f"record_shape_names entry for keys {sorted(keys)!r} "
                    "maps to 'Check', which collides with the generated "
                    "outer wrapper class."
                )
                raise InvalidRecordNameError(msg)
            if name in seen_names:
                msg = (
                    "record_shape_names maps multiple key-sets to "
                    f"{name!r}; record names must be unique."
                )
                raise InvalidRecordNameError(msg)
            seen_names.add(name)

    validate_call_arg = default_validate_call_arg

    format_call_statement = default_format_call_statement

    wrap_calls_with_declarations = default_wrap_calls_with_declarations

    class VariableTypeHints(enum.Enum):
        """Variable type hint options."""

        NEVER = enum.auto()
        SAFE = enum.auto()

    variable_type_hints_formats = VariableTypeHints

    class JsonTypes(JsonType):
        """JSON value type options for C#."""

        SYSTEM_TEXT_JSON_NODE = "JsonNode"
        """``System.Text.Json.Nodes.JsonNode``, the built-in .NET JSON
        document object model.
        """

    json_types = JsonTypes
    declaration_styles = DeclarationStyles
    dict_entry_styles = DictEntryStyles
    dict_formats = DictFormats
    empty_dict_keys = EmptyDictKey
    float_formats = FloatFormats
    integer_formats = IntegerFormats
    integer_width_strategies = BareIntegerWidthStrategies
    numeric_literal_suffixes = NumericLiteralSuffixes
    numeric_separators = NumericSeparators
    numeric_styles = NumericStyles
    string_formats = StringFormats
    trailing_commas = TrailingCommas

    class StatementTerminatorStyles(enum.Enum):
        """Statement terminator options."""

        SEMICOLON = enum.auto()

    statement_terminator_styles = StatementTerminatorStyles

    class CallStyles(enum.Enum):
        """CSharp call style options."""

        POSITIONAL = PositionalCallStyle(
            arg_separator=", ", parenthesize_each_arg=False
        )
        NAMED = KeywordCallStyle(separator=": ")

    call_styles = CallStyles

    def wrap_in_file(
        self,
        content: str,
        context: FileWrapperContext,
    ) -> str:
        """Wrap code in a valid file.

        When the context carries a class-field modifier (one
        of the visibility or storage keywords that C# only accepts on
        class members) the declaration is placed inside a ``class
        Check`` body with a ``Main`` entry point.

        When *context.class_preamble* carries call-stub declarations (``class
        Foo_ { ... }`` and ``static Foo_ foo = new Foo_();``) the whole
        file is wrapped in ``class Check { ...stubs... static void
        Main() { ...content... } }``.  C# requires type declarations to
        follow top-level statements, so stubs cannot sit before
        top-level calls — wrapping them as class members sidesteps
        that ordering rule.

        Under the ``RECORD`` strategy a record literal's ``var``
        declaration would otherwise be a bare top-level statement, but
        the generated ``record`` declarations are emitted at file scope
        (by the data-dependent preamble) ahead of this output and C#
        forbids a top-level statement after a type declaration; such
        content is therefore wrapped as a ``Main`` method body inside
        ``class Check`` rather than left as a top-level statement (call
        stubs and class-field declarations keep their own wrapping).

        Otherwise the content is emitted as a top-level statement,
        which is the only context where ``var`` declarations are valid.
        """
        body_preamble = context.body_preamble
        variable_name = context.variable_name
        use_line = (
            f"\n{self.indent}_ = {variable_name};"
            if variable_name != ""
            else ""
        )
        stub_lines = context.class_preamble
        stub_block = ""
        if len(stub_lines) > 0:
            stub_block = "\n".join(stub_lines) + "\n"
        if _is_csharp_class_field(context.modifiers):
            preamble_block = "\n".join((*body_preamble, ""))
            return (
                f"{preamble_block}class Check {{\n"
                f"{stub_block}"
                f"{content}\n"
                f"{self.indent}public static void Main() {{"
                + (
                    f" _ = {variable_name};"
                    if _CSharpModifiers.STATIC in context.modifiers
                    else ""
                )
                + " }\n"
                + (
                    ""
                    if _CSharpModifiers.STATIC in context.modifiers
                    else (
                        f"{self.indent}public void _Read_{variable_name}() "
                        f"{{ _ = {variable_name}; }}\n"
                    )
                )
                + "}"
            )
        if len(stub_lines) > 0:
            body = prepend_body_preamble(
                content=content,
                body_preamble=body_preamble,
            )
            return (
                f"class Check {{\n"
                f"{stub_block}"
                f"{self.indent}public static void Main() {{\n"
                f"{body}{use_line}\n"
                f"{self.indent}}}\n"
                f"}}"
            )
        if self._record_strategy_active:
            body = prepend_body_preamble(
                content=content,
                body_preamble=body_preamble,
            )
            return (
                f"class Check {{\n"
                f"{self.indent}public static void Main() {{\n"
                f"{body}{use_line}\n"
                f"{self.indent}}}\n"
                f"}}"
            )
        return wrap_in_file_noop(
            content=content + use_line,
            context=context,
        )

    @property
    def call_wrapper_entrypoint_name(self) -> str:
        """Return the generated complete-file entry-point name."""
        return "Main"

    def wrap_combined_in_file(
        self,
        declaration: str,
        assignment: str,
        context: FileWrapperContext,
    ) -> str:
        """Wrap declaration and assignment in a valid file.

        Field reassignments belong in a static or instance constructor,
        matching the declaration's storage modifier.

        Under the ``RECORD`` strategy the declaration and assignment are
        top-level statements that must follow the file-scope ``record``
        declarations, so they are wrapped as a ``Main`` method body via
        :meth:`wrap_in_file`; otherwise this is a no-op.
        """
        if _is_csharp_class_field(context.modifiers):
            prefix = "public "
            if _CSharpModifiers.STATIC in context.modifiers:
                prefix = "static "
            return self.wrap_in_file(
                content=(
                    f"{declaration}\n"
                    f"{self.indent}{prefix}Check() {{\n"
                    f"{assignment}\n"
                    f"{self.indent}}}"
                ),
                context=context,
            )
        if self._record_strategy_active:
            return self.wrap_in_file(
                content=declaration + "\n" + assignment,
                context=context,
            )
        return self.wrap_in_file(
            content=declaration + "\n" + assignment,
            context=context,
        )

    date_format: DateFormats = DateFormats.CSHARP
    datetime_format: DatetimeFormats = DatetimeFormats.CSHARP
    bytes_format: BytesFormats = BytesFormats.HEX
    sequence_format: SequenceFormats = SequenceFormats.TUPLE
    set_format: SetFormats = SetFormats.HASH_SET
    default_set_element_type: str = "object?"
    default_sequence_element_type: str = "object?"
    default_dict_key_type: str = "string"
    default_dict_value_type: str = "object?"
    variable_type_hints: VariableTypeHints = VariableTypeHints.NEVER
    comment_format: CommentFormats = CommentFormats.DOUBLE_SLASH
    declaration_style: DeclarationStyles = DeclarationStyles.VAR
    dict_entry_style: DictEntryStyles = DictEntryStyles.DEFAULT
    dict_format: DictFormats = DictFormats.DICTIONARY
    float_format: FloatFormats = FloatFormats.REPR
    integer_format: IntegerFormats = IntegerFormats.DECIMAL
    integer_width_strategy: BareIntegerWidthStrategies = (
        BareIntegerWidthStrategies.BARE
    )
    numeric_literal_suffix: NumericLiteralSuffixes = (
        NumericLiteralSuffixes.NONE
    )
    numeric_separator: NumericSeparators = NumericSeparators.NONE
    numeric_style: NumericStyles = NumericStyles.OVERLOADED
    string_format: StringFormats = StringFormats.DOUBLE
    trailing_comma: TrailingCommas = TrailingCommas.NO
    statement_terminator_style: StatementTerminatorStyles = (
        StatementTerminatorStyles.SEMICOLON
    )
    call_style: CallStyles = CallStyles.POSITIONAL
    heterogeneous_strategy: HeterogeneousStrategies = (
        HeterogeneousStrategies.ERROR
    )
    record_shape_names: Mapping[frozenset[str], str] = dataclasses.field(
        default_factory=empty_record_shape_names,
        hash=False,
    )
    json_type: JsonTypes | None = None
    # Keep in sync with the `LanguageVersion` passed to the C# lint host
    # in `scripts/lint-csharp/Program.cs`.
    language_version: VersionFormats = VersionFormats.V10
    indent: str = "    "
    skip_null_dict_values: bool = False

    _default_null_literal: ClassVar[str] = "(object?)null"
    true_literal: ClassVar[str] = "true"
    false_literal: ClassVar[str] = "false"
    indent_closing_delimiter: ClassVar[bool] = False
    element_separator: ClassVar[str] = ", "
    supports_collection_comments: ClassVar[bool] = True
    supports_scalar_before_comments: ClassVar[bool] = True
    supports_scalar_inline_comments: ClassVar[bool] = False
    statement_terminator: ClassVar[str] = ";"
    static_preamble: ClassVar[Sequence[str]] = ()
    static_body_preamble: ClassVar[Sequence[str]] = ()
    special_float_preamble: ClassVar[tuple[str, ...]] = ()

    @cached_property
    @beartype
    def _json_type_active(self) -> bool:
        """Return whether C# should render through ``JsonNode``."""
        return self.json_type is not None

    @cached_property
    @beartype
    def null_literal(self) -> str:
        """Null literal for the active C# representation.

        Under ``json_type`` an explicitly-typed ``(JsonNode?)null``
        keeps a top-level ``null`` from ambiguously binding to a method
        overload (``System.Text.Json.Nodes`` exposes implicit operators
        from many primitive types that a bare ``null`` literal would
        also match).
        """
        if self._json_type_active:
            return "(JsonNode?)null"
        return self._default_null_literal

    @cached_property
    @beartype
    def format_call_arg(self) -> Callable[[Value, str], str]:
        """Callable that rewrites a formatted direct call argument.

        Under ``json_type`` every call argument is cast to ``JsonNode?``
        so the underlying stub receives a JSON value; under any other
        mode call arguments pass through unchanged.
        """
        if self._json_type_active:
            return _format_csharp_json_call_arg
        return identity_call_arg

    @cached_property
    @beartype
    def format_sequence_entry(self) -> Callable[[Value, str], str]:
        """Format a sequence entry."""
        return passthrough_sequence_entry

    @cached_property
    @beartype
    def format_set_entry(self) -> Callable[[Value, str], str]:
        """Format a set entry."""
        return passthrough_set_entry

    assignment_declares_binding = requires_declared_binding
    reference_assignment_declares_binding = assignment_declares_binding
    call_assignment_declares_binding = False

    @cached_property
    @beartype
    def format_variable_assignment(self) -> Callable[[str, str, Value], str]:
        """Format an assignment to an existing variable.

        Under ``json_type`` the assigned expression is cast to
        ``JsonNode?`` through the same helper as the declaration form
        so the two halves of a combined declaration / assignment stay
        consistent.
        """
        if self._json_type_active:
            return _format_csharp_json_assignment
        return variable_formatter(template="{name} = {value};")

    @cached_property
    @beartype
    def format_ordered_map_entry(self) -> Callable[[str, Value, str], str]:
        """Format one ordered-map entry.

        Under ``json_type`` an ordered map renders as a ``JsonObject``,
        whose collection initializer takes ``KeyValuePair`` entries via
        the indexer ``["key"] = value`` form (matching the dict
        renderer).
        """
        return dict_entry_with_template(
            template="[{key}] = {value}",
            format_value=passthrough_sequence_entry,
        )

    @cached_property
    @beartype
    def _record_strategy_active(self) -> bool:
        """Return whether the ``RECORD`` heterogeneous strategy is set."""
        return (
            self.heterogeneous_strategy
            is type(self.heterogeneous_strategy).RECORD
        )

    @cached_property
    @beartype
    def _csharp_record_scalar_resolver(
        self,
    ) -> Callable[[type], str | None]:
        """Map a scalar field's Python type to its C# type name.

        Built from the same scalar mapping the collection openers use,
        with the date/datetime names resolved from the configured
        formats (so an ``ISO`` datetime field is typed ``string``,
        matching the rendered literal).  A type with no entry in that
        mapping (e.g. ``NoneType``) yields ``None`` so the caller can
        fall back to the top type ``object?`` that permits null.
        """
        cfg = self._opener_config
        return cfg.element_to_type(
            dict_value_to_type=None,
            list_template=None,
            enable_list_type=False,
            date_type=cfg.type_name(py_type=self._date_tp),
            datetime_type=cfg.type_name(py_type=self._dt_tp),
            enable_dict_type=False,
            dict_key_type="",
        )

    @beartype
    def _csharp_scalar_field_type(self, *, value: Value) -> str:
        """Resolve the scalar field type with the object fallback."""
        scalar_type = self._csharp_record_scalar_resolver(type(value))
        field_type = "object?"
        if scalar_type is not None and scalar_type != "":
            field_type = scalar_type
        return field_type

    def _csharp_record_field_type(
        self,
        request: RecordFieldType,
        /,
    ) -> str:
        """Return the C# record-component type for a field, derived
        structurally from the raw value (the Go/Java/Scala pattern).

        A field whose value is itself a nested record-shaped dict uses
        that record's generated name.  A field whose value is a list of
        record-shaped dicts (one shared shape) is typed ``RecordN[]`` to
        match the implicitly-typed array opener
        :attr:`sequence_open` widens it to (C# infers the element type
        from the ``RecordN`` literals).  An integer is sized to match
        the literal C# infers for the same value (``int``/``long``, or
        ``ulong`` beyond signed 64-bit range, the bare-decimal overflow
        fallback).  An ``EPOCH`` datetime renders as its epoch integer,
        so it is sized like that integer. Lists and ordered maps share
        structured type information with their literal openers. Every
        other scalar uses the shared scalar resolver.

        A record-eligible dict with no ``record_name`` was widened out
        of record inference because its nested sibling maps cannot
        share one shape.  Type that field as ``Dictionary<string,
        object?>`` so the uniform enclosing record survives (#2913).  A
        set or a genuinely non-record dict (empty or non-string-keyed)
        still has no precise component type; per the cross-language
        decision in #2317, C# folds it into the ``object?`` top type.
        """
        if request.record_name is not None:
            return request.record_name
        if request.element_record_name is not None:
            return f"{request.element_record_name}[]"
        value = request.value
        # An ``EPOCH`` datetime renders as its epoch integer, so size
        # the field exactly like that integer; other datetime formats
        # stay datetime-typed via the scalar resolver below.
        if (
            isinstance(value, dt.datetime)
            and self.datetime_format.value.type_produced is int
        ):
            value = datetime_epoch_seconds(value=value)
        match value:
            case int() if not isinstance(value, bool):
                field_type = _csharp_int_field_type(value=value)
            case OrderedMap():
                field_type = self._ordered_map_type(value).declared_type
            case dict() if record_shape_for_dict(value=value) is not None:
                field_type = self._csharp_derecordized_map_field_type()
            case dict():
                field_type = "object?"
            case list():
                field_type = self._array_type(value).declared_type
            case _:
                field_type = self._csharp_scalar_field_type(value=value)
        return field_type

    @cached_property
    @beartype
    def _record_renderer(self) -> RecordRenderer:
        """C# syntax hooks for the ``RECORD`` strategy."""
        return RecordRenderer(
            name_prefix="Record",
            record_shape_names=self.record_shape_names,
            field_identifier=_csharp_record_field_identifier,
            field_identifier_key=identity_field_identifier_key,
            field_type=self._csharp_record_field_type,
            render_declaration=_csharp_render_record_declaration,
            render_literal=_csharp_record_literal,
            field_type_names_nested_records=False,
            suppress_custom_name_declarations=False,
        )

    @cached_property
    @beartype
    def _record_strategy(self) -> RecordStrategy:
        """Behavior + ``record``-declaration preamble for ``RECORD``."""
        if not self._record_strategy_active:
            return RecordStrategy(
                behavior=NO_HETEROGENEOUS_BEHAVIOR,
                preamble=no_data_preamble,
                record_name_for_value=None,
            )
        strategy = build_record_strategy(
            renderer=self._record_renderer,
            widen_unrecordizable_nested_sibling_maps=True,
            derecordized_map_open=None,
        )
        narrowing = self._derecordized_map_narrowing
        base_compute_wrap_ids = strategy.behavior.compute_wrap_ids

        @beartype
        def _compute_wrap_ids(data: Value, /) -> frozenset[int]:
            """Refresh the widened-map value type for this render pass."""
            wrap_ids = base_compute_wrap_ids(data)
            narrowing.value_type = self._csharp_narrow_derecordized_map_type(
                data=data,
                wrap_ids=wrap_ids,
            )
            return wrap_ids

        @beartype
        def _widened_map_open() -> str:
            """Return the fallback-map opener for the current pass."""
            value_type = narrowing.value_type
            if value_type is None or value_type == "":
                value_type = "object?"
            return f"new Dictionary<string, {value_type}> {{"

        return dataclasses.replace(
            strategy,
            behavior=dataclasses.replace(
                strategy.behavior,
                compute_wrap_ids=_compute_wrap_ids,
                dict_open_for_wrap_ids=_widened_map_open,
            ),
        )

    def _csharp_derecordized_map_field_type(self) -> str:
        """Return the component type for a widened fallback map."""
        value_type = self._derecordized_map_narrowing.value_type
        if value_type is None or value_type == "":
            value_type = "object?"
        return f"Dictionary<string, {value_type}>"

    def _csharp_narrow_derecordized_map_type(
        self,
        *,
        data: Value,
        wrap_ids: frozenset[int],
    ) -> str | None:
        """Return the one concrete type shared by widened-map scalars."""

        @beartype
        def contains_wrapped_non_scalar(value: Value) -> bool:
            """Return whether a widened map contains a collection
            value.
            """
            if isinstance(value, dict):
                if id(value) in wrap_ids and any(
                    isinstance(child, (dict, list, set))
                    for child in value.values()
                ):
                    return True
                return any(
                    contains_wrapped_non_scalar(value=child)
                    for child in value.values()
                )
            if isinstance(value, (list, set)):
                return any(
                    contains_wrapped_non_scalar(value=child) for child in value
                )
            return False

        if contains_wrapped_non_scalar(value=data):
            return None
        scalars = iter_wrapped_scalars(data=data, wrap_ids=wrap_ids)
        if len(scalars) == 0:
            return None
        scalar_types = {
            self._csharp_record_field_type(
                RecordFieldType(
                    value=scalar,
                    record_name=None,
                    element_record_name=None,
                ),
            )
            for scalar in scalars
        }
        concrete_type = single_concrete_type(
            types=scalar_types, fallback_type="object?"
        )
        if concrete_type is not None:
            return concrete_type
        return _csharp_object_fallback(items=scalars, fallback="object?")

    @cached_property
    @beartype
    def _derecordized_map_narrowing(self) -> _CSharpWidenedMapNarrowing:
        """Cache the fallback-map value type within one render pass."""
        return _CSharpWidenedMapNarrowing(value_type=None)

    @cached_property
    @beartype
    def data_dependent_preamble(self) -> Callable[[Value], tuple[str, ...]]:
        """Return data-dependent preamble lines.

        Under ``json_type`` every rendered file pulls in
        ``System.Text.Json.Nodes`` unconditionally; the per-collection
        format configurations leave their ``preamble_lines`` empty so
        the ``using`` line is emitted here exactly once regardless of
        which container shapes appear in the data.

        Under ``HeterogeneousStrategies.RECORD`` this emits one
        positional ``record`` declaration per record shape present in
        the data; otherwise C# needs no data-dependent preamble.
        """
        if self._json_type_active:

            @beartype
            def _json_preamble(_data: Value, /) -> tuple[str, ...]:
                """Always contribute the JsonNode ``using`` directive."""
                return (_CSHARP_JSON_USING,)

            return _json_preamble
        if self._record_strategy_active:
            return self._record_strategy.preamble
        return no_data_preamble

    @cached_property
    @beartype
    def heterogeneous_behavior(self) -> HeterogeneousBehavior:
        """Return the heterogeneous-behavior config.

        ``json_type`` relaxes scalar-type checks unconditionally,
        because ``JsonObject`` / ``JsonArray`` accept heterogeneous
        ``JsonNode`` children by construction.

        ``RECORD`` resolves to the shared record behavior (its value
        needs the per-instance renderer, so it cannot be stored on the
        enum member); ``ERROR`` uses the static raising behavior.
        """
        if self._json_type_active:
            return dataclasses.replace(
                NO_HETEROGENEOUS_BEHAVIOR,
                skip_scalar_checks=True,
                wrap_non_scalar=passthrough_sequence_entry,
            )
        if self._record_strategy_active:
            return self._record_strategy.behavior
        return NO_HETEROGENEOUS_BEHAVIOR

    call_data_dependent_preamble = default_call_data_dependent_preamble

    type_hint_collection_preamble_lines = (
        default_type_hint_collection_preamble_lines
    )

    @cached_property
    @beartype
    def format_call_class_scope_stub(
        self,
    ) -> Callable[
        [Sequence[str], Sequence[str], StubReturn, Sequence[Value]],
        tuple[str, ...],
    ]:
        """Return stub declarations for a call expression."""
        return _csharp_call_stub

    format_call_stub = default_format_call_stub

    format_call_preamble_stub = default_format_call_stub

    format_call_target = default_format_call_target

    @cached_property
    @beartype
    def format_call_ref_identifier(
        self,
    ) -> Callable[[str, Value | None], str]:
        """Copy JSON nodes before attaching them to another parent."""
        if not self._json_type_active:
            return identity_call_ref_identifier

        @beartype
        def _clone_ref(name: str, _value: Value | None, /) -> str:
            """Convert native scalars and detach non-null JSON nodes."""
            return f"((JsonNode?){name})?.DeepClone()"

        return _clone_ref

    format_call_arg_ref_identifier = default_format_call_arg_ref_identifier

    format_call_arg_ref_identifier_consumable = (
        default_format_call_arg_ref_identifier_consumable
    )

    consumable_ref_value_inhibits_consuming_form = (
        default_consumable_ref_value_inhibits_consuming_form
    )

    @cached_property
    @beartype
    def _date_tp(self) -> type:
        """Python type produced by the chosen date format."""
        return self.date_format.value.type_produced

    @cached_property
    @beartype
    def _dt_tp(self) -> type:
        """Python type produced by the chosen datetime format."""
        return self.datetime_format.value.type_produced

    @cached_property
    @beartype
    def _base_set_format_config(self) -> SetFormatConfig:
        """Base set format config before typed-opener application."""
        return self.set_format(
            default_type=self.default_set_element_type,
        )

    @cached_property
    @beartype
    def _openers(self) -> TypeOpeners:
        """Typed openers built from the opener config."""
        cfg = self._opener_config
        effective_set_opener_template = None
        if self._base_set_format_config.set_opener_template != "":
            effective_set_opener_template = (
                self._base_set_format_config.set_opener_template
            )
        base = cfg.build(
            date_type=cfg.type_name(py_type=self._date_tp),
            datetime_type=cfg.type_name(py_type=self._dt_tp),
            set_opener_template=(effective_set_opener_template),
            narrow_dict_values=False,
            narrow_list_values=True,
            dict_key_type=self.default_dict_key_type,
        )

        @beartype
        def _sequence_element_type(
            element_type: type | ListType | DictType,
        ) -> str | None:
            """Give nested maps the same carrier as their literal
            opener.
            """
            if isinstance(element_type, DictType):
                return self._dict_type(list(element_type.values)).declared_type
            if isinstance(element_type, ListType):
                inner = _sequence_element_type(element_type=element_type.inner)
                return None if inner is None else f"{inner}[]"
            return base.seq_element_type(element_type)

        return dataclasses.replace(
            base, seq_element_type=_sequence_element_type
        )

    @cached_property
    @beartype
    def _resolved_dict_opener(self) -> str:
        """Opener template with the key type resolved."""
        return self.dict_format.value.opener_template.replace(
            "{key_type}",
            self.default_dict_key_type,
        )

    @cached_property
    @beartype
    def sequence_format_config(self) -> SequenceFormatConfig:
        """Configuration for the chosen sequence format.

        Under ``json_type`` every sequence is rendered as ``new
        JsonArray { ... }`` (and ``new JsonArray()`` for the empty
        case), which accepts heterogeneous ``JsonNode`` children via
        the implicit conversion operators on
        ``System.Text.Json.Nodes``.  The ``using`` directive is
        contributed by :attr:`data_dependent_preamble`, so this config
        leaves its ``preamble_lines`` empty.

        ``()`` parses as an invalid expression in C#; the language's
        ``ValueTuple.Create()`` (or a typed empty array literal
        ``new T[] {}`` for the array format) is the syntactically valid
        empty form, so prefer it whenever an empty inner list sits
        beside non-empty siblings.  The array empty form is a plain
        language-level array literal, never ``Array.Empty<T>()``, so the
        array literal itself needs no ``using System;``. A configured
        ``String`` element name contributes that import separately.
        """
        if self.json_type is not None:
            effective_declared_type = self.json_type.value
            return SequenceFormatConfig(
                length_is_part_of_type=False,
                sequence_open=fixed_open(open_str=_CSHARP_JSON_ARRAY_OPEN),
                close="}",
                supports_heterogeneity=True,
                single_element_trailing_comma=False,
                single_element_template=None,
                supports_trailing_comma=True,
                empty_sequence=_CSHARP_JSON_EMPTY_ARRAY,
                preamble_lines=(),
                format_entry=passthrough_sequence_entry,
                typed_opener_fallback=None,
                uses_typed_literal_for_scalars=False,
                requires_uniform_record_shapes=False,
                declared_type=(effective_declared_type),
                narrowed_empty_form=None,
            )
        element_type = self.default_sequence_element_type
        base = self.sequence_format(default_type=element_type)
        empty = "ValueTuple.Create()"
        if self.sequence_format is type(self.sequence_format).ARRAY:
            empty = f"new {element_type}[] {{}}"

        @beartype
        def _narrowed_empty_form(
            siblings: Sequence[list[Value]],
        ) -> str:
            """Return an empty literal matching its sibling array type."""
            if self.sequence_format is self.sequence_formats.ARRAY:
                items = [item for sibling in siblings for item in sibling]
                array_type = self._array_type(items)
                return f"new {array_type.declared_type} {{}}"
            return empty

        return dataclasses.replace(
            base,
            length_is_part_of_type=self.sequence_format
            is self.sequence_formats.TUPLE,
            preamble_lines=(
                (*base.preamble_lines, "using System;")
                if element_type == "String"
                else base.preamble_lines
            ),
            narrowed_empty_form=_narrowed_empty_form,
        )

    @cached_property
    @beartype
    def set_format_config(self) -> SetFormatConfig:
        """Configuration for the chosen set format (with typed opener).

        Under ``json_type`` a set renders as a ``new JsonArray { ... }``
        because JSON has no native set type; the empty form widens to
        ``new JsonArray()`` for the same reason an empty sequence does.
        """
        if self._json_type_active:
            return SetFormatConfig(
                set_open=fixed_open(open_str=_CSHARP_JSON_ARRAY_OPEN),
                close="}",
                empty_set=_CSHARP_JSON_EMPTY_ARRAY,
                preamble_lines=(),
                set_opener_template="",
                supports_heterogeneity=True,
                supports_trailing_comma=True,
            )
        base = self._base_set_format_config
        type_to_opener = self._openers.set
        if base.supports_heterogeneity:

            @beartype
            def _heterogeneous_set_open(
                element_type: type | ListType | DictType,
                /,
            ) -> str | None:
                """Keep integer values without coercing them to double."""
                if element_type is MixedNumeric:
                    return "new HashSet<object> {"
                return self._openers.set(element_type)

            type_to_opener = _heterogeneous_set_open
        typed = base.with_typed_opener(
            type_to_opener=type_to_opener,
            fallback=base.set_open([]),
        )

        non_nullable = self.set_format(
            default_type="object"
        ).with_typed_opener(
            type_to_opener=type_to_opener,
            fallback=self.set_format(default_type="object").set_open([]),
        )

        @beartype
        def _set_open(items: list[Value]) -> str:
            """Keep object and epoch carriers consistent with the
            values.
            """
            selected = typed
            if (
                _csharp_object_fallback(
                    items=items, fallback=self.default_set_element_type
                )
                != self.default_set_element_type
            ):
                selected = non_nullable
            if self._dt_tp is int:
                items = [_csharp_epoch_array_item(item) for item in items]
            return selected.set_open(items)

        return dataclasses.replace(typed, set_open=_set_open)

    @cached_property
    @beartype
    def sequence_open(self) -> Callable[[list[Value]], str]:
        """Render the opener chosen with the semantic array type."""
        if (
            self._json_type_active
            or self.sequence_format is self.sequence_formats.TUPLE
        ):
            return self.sequence_format_config.sequence_open
        return collection_type_open(
            infer=self._array_type,
            fallback_type=f"{self.default_sequence_element_type}[]",
        )

    @cached_property
    @beartype
    def _array_type(self) -> Callable[[list[Value]], CollectionType]:
        """Keep array literals and record-component types together."""
        lookup = self._record_strategy.record_name_for_value

        @beartype
        def _infer(items: list[Value]) -> CollectionType:
            """Resolve nested records or the shared typed array
            fallback.
            """
            if lookup is not None:
                record_type = _csharp_record_sequence_type(
                    value=items, record_name_for_value=lookup
                )
                if record_type is not None:
                    depth, name = record_type
                    return CollectionType(
                        opener="new[] {", declared_type=name + "[]" * depth
                    )
            fallback_type = _csharp_object_fallback(
                items=items, fallback=self.default_sequence_element_type
            )
            # Object carriers can box arrays of any rank. A typed leaf
            # fallback must retain the native array dimensions instead.
            if (
                fallback_type.removeprefix("global::")
                .removeprefix("System.")
                .removesuffix("?")
                not in {"object", "Object", "dynamic"}
                and len(items) > 0
                and all(isinstance(item, list) for item in items)
            ):
                nested_types = {
                    _infer(items=item).declared_type
                    for item in items
                    if isinstance(item, list)
                }
                fallback_type = (
                    next(iter(nested_types))
                    if len(nested_types) == 1
                    else "object?"
                )
            if self._dt_tp is int:
                items = [_csharp_epoch_array_item(item) for item in items]
            return infer_collection_type(
                items=items,
                element_to_type=self._openers.seq_element_type,
                opener_template="new {type_name}[] {{",
                declared_type_template="{type_name}[]",
                fallback=CollectionType(
                    opener=f"new {fallback_type}[] {{",
                    declared_type=f"{fallback_type}[]",
                ),
            )

        return _infer

    def _ordered_map_type(
        self, value: Mapping[Scalar, Value], /
    ) -> CollectionType:
        """Resolve ordered-map defaults before adding literal syntax."""
        value_type = _csharp_object_fallback(
            items=list(value.values()), fallback=self.default_dict_value_type
        )
        declared_type = (
            f"Dictionary<{self.default_dict_key_type}, {value_type}>"
        )
        return CollectionType(
            opener=f"new {declared_type} {{", declared_type=declared_type
        )

    def _dict_type(self, values: list[Value], /) -> CollectionType:
        """Infer a map's literal and nested declared type together."""
        cfg = self._opener_config
        if self._dt_tp is int:
            values = [_csharp_epoch_array_item(value) for value in values]
        fallback = _csharp_object_fallback(
            items=values, fallback=self.default_dict_value_type
        )
        declared_template = (
            f"Dictionary<{self.default_dict_key_type}, {{type_name}}>"
        )
        return infer_collection_type(
            items=values,
            element_to_type=cfg.element_to_type(
                dict_value_to_type=None,
                list_template=None,
                enable_list_type=self.sequence_format
                is self.sequence_formats.ARRAY,
                date_type=cfg.type_name(py_type=self._date_tp),
                datetime_type=cfg.type_name(py_type=self._dt_tp),
                enable_dict_type=False,
                dict_key_type=self.default_dict_key_type,
            ),
            opener_template=self._resolved_dict_opener,
            declared_type_template=declared_template,
            fallback=CollectionType(
                opener=self._resolved_dict_opener.format(type_name=fallback),
                declared_type=declared_template.format(type_name=fallback),
            ),
        )

    @cached_property
    @beartype
    def dict_format_config(self) -> DictFormatConfig:
        """Configuration for dict formatting.

        Under ``json_type`` every dict literal is wrapped in ``new
        JsonObject { ["key"] = value, ... }`` so it renders as a JSON
        object, and an empty dict widens to ``new JsonObject()``.  The
        ``using System.Text.Json.Nodes;`` line that powers
        ``JsonObject`` is contributed by :attr:`data_dependent_preamble`
        rather than from this config, so a json-mode fixture imports it
        exactly once regardless of how many dict literals appear.
        """
        if self._json_type_active:
            return DictFormatConfig(
                dict_open=fixed_open(open_str=_CSHARP_JSON_OBJECT_OPEN),
                close="}",
                format_entry=dict_entry_with_template(
                    template="[{key}] = {value}",
                    format_value=passthrough_sequence_entry,
                ),
                empty_dict=_CSHARP_JSON_EMPTY_OBJECT,
                preamble_lines=(),
                narrowed_open=None,
                supports_trailing_comma=True,
                narrowed_empty_form=None,
            )

        @beartype
        def _infer(data: dict[Scalar, Value], /) -> CollectionType:
            """Resolve a map from its immediate values."""
            return self._dict_type(list(data.values()))

        return DictFormatConfig(
            dict_open=collection_type_open(
                infer=_infer,
                fallback_type=(
                    f"Dictionary<{self.default_dict_key_type}, "
                    f"{self.default_dict_value_type}>"
                ),
            ),
            close="}",
            format_entry=dict_entry_with_template(
                template="[{key}] = {value}",
                format_value=passthrough_sequence_entry,
            ),
            empty_dict=None,
            preamble_lines=("using System.Collections.Generic;",),
            narrowed_open=None,
            supports_trailing_comma=True,
            narrowed_empty_form=None,
        )

    @cached_property
    @beartype
    def trailing_comma_config(self) -> TrailingCommaConfig:
        """Configuration for trailing-comma behavior."""
        return self.trailing_comma.value

    @cached_property
    @beartype
    def format_bytes(self) -> Callable[[bytes], str]:
        """Callable that formats a bytes value as a string literal."""
        return self.bytes_format

    @cached_property
    @beartype
    def format_date(self) -> Callable[[dt.date], str]:
        """Callable that formats a date as a string literal.

        ``json_type`` overrides the configured ``date_format`` with the
        ISO 8601 string form because the C# native ``DateOnly`` literal
        would not round-trip through JSON.
        """
        if self._json_type_active:
            return format_date_iso
        return self.date_format

    @cached_property
    @beartype
    def format_datetime(self) -> Callable[[dt.datetime], str]:
        """Callable that formats a datetime as a string literal.

        ``json_type`` overrides the configured ``datetime_format`` with
        the ISO 8601 string form unless the user has explicitly chosen
        the ``EPOCH`` integer form, which remains a valid JSON number.
        """
        if (
            self._json_type_active
            and self.datetime_format.value.type_produced is not int
        ):
            return format_datetime_iso
        return self.datetime_format

    @cached_property
    @beartype
    def format_time(self) -> Callable[[dt.time], str]:
        """Callable that formats a time as a string literal.

        ``json_type`` overrides the native ``TimeOnly`` literal with the
        ISO 8601 string form because there is no implicit conversion
        from ``TimeOnly`` to ``JsonNode`` and JSON has no native time
        type.
        """
        if self._json_type_active:
            return format_time_iso
        return format_time_csharp

    @cached_property
    @beartype
    def format_string(self) -> Callable[[str], str]:
        """Callable that formats a string value as a quoted literal."""
        return self.string_format

    @cached_property
    @beartype
    def format_float(self) -> Callable[[float], str]:
        """Callable that formats a float value as a literal."""
        return self.float_format

    @cached_property
    @beartype
    def format_integer(self) -> Callable[[int], str]:
        """Callable that formats an int value as a literal.

        Positive values above ``long.MaxValue`` are accepted as bare
        literals because C# infers ``ulong`` for literals without a
        type suffix up to ``ulong.MaxValue``.  Values below
        ``long.MinValue`` have no clean literal form (unary minus
        cannot apply to ``ulong``), so they raise
        ``UnrepresentableIntegerError``.
        """
        base = self.integer_format.get_formatter(
            numeric_separator=self.numeric_separator,
        )
        return make_overflow_fallback_formatter(
            base=base,
            fallback=raise_for_unrepresentable_int(language_name="C#"),
            min_value=I64_MIN,
            max_value=2**64 - 1,
        )

    @cached_property
    @beartype
    def format_integer_beyond_i64(self) -> Callable[[int], str]:
        """Always-``UL``-suffixed formatter for collections that exceed
        signed 64-bit range.
        """
        return make_unsigned_overflow_fallback(
            format_positive=_format_csharp_ulong_positive,
            language_name="C#",
        )

    @cached_property
    @beartype
    def comment_config(self) -> CommentConfig:
        """Configuration for the language's comment syntax."""
        return self.comment_format.value

    @cached_property
    @beartype
    def ordered_map_format_config(self) -> OrderedMapFormatConfig:
        """Configuration for ordered-map formatting.

        Under ``json_type`` an ordered map renders as a ``JsonObject``;
        the ``System.Text.Json.Nodes`` library preserves the indexer
        insertion order in the rendered output, so the JSON object
        opener is interchangeable with the dict opener here.
        """
        if self._json_type_active:
            return OrderedMapFormatConfig(
                ordered_map_open=fixed_open(
                    open_str=_CSHARP_JSON_OBJECT_OPEN,
                ),
                close="}",
                preamble_lines=(),
            )
        base = ordered_map_format_factory(
            open_template="new Dictionary<{key_type}, {type}> {{",
            close="}",
            preamble_lines=("using System.Collections.Generic;",),
        )(
            self.default_dict_value_type,
            default_key_type=self.default_dict_key_type,
        )

        @beartype
        def _open(value: dict[Scalar, Value]) -> str:
            """Render the ordered-map opener from its semantic type."""
            return self._ordered_map_type(value).opener

        return dataclasses.replace(base, ordered_map_open=_open)

    @cached_property
    @beartype
    def format_variable_declaration(
        self,
    ) -> Callable[[str, str, Value, frozenset[enum.Enum]], str]:
        """Callable that formats a new variable declaration.

        Under ``json_type`` the declaration carries an explicit
        ``JsonNode?`` type annotation (never ``var``) and the
        right-hand side is wrapped in a ``(JsonNode?)`` cast unless the
        value is already a ``JsonObject`` / ``JsonArray`` literal.  The
        per-declaration formatter rejects the ``const`` modifier
        because every json-mode initializer (the cast or the
        constructor) is a runtime expression.
        """
        json_type = self.json_type
        if json_type is not None:
            return _csharp_json_declaration_formatter(
                json_type=json_type.value,
            )
        date_hint = "DateOnly"
        if self.date_format.value.type_produced is str:
            date_hint = "string"
        if self.datetime_format.value.type_produced is int:
            datetime_hint = "long"
        else:
            datetime_hint = "DateTime"
            if self.datetime_format.value.type_produced is str:
                datetime_hint = "string"
        dict_value_type = self.default_dict_value_type
        tuple_sequences = self.sequence_format is self.sequence_formats.TUPLE

        @beartype
        def _formatter(
            name: str,
            value: str,
            data: Value,
            modifiers: frozenset[enum.Enum],
        ) -> str:
            """Adapt :func:`_format_csharp_declaration` to the positional
            formatter interface.
            """
            return _format_csharp_declaration(
                name=name,
                value=value,
                data=data,
                modifiers=modifiers,
                date_hint=date_hint,
                datetime_hint=datetime_hint,
                dict_value_type=dict_value_type,
                tuple_sequences=tuple_sequences,
                record_type=(
                    None
                    if self._record_strategy.record_name_for_value is None
                    else self._record_strategy.record_name_for_value(data)
                ),
            )

        return _formatter

    @staticmethod
    def bound_reference_modifiers(
        modifiers: frozenset[enum.Enum], /
    ) -> frozenset[enum.Enum]:
        """Class-field roots require typed static bound fields."""
        if _is_csharp_class_field(modifiers):
            return frozenset({_CSharpModifiers.STATIC})
        return frozenset[enum.Enum]()

    def validate_reference_binding_hint(
        self, value: Value, hint: Value, /
    ) -> None:
        """Reject an explicit hint incompatible with its bound field
        type.
        """
        modifiers = frozenset[enum.Enum]({_CSharpModifiers.STATIC})
        formatter = self.format_variable_declaration
        actual_declaration = formatter("bound", "value", value, modifiers)
        hinted_declaration = formatter("bound", "value", hint, modifiers)
        if actual_declaration != hinted_declaration:
            msg = (
                "C# reference hints must have the same declaration type "
                "as their bound values"
            )
            raise UnrepresentableInputError(msg)

    @cached_property
    @beartype
    def scalar_preamble(self) -> dict[type, tuple[str, ...]]:
        """Per-instance scalar preamble computed from date/datetime format.

        Under ``json_type`` the ``using System.Text.Json.Nodes;`` line
        is contributed by :attr:`data_dependent_preamble` instead, so
        this method returns an empty per-scalar map to avoid
        duplicating it; dates / datetimes / times all render as ISO
        8601 strings (or an epoch integer for the explicit ``EPOCH``
        datetime format) and need no per-scalar import of their own.
        """
        if self._json_type_active:
            return {}
        return date_scalar_preamble(
            date_format=self.date_format,
            datetime_format=self.datetime_format,
            extra={dt.time: ("using System;",)},
        )

    @cached_property
    @beartype
    def scalar_body_preamble(self) -> dict[type, tuple[str, ...]]:
        """Per-instance scalar body preamble (C# needs none)."""
        return {}

    @cached_property
    @beartype
    def compute_body_preamble(
        self,
    ) -> Callable[[frozenset[type], Value], tuple[str, ...]]:
        """Compute body-preamble lines from the scalar map."""
        return body_preamble_from_scalars(
            scalar_body_preamble=self.scalar_body_preamble,
            format_lines=tuple,
        )

    @cached_property
    @beartype
    def call_style_config(self) -> CallStyle:
        """Configuration for the chosen call style."""
        config: CallStyle = self.call_style.value
        return config
