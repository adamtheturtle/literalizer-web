"""Kotlin language specification."""

import dataclasses
import datetime as dt
import enum
import functools
import json
import re
from collections.abc import Callable, Mapping, Sequence
from functools import cached_property
from types import MappingProxyType
from typing import TYPE_CHECKING, ClassVar, Final

from beartype import beartype

from literalizer._checks import (
    check_empty_sibling_sequence_type_hint_data,
    reject_aware_datetimes,
)
from literalizer._comments import NestingCommentSuffix
from literalizer._formatters.collection_openers import (
    CollectionSignature,
    CollectionType,
    TypedOpenerConfig,
    fixed_open,
    infer_collection_type,
    signature_open,
    typed_collection_open,
)
from literalizer._formatters.format_dates import (
    date_ymd_formatter,
    datetime_ymdhms_formatter,
    format_date_iso,
    format_datetime_epoch,
    format_datetime_iso,
    format_time_local_time_of,
)
from literalizer._formatters.format_entries import (
    dict_entry_with_separator,
    dict_entry_with_template,
    format_bytes_base64,
    format_bytes_hex,
    passthrough_sequence_entry,
    passthrough_set_entry,
    variable_declaration_formatter,
    variable_formatter,
)
from literalizer._formatters.format_factories import set_format_factory
from literalizer._formatters.format_floats import (
    format_float_fixed,
    format_float_repr,
    format_float_scientific,
)
from literalizer._formatters.format_integers import (
    I64_MAX,
    I64_MIN,
    data_has_out_of_range_int,
    format_integer_binary,
    format_integer_hex,
    format_integer_underscore,
    make_long_suffix_formatter,
    make_overflow_fallback_formatter,
)
from literalizer._formatters.format_json_value import JsonValue
from literalizer._formatters.format_strings import (
    make_backslash_string_formatter,
)
from literalizer._formatters.initializer_types import TypedCollectionOpen
from literalizer._formatters.record_strategy import (
    RecordDeclarationField,
    RecordFieldType,
    RecordLiteralField,
    RecordRenderer,
    RecordStrategy,
    build_record_strategy,
    identity_field_identifier_key,
)
from literalizer._formatters.tuple_strategy import (
    TupleRenderer,
    build_tuple_strategy,
)
from literalizer._formatters.type_inference import (
    DictType,
    ListType,
    infer_element_type,
    record_shape_for_dict,
    single_concrete_type,
)
from literalizer._heterogeneous import iter_wrapped_values
from literalizer._json_native_document import (
    register_json_native_document_fast,
)
from literalizer._language import (
    NO_CALL_PARAMETER_LIMIT,
    NO_HETEROGENEOUS_BEHAVIOR,
    NON_KEBAB_REF_CASES,
    BareIntegerWidthStrategies,
    CallParameterShadowing,
    CallStubResult,
    CallStyle,
    CommentConfig,
    DateFormatConfig,
    DateFormatEnum,
    DatetimeFormatConfig,
    DatetimeFormatEnum,
    DeclarationStyleConfig,
    DictFormatConfig,
    FileWrapperContext,
    FloatSpecialsMixin,
    FormatValueMixin,
    HeterogeneousBehavior,
    IdentifierCase,
    JsonType,
    KeywordCallStyle,
    LanguageCls,
    ModifierCombination,
    NewVariableNameSyntax,
    OrderedMapFormatConfig,
    PositionalCallStyle,
    RenderedRecordLiteral,
    RenderedTupleLiteral,
    RoundTripCapability,
    SequenceFormatConfig,
    SetFormatConfig,
    StubReturn,
    TrailingCommaConfig,
    VariantMetadata,
    body_preamble_from_scalars,
    date_scalar_preamble,
    default_call_data_dependent_preamble,
    default_consumable_ref_value_inhibits_consuming_form,
    default_format_call_arg_ref_identifier,
    default_format_call_arg_ref_identifier_consumable,
    default_format_call_ref_identifier,
    default_format_call_statement,
    default_format_call_stub,
    default_format_call_target,
    default_format_call_variable_assignment,
    default_sequence_binding_declarations,
    default_type_hint_collection_preamble_lines,
    default_validate_call_arg,
    default_wrap_calls_with_declarations,
    empty_record_shape_names,
    identity_call_arg,
    identity_constructor_target,
    no_call_binding_body_preamble,
    no_call_binding_file_pragmas,
    no_data_preamble,
    no_leading_preamble,
    requires_declared_binding,
    wrap_combined_in_file_noop_static,
    wrap_in_file_noop_static,
)
from literalizer._types import OrderedMap, Scalar, Value
from literalizer.exceptions import (
    IncompatibleFormatsError,
    InvalidRecordNameError,
    UnrepresentableInputError,
)

_PASCAL_CASE_IDENTIFIER = re.compile(pattern=r"^[A-Z][A-Za-z0-9_]*$")
_TRAILING_LINE_WHITESPACE = re.compile(pattern=r"[ \t]+(?=\n)")

# Kotlin reserves every all-underscore name -- ``_``, ``__``,
# ``___`` and so on -- so the set is spelled as a pattern rather
# than enumerated (issue #4510).
_KOTLIN_ALL_UNDERSCORES = re.compile(pattern=r"_+")

_format_string_backslash_dollar_nul = make_backslash_string_formatter(
    quote_char='"',
    extra_replacements=[("$", r"\$"), ("\0", r"\u0000")],
)


_KOTLIN_EMITTED_TYPE_NAMES: Final[frozenset[str]] = frozenset(
    {
        "Any",
        "Array",
        "BigInteger",
        "Boolean",
        "BooleanArray",
        "Double",
        "DoubleArray",
        "Int",
        "IntArray",
        "LinkedHashMap",
        "List",
        "LocalDate",
        "LocalDateTime",
        "LocalTime",
        "Long",
        "Map",
        "Pair",
        "Set",
        "String",
        "Triple",
    }
)
"""Type names the generated code can reference.

A data class named after one of these either shadows the
type the same file uses or clashes with what its import line brings
in, so the compiler rejects the output (issue #4536).
"""


@beartype
def _format_string_multiline(value: str) -> str:
    r"""Format *value* as a non-interpolating Kotlin raw string."""
    if (
        "\r" in value
        or "\0" in value
        or _TRAILING_LINE_WHITESPACE.search(string=value) is not None
    ):
        return _format_string_backslash_dollar_nul(value=value)
    collected_escaped: list[str] = []
    for entry_char in value:
        if entry_char == "$":
            effective_value = "${'$'}"
        else:
            effective_value = entry_char
            if effective_value == '"':
                effective_value = "${'\"'}"
        collected_escaped.append(effective_value)
    escaped = "".join(collected_escaped)
    return f'"""{escaped}"""'


@beartype
def _format_kotlin_biginteger_literal(value: int) -> str:
    """Format a value outside signed 64-bit range as a Kotlin
    ``java.math.BigInteger`` constructor call.

    The Kotlin ``Long`` type is signed 64-bit; values outside that
    range must use ``java.math.BigInteger`` (with a matching ``import``
    statement emitted via the data-dependent preamble).
    """
    return f'BigInteger("{value}")'


@beartype
def _kotlin_biginteger_preamble(data: Value, /) -> tuple[str, ...]:
    """Return ``import java.math.BigInteger`` if *data* contains a
    very-large integer.
    """
    if data_has_out_of_range_int(data=data):
        return ("import java.math.BigInteger",)
    return ()


@beartype
def _kotlin_sequence_constructor(
    element_type: type | ListType | DictType,
) -> str | None:
    """Select the LIST constructor from the inferred element kind."""
    scalar_constructors: dict[type, str] = {
        str: "arrayOf",
        bool: "booleanArrayOf",
        int: "intArrayOf",
        float: "doubleArrayOf",
        bytes: "arrayOf",
        dt.date: "arrayOf",
        dt.datetime: "arrayOf",
        dt.time: "arrayOf",
    }
    match element_type:
        case DictType():
            return None
        case ListType():
            inner = _kotlin_sequence_constructor(
                element_type=element_type.inner
            )
            return "arrayOf" if inner is not None else None
        case _:
            return scalar_constructors.get(element_type)


@beartype
def _kotlin_type_to_opener(
    element_type: type | ListType | DictType,
) -> str | None:
    """Spell the selected constructor for value-less type resolution."""
    constructor = _kotlin_sequence_constructor(element_type=element_type)
    return f"{constructor}(" if constructor is not None else None


_KOTLIN_PRIMITIVE_ARRAY_TYPES: dict[type, str] = {
    bool: "BooleanArray",
    int: "IntArray",
    float: "DoubleArray",
}
"""The element types the LIST format renders as a primitive array.

``intArrayOf(1)`` is an ``IntArray``, which is unrelated to
``Array<Int>``, so a map value carrying one has to be annotated with
the primitive array type (issue #3941).
"""


@beartype
def _kotlin_array_type(*, element_name: str | None) -> str | None:
    """Wrap a resolved Kotlin element type in an array type."""
    if element_name is None:
        return None
    return f"Array<{element_name}>"


@beartype
def _kotlin_list_value_type_name(
    element_type: ListType,
    *,
    scalar_resolver: Callable[[type | ListType | DictType], str | None],
) -> str | None:
    """Return the type the LIST format renders a list value as.

    Mirrors :func:`_kotlin_type_to_opener` arm for arm, so a narrowed
    map value type and the literal in it always name the same Kotlin
    type.  ``None`` means the opener chosen there has no narrow type
    to name, and the caller falls back to the generic value type.
    """
    inner = element_type.inner
    match inner:
        case ListType():
            nested = _kotlin_list_value_type_name(
                element_type=inner,
                scalar_resolver=scalar_resolver,
            )
            return _kotlin_array_type(element_name=nested)
        case DictType():
            return None
        case _:
            primitive = _KOTLIN_PRIMITIVE_ARRAY_TYPES.get(inner)
            if primitive is not None:
                return primitive
            # The opener has no arm for the wide-integer sentinels, so
            # the literal falls back to ``listOf<Any?>(``.  Naming
            # ``Array<Long>`` for one would annotate a type the literal
            # is not, so defer to the generic value type instead.
            if _kotlin_type_to_opener(element_type=inner) is None:
                return None
            scalar = scalar_resolver(inner)
            return _kotlin_array_type(element_name=scalar)


@beartype
def _format_kotlin_datetime_epoch(value: dt.datetime, /) -> str:
    """Format epoch seconds as a Kotlin ``Long`` literal."""
    return f"{format_datetime_epoch(value=value)}L"


@beartype
def _kotlin_dict_value_type_name(
    element_type: type | ListType | DictType,
    *,
    base_resolver: Callable[[type | ListType | DictType], str | None],
    list_resolver: Callable[[ListType], str | None],
    key_type: str,
    fallback: str,
) -> str | None:
    """Resolve a dict value's Kotlin type name to match the renderer.

    Narrows only ``DictType`` values, to ``Map<key, ...>`` recursively
    (``Map`` is covariant in its value type, so a narrower rendered map
    is still accepted), and defers every other element type to
    *base_resolver*, which keeps the prior ``Array``/``Any?`` list
    typing.  See :meth:`Kotlin._kotlin_dict_value_type` for why list
    values are left to *base_resolver* rather than narrowed (#2890).
    """
    if isinstance(element_type, ListType):
        return list_resolver(element_type)
    if not isinstance(element_type, DictType):
        return base_resolver(element_type)
    value_type = element_type.value_type
    if value_type is None:
        return f"Map<{key_type}, {fallback}>"
    inner = _kotlin_dict_value_type_name(
        element_type=value_type,
        base_resolver=base_resolver,
        list_resolver=list_resolver,
        key_type=key_type,
        fallback=fallback,
    )
    effective_inner = fallback
    if inner is not None:
        effective_inner = inner
    return f"Map<{key_type}, {effective_inner}>"


_KOTLIN_I32_MIN = -(2**31)
_KOTLIN_I32_MAX = 2**31 - 1


@beartype
def _format_kotlin_typed_declaration(
    *,
    name: str,
    value: str,
    data: Value,
    _modifiers: frozenset[enum.Enum],
    keyword: str,
    type_hint: Callable[[Value], str],
) -> str:
    """Format a declaration using the language's retained type
    decisions.
    """
    return f"{keyword} {name}: {type_hint(data)} = {value}"


@beartype
@dataclasses.dataclass(frozen=True)
class _KotlinDictSpec:
    """Per-format dict config pieces resolved at init time."""

    opener_template: str
    declared_type_template: str


@beartype
def _kotlin_call_stub(
    parts: Sequence[str],
    params: Sequence[str],
    _stub_return: StubReturn,
    _args: Sequence[Value],
    /,
) -> tuple[str, ...]:
    """Return Kotlin stub declarations for a call name."""
    # Return the supplied arguments as a placeholder result, using every
    # parameter without suppressing warnings. Explicit type arguments select
    # the standard collection function even when the stub is named listOf.
    param_list = ", ".join(f"{p}: Any? = null" for p in params)
    result = f"listOf<Any?>({', '.join(params)})"
    if len(parts) == 1:
        return (f"fun {parts[0]}({param_list}): Any? = {result}",)
    root = parts[0]
    method = parts[-1]
    fields = parts[1:-1]
    if len(fields) == 0:
        cls = f"_{root.title()}Type"
        return (
            f"class {cls} {{ fun {method}({param_list}): Any? = {result} }}",
            f"val {root} = {cls}()",
        )
    lines: list[str] = []
    inner_cls = f"_{fields[-1].title()}Type"
    lines.append(
        f"class {inner_cls} {{ fun {method}({param_list}): Any? = {result} }}"
    )
    prev_cls = inner_cls
    for i in range(len(fields) - 2, -1, -1):
        cls = f"_{fields[i].title()}Type"
        lines.append(f"class {cls} {{ val {fields[i + 1]} = {prev_cls}() }}")
        prev_cls = cls
    root_cls = f"_{root.title()}Type"
    lines.append(f"class {root_cls} {{ val {fields[0]} = {prev_cls}() }}")
    lines.append(f"val {root} = {root_cls}()")
    return tuple(lines)


@beartype
def _kotlin_record_field_identifier(
    key: str, /, *, reserved_identifiers: frozenset[str]
) -> str:
    """Return the Kotlin record field name for a dict *key*.

    Kotlin allows ordinary identifiers verbatim and reserved words when
    enclosed in backticks.  A name written only of underscores is
    reserved as well, and backticks carry it too (issue #4505).
    """
    if key in reserved_identifiers or set(key) == {"_"}:
        return f"`{key}`"
    return key


@beartype
def _kotlin_render_declaration(
    name: str,
    fields: Sequence[RecordDeclarationField],
    /,
) -> str:
    """Render a Kotlin ``data class Name(val f: T, ...)`` declaration."""
    params = ", ".join(
        f"val {field.identifier}: {field.type_name}" for field in fields
    )
    return f"data class {name}({params})"


@beartype
def _kotlin_record_literal(
    name: str,
    fields: Sequence[RecordLiteralField],
    /,
) -> RenderedRecordLiteral:
    """Render a Kotlin ``Name(field = value, ...)`` literal as
    structured pieces for the shared compact/multiline layout code.
    """
    return RenderedRecordLiteral(
        head=TypedCollectionOpen(f"{name}(", declared_type=name),
        entries=tuple(
            f"{field.identifier} = {field.formatted}" for field in fields
        ),
        closer=")",
        compact_pad="",
    )


@beartype
@dataclasses.dataclass
class _KotlinWidenedMapNarrowing:
    """Per-pass cache of the widened fallback maps' narrow value type.

    ``value_type`` holds the single concrete Kotlin type shared by
    every scalar inside the maps the ``RECORD`` strategy widened out of
    the record-shape mapping, or ``None`` when those scalars mix Kotlin
    types and the ``Map<String, Any?>`` top type is required (issue
    #3608).  Refreshed by the strategy's ``compute_wrap_ids`` hook,
    which the shared data checks run before any rendering; the
    widened-map opener and the record field-type hook read the cached
    decision within the same pass.
    """

    value_type: str | None


@beartype
def _kotlin_tuple_literal(
    value: list[Value],
    elements: Sequence[str],
    /,
    *,
    declared_type: Callable[[list[Value]], str],
) -> RenderedTupleLiteral:
    """Render a heterogeneous scalar array as a Kotlin two-element
    ``Pair(...)`` or three-element ``Triple(...)`` literal as
    structured pieces for the shared compact/multiline layout code.

    :func:`~literalizer._formatters.tuple_strategy.build_tuple_strategy`
    validates the length at check time (Kotlin has no fixed-size tuple
    of any other length), so *value* is always length 2 or 3 here; it
    selects the constructor and is otherwise unused because every
    element arrives already formatted.
    """
    head = {2: "Pair(", 3: "Triple("}[len(value)]
    return RenderedTupleLiteral(
        head=TypedCollectionOpen(head, declared_type=declared_type(value)),
        entries=tuple(elements),
        closer=")",
        compact_pad="",
        # ``Pair(a,\n    b,\n)`` is valid Kotlin -- a trailing comma is
        # allowed in an argument list -- so keep the language-wide
        # trailing-comma policy for the multiline form.
        multiline_trailing_comma=True,
    )


@beartype
def _kotlin_tuple_arity_representable(arity: int, /) -> bool:
    """Return whether Kotlin has a native fixed-size tuple of the
    given element count.

    Kotlin only ships ``Pair`` (two elements) and ``Triple`` (three
    elements); any other length has no typed tuple, so the ``TUPLE``
    strategy raises rather than dropping the per-position types.
    """
    return arity in {2, 3}


_KOTLINX_JSON_ELEMENT_PREAMBLE: tuple[str, ...] = (
    "import kotlinx.serialization.json.Json",
    "import kotlinx.serialization.json.JsonElement",
)


# Sequence/dict format definitions used while ``json_type`` is active.
# The framework still walks the data to compute a formatted ``value``,
# but that string is discarded by
# :func:`_make_format_kotlin_json_declaration` and friends in favor of a
# fresh ``json.dumps`` of the raw data.  These definitions only need to
# be permissive enough that the formatting pass does not error on
# heterogeneous data or nulls inside containers.
_JSON_NODE_SEQUENCE_CONFIG = SequenceFormatConfig(
    length_is_part_of_type=False,
    sequence_open=fixed_open(open_str="["),
    close="]",
    supports_heterogeneity=True,
    single_element_trailing_comma=False,
    single_element_template=None,
    supports_trailing_comma=True,
    empty_sequence="[]",
    preamble_lines=(),
    format_entry=passthrough_sequence_entry,
    typed_opener_fallback=None,
    uses_typed_literal_for_scalars=False,
    requires_uniform_record_shapes=False,
    declared_type=None,
    narrowed_empty_form=None,
)

_JSON_NODE_SET_CONFIG = SetFormatConfig(
    set_open=fixed_open(open_str="["),
    close="]",
    empty_set="[]",
    preamble_lines=(),
    set_opener_template="",
    supports_heterogeneity=True,
    supports_trailing_comma=True,
)

_JSON_NODE_DICT_CONFIG = DictFormatConfig(
    dict_open=fixed_open(open_str="{"),
    close="}",
    format_entry=dict_entry_with_template(
        template="{key}: {value}",
        format_value=passthrough_sequence_entry,
    ),
    empty_dict="{}",
    preamble_lines=(),
    narrowed_open=None,
    supports_trailing_comma=True,
    narrowed_empty_form=None,
)

_JSON_NODE_ORDERED_MAP_CONFIG = OrderedMapFormatConfig(
    ordered_map_open=fixed_open(open_str="{"),
    close="}",
    preamble_lines=(),
)


@beartype
def _kotlin_temporal_to_iso(data: dt.date | dt.time) -> str:
    """Return ISO-8601 text for a date / datetime / time value."""
    return data.isoformat()


@beartype
def _kotlin_to_jsonable(data: Value) -> JsonValue:
    """Convert *data* into a value :func:`json.dumps` can serialize.

    Dates, datetimes, and times become ISO-8601 strings (JSON has no
    temporal type).  Bytes become a hex-encoded string.  Sets and
    :class:`OrderedMap` are folded into list/dict respectively.  Non-
    string dict keys are not handled here; the caller validates first.
    """
    match data:
        case dt.datetime() | dt.date() | dt.time():
            return _kotlin_temporal_to_iso(data=data)
        case bytes():
            return data.hex()
        case OrderedMap() | dict():
            return {
                key: _kotlin_to_jsonable(data=value)
                for key, value in data.items()
            }
        case set():
            items = [_kotlin_to_jsonable(data=item) for item in data]
            items.sort(key=repr)
            return items
        case list():
            return [_kotlin_to_jsonable(data=item) for item in data]
        case _:
            return data


@beartype
def _format_kotlin_json_value(data: Value) -> str:
    """Serialize *data* as a single-line JSON expression."""
    return json.dumps(
        obj=_kotlin_to_jsonable(data=data),
        ensure_ascii=False,
    )


@beartype
def _kotlin_parse_to_json_element_expression(data: Value) -> str:
    """Render ``Json.parseToJsonElement("...")`` for *data*."""
    json_text = _format_kotlin_json_value(data=data)
    kotlin_literal = _format_string_backslash_dollar_nul(value=json_text)
    return f"Json.parseToJsonElement({kotlin_literal})"


@beartype
def _make_format_kotlin_json_declaration(
    *,
    keyword: str,
) -> Callable[[str, str, Value, frozenset[enum.Enum]], str]:
    """Build a JsonElement declaration formatter for ``val`` or ``var``.

    The keyword tracks ``declaration_style`` so the combined
    declaration + assignment form stays valid Kotlin (``var`` lets the
    later assignment rebind the variable).
    """

    @beartype
    def _format(
        name: str,
        _value: str,
        data: Value,
        _modifiers: frozenset[enum.Enum],
    ) -> str:
        """Format the declaration with the bound *keyword*."""
        expression = _kotlin_parse_to_json_element_expression(data=data)
        return f"{keyword} {name}: JsonElement = {expression}"

    return _format


@beartype
def _format_kotlin_json_assignment(
    name: str,
    _value: str,
    data: Value,
) -> str:
    """Format a JsonElement assignment backed by
    ``parseToJsonElement``.
    """
    return f"{name} = {_kotlin_parse_to_json_element_expression(data=data)}"


@beartype
def _format_kotlin_json_call_arg(raw_value: Value, _formatted: str) -> str:
    """Format a direct call argument as a JsonElement literal."""
    return _kotlin_parse_to_json_element_expression(data=raw_value)


# Work around https://github.com/astral-sh/ty/issues/4573.
if TYPE_CHECKING:
    _BytesEnumMember = enum.member[Callable[[bytes], str]]
    _StringEnumMember = enum.member[Callable[[str], str]]
else:
    _BytesEnumMember = enum.member
    _StringEnumMember = enum.member


@beartype
@dataclasses.dataclass(frozen=True, kw_only=True)
class Kotlin(metaclass=LanguageCls):
    """Kotlin language specification.

    Args:
        date_format: How to format :class:`datetime.date` values.

            * ``date_formats.KOTLIN`` — ``LocalDate.of(...)`` call,
              e.g. ``LocalDate.of(2024, 1, 15)``.
            * ``date_formats.ISO`` — ISO 8601 quoted string,
              e.g. ``"2024-01-15"``.

        datetime_format: How to format :class:`datetime.datetime` values.

            * ``datetime_formats.KOTLIN`` — ``LocalDateTime.of(...)`` call,
              e.g. ``LocalDateTime.of(2024, 1, 15, 12, 30, 0)``.
            * ``datetime_formats.ISO`` — ISO 8601 quoted string,
              e.g. ``"2024-01-15T12:30:00"``.

        sequence_format: Which Kotlin sequence type to use.

            * ``sequence_formats.LIST`` — typed array calls
              (e.g. ``intArrayOf(1, 2, 3)``).  Heterogeneous
              sequences fall back to ``listOf<Any?>(…)``.
            * ``sequence_formats.TUPLE`` — ``Pair(…)`` for two-element
              sequences, ``Triple(…)`` for three-element sequences,
              e.g. ``Pair("a", 1)``.  Other sizes fall back to
              ``listOf<Any?>(…)``.

        json_type: When set to ``json_types.KOTLINX_JSON_ELEMENT``,
            render values through ``Json.parseToJsonElement(...)`` so
            the output produces a ``kotlinx.serialization.json.JsonElement``
            instead of Kotlin's narrow ``List`` / ``Map`` / array types.
    """

    format_call_class_scope_stub = default_format_call_stub

    reserved_module_identifiers: ClassVar[frozenset[str]] = frozenset()
    immutable_variable_modifiers: ClassVar[frozenset[enum.Enum]] = frozenset()
    wrap_in_file_tolerates_pre_indent = True
    module_name_shares_variable_scope = False
    reserved_call_parameter_identifiers: ClassVar[frozenset[str]] = frozenset()
    reserved_call_parameter_identifier_pattern: ClassVar[
        re.Pattern[str] | None
    ] = None
    accepts_type_name_call_target = True
    declares_type_name_call_target = True
    dotted_call_root_shares_entrypoint_namespace = True
    reserved_bare_call_target_identifiers: ClassVar[frozenset[str]] = (
        frozenset()
    )
    reserved_call_target_head_identifiers: ClassVar[frozenset[str]] = (
        frozenset()
    )
    contextual_call_target_identifiers: ClassVar[frozenset[str]] = frozenset()
    call_parameter_shadowing = CallParameterShadowing.ALLOWED
    reserved_call_target_keywords_case_sensitive = True
    module_name_must_start_uppercase = False
    new_variable_name_syntax = NewVariableNameSyntax.ASCII
    max_variable_identifier_length: ClassVar[int | None] = None
    call_stub_result: ClassVar[CallStubResult | None] = None
    call_literal_syntax: ClassVar[None] = None
    call_target_name_syntax: ClassVar[NewVariableNameSyntax | None] = None
    supports_multiline_dict_layout = True
    pools_map_integer_width = True

    format_call_variable_assignment = default_format_call_variable_assignment
    format_constructor_target: ClassVar["staticmethod[[str], str]"] = (
        staticmethod(identity_constructor_target)
    )
    sequence_binding_declarations = default_sequence_binding_declarations
    format_call_binding_body_preamble = no_call_binding_body_preamble
    format_call_binding_file_pragmas = no_call_binding_file_pragmas

    leading_preamble = no_leading_preamble
    extension = ".kts"
    pygments_name = "kotlin"
    stringifies_nested_collections = False
    supports_special_floats = True
    supports_variable_names = True
    supports_no_variable_wrap_in_file = False
    wraps_data_dependent_preamble_in_body = False
    dict_supports_heterogeneous_values = True
    supports_native_invocations = False
    supports_dotted_calls = True
    has_free_function_calls = True
    declares_call_parameter_names = True
    reserved_variable_identifiers_case_sensitive: bool = True
    reserved_variable_identifier_pattern: ClassVar[re.Pattern[str]] = (
        _KOTLIN_ALL_UNDERSCORES
    )
    reserved_variable_identifiers: frozenset[str] = frozenset(
        {
            "Any",
            "Array",
            "Boolean",
            "Double",
            "HashMap",
            "Int",
            "LinkedHashMap",
            "List",
            "Long",
            "Map",
            "MutableSet",
            "Set",
            "String",
            "as",
            "break",
            "class",
            "continue",
            "do",
            "else",
            "false",
            "for",
            "fun",
            "if",
            "in",
            "interface",
            "is",
            "null",
            "object",
            "package",
            "return",
            "super",
            "this",
            "throw",
            "true",
            "try",
            "typealias",
            "typeof",
            "val",
            "var",
            "when",
            "while",
        }
    )
    reserved_identifiers: ClassVar[frozenset[str]] = (
        reserved_variable_identifiers
        - (
            frozenset(
                {
                    "Any",
                    "Array",
                    "Boolean",
                    "Double",
                    "HashMap",
                    "Int",
                    "LinkedHashMap",
                    "List",
                    "Long",
                    "Map",
                    "MutableSet",
                    "Set",
                    "String",
                }
            )
        )
    )
    allows_empty_call_parens = True
    supports_dotted_call_stub = True
    dotted_call_stub_requires_unique_parts = True
    dotted_call_stub_normalizes_part_case = True
    call_returns_expression = True
    supports_json_call_result_binding = False
    supports_zero_parameter_calls = True
    max_call_parameters = NO_CALL_PARAMETER_LIMIT
    supports_inline_multiline_dict_args = True
    supports_standalone_comments_in_wrapped_calls = True
    supports_multi_param_call_wrapper_stub = True
    supports_dict_literal_as_free_expression = True
    supports_module_name = False
    supports_empty_dict_key = False
    supports_call_style = True
    supports_default_dict_key_type = True
    supports_default_dict_value_type = True
    supports_default_sequence_element_type = False
    supports_default_set_element_type = True
    supports_default_ordered_map_value_type = False
    json_type_variant_name_suffix: ClassVar[str | None] = None
    supports_non_ascii_string_literals = True
    supports_multiline_string_literals = True
    supports_empty_sibling_sequence_type_hints = False
    supports_typed_dict_open = True
    language_id: ClassVar[str] = "kotlin"
    variant_metadata: ClassVar[VariantMetadata] = VariantMetadata(
        round_trip_capabilities=frozenset(
            {
                RoundTripCapability.I64_BOUNDARIES,
                RoundTripCapability.INTERPOLATION_STRINGS,
                RoundTripCapability.EMBEDDED_NUL,
            }
        ),
        modifier_sequence_format_overrides={},
        string_literals_escape_null_byte=True,
        supports_ref_elements_in_tuple_strategy=False,
    )
    supports_record_struct_name_prefix = True
    supports_record_shape_names = True
    record_shape_names_emit_declarations = True
    supports_non_string_dict_keys = False
    checks_raw_control_dict_keys_separately = False

    _opener_config = TypedOpenerConfig(
        str_type="String",
        bool_type="Boolean",
        int_type="Int",
        wide_int_type="Long",
        beyond_i64_type="BigInteger",
        float_type="Double",
        bytes_type="String",
        mixed_numeric_type=None,
        date_type="LocalDate",
        datetime_type="LocalDateTime",
        time_type="LocalTime",
        list_template="Array<{inner}>",
        sequence_opener_template="arrayOf(",
        dict_opener_template="mapOf<{key_type}, {type_name}>(",
        set_opener_template="setOf<{type_name}>(",
        dict_type_template="Map<{key_type}, {inner}>",
        fallback_value_type="Any?",
    )

    class DateFormats(DateFormatEnum):
        """Date format options for Kotlin."""

        KOTLIN = DateFormatConfig(
            formatter=date_ymd_formatter(
                template="LocalDate.of({year}, {month}, {day})",
            ),
            preamble_lines=("import java.time.LocalDate",),
            type_produced=dt.date,
        )
        ISO = DateFormatConfig(
            formatter=format_date_iso, type_produced=str, preamble_lines=()
        )

    class DatetimeFormats(DatetimeFormatEnum):
        """Datetime format options for Kotlin."""

        KOTLIN = DatetimeFormatConfig(
            formatter=datetime_ymdhms_formatter(
                template="LocalDateTime.of({year}, {month}, {day}, "
                "{hour}, {minute}, {second})",
                millisecond_template=None,
            ),
            preamble_lines=("import java.time.LocalDateTime",),
            type_produced=dt.datetime,
        )
        ISO = DatetimeFormatConfig(
            formatter=format_datetime_iso,
            type_produced=str,
            preamble_lines=(),
        )

        EPOCH = DatetimeFormatConfig(
            formatter=_format_kotlin_datetime_epoch,
            type_produced=int,
            preamble_lines=(),
        )

    class BytesFormats(FormatValueMixin[Callable[[bytes], str]], enum.Enum):
        """Bytes formatting options."""

        HEX = _BytesEnumMember(value=format_bytes_hex)
        BASE64 = _BytesEnumMember(value=format_bytes_base64)

        def __call__(self, data: bytes, /) -> str:
            """Format bytes."""
            return self.value(data)

    class SequenceFormats(enum.Enum):
        """Sequence type options for Kotlin."""

        LIST = SequenceFormatConfig(
            length_is_part_of_type=False,
            sequence_open=typed_collection_open(
                type_to_opener=_kotlin_type_to_opener,
                fallback="listOf<Any?>(",
            ),
            close=")",
            supports_heterogeneity=True,
            single_element_trailing_comma=False,
            single_element_template=None,
            supports_trailing_comma=True,
            empty_sequence=None,
            preamble_lines=(),
            format_entry=passthrough_sequence_entry,
            typed_opener_fallback="listOf<Any?>(",
            uses_typed_literal_for_scalars=False,
            requires_uniform_record_shapes=False,
            declared_type=None,
            narrowed_empty_form=None,
        )
        ARRAY = SequenceFormatConfig(
            length_is_part_of_type=False,
            sequence_open=fixed_open(open_str="arrayOf<Any?>("),
            close=")",
            supports_heterogeneity=True,
            single_element_trailing_comma=False,
            single_element_template=None,
            supports_trailing_comma=True,
            empty_sequence=None,
            preamble_lines=(),
            format_entry=passthrough_sequence_entry,
            typed_opener_fallback=None,
            uses_typed_literal_for_scalars=False,
            requires_uniform_record_shapes=False,
            declared_type=None,
            narrowed_empty_form=None,
        )
        TUPLE = SequenceFormatConfig(
            length_is_part_of_type=False,
            sequence_open=fixed_open(open_str="listOf<Any?>("),
            format_entry=passthrough_sequence_entry,
            typed_opener_fallback=None,
            uses_typed_literal_for_scalars=False,
            requires_uniform_record_shapes=False,
            close=")",
            supports_heterogeneity=True,
            single_element_trailing_comma=False,
            single_element_template=None,
            supports_trailing_comma=True,
            empty_sequence=None,
            preamble_lines=(),
            declared_type=None,
            narrowed_empty_form=None,
        )

    class SetFormats(
        FormatValueMixin[Callable[[str], SetFormatConfig]], enum.Enum
    ):
        """Set type options for Kotlin."""

        SET = enum.member(
            value=set_format_factory(
                open_template="setOf<{type}>(",
                close=")",
                empty_template=None,
                preamble_lines=(),
                set_opener_template="",
                supports_heterogeneity=True,
                supports_trailing_comma=True,
            )
        )
        SORTED_SET = enum.member(
            value=set_format_factory(
                open_template="sortedSetOf<{type}>(",
                close=")",
                empty_template=None,
                preamble_lines=(),
                set_opener_template="sortedSetOf<{type_name}>(",
                supports_heterogeneity=False,
                supports_trailing_comma=True,
            )
        )

        def __call__(self, default_type: str) -> SetFormatConfig:
            """Create a set format config for the given type."""
            return self.value(default_type)

    class CommentFormats(enum.Enum):
        """Comment style options."""

        DOUBLE_SLASH = CommentConfig(
            prefix="//",
            suffix="",
        )
        BLOCK = CommentConfig(
            prefix="/*",
            suffix=NestingCommentSuffix(object=" */"),
        )

    class DeclarationStyles(enum.Enum):
        """Declaration style options."""

        VAL = DeclarationStyleConfig(
            formatter=variable_declaration_formatter(
                template="val {name} = {value}"
            ),
            supports_redefinition=False,
        )
        VAR = DeclarationStyleConfig(
            formatter=variable_declaration_formatter(
                template="var {name} = {value}"
            ),
            supports_redefinition=True,
        )

    class DictEntryStyles(enum.Enum):
        """Dict entry style options."""

        DEFAULT = enum.auto()

    class DictFormats(enum.Enum):
        """Dict/map format options."""

        MAP = _KotlinDictSpec(
            opener_template="mapOf<{key_type}, {type_name}>(",
            declared_type_template="Map<{key_type}, {type_name}>",
        )
        HASH_MAP = _KotlinDictSpec(
            opener_template="hashMapOf<{key_type}, {type_name}>(",
            declared_type_template="HashMap<{key_type}, {type_name}>",
        )

    class EmptyDictKey(enum.Enum):
        """Empty dict key options."""

        ALLOW = enum.auto()

    class FloatFormats(
        FloatSpecialsMixin,
        enum.Enum,
        positive_infinity="Double.POSITIVE_INFINITY",
        negative_infinity="Double.NEGATIVE_INFINITY",
        nan="Double.NaN",
    ):
        """Float format options."""

        REPR = enum.member(value=format_float_repr)
        SCIENTIFIC = enum.member(value=format_float_scientific)
        FIXED = enum.member(value=format_float_fixed)

    class IntegerFormats(enum.Enum):
        """Integer format options."""

        DECIMAL = MappingProxyType(
            mapping={
                "NONE": str,
                "UNDERSCORE": format_integer_underscore,
            }
        )
        HEX = MappingProxyType(
            mapping={
                "NONE": format_integer_hex,
                "UNDERSCORE": format_integer_hex,
            }
        )
        BINARY = MappingProxyType(
            mapping={
                "NONE": format_integer_binary,
                "UNDERSCORE": format_integer_binary,
            }
        )

        def get_formatter(
            self,
            numeric_separator: enum.Enum,
        ) -> Callable[[int], str]:
            """Return the integer formatter for the given separator."""
            formatter: Callable[[int], str] = self.value[
                numeric_separator.name
            ]
            return formatter

    class NumericLiteralSuffixes(enum.Enum):
        """Numeric literal suffix options."""

        NONE = enum.auto()

    class NumericSeparators(enum.Enum):
        """Numeric separator options."""

        NONE = enum.auto()
        UNDERSCORE = enum.auto()

    class NumericStyles(enum.Enum):
        """Numeric literal style options."""

        OVERLOADED = enum.auto()

    class StringFormats(FormatValueMixin[Callable[[str], str]], enum.Enum):
        """String format options."""

        DOUBLE = enum.member(value=_format_string_backslash_dollar_nul)
        MULTILINE = _StringEnumMember(value=_format_string_multiline)

        def __call__(self, value: str, /) -> str:
            """Format a string."""
            return self.value(value)

    class TrailingCommas(enum.Enum):
        """Trailing comma options."""

        YES = TrailingCommaConfig(multiline_trailing_comma=True)
        NO = TrailingCommaConfig(multiline_trailing_comma=False)

    date_formats = DateFormats
    datetime_formats = DatetimeFormats
    bytes_formats = BytesFormats
    sequence_formats = SequenceFormats
    set_formats = SetFormats
    comment_formats = CommentFormats

    class VariableTypeHints(enum.Enum):
        """Variable type hint options."""

        NEVER = enum.auto()
        ALWAYS = enum.auto()
        SAFE = enum.auto()

        def formatter(
            self,
            *,
            auto_formatter: Callable[
                [str, str, Value, frozenset[enum.Enum]], str
            ],
            keyword: str,
            type_hint: Callable[[Value], str],
        ) -> Callable[[str, str, Value, frozenset[enum.Enum]], str]:
            """Return the variable declaration formatter."""
            if self in {type(self).NEVER, type(self).SAFE}:
                return auto_formatter

            @beartype
            def _typed_formatter(
                name: str,
                value: str,
                data: Value,
                modifiers: frozenset[enum.Enum],
            ) -> str:
                """Adapt :func:`_format_kotlin_typed_declaration` to the
                positional formatter interface.
                """
                return _format_kotlin_typed_declaration(
                    name=name,
                    value=value,
                    data=data,
                    _modifiers=modifiers,
                    keyword=keyword,
                    type_hint=type_hint,
                )

            return _typed_formatter

    variable_type_hints_formats = VariableTypeHints
    declaration_styles = DeclarationStyles
    dict_entry_styles = DictEntryStyles
    dict_formats = DictFormats
    empty_dict_keys = EmptyDictKey
    float_formats = FloatFormats
    integer_formats = IntegerFormats
    integer_width_strategies = BareIntegerWidthStrategies
    numeric_literal_suffixes = NumericLiteralSuffixes
    numeric_separators = NumericSeparators
    numeric_styles = NumericStyles
    string_formats = StringFormats
    trailing_commas = TrailingCommas

    class StatementTerminatorStyles(enum.Enum):
        """Statement terminator options."""

        SEMICOLON = enum.auto()

    statement_terminator_styles = StatementTerminatorStyles

    class CallStyles(enum.Enum):
        """Kotlin call style options."""

        KEYWORD = KeywordCallStyle(separator=" = ")
        POSITIONAL = PositionalCallStyle(
            arg_separator=", ", parenthesize_each_arg=False
        )

    call_styles = CallStyles

    class Modifiers(enum.Enum):
        """C++/Java/C#-style declaration modifiers: this language has none."""

    modifiers = Modifiers

    class HeterogeneousStrategies(enum.Enum):
        """Strategy for dicts whose values span more than one Kotlin
        type.

        ``ERROR`` keeps Kotlin's strict-typing behavior (mixed-value
        dicts that cannot be represented raise).  ``RECORD`` renders
        each record-shaped dict (non-empty, string-keyed) as a generated
        ``data class`` declared in the preamble plus a matching
        constructor-call literal, so fields may legitimately mix scalars
        and containers.  ``TUPLE`` composes ``RECORD`` and additionally
        renders a fixed-length heterogeneous scalar array that is a
        dict value or the document root as a two-element ``Pair(...)``
        or three-element ``Triple(...)`` typed ``Pair<...>`` /
        ``Triple<...>`` -- a record field whose value is such an array
        becomes a tuple-typed field.  Kotlin has no general N-tuple, so
        an array of any other length raises
        :class:`~literalizer.exceptions.TupleArityNotRepresentableError`
        rather than degrading to a homogeneous list.
        """

        ERROR = enum.auto()
        RECORD = enum.auto()
        TUPLE = enum.auto()

    heterogeneous_strategies = HeterogeneousStrategies

    class BoolFormats(enum.Enum):
        """Empty: this language has no alternative boolean formats."""

    bool_formats = BoolFormats

    class JsonTypes(JsonType):
        """JSON value type options for Kotlin."""

        KOTLINX_JSON_ELEMENT = "kotlinx.serialization.json.JsonElement"
        """Dynamic JSON value type from ``kotlinx.serialization.json``."""

    json_types = JsonTypes

    class VersionFormats(enum.Enum):
        """Version options for Kotlin."""

        V2_4 = enum.auto()

    version_formats = VersionFormats

    modifier_combinations: ClassVar[tuple[ModifierCombination, ...]] = ()
    identifier_cases: ClassVar[tuple[IdentifierCase, ...]] = (
        IdentifierCase.CAMEL,
        IdentifierCase.PASCAL,
        IdentifierCase.UPPER_SNAKE,
    )
    uses_resolved_ref_declaration_data = True

    supported_ref_cases: ClassVar[frozenset[IdentifierCase]] = (
        NON_KEBAB_REF_CASES
    )

    validate_call_arg = default_validate_call_arg

    format_call_statement = default_format_call_statement

    wrap_calls_with_declarations = default_wrap_calls_with_declarations

    wrap_in_file: ClassVar["staticmethod[[str, FileWrapperContext], str]"] = (
        wrap_in_file_noop_static
    )

    wrap_combined_in_file: ClassVar[
        "staticmethod[[str, str, FileWrapperContext], str]"
    ] = wrap_combined_in_file_noop_static

    date_format: DateFormats = DateFormats.KOTLIN
    datetime_format: DatetimeFormats = DatetimeFormats.KOTLIN
    bytes_format: BytesFormats = BytesFormats.HEX
    sequence_format: SequenceFormats = SequenceFormats.LIST
    set_format: SetFormats = SetFormats.SET
    default_set_element_type: str = "Any?"
    default_dict_key_type: str = "String"
    default_dict_value_type: str = "Any?"
    variable_type_hints: VariableTypeHints = VariableTypeHints.NEVER
    comment_format: CommentFormats = CommentFormats.DOUBLE_SLASH
    declaration_style: DeclarationStyles = DeclarationStyles.VAL
    dict_entry_style: DictEntryStyles = DictEntryStyles.DEFAULT
    dict_format: DictFormats = DictFormats.MAP
    float_format: FloatFormats = FloatFormats.REPR
    integer_format: IntegerFormats = IntegerFormats.DECIMAL
    integer_width_strategy: BareIntegerWidthStrategies = (
        BareIntegerWidthStrategies.BARE
    )
    numeric_literal_suffix: NumericLiteralSuffixes = (
        NumericLiteralSuffixes.NONE
    )
    numeric_separator: NumericSeparators = NumericSeparators.NONE
    numeric_style: NumericStyles = NumericStyles.OVERLOADED
    string_format: StringFormats = StringFormats.DOUBLE
    trailing_comma: TrailingCommas = TrailingCommas.YES
    statement_terminator_style: StatementTerminatorStyles = (
        StatementTerminatorStyles.SEMICOLON
    )
    call_style: CallStyles = CallStyles.KEYWORD
    heterogeneous_strategy: HeterogeneousStrategies = (
        HeterogeneousStrategies.ERROR
    )
    json_type: JsonTypes | None = None
    record_struct_name_prefix: str = "Record"
    record_shape_names: Mapping[frozenset[str], str] = dataclasses.field(
        default_factory=empty_record_shape_names,
        hash=False,
    )
    # Keep in sync with the version flags passed to the Kotlin lint host in
    # `scripts/lint-kotlin.kts`.
    language_version: VersionFormats = VersionFormats.V2_4
    indent: str = "    "
    skip_null_dict_values: bool = False

    null_literal: ClassVar[str] = "null"
    true_literal: ClassVar[str] = "true"
    false_literal: ClassVar[str] = "false"
    indent_closing_delimiter: ClassVar[bool] = False
    element_separator: ClassVar[str] = ", "
    supports_scalar_inline_comments: ClassVar[bool] = True
    statement_terminator: ClassVar[str] = ""
    static_body_preamble: ClassVar[Sequence[str]] = ()
    special_float_preamble: ClassVar[tuple[str, ...]] = ()

    def __post_init__(self) -> None:
        """Validate ``record_shape_names`` after construction."""
        self._validate_record_naming()
        self._validate_json_type_spec()

    @cached_property
    @beartype
    def supports_scalar_before_comments(self) -> bool:
        """Whether a comment can sit above the rendered value.

        Under :attr:`json_type` the declaration is built from the
        document rather than from the formatted value, so a comment
        written into that value never reaches the output; it goes
        above the declaration instead (issue #4546).
        """
        return not self._json_type_active

    @cached_property
    @beartype
    def supports_collection_comments(self) -> bool:
        """Whether a comment can sit inside the rendered value.

        ``Json.parseToJsonElement`` is handed one JSON document, and
        JSON has no comments, so a comment written inside it would
        be text the parser refuses.  The comments go before the
        declaration instead (issue #4546).
        """
        return not self._json_type_active

    @cached_property
    @beartype
    def _json_type_active(self) -> bool:
        """Return whether Kotlin should render via ``JsonElement``."""
        return self.json_type is not None

    @cached_property
    @beartype
    def static_preamble(self) -> Sequence[str]:
        """Static preamble lines emitted once per file.

        When :attr:`json_type` is active the ``Json`` and ``JsonElement``
        imports are emitted here so every fixture has them in scope
        regardless of the rendered data.
        """
        if self._json_type_active:
            return _KOTLINX_JSON_ELEMENT_PREAMBLE
        return ()

    @cached_property
    @beartype
    def format_call_arg(self) -> Callable[[Value, str], str]:
        """Callable that rewrites a formatted direct call argument."""
        if self._json_type_active:
            return _format_kotlin_json_call_arg
        return identity_call_arg

    def _validate_json_type_spec(self) -> None:
        """Reject ``json_type`` combinations the generator cannot emit.

        ``Json.parseToJsonElement(...)`` produces a single
        ``JsonElement`` value; a ``RECORD`` or ``TUPLE`` heterogeneous
        strategy would generate ``data class`` declarations and
        ``Pair``/``Triple`` literals that have no place inside that
        single JSON value, so both are rejected up front.
        """
        if not self._json_type_active:
            return
        cls = type(self.heterogeneous_strategy)
        if self.heterogeneous_strategy is not cls.ERROR:
            msg = (
                "Kotlin json_type renders data through "
                "Json.parseToJsonElement(...) and is incompatible with "
                f"heterogeneous_strategy={self.heterogeneous_strategy.name}, "
                "which generates typed declarations. Use "
                "heterogeneous_strategy=ERROR."
            )
            raise IncompatibleFormatsError(msg)

    def _validate_json_value_keys(self, data: Value, /) -> None:
        """Reject non-string object keys for ``JsonElement``."""
        match data:
            case OrderedMap() | dict():
                for key, value in data.items():
                    if not isinstance(key, str):
                        msg = (
                            "Kotlin json_type can only represent dict "
                            "keys as JSON object strings, not "
                            f"{type(key).__name__}"
                        )
                        raise UnrepresentableInputError(msg)
                    self._validate_json_value_keys(value)
            case list() | set():
                for item in data:
                    self._validate_json_value_keys(item)
            case _:
                return

    def validate_spec_for_data(self, data: Value) -> None:
        """Validate the spec against the data.

        When :attr:`json_type` is active, walk *data* to reject non-
        string dict keys, which JSON objects cannot represent.
        """
        if self._json_type_active:
            self._validate_json_value_keys(data)
        if (
            not self._json_type_active
            and self.datetime_format.value.type_produced is dt.datetime
        ):
            reject_aware_datetimes(
                data=data, language_name="Kotlin", allow_utc_offset=False
            )

    def _validate_record_naming(self) -> None:
        """Validate ``record_shape_names`` for PascalCase identifier
        shape, collisions with the auto-generated ``{prefix}{N}``
        struct names, and duplicate target names.

        Ported from
        :meth:`literalizer.languages.Rust._validate_record_naming`.
        Kotlin has no ``heterogeneous_value_enum_name`` so that
        collision check does not apply, and Rust's reserved-keyword
        check is unnecessary here: every Kotlin keyword is lowercase,
        so the PascalCase requirement already rejects every one of
        them.
        """
        prefix = self.record_struct_name_prefix
        auto_name_pattern = re.compile(
            pattern=rf"^{re.escape(pattern=prefix)}\d+$",
        )
        seen_names: set[str] = set()
        for keys, name in self.record_shape_names.items():
            if _PASCAL_CASE_IDENTIFIER.match(string=name) is None:
                msg = (
                    f"record_shape_names entry for keys {sorted(keys)!r} "
                    f"maps to {name!r}, which is not a PascalCase Kotlin "
                    f"identifier."
                )
                raise InvalidRecordNameError(msg)
            if name in _KOTLIN_EMITTED_TYPE_NAMES:
                msg = (
                    f"record_shape_names entry for keys {sorted(keys)!r} "
                    f"maps to {name!r}, which names a type the generated "
                    f"code itself uses."
                )
                raise InvalidRecordNameError(msg)
            if auto_name_pattern.match(string=name) is not None:
                msg = (
                    f"record_shape_names entry for keys {sorted(keys)!r} "
                    f"maps to {name!r}, which collides with the "
                    f"auto-generated {prefix!r}-prefixed struct names."
                )
                raise InvalidRecordNameError(msg)
            if name in seen_names:
                msg = (
                    f"record_shape_names maps multiple key-sets to "
                    f"{name!r}; struct names must be unique."
                )
                raise InvalidRecordNameError(msg)
            seen_names.add(name)

    @cached_property
    @beartype
    def format_string(self) -> Callable[[str], str]:
        """Format a string value as a quoted literal."""
        return self.string_format

    @cached_property
    @beartype
    def format_sequence_entry(self) -> Callable[[Value, str], str]:
        """Format a sequence entry."""
        return passthrough_sequence_entry

    @cached_property
    @beartype
    def format_set_entry(self) -> Callable[[Value, str], str]:
        """Format a set entry."""
        return passthrough_set_entry

    assignment_declares_binding = requires_declared_binding
    reference_assignment_declares_binding = assignment_declares_binding
    call_assignment_declares_binding = False

    @cached_property
    @beartype
    def format_variable_assignment(self) -> Callable[[str, str, Value], str]:
        """Format an assignment to an existing variable."""
        if self._json_type_active:
            return _format_kotlin_json_assignment
        return variable_formatter(template="{name} = {value}")

    @cached_property
    @beartype
    def _kotlin_record_scalar_resolver(
        self,
    ) -> Callable[[type | ListType | DictType], str | None]:
        """Type-only scalar resolver (the mapping the typed openers are
        built on); returns ``None`` for a type it does not cover so
        callers can fall back to the ``Any?`` top type.
        """
        return self._opener_config.element_to_type(
            dict_value_to_type=None,
            list_template=None,
            enable_list_type=False,
            date_type=None,
            datetime_type=None,
            enable_dict_type=False,
            dict_key_type="",
        )

    def _kotlin_record_datetime_type(
        self,
        value: dt.datetime,
        /,
    ) -> str:
        """Kotlin type for a :class:`datetime.datetime` record field.

        A record component must match the literal the formatter emits,
        so it is driven by the chosen datetime format: ``ISO`` renders a
        quoted string (``String``); ``EPOCH`` renders the epoch seconds
        as a bare integer that overflows Kotlin's signed 32-bit ``Int``
        after 2038-01-19, so the component widens to ``Long`` exactly
        when the value leaves that range (the same ``Int``/``Long``
        formula a plain integer field uses); the default ``KOTLIN``
        format renders a ``LocalDateTime.of(...)`` call.  It stays
        value-driven rather than a pure ``cached_property``.
        """
        del value
        produced = self.datetime_format.value.type_produced
        if produced is str:
            return "String"
        if produced is int:
            return "Long"
        return "LocalDateTime"

    def _kotlin_record_field_type(self, request: RecordFieldType, /) -> str:
        """Return the Kotlin ``data class`` field type for a record
        field, derived structurally from the raw value.

        A field whose value is itself a nested record-shaped dict uses
        that record's generated name.  A list or ordered-map field
        derives its type from the very collection opener the value
        formatter uses for that value (a record field is formatted with
        no sibling override, so the opener equals the one emitted),
        resolved by :func:`_kotlin_opener_to_type`.  ``Int`` magnitude
        (``Int`` vs ``Long``) and the format-dependent ``datetime`` type
        are value- and spec-driven, so they are resolved explicitly;
        every other scalar (including ``date`` -> ``LocalDate`` and
        ``bytes`` -> ``String``) goes through the shared type-only
        resolver.

        A record-eligible dict with no ``record_name`` was widened out
        of record inference because its nested sibling maps cannot
        share one shape.  Type that field as ``Map<String, Any?>`` so
        the uniform enclosing record survives (#2914), narrowed to
        ``Map<String, T>`` when every scalar across the widened maps
        shares one concrete Kotlin type ``T`` (issue #3608).  A set or a
        genuinely non-record dict (empty or non-string-keyed) still has
        no precise component type; per the cross-language decision in
        #2317, Kotlin folds it into the ``Any?`` top type.
        """
        if request.record_name is not None:
            return request.record_name
        if request.element_record_name is not None:
            return f"List<{request.element_record_name}>"
        return self._kotlin_value_field_type(request.value)

    @beartype
    def _kotlin_list_field_type(self, *, value: list[Value]) -> str:
        """Read the type selected by the sequence producer."""
        return self._kotlin_sequence_type(value).declared_type

    def _kotlin_value_field_type(
        self,
        value: Value,
        /,
    ) -> str:
        """Resolve the Kotlin field type for a raw (non-nested-record)
        value, descending into an ``arrayOf(`` element type.
        """
        match value:
            case int() if (
                not isinstance(value, bool) and not I64_MIN <= value <= I64_MAX
            ):
                field_type = "BigInteger"
            case int() if not isinstance(value, bool):
                in_i32 = _KOTLIN_I32_MIN <= value <= _KOTLIN_I32_MAX
                field_type = "Long"
                if in_i32:
                    field_type = "Int"
            case dt.datetime():
                field_type = self._kotlin_record_datetime_type(value)
            case OrderedMap():
                field_type = (
                    f"LinkedHashMap<{self.default_dict_key_type}, "
                    f"{self.default_dict_value_type}>"
                )
            case dict() if record_shape_for_dict(value=value) is not None:
                field_type = self._kotlin_derecordized_map_field_type()
            case list():
                field_type = self._kotlin_list_field_type(value=value)
            case _:
                scalar_type = self._kotlin_record_scalar_resolver(type(value))
                field_type = "Any?"
                if scalar_type is not None and scalar_type != "":
                    field_type = scalar_type
        return field_type

    def _kotlin_tuple_field_type(self, elements: list[Value], /) -> str:
        """Return the Kotlin ``Pair``/``Triple`` type for a
        tuple-eligible ``RECORD`` field, one type parameter per
        position.

        The length is validated at check time, so *elements* is length
        2 or 3; each position's type reuses
        :meth:`_kotlin_value_field_type` (the same scalar resolution a
        plain field value uses), so e.g. ``[1, "email"]`` types
        ``Pair<Int, String>``.
        """
        elem_types = [self._kotlin_value_field_type(e) for e in elements]
        constructor = {2: "Pair", 3: "Triple"}[len(elements)]
        return f"{constructor}<{', '.join(elem_types)}>"

    @cached_property
    @beartype
    def _record_renderer(self) -> RecordRenderer:
        """Kotlin syntax hooks for the ``RECORD`` strategy."""
        return RecordRenderer(
            name_prefix=self.record_struct_name_prefix,
            record_shape_names=self.record_shape_names,
            field_identifier=functools.partial(
                _kotlin_record_field_identifier,
                reserved_identifiers=self.reserved_variable_identifiers,
            ),
            field_identifier_key=identity_field_identifier_key,
            field_type=self._kotlin_record_field_type,
            render_declaration=_kotlin_render_declaration,
            render_literal=_kotlin_record_literal,
            field_type_names_nested_records=False,
            suppress_custom_name_declarations=False,
        )

    @cached_property
    @beartype
    def _tuple_renderer(self) -> TupleRenderer:
        """Kotlin syntax hooks for the ``TUPLE`` strategy."""
        return TupleRenderer(
            render_literal=functools.partial(
                _kotlin_tuple_literal,
                declared_type=self._kotlin_tuple_field_type,
            ),
            field_type=self._kotlin_tuple_field_type,
            representable_arity=_kotlin_tuple_arity_representable,
        )

    def _kotlin_derecordized_map_field_type(self) -> str:
        """Return the declared field type for a widened fallback map.

        Spells the concrete value type when every scalar across the
        widened maps shares one Kotlin type in the current pass and the
        ``Map<String, Any?>`` top type otherwise (issue #3608).
        """
        narrow_value_type = self._derecordized_map_narrowing.value_type
        if narrow_value_type is not None:
            return f"Map<String, {narrow_value_type}>"
        return "Map<String, Any?>"

    def _kotlin_narrow_derecordized_map_value_type(
        self,
        *,
        data: Value,
        wrap_ids: frozenset[int],
    ) -> str | None:
        """Return the single Kotlin type every widened-map scalar
        shares.

        Returns ``None`` when the widened maps genuinely mix scalar
        types (the ``Map<String, Any?>`` top type is then required),
        when there is nothing to widen, or when any widened scalar only
        has the ``Any?`` top type (a ``null`` value).
        """
        scalars = iter_wrapped_values(data=data, wrap_ids=wrap_ids)
        if len(scalars) == 0:
            return None
        scalar_types = {
            self._kotlin_value_field_type(scalar) for scalar in scalars
        }
        return single_concrete_type(types=scalar_types, fallback_type="Any?")

    @cached_property
    @beartype
    def _derecordized_map_narrowing(self) -> _KotlinWidenedMapNarrowing:
        """Per-pass narrow-value-type cache for widened fallback maps."""
        return _KotlinWidenedMapNarrowing(value_type=None)

    @cached_property
    @beartype
    def _record_strategy(self) -> RecordStrategy:
        """Resolve the active strategy to its behavior + preamble.

        The ``RECORD`` strategy's widened fallback maps normally open
        with ``mapOf<String, Any?>(``; when every scalar across those
        maps shares one concrete Kotlin type the opener and the
        declared field type narrow to that type instead (issue #3608),
        so the opener is deferred to render time through the per-pass
        narrowing cache refreshed by ``compute_wrap_ids``.
        """
        cls = type(self.heterogeneous_strategy)
        if self.heterogeneous_strategy is cls.RECORD:
            strategy = build_record_strategy(
                renderer=self._record_renderer,
                widen_unrecordizable_nested_sibling_maps=True,
                derecordized_map_open=None,
            )
            narrowing = self._derecordized_map_narrowing
            base_compute_wrap_ids = strategy.behavior.compute_wrap_ids

            @beartype
            def _compute_wrap_ids(data: Value, /) -> frozenset[int]:
                """Refresh the narrow-type cache alongside the wrap
                ids.
                """
                wrap_ids = base_compute_wrap_ids(data)
                narrowing.value_type = (
                    self._kotlin_narrow_derecordized_map_value_type(
                        data=data,
                        wrap_ids=wrap_ids,
                    )
                )
                return wrap_ids

            @beartype
            def _widened_map_open() -> str:
                """Return the widened-map opener for the current
                pass.
                """
                if narrowing.value_type is not None:
                    return TypedCollectionOpen(
                        f"mapOf<String, {narrowing.value_type}>(",
                        declared_type=f"Map<String, {narrowing.value_type}>",
                    )
                return TypedCollectionOpen(
                    "mapOf<String, Any?>(", declared_type="Map<String, Any?>"
                )

            return dataclasses.replace(
                strategy,
                behavior=dataclasses.replace(
                    strategy.behavior,
                    compute_wrap_ids=_compute_wrap_ids,
                    dict_open_for_wrap_ids=_widened_map_open,
                ),
            )
        if self.heterogeneous_strategy is cls.TUPLE:
            return build_tuple_strategy(
                record_renderer=self._record_renderer,
                tuple_renderer=self._tuple_renderer,
            )
        return RecordStrategy(
            behavior=NO_HETEROGENEOUS_BEHAVIOR,
            preamble=no_data_preamble,
            record_name_for_value=None,
        )

    @cached_property
    @beartype
    def data_dependent_preamble(self) -> Callable[[Value], tuple[str, ...]]:
        """Return data-dependent preamble lines.

        Always emits ``import java.math.BigInteger`` when the data
        carries an out-of-range integer; under
        ``HeterogeneousStrategies.RECORD`` additionally emits one
        ``data class`` declaration per record shape present in the data.
        When :attr:`json_type` is active neither applies: integers
        outside the 64-bit range ride inside the JSON text, and the
        data flows through a single ``Json.parseToJsonElement`` call
        instead of typed records.
        """
        if self._json_type_active:
            return no_data_preamble
        record_preamble = self._record_strategy.preamble

        @beartype
        def _preamble(data: Value, /) -> tuple[str, ...]:
            """Combine the BigInteger import with record declarations."""
            return _kotlin_biginteger_preamble(data) + record_preamble(data)

        return _preamble

    @cached_property
    @beartype
    def heterogeneous_behavior(self) -> HeterogeneousBehavior:
        """Return the behavior for the chosen heterogeneous strategy."""
        if self._json_type_active:
            return dataclasses.replace(
                NO_HETEROGENEOUS_BEHAVIOR,
                skip_scalar_checks=True,
            )
        return self._record_strategy.behavior

    call_data_dependent_preamble = default_call_data_dependent_preamble

    type_hint_collection_preamble_lines = (
        default_type_hint_collection_preamble_lines
    )

    @cached_property
    @beartype
    def format_call_stub(
        self,
    ) -> Callable[
        [Sequence[str], Sequence[str], StubReturn, Sequence[Value]],
        tuple[str, ...],
    ]:
        """Return stub declarations for a call expression."""
        return _kotlin_call_stub

    format_call_preamble_stub = default_format_call_stub

    format_call_target = default_format_call_target

    format_call_ref_identifier = default_format_call_ref_identifier

    format_call_arg_ref_identifier = default_format_call_arg_ref_identifier

    format_call_arg_ref_identifier_consumable = (
        default_format_call_arg_ref_identifier_consumable
    )

    consumable_ref_value_inhibits_consuming_form = (
        default_consumable_ref_value_inhibits_consuming_form
    )

    @cached_property
    @beartype
    def _date_type_name(self) -> str | None:
        """Resolved Kotlin type name for the chosen date format."""
        return self._opener_config.type_name(
            py_type=self.date_format.value.type_produced,
        )

    @cached_property
    @beartype
    def _dt_type_name(self) -> str | None:
        """Resolved Kotlin type name for the chosen datetime format.

        Epoch seconds leave Kotlin's signed 32-bit ``Int`` after
        2038-01-19, and the type a map value takes cannot depend on
        which side of that the value falls, so ``EPOCH`` is always a
        ``Long`` and its literal always carries the suffix that makes
        it one (issue #3965).
        """
        if self.datetime_format.value.type_produced is int:
            return "Long"
        return self._opener_config.type_name(
            py_type=self.datetime_format.value.type_produced,
        )

    @cached_property
    @beartype
    def sequence_format_config(self) -> SequenceFormatConfig:
        """Configuration for the chosen sequence format."""
        if self._json_type_active:
            return _JSON_NODE_SEQUENCE_CONFIG
        config = self.sequence_format.value
        if self.sequence_format is not self.sequence_formats.LIST:
            return config

        @beartype
        def _narrow_empty(siblings: Sequence[list[Value]]) -> str:
            """Keep empty bindings typed independently of their uses."""
            items = [item for sibling in siblings for item in sibling]
            selected = self._kotlin_sequence_type(items)
            element_type = infer_element_type(items=items)
            if (
                self._kotlin_record_sequence_type(items) is None
                and element_type is not None
                and _kotlin_sequence_constructor(element_type=element_type)
                == "arrayOf"
            ):
                return f"arrayOf<{self._kotlin_array_element_type(items)}>()"
            return selected.opener + config.close

        return dataclasses.replace(config, narrowed_empty_form=_narrow_empty)

    def _kotlin_record_sequence_type(
        self, items: list[Value], /
    ) -> CollectionType | None:
        """Select a record-aware sequence before ordinary collection
        inference.
        """
        lookup = self._record_strategy.record_name_for_value
        if lookup is None:
            return None
        names = {lookup(item) for item in items}
        if len(names) == 1:
            (name,) = names
            if name is not None:
                return CollectionType(
                    opener=f"listOf<{name}>(", declared_type=f"List<{name}>"
                )
        if any(
            isinstance(item, dict) and not isinstance(item, OrderedMap)
            for item in items
        ):
            return CollectionType(
                opener="listOf<Any?>(", declared_type="List<Any?>"
            )
        return None

    def _kotlin_array_element_type(self, items: list[Value], /) -> str:
        """Resolve the element type of a structurally selected generic
        array.
        """
        if all(isinstance(item, list) for item in items):
            children = [
                child
                for item in items
                if isinstance(item, list)
                for child in item
            ]
            return self._kotlin_list_field_type(value=children)
        return self._kotlin_value_field_type(items[0])

    def _kotlin_list_sequence_type(
        self, items: list[Value], /
    ) -> CollectionType:
        """Select a LIST constructor and its corresponding declaration
        type.
        """
        if len(items) == 0:
            return CollectionType(
                opener="arrayOf<Any?>(", declared_type="Array<Any?>"
            )
        element_type = infer_element_type(items=items)
        if isinstance(element_type, DictType):
            element = self._kotlin_dict_value_type(element_type)
            return CollectionType(
                opener=f"listOf<{element}>(", declared_type=f"List<{element}>"
            )
        constructor = None
        if element_type is not None:
            constructor = _kotlin_sequence_constructor(
                element_type=element_type
            )
        if constructor is None:
            return CollectionType(
                opener="listOf<Any?>(", declared_type="List<Any?>"
            )
        primitive_type = {
            "booleanArrayOf": "BooleanArray",
            "intArrayOf": "IntArray",
            "doubleArrayOf": "DoubleArray",
        }.get(constructor)
        if primitive_type is not None:
            return CollectionType(
                opener=f"{constructor}(", declared_type=primitive_type
            )
        return CollectionType(
            opener="arrayOf(",
            declared_type=f"Array<{self._kotlin_array_element_type(items)}>",
        )

    def _kotlin_sequence_type(self, items: list[Value], /) -> CollectionType:
        """Select a constructor and declared type before spelling
        either.
        """
        record_type = self._kotlin_record_sequence_type(items)
        if record_type is not None:
            return record_type
        if self.sequence_format is self.sequence_formats.ARRAY:
            return CollectionType(
                opener="arrayOf<Any?>(", declared_type="Array<Any?>"
            )
        if self.sequence_format is self.sequence_formats.TUPLE:
            if len(items) in {2, 3}:
                constructor = {2: "Pair", 3: "Triple"}[len(items)]
                return CollectionType(
                    opener=f"{constructor}(",
                    declared_type=self._kotlin_tuple_field_type(items),
                )
            return CollectionType(
                opener="listOf<Any?>(", declared_type="List<Any?>"
            )
        return self._kotlin_list_sequence_type(items)

    @cached_property
    @beartype
    def sequence_open(self) -> Callable[[list[Value]], str]:
        """Emit the constructor selected alongside the sequence's type."""
        if self._json_type_active:
            return _JSON_NODE_SEQUENCE_CONFIG.sequence_open

        @beartype
        def _open(items: list[Value], /) -> str:
            """Retain the selected sequence type through literal
            assembly.
            """
            selected = self._kotlin_sequence_type(items)
            return TypedCollectionOpen(
                selected.opener, declared_type=selected.declared_type
            )

        @beartype
        def _signature(items: list[Value], /) -> CollectionSignature:
            """Retain constructor inference and tuple arity before
            emission.
            """
            record_type = self._kotlin_record_sequence_type(items)
            if record_type is not None:
                key = record_type.declared_type
                return CollectionSignature(
                    type_key=key,
                    arity=None,
                    arity_decision=False,
                    fallback_decision=True,
                    narrowing_decision=True,
                    uses_fallback_decision=key == "List<Any?>",
                )
            if self.sequence_format is self.sequence_formats.ARRAY:
                return CollectionSignature(
                    type_key="Array<Any?>",
                    arity=None,
                    arity_decision=False,
                    fallback_decision=True,
                    narrowing_decision=False,
                    uses_fallback_decision=True,
                )
            if self.sequence_format is self.sequence_formats.TUPLE:
                arity = len(items) if len(items) in {2, 3} else None
                return CollectionSignature(
                    type_key="tuple" if arity is not None else "List<Any?>",
                    arity=arity,
                    arity_decision=len(items) in {1, 2, 3},
                    fallback_decision=False,
                    narrowing_decision=True,
                    uses_fallback_decision=arity is None,
                )
            if len(items) == 0:
                return CollectionSignature(
                    type_key="Array<Any?>",
                    arity=None,
                    arity_decision=False,
                    fallback_decision=False,
                    narrowing_decision=True,
                    uses_fallback_decision=True,
                )
            selected = self._kotlin_list_sequence_type(items)
            element_type = infer_element_type(items=items)
            constructor = None
            if element_type is not None:
                constructor = _kotlin_sequence_constructor(
                    element_type=element_type
                )
            key = selected.declared_type
            if constructor == "arrayOf":
                key = "deduced-array"
            return CollectionSignature(
                type_key=key,
                arity=None,
                arity_decision=False,
                fallback_decision=False,
                narrowing_decision=True,
                uses_fallback_decision=False,
            )

        return signature_open(render=_open, infer=_signature)

    @cached_property
    @beartype
    def set_format_config(self) -> SetFormatConfig:
        """Configuration for the chosen set format."""
        if self._json_type_active:
            return _JSON_NODE_SET_CONFIG
        base = self.set_format(default_type=self.default_set_element_type)
        opener_template = "setOf<{type_name}>("
        set_outer = "Set"
        if self.set_format is self.set_formats.SORTED_SET:
            opener_template = base.set_opener_template
            set_outer = "MutableSet"
        fallback = CollectionType(
            opener=base.set_open([]),
            declared_type=f"{set_outer}<{self.default_set_element_type}>",
        )
        resolver = self._opener_config.element_to_type(
            dict_value_to_type=None,
            list_template=None,
            enable_list_type=True,
            date_type=self._date_type_name,
            datetime_type=self._dt_type_name,
            enable_dict_type=False,
            dict_key_type=self.default_dict_key_type,
        )

        @beartype
        def _open(items: list[Value], /) -> str:
            """Carry the selected set type rather than inspect its
            constructor.
            """
            selected = infer_collection_type(
                items=items,
                element_to_type=resolver,
                opener_template=opener_template,
                declared_type_template=f"{set_outer}<{{type_name}}>",
                fallback=fallback,
            )
            return TypedCollectionOpen(
                selected.opener, declared_type=selected.declared_type
            )

        return dataclasses.replace(base, set_open=_open)

    @cached_property
    @beartype
    def _kotlin_dict_value_type(
        self,
    ) -> Callable[[type | ListType | DictType], str | None]:
        """Resolve a dict value's Kotlin type name to match the renderer.

        Kotlin's dict opener previously disabled value narrowing entirely
        (its base list template renders as an ``Array`` type, which does
        not match the real ``List`` sequence rendering, so narrowing list
        values would give them the wrong type).  That left a map value
        typed ``Any?`` where a nested ``Map<...>`` was declared, so a map
        used as e.g. a sequence element did not compile (#2890).

        Delegates to :func:`_kotlin_dict_value_type_name`, which narrows
        only ``DictType`` values and keeps the prior ``Array``/``Any?``
        list typing for everything else.
        """
        base_resolver = self._opener_config.element_to_type(
            dict_value_to_type=None,
            list_template=None,
            enable_list_type=True,
            date_type=self._date_type_name,
            datetime_type=self._dt_type_name,
            enable_dict_type=False,
            dict_key_type=self.default_dict_key_type,
        )
        key_type = self.default_dict_key_type
        fallback = self.default_dict_value_type
        scalar_resolver = self._opener_config.element_to_type(
            dict_value_to_type=None,
            list_template=None,
            enable_list_type=False,
            date_type=self._date_type_name,
            datetime_type=self._dt_type_name,
            enable_dict_type=False,
            dict_key_type=self.default_dict_key_type,
        )
        # Only the LIST format renders a list value as an array; the
        # others render one whose type the element type alone does not
        # name (``Pair``/``Triple`` depend on arity), so those take the
        # generic value type (issue #3941).
        renders_arrays = (
            self.sequence_format is type(self.sequence_format).LIST
        )

        @beartype
        def resolve_list(element_type: ListType) -> str | None:
            """Map a list value to its rendered Kotlin type name."""
            if not renders_arrays:
                return None
            return _kotlin_list_value_type_name(
                element_type=element_type,
                scalar_resolver=scalar_resolver,
            )

        @beartype
        def resolve(element_type: type | ListType | DictType) -> str | None:
            """Map an element type to its rendered Kotlin type name."""
            return _kotlin_dict_value_type_name(
                element_type=element_type,
                base_resolver=base_resolver,
                list_resolver=resolve_list,
                key_type=key_type,
                fallback=fallback,
            )

        return resolve

    @cached_property
    @beartype
    def dict_format_config(self) -> DictFormatConfig:
        """Configuration for dict formatting."""
        if self._json_type_active:
            return _JSON_NODE_DICT_CONFIG
        config = self.dict_format.value
        opener_template = config.opener_template.replace(
            "{key_type}", self.default_dict_key_type
        )
        type_template = config.declared_type_template.replace(
            "{key_type}", self.default_dict_key_type
        )
        fallback = CollectionType(
            opener=opener_template.format(
                type_name=self.default_dict_value_type
            ),
            declared_type=type_template.format(
                type_name=self.default_dict_value_type
            ),
        )

        @beartype
        def _open(items: dict[Scalar, Value], /) -> str:
            """Retain the selected mapping type before emitting its opener."""
            selected = infer_collection_type(
                items=list(items.values()),
                element_to_type=self._kotlin_dict_value_type,
                opener_template=opener_template,
                declared_type_template=type_template,
                fallback=fallback,
            )
            return TypedCollectionOpen(
                selected.opener, declared_type=selected.declared_type
            )

        @beartype
        def _signature(items: dict[Scalar, Value], /) -> CollectionSignature:
            """Retain the inferred mapping value type and stable
            fallback.
            """
            selected = infer_collection_type(
                items=list(items.values()),
                element_to_type=self._kotlin_dict_value_type,
                opener_template=opener_template,
                declared_type_template=type_template,
                fallback=fallback,
            )
            return CollectionSignature(
                type_key=selected.declared_type,
                arity=None,
                arity_decision=False,
                fallback_decision=True,
                narrowing_decision=True,
                uses_fallback_decision=selected.declared_type
                == fallback.declared_type,
            )

        return DictFormatConfig(
            dict_open=signature_open(render=_open, infer=_signature),
            narrowed_open=None,
            supports_trailing_comma=True,
            close=")",
            format_entry=dict_entry_with_separator(
                separator=" to ",
                format_value=passthrough_sequence_entry,
            ),
            empty_dict=None,
            preamble_lines=(),
            narrowed_empty_form=None,
        )

    @cached_property
    @beartype
    def trailing_comma_config(self) -> TrailingCommaConfig:
        """Configuration for trailing-comma behavior."""
        return self.trailing_comma.value

    @cached_property
    @beartype
    def format_bytes(self) -> Callable[[bytes], str]:
        """Callable that formats a bytes value as a string literal."""
        return self.bytes_format

    @cached_property
    @beartype
    def format_date(self) -> Callable[[dt.date], str]:
        """Callable that formats a date as a string literal."""
        return self.date_format

    @cached_property
    @beartype
    def format_datetime(self) -> Callable[[dt.datetime], str]:
        """Callable that formats a datetime as a string literal."""
        return self.datetime_format

    @cached_property
    @beartype
    def format_time(self) -> Callable[[dt.time], str]:
        """Callable that formats a time as a string literal."""
        return format_time_local_time_of

    @cached_property
    @beartype
    def format_float(self) -> Callable[[float], str]:
        """Callable that formats a float value as a literal."""
        return self.float_format

    @cached_property
    @beartype
    def format_integer(self) -> Callable[[int], str]:
        """Callable that formats an int value as a literal."""
        base = self.integer_format.get_formatter(
            numeric_separator=self.numeric_separator,
        )

        @beartype
        def format_signed(value: int) -> str:
            """Format the signed minimum using its named constant."""
            if value == I64_MIN:
                return "Long.MIN_VALUE"
            return base(value)

        return make_overflow_fallback_formatter(
            base=format_signed,
            fallback=_format_kotlin_biginteger_literal,
            min_value=I64_MIN,
            max_value=I64_MAX,
        )

    @cached_property
    @beartype
    def format_integer_widened(self) -> Callable[[int], str]:
        """Always-``L``-suffixed integer formatter for widened
        collections (mixed-magnitude int sets/lists).
        """
        base = self.integer_format.get_formatter(
            numeric_separator=self.numeric_separator,
        )
        suffixed = make_long_suffix_formatter(base=base)

        @beartype
        def format_signed(value: int) -> str:
            """Format the signed minimum using its named constant."""
            if value == I64_MIN:
                return "Long.MIN_VALUE"
            return suffixed(value)

        return make_overflow_fallback_formatter(
            base=format_signed,
            fallback=_format_kotlin_biginteger_literal,
            min_value=I64_MIN,
            max_value=I64_MAX,
        )

    @cached_property
    @beartype
    def format_integer_beyond_i64(self) -> Callable[[int], str]:
        """Always-``BigInteger`` formatter for collections that exceed
        signed 64-bit range.
        """
        return _format_kotlin_biginteger_literal

    @cached_property
    @beartype
    def comment_config(self) -> CommentConfig:
        """Configuration for the language's comment syntax."""
        return self.comment_format.value

    @cached_property
    @beartype
    def ordered_map_format_config(self) -> OrderedMapFormatConfig:
        """Configuration for ordered-map formatting."""
        if self._json_type_active:
            return _JSON_NODE_ORDERED_MAP_CONFIG
        return OrderedMapFormatConfig(
            ordered_map_open=fixed_open(
                open_str=TypedCollectionOpen(
                    (
                        f"linkedMapOf<{self.default_dict_key_type}, "
                        f"{self.default_dict_value_type}>("
                    ),
                    declared_type=(
                        f"LinkedHashMap<{self.default_dict_key_type}, "
                        f"{self.default_dict_value_type}>"
                    ),
                )
            ),
            close=")",
            preamble_lines=(),
        )

    @cached_property
    @beartype
    def format_ordered_map_entry(self) -> Callable[[str, Value, str], str]:
        """Callable that formats one ordered-map entry."""
        return dict_entry_with_separator(
            separator=" to ",
            format_value=passthrough_sequence_entry,
        )

    @cached_property
    @beartype
    def format_call_variable_declaration(
        self,
    ) -> Callable[[str, str, Value, frozenset[enum.Enum]], str]:
        """Infer a call's result type independently of its arguments."""
        return self.declaration_style.value.formatter

    def format_contextual_variable_declaration(
        self,
        name: str,
        value: str,
        data: Value,
        modifiers: frozenset[enum.Enum],
        /,
        *,
        inferred_empty_sequence: bool,
        is_reference_binding: bool,
        initializer_type: str | None,
    ) -> str:
        """Use the retained type of the emitted initializer for explicit
        hints.
        """
        del inferred_empty_sequence, is_reference_binding
        if (
            not self._json_type_active
            and self.variable_type_hints
            is self.variable_type_hints_formats.ALWAYS
            and initializer_type is not None
        ):
            check_empty_sibling_sequence_type_hint_data(
                data=data,
                language_name=type(self).__name__,
                supports_empty_sibling_sequence_type_hints=self.supports_empty_sibling_sequence_type_hints,
            )
            keyword = self.declaration_style.name.lower()
            return f"{keyword} {name}: {initializer_type} = {value}"
        return self.format_variable_declaration(name, value, data, modifiers)

    def _kotlin_declaration_type(self, data: Value, /) -> str:
        """Reuse field inference for initializers without retained type
        metadata.
        """
        if isinstance(data, dt.date) and not isinstance(data, dt.datetime):
            date_type = "LocalDate"
            if self.date_format.value.type_produced is str:
                date_type = "String"
            return date_type
        record_name_for_value = self._record_strategy.record_name_for_value
        if record_name_for_value is not None:
            record_name = record_name_for_value(data)
            if record_name is not None:
                return record_name
        return self._kotlin_value_field_type(data)

    @cached_property
    @beartype
    def format_variable_declaration(
        self,
    ) -> Callable[[str, str, Value, frozenset[enum.Enum]], str]:
        """Callable that formats a new variable declaration."""
        if self._json_type_active:
            return _make_format_kotlin_json_declaration(
                keyword=self.declaration_style.name.lower(),
            )
        formatter = self.variable_type_hints.formatter(
            auto_formatter=self.declaration_style.value.formatter,
            keyword=self.declaration_style.name.lower(),
            type_hint=self._kotlin_declaration_type,
        )
        if (
            self.supports_empty_sibling_sequence_type_hints
            or self.variable_type_hints
            is not type(self.variable_type_hints).ALWAYS
        ):
            return formatter

        @beartype
        def checked_formatter(
            name: str,
            value: str,
            data: Value,
            modifiers: frozenset[enum.Enum],
        ) -> str:
            """Reject data whose explicit type hint Kotlin cannot
            represent.
            """
            check_empty_sibling_sequence_type_hint_data(
                data=data,
                language_name=type(self).__name__,
                supports_empty_sibling_sequence_type_hints=(
                    self.supports_empty_sibling_sequence_type_hints
                ),
            )
            return formatter(name, value, data, modifiers)

        return checked_formatter

    @cached_property
    @beartype
    def scalar_preamble(self) -> dict[type, tuple[str, ...]]:
        """Per-instance scalar preamble computed from date/datetime format.

        Under :attr:`json_type` every temporal value is folded into the
        JSON text as an ISO-8601 string, so the temporal Kotlin imports
        that the configured ``date_format`` / ``datetime_format`` would
        otherwise add do not apply.
        """
        if self._json_type_active:
            return {}
        return date_scalar_preamble(
            date_format=self.date_format,
            datetime_format=self.datetime_format,
            extra={dt.time: ("import java.time.LocalTime",)},
        )

    @cached_property
    @beartype
    def scalar_body_preamble(self) -> dict[type, tuple[str, ...]]:
        """Per-instance scalar body preamble (Kotlin needs none)."""
        return {}

    @cached_property
    @beartype
    def compute_body_preamble(
        self,
    ) -> Callable[[frozenset[type], Value], tuple[str, ...]]:
        """Compute body-preamble lines from the scalar map."""
        return body_preamble_from_scalars(
            scalar_body_preamble=self.scalar_body_preamble,
            format_lines=tuple,
        )

    @cached_property
    @beartype
    def call_style_config(self) -> CallStyle:
        """Configuration for the chosen call style."""
        config: CallStyle = self.call_style.value
        return config


register_json_native_document_fast(language_cls=Kotlin)
