"""Date and datetime formatting functions."""

import datetime as dt
from collections.abc import Callable

from beartype import beartype

from literalizer.exceptions import UnrepresentableInputError


@beartype
def normalize_datetime_utc(
    value: dt.datetime, *, language_name: str
) -> dt.datetime:
    """Normalize an aware datetime or raise a typed representation
    error.
    """
    try:
        return value.astimezone(tz=dt.UTC)
    except OverflowError as error:
        msg = (
            f"{language_name} cannot normalize datetime to UTC within "
            f"Python's supported year range: {value.isoformat()}"
        )
        raise UnrepresentableInputError(msg) from error


@beartype
def format_date_iso(value: dt.date) -> str:
    """Format a date as an ISO 8601 quoted string literal.

    Example: ``datetime.date(2024, 1, 15)`` -> ``"2024-01-15"``.
    """
    return f'"{value.isoformat()}"'


# ECMA-262 maps a year argument of 0 to 99 to ``1900 + year``, so the
# numeric constructor cannot spell an early year directly.  ``setFullYear``
# takes the year as given and returns the adjusted time value, which the
# outer constructor turns back into a ``Date`` (issue #4520).
_JAVASCRIPT_OFFSET_YEAR_MAX = 99


@beartype
def _javascript_date_expression(*, year: int, args: str) -> str:
    """Return a ``Date`` expression that keeps *year* as written."""
    if 0 <= year <= _JAVASCRIPT_OFFSET_YEAR_MAX:
        return f"new Date(new Date({args}).setFullYear({year}))"
    return f"new Date({args})"


@beartype
def format_date_javascript(value: dt.date) -> str:
    """Format a date as a JavaScript local-midnight ``Date``.

    The numeric constructor uses local calendar components. Its month is
    zero-based, unlike :class:`datetime.date`.
    """
    return _javascript_date_expression(
        year=value.year,
        args=f"{value.year}, {value.month - 1}, {value.day}",
    )


@beartype
def format_datetime_javascript(value: dt.datetime) -> str:
    """Format an exactly representable JavaScript ``Date``.

    Naive values use the numeric constructor so their calendar components do
    not get parsed as an environment-dependent instant. Aware values retain
    their explicit ISO offset where its syntax is supported. JavaScript
    ``Date`` has millisecond precision.
    """
    offset = value.utcoffset()
    epoch_microseconds: int | None = None
    precision = value.microsecond % 1000
    if (
        offset is not None
        and offset % dt.timedelta(minutes=1) != dt.timedelta()
    ):
        epoch_microseconds = _datetime_epoch_delta(value) // dt.timedelta(
            microseconds=1
        )
        precision = epoch_microseconds % 1000
    if precision != 0:
        msg = (
            "JavaScript Date cannot preserve sub-millisecond datetime "
            f"precision: {value.isoformat()}"
        )
        raise UnrepresentableInputError(msg)
    if epoch_microseconds is not None:
        return f"new Date({epoch_microseconds // 1000})"
    if offset is not None:
        return f'new Date("{value.isoformat(timespec="milliseconds")}")'
    args = (
        f"{value.year}, {value.month - 1}, {value.day}, {value.hour}, "
        f"{value.minute}, {value.second}"
    )
    if value.microsecond != 0:
        args += f", {value.microsecond // 1000}"
    return _javascript_date_expression(year=value.year, args=args)


@beartype
def format_datetime_iso(value: dt.datetime) -> str:
    """Format a datetime as an ISO 8601 quoted string literal.

    Example: ``datetime.datetime(2024, 1, 15, 12, 30)`` ->
    ``"2024-01-15T12:30:00"``.
    """
    return f'"{value.isoformat()}"'


@beartype
def format_time_iso(value: dt.time) -> str:
    """Format a time as an ISO 8601 quoted string literal.

    Example: ``datetime.time(9, 30)`` -> ``"09:30:00"``.
    """
    return f'"{value.isoformat()}"'


@beartype
def format_time_local_time_of(value: dt.time) -> str:
    """Format a time as a ``LocalTime.of(...)`` call.

    Shared by Java, Kotlin, Scala, and Groovy, which all use the
    ``java.time.LocalTime`` factory method.

    Example: ``datetime.time(9, 30)`` -> ``LocalTime.of(9, 30)``.
    """
    parts = [str(object=value.hour), str(object=value.minute)]
    nanoseconds = value.microsecond * 1000
    if value.second != 0 or bool(nanoseconds):
        parts.append(str(object=value.second))
    if nanoseconds != 0:
        parts.append(str(object=nanoseconds))
    return f"LocalTime.of({', '.join(parts)})"


@beartype
def _time_only_args(value: dt.time) -> str:
    """Return the comma-separated argument list for a ``TimeOnly``
    call.
    """
    parts = [
        str(object=value.hour),
        str(object=value.minute),
        str(object=value.second),
    ]
    if value.microsecond != 0:
        milliseconds, microseconds = divmod(value.microsecond, 1000)
        parts.append(str(object=milliseconds))
        if microseconds != 0:
            parts.append(str(object=microseconds))
    return ", ".join(parts)


@beartype
def format_time_csharp(value: dt.time) -> str:
    """Format a time as a C# ``new TimeOnly(...)`` expression."""
    return f"new TimeOnly({_time_only_args(value=value)})"


@beartype
def format_time_fsharp(value: dt.time) -> str:
    """Format a time as an F# ``System.TimeOnly(...)`` expression.

    Fully qualifies ``System.TimeOnly`` so the rendered output does not
    require an ``open System`` preamble; an ``open`` directive would
    sort before ``module``, which F# rejects.
    """
    return f"System.TimeOnly({_time_only_args(value=value)})"


@beartype
def format_time_vb(value: dt.time) -> str:
    """Format a time as a VB.NET ``New TimeOnly(...)`` expression."""
    return f"New TimeOnly({_time_only_args(value=value)})"


@beartype
def _datetime_epoch_delta(value: dt.datetime, /) -> dt.timedelta:
    """Return exact elapsed time without normalizing calendar fields."""
    offset = value.utcoffset()
    if offset is None or offset == dt.timedelta():
        offset = dt.timedelta()
    elapsed = dt.timedelta(
        days=value.toordinal()
        - dt.date(year=1970, month=1, day=1).toordinal(),
        seconds=value.hour * 3600 + value.minute * 60 + value.second,
        microseconds=value.microsecond,
    )
    return elapsed - offset


@beartype
def datetime_epoch_seconds(value: dt.datetime) -> int:
    """Return exact integer Unix epoch seconds for a datetime."""
    elapsed = _datetime_epoch_delta(value)
    if elapsed.microseconds != 0:
        msg = (
            "integer Unix epoch seconds cannot preserve fractional "
            f"datetime precision: {value.isoformat()}"
        )
        raise UnrepresentableInputError(msg)
    return elapsed // dt.timedelta(seconds=1)


@beartype
def format_datetime_epoch_fractional(value: dt.datetime) -> str:
    """Format exact Unix epoch seconds, retaining a fractional part."""
    total_microseconds = _datetime_epoch_delta(value) // dt.timedelta(
        microseconds=1
    )
    sign = ""
    if total_microseconds < 0:
        sign = "-"
    seconds, microseconds = divmod(abs(total_microseconds), 1_000_000)
    if microseconds == 0:
        return f"{sign}{seconds}"
    fraction = f"{microseconds:06d}".rstrip("0")
    return f"{sign}{seconds}.{fraction}"


@beartype
def format_datetime_epoch(value: dt.datetime) -> str:
    """Format a datetime as integer Unix epoch seconds."""
    return str(object=datetime_epoch_seconds(value=value))


@beartype
def datetime_epoch_formatter(
    *,
    format_integer: Callable[[int], str],
) -> Callable[[dt.datetime], str]:
    """Return a datetime formatter that delegates epoch seconds to an
    integer formatter.
    """

    @beartype
    def _format(value: dt.datetime) -> str:
        """Format using the supplied integer formatter."""
        return format_integer(datetime_epoch_seconds(value=value))

    return _format


@beartype
def _format_date_ymd(value: dt.date, template: str) -> str:
    """Format a date using a year/month/day template."""
    return template.format(
        year=value.year,
        month=value.month,
        day=value.day,
    )


@beartype
def date_ymd_formatter(
    *,
    template: str,
) -> Callable[[dt.date], str]:
    """Return a date formatter that substitutes year, month, and day
    into *template*.

    The *template* must contain ``{year}``, ``{month}``, and ``{day}``
    placeholders.

    Example::

        fmt = date_ymd_formatter(
            template="LocalDate.of({year}, {month}, {day})",
        )
        fmt(datetime.date(2024, 1, 15))  # => "LocalDate.of(2024, 1, 15)"
    """

    @beartype
    def _format(value: dt.date) -> str:
        """Delegate to module-level implementation."""
        return _format_date_ymd(value=value, template=template)

    return _format


_MICROSECONDS_PER_MILLISECOND = 1000


@beartype
def _format_datetime_ymdhms(
    value: dt.datetime,
    template: str,
    millisecond_template: str | None,
) -> str:
    """Format a datetime using a year/month/day/hour/minute/second
    template.

    A target whose native type carries milliseconds supplies a second
    template taking a ``{millisecond}`` placeholder; it is used only
    for a value that has one, so a whole-second value keeps the
    shorter spelling (issue #4521).
    """
    if millisecond_template is None:
        if value.microsecond != 0:
            msg = (
                "whole-second native datetime format cannot preserve "
                f"microseconds: {value.isoformat()}"
            )
            raise UnrepresentableInputError(msg)
    elif value.microsecond % _MICROSECONDS_PER_MILLISECOND != 0:
        msg = (
            "millisecond-precision native datetime format cannot "
            f"preserve sub-millisecond precision: {value.isoformat()}"
        )
        raise UnrepresentableInputError(msg)
    if value.utcoffset() is not None:
        msg = (
            "timezone-naive native datetime format cannot preserve "
            f"timezone awareness: {value.isoformat()}"
        )
        raise UnrepresentableInputError(msg)
    selected = template
    if millisecond_template is not None and bool(value.microsecond):
        selected = millisecond_template
    return selected.format(
        year=value.year,
        month=value.month,
        day=value.day,
        hour=value.hour,
        minute=value.minute,
        second=value.second,
        millisecond=value.microsecond // _MICROSECONDS_PER_MILLISECOND,
    )


@beartype
def datetime_ymdhms_formatter(
    *,
    template: str,
    millisecond_template: str | None,
) -> Callable[[dt.datetime], str]:
    """Return a datetime formatter that substitutes year, month, day,
    hour, minute, and second into *template*.

    The *template* must contain ``{year}``, ``{month}``, ``{day}``,
    ``{hour}``, ``{minute}``, and ``{second}`` placeholders.

    *millisecond_template* is that template plus a ``{millisecond}``
    placeholder, for a target whose native datetime type carries
    milliseconds; ``None`` means the target is whole-second and any
    fraction is refused.

    Example::

        fmt = datetime_ymdhms_formatter(
            template="new DateTime({year}, {month}, {day}, "
                     "{hour}, {minute}, {second})",
            millisecond_template=None,
        )
    """

    @beartype
    def _format(value: dt.datetime) -> str:
        """Delegate to module-level implementation."""
        return _format_datetime_ymdhms(
            value=value,
            template=template,
            millisecond_template=millisecond_template,
        )

    return _format


@beartype
def _format_date_iso_template(value: dt.date, template: str) -> str:
    """Format a date using the ISO template."""
    return template.format(iso=value.isoformat())


@beartype
def date_iso_formatter(
    *,
    template: str,
) -> Callable[[dt.date], str]:
    """Return a date formatter that substitutes the ISO 8601 string
    into *template*.

    The *template* must contain an ``{iso}`` placeholder.

    Example::

        fmt = date_iso_formatter(
            template='DateTime.parse("{iso}")',
        )
        fmt(datetime.date(2024, 1, 15))  # => 'DateTime.parse("2024-01-15")'
    """

    @beartype
    def _format(value: dt.date) -> str:
        """Delegate to module-level implementation."""
        return _format_date_iso_template(value=value, template=template)

    return _format


@beartype
def _format_datetime_iso_template(value: dt.datetime, template: str) -> str:
    """Format a datetime using the ISO template."""
    return template.format(iso=value.isoformat())


@beartype
def datetime_iso_formatter(
    *,
    template: str,
) -> Callable[[dt.datetime], str]:
    """Return a datetime formatter that substitutes the ISO 8601 string
    into *template*.

    The *template* must contain an ``{iso}`` placeholder.

    Example::

        fmt = datetime_iso_formatter(
            template='new Date("{iso}")',
        )
    """

    @beartype
    def _format(value: dt.datetime) -> str:
        """Delegate to module-level implementation."""
        return _format_datetime_iso_template(value=value, template=template)

    return _format
