"""String formatting functions."""

import functools
import re
from collections.abc import Callable, Sequence
from typing import Protocol, runtime_checkable

from beartype import beartype

from literalizer.exceptions import UnrepresentableStringError


@beartype
def escape_trailing_whitespace(match: re.Match[str]) -> str:
    r"""Return one ``\x20`` escape per character of the whitespace run."""
    return r"\x20" * len(match[0])


@runtime_checkable
class _StringFormatter(Protocol):
    """Protocol for string formatting functions."""

    def __call__(self, value: str) -> str:
        """Format *value* using backslash escaping."""
        ...


BIDI_FORMATTING_CHARACTERS: tuple[str, ...] = (
    "\u202a",
    "\u202b",
    "\u202c",
    "\u202d",
    "\u202e",
    "\u2066",
    "\u2067",
    "\u2068",
    "\u2069",
)
"""The Unicode bidirectional formatting characters.

Several toolchains reject these in source because of the "Trojan
Source" class of attacks -- ``rustc`` denies them by default, Elixir
raises a syntax error, the Dart analyzer warns -- so a backend whose
toolchain does emits them as escapes instead (issue #3912).
"""


@beartype
def bidi_escape_replacements(*, template: str) -> list[tuple[str, str]]:
    r"""Return one ``(character, escape)`` pair per formatting character.

    *template* receives the code point as a positional integer, e.g.
    ``"\\u{{{:04X}}}"`` -> ``\\u{202A}``.
    """
    return [
        (character, template.format(ord(character)))
        for character in BIDI_FORMATTING_CHARACTERS
    ]


@beartype
def has_bidi_formatting_character(*, value: str) -> bool:
    """Return whether *value* holds one of those characters."""
    return any(character in value for character in BIDI_FORMATTING_CHARACTERS)


@beartype
def _backslash_escape(*, value: str, quote_char: str) -> str:
    r"""Apply base backslash escapes to *value*.

    Escapes backslashes, *quote_char*, ``\r``, ``\n``, and ``\t``.
    Does **not** wrap the result in quotes.
    """
    return (
        value.replace("\\", "\\\\")
        .replace(quote_char, f"\\{quote_char}")
        .replace("\r", "\\r")
        .replace("\n", "\\n")
        .replace("\t", "\\t")
    )


@beartype
def _apply_backslash_formatter(
    value: str,
    quote_char: str,
    extra_replacements: Sequence[tuple[str, str]],
) -> str:
    """Format *value* using backslash escaping."""
    # Performance fast path: most strings are simple identifiers, keys, or
    # labels, so avoid the replacement chain unless the value contains a
    # character or sequence that would actually change the escaped output.
    has_base_escape = (
        "\\" in value
        or quote_char in value
        or "\r" in value
        or "\n" in value
        or "\t" in value
    )
    if not has_base_escape and not any(
        (old in value for old, _new in extra_replacements)
    ):
        return f"{quote_char}{value}{quote_char}"

    escaped = _backslash_escape(value=value, quote_char=quote_char)
    for old, new in extra_replacements:
        escaped = escaped.replace(old, new)
    return f"{quote_char}{escaped}{quote_char}"


@beartype
def make_backslash_string_formatter(
    *,
    quote_char: str,
    extra_replacements: Sequence[tuple[str, str]],
) -> _StringFormatter:
    r"""Return a backslash-escape string formatter.

    Every returned formatter applies the same base escapes — backslash,
    *quote_char*, ``\r``, ``\n``, ``\t`` — then any *extra_replacements*
    in order, and finally wraps the result in *quote_char*.

    *extra_replacements* is a sequence of ``(old, new)`` pairs passed to
    :meth:`str.replace`.
    """

    @beartype
    def _format(value: str) -> str:
        """Delegate to module-level implementation."""
        return _apply_backslash_formatter(
            value=value,
            quote_char=quote_char,
            extra_replacements=extra_replacements,
        )

    return _format


format_string_backslash = make_backslash_string_formatter(
    quote_char='"',
    extra_replacements=(),
)
r"""Format a string using backslash escaping.

Escapes backslashes, double quotes, and newlines with a backslash
prefix, then wraps the result in double quotes.

Example: ``hello "world"`` -> ``"hello \"world\""``.
"""

format_string_backslash_nul_hex = make_backslash_string_formatter(
    quote_char='"',
    extra_replacements=[("\0", "\\x00")],
)
format_string_backslash_single_nul_hex = make_backslash_string_formatter(
    quote_char="'",
    extra_replacements=[("\0", r"\x00")],
)
r"""Format a double-quoted string and escape the null byte as ``\x00``.

Fixed-width hex avoids digit-greedy octal/decimal escapes such as
``\0`` followed by ``0``-``7`` (or Nim's decimal ``\0``).
"""

format_string_backslash_nul_octal = make_backslash_string_formatter(
    quote_char='"',
    extra_replacements=[("\0", "\\000")],
)
r"""Format a double-quoted string and escape NUL as fixed-width ``\000``."""


@beartype
def format_string_c_utf8_characters(*, value: str) -> str:
    r"""Return escaped C character entries for the UTF-8 bytes of *value*."""
    encoded = value.encode(encoding="utf-8")
    return ", ".join(rf"'\{byte:03o}'" for byte in encoded)


@beartype
def format_string_c(value: str) -> str:
    r"""Render bidirectional controls as a terminated UTF-8 character array."""
    if not value.isascii() and has_bidi_formatting_character(value=value):
        entries = format_string_c_utf8_characters(value=value)
        return f"(const char[]){{{entries}, '\\000'}}"
    return format_string_backslash_nul_octal(value=value)


format_string_backslash_nul_unicode = make_backslash_string_formatter(
    quote_char='"',
    extra_replacements=[("\0", "\\u0000")],
)
r"""Format a double-quoted string and escape NUL as ``\u0000``."""

format_string_backslash_nul_braced_unicode = make_backslash_string_formatter(
    quote_char='"',
    extra_replacements=[("\0", "\\u{0000}")],
)
r"""Format a double-quoted string and escape NUL as ``\u{0000}``."""

format_string_backslash_dollar = make_backslash_string_formatter(
    quote_char='"',
    extra_replacements=[("$", "\\$")],
)
r"""Format a string using backslash escaping, including ``$``.

Escapes backslashes, double quotes, newlines, tabs, and dollar signs
with a backslash prefix, then wraps the result in double quotes.

Example: ``price $10`` -> ``"price \$10"``.
"""

format_string_backslash_dollar_nul_hex = make_backslash_string_formatter(
    quote_char='"',
    extra_replacements=[("$", "\\$"), ("\0", "\\x00")],
)
r"""Escape dollar interpolation and NUL in a double-quoted string."""

format_string_backslash_dollar_nul_unicode = make_backslash_string_formatter(
    quote_char='"',
    extra_replacements=[("$", "\\$"), ("\0", "\\u0000")],
)
r"""Escape dollar interpolation and NUL with a Unicode escape."""


@beartype
def reject_nul_string_formatter(
    formatter: Callable[[str], str],
    /,
    *,
    language_name: str,
) -> Callable[[str], str]:
    """Wrap *formatter* to reject strings with an embedded null byte."""

    @beartype
    def _format(value: str) -> str:
        """Reject a null byte, then delegate to the wrapped formatter."""
        if "\0" in value:
            raise UnrepresentableStringError(
                language_name=language_name,
                character_name="NUL",
            )
        return formatter(value)

    return _format


@beartype
def format_string_concat_control(
    *,
    quote_char: str,
    quote_escape: str,
    control_char_template: str,
    concat_operator: str,
    escape_delete_and_c1: bool,
) -> Callable[[str], str]:
    """Return a string formatter that splits on control characters and
    concatenates parts with a language-specific operator.

    Text segments are wrapped in *quote_char* with embedded quotes
    escaped to *quote_escape*. C0 controls and Unicode line separators
    are emitted using *control_char_template*. Unicode separators are
    expanded to their UTF-8 bytes so byte-oriented string types preserve
    the source value.

    Example::

        format_string = format_string_concat_control(
            quote_char="'",
            quote_escape="''",
            control_char_template="achar({})",
            concat_operator=" // ",
            escape_delete_and_c1=False,
        )
        format_string("hello")  # => "'hello'"
    """
    empty = f"{quote_char}{quote_char}"

    @beartype
    def _format(value: str) -> str:
        """Delegate to module-level implementation."""
        return _apply_concat_control(
            value=value,
            quote_char=quote_char,
            quote_escape=quote_escape,
            control_char_template=control_char_template,
            concat_operator=concat_operator,
            empty=empty,
            escape_delete_and_c1=escape_delete_and_c1,
        )

    return _format


@beartype
def _apply_concat_control(
    value: str,
    *,
    quote_char: str,
    quote_escape: str,
    control_char_template: str,
    concat_operator: str,
    empty: str,
    escape_delete_and_c1: bool,
) -> str:
    """Format a string with control character concatenation."""
    control_char_threshold = 32
    delete_code_point = 127
    c1_control_start = 128
    c1_control_end = 159
    parts: list[str] = []
    pattern = r"([\x00-\x1f\x85\u2028\u2029])"
    if escape_delete_and_c1:
        pattern = r"([\x00-\x1f\x7f-\x9f\u2028\u2029])"
    for segment in re.split(pattern=pattern, string=value):
        if segment == "":
            continue
        if len(segment) == 1 and (
            ord(segment) < control_char_threshold
            or (escape_delete_and_c1 and ord(segment) == delete_code_point)
        ):
            parts.append(control_char_template.format(ord(segment)))
        elif segment in "\x85\u2028\u2029" or (
            escape_delete_and_c1
            and len(segment) == 1
            and c1_control_start <= ord(segment) <= c1_control_end
        ):
            parts.extend(
                control_char_template.format(byte)
                for byte in segment.encode(encoding="utf-8")
            )
        else:
            escaped = segment.replace(quote_char, quote_escape)
            parts.append(f"{quote_char}{escaped}{quote_char}")
    match parts:
        case []:
            return empty
        case [single]:
            return single
        case _:
            return concat_operator.join(parts)


@beartype
def _format_control_char(match: re.Match[str], *, fmt: str) -> str:
    """Return the escape sequence for the control character in *match*."""
    return fmt.format(ord(match.group()))


@beartype
def escape_control_chars(*, value: str, fmt: str, escape_delete: bool) -> str:
    r"""Replace C0 control characters (U+0000-U+001F) with escape sequences.

    Call **after** replacing named escapes (``\t``, ``\n``, ``\r``) so that
    only truly unhandled control characters are affected.

    The format pattern passed in ``fmt`` receives the code point as a
    positional integer, e.g. ``"\\x{:02x}"`` -> ``\\x01``.

    *escape_delete* extends the replacement to U+007F (DELETE), which
    some target languages reject as a raw byte in a string literal
    while others carry it verbatim.
    """
    pattern = r"[\x00-\x1f]"
    if escape_delete:
        pattern = r"[\x00-\x1f\x7f]"
    return re.sub(
        pattern=pattern,
        repl=functools.partial(_format_control_char, fmt=fmt),
        string=value,
    )


@beartype
def format_string_backslash_control(
    *,
    value: str,
    control_char_fmt: str,
    escape_delete: bool,
) -> str:
    r"""Format a string using backslash escaping plus control-char escaping.

    Combines :func:`format_string_backslash`-style replacements with
    :func:`escape_control_chars` in one step.  The *control_char_fmt*
    is passed directly to :func:`escape_control_chars`.

    Example with ``control_char_fmt="\\x{:02x}"`` and ``value="\x01hi"``
    returns ``'"\\x01hi"'``.

    *escape_delete* is passed through to :func:`escape_control_chars`.
    """
    escaped = _backslash_escape(value=value, quote_char='"')
    escaped = escape_control_chars(
        value=escaped,
        fmt=control_char_fmt,
        escape_delete=escape_delete,
    )
    return f'"{escaped}"'


@beartype
def format_string_backslash_single_minimal(value: str) -> str:
    r"""Format a string with single quotes, escaping only ``\\`` and ``\'``.

    For languages like Ruby, Perl, and PHP where single-quoted strings
    only recognize ``\\`` and ``\'`` as escape sequences.  Actual
    newline, carriage-return, and tab characters are embedded literally.

    Example: ``hello 'world'`` -> ``'hello \'world\''``.
    """
    escaped = value.replace("\\", "\\\\").replace("'", "\\'")
    return f"'{escaped}'"
