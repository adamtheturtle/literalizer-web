"""Collection opener functions and typed opener configuration."""

import datetime as dt
from collections.abc import Callable, Sequence
from dataclasses import dataclass, field
from typing import Protocol, Self, override, runtime_checkable

from beartype import beartype

from literalizer._formatters.type_inference import (
    BeyondI64,
    DictType,
    ListType,
    MixedNumeric,
    WideInt,
    infer_element_type,
)
from literalizer._types import Scalar, Value


@beartype
@dataclass(frozen=True, kw_only=True)
class CollectionSignature:
    """The producer's selected type, length policy, and fallback
    policy.
    """

    type_key: str | None
    arity: int | None
    arity_decision: bool | Callable[[], bool] = field(compare=False)
    fallback_decision: bool | Callable[[], bool] = field(compare=False)
    narrowing_decision: bool | Callable[[], bool] = field(compare=False)
    uses_fallback_decision: bool | Callable[[], bool] = field(compare=False)

    @property
    def arity_dependent(self) -> bool:
        """Read the producer's arity dependent decision."""
        return _decision_value(decision=self.arity_decision)

    @property
    def stable_fallback(self) -> bool:
        """Read the producer's stable fallback decision."""
        return _decision_value(decision=self.fallback_decision)

    @property
    def narrows(self) -> bool:
        """Read the producer's narrows decision."""
        return _decision_value(decision=self.narrowing_decision)

    @property
    def uses_fallback(self) -> bool:
        """Read the producer's uses fallback decision."""
        return _decision_value(decision=self.uses_fallback_decision)

    @override
    def __hash__(self) -> int:
        """Compare target identity and arity independently of policy flags."""
        return hash((self.type_key, self.arity))


@runtime_checkable
class _SignatureOpen(Protocol):
    """An opener that can retain its decision before spelling a
    literal.
    """

    def signature(
        self, items: list[Value] | dict[Scalar, Value], /
    ) -> CollectionSignature:
        """Infer the target collection signature."""
        ...


@beartype
def collection_signature(
    opener: Callable[..., str],
    items: list[Value] | dict[Scalar, Value],
    /,
) -> CollectionSignature:
    """Read native inference facts, retaining opaque callback
    compatibility.

    Custom openers without a signature still own their text-only contract.
    Their compatibility probes stay at this callback boundary.
    """
    if isinstance(opener, _SignatureOpen):
        return opener.signature(items)
    return _opaque_collection_signature(opener=opener, items=items)


@beartype
def _decision_value(*, decision: bool | Callable[[], bool]) -> bool:
    """Evaluate opaque policy only at the boundary that needs it."""
    if isinstance(decision, bool):
        return decision
    return decision()


@beartype
def _opaque_collection_signature(
    *, opener: Callable[..., str], items: list[Value] | dict[Scalar, Value]
) -> CollectionSignature:
    """Preserve conditional inference for text-only custom callbacks."""
    code = opener(items)
    if isinstance(items, dict):

        @beartype
        def _narrows() -> bool:
            """Infer narrowing only when map widening asks for it."""
            return opener({"_probe": "s"}) != opener({"_probe": 1})

        @beartype
        def _stable() -> bool:
            """Infer map fallback policy only after narrowing is known."""
            return opener({"_a": 1, "_b": "s"}) == opener(
                {"_a": 1.5, "_b": False}
            )

        return CollectionSignature(
            type_key=code,
            arity=None,
            arity_decision=False,
            fallback_decision=_stable,
            narrowing_decision=_narrows,
            uses_fallback_decision=False,
        )

    @beartype
    def _length_bearing() -> bool:
        """Probe length only where a sibling's literal might be
        borrowed.
        """
        return code != opener([*items, items[0]])

    @beartype
    def _fallback() -> bool:
        """Infer the custom sequence's fallback only when widening needs
        it.
        """
        return opener([]) == opener([1, "probe"])

    @beartype
    def _uses_fallback() -> bool:
        """Check anonymous-element elision against the custom empty opener."""
        return code == opener([])

    return CollectionSignature(
        type_key=code,
        arity=None,
        arity_decision=_length_bearing if bool(items) else False,
        fallback_decision=_fallback,
        narrowing_decision=True,
        uses_fallback_decision=_uses_fallback,
    )


@beartype
@dataclass(frozen=True, kw_only=True)
class SignatureOpen[Items: list[Value] | dict[Scalar, Value]]:
    """Keep a producer's inference callable beside its existing
    renderer.
    """

    render: Callable[[Items], str]
    infer: Callable[[Items], CollectionSignature]

    def __call__(self, items: Items, /) -> str:
        """Spell the opener selected by the producer."""
        return self.render(items)

    def signature(self, items: Items, /) -> CollectionSignature:
        """Return the producer's retained inference facts."""
        return self.infer(items)


@beartype
def signature_open[Items: list[Value] | dict[Scalar, Value]](
    *,
    render: Callable[[Items], str],
    infer: Callable[[Items], CollectionSignature],
) -> SignatureOpen[Items]:
    """Attach producer-owned inference to the compatible string
    callback.
    """
    return SignatureOpen(render=render, infer=infer)


@beartype
class CollectionOverride(str):
    """A selected opener whose inference facts survive sibling
    inference.
    """

    __slots__ = ("_original", "_signature")

    _signature: CollectionSignature
    _original: str

    def __new__(cls, code: str, /, *, signature: CollectionSignature) -> Self:
        """Allocate text; the initializer retains producer metadata."""
        del signature
        return super().__new__(cls, object=code)

    def __init__(
        self, code: str, /, *, signature: CollectionSignature
    ) -> None:
        """Keep a chosen opener and its original type-bearing value."""
        self._signature = signature
        self._original = code

    @property
    def signature(self) -> CollectionSignature:
        """The producer's already selected collection signature."""
        return self._signature

    @property
    def original(self) -> str:
        """The original opener, including initializer type metadata."""
        return self._original


@beartype
def selected_collection_open(
    opener: Callable[..., str],
    items: list[Value] | dict[Scalar, Value],
    /,
) -> str:
    """Infer first, then spell an opener that carries the same
    decision.
    """
    signature = collection_signature(opener, items)
    return CollectionOverride(opener(items), signature=signature)


@beartype
@dataclass(frozen=True)
class FixedOpen:
    """An opener that returns ``open_str`` whatever the collection holds.

    A class rather than a closure so callers can recognize a
    content-insensitive opener and read its delimiter back off
    ``open_str``.  The JSON-native document fast path
    (:mod:`literalizer._json_native_document`) uses that to hoist the
    delimiter out of the per-node recursion, and to establish that none
    of the sibling-widening overrides in the shared renderer can change
    the opener a collection renders with.
    """

    open_str: str

    @staticmethod
    def signature(
        _items: list[Value] | dict[Scalar, Value], /
    ) -> CollectionSignature:
        """A fixed delimiter never narrows or depends on collection length."""
        return CollectionSignature(
            type_key=None,
            arity=None,
            arity_decision=False,
            fallback_decision=True,
            narrowing_decision=False,
            uses_fallback_decision=True,
        )

    def __call__(self, _items: list[Value] | dict[Scalar, Value], /) -> str:
        """Return the fixed opening delimiter, ignoring *_items*."""
        return self.open_str


@beartype
@dataclass(frozen=True)
class SequenceSurrogateSetOpen(FixedOpen):
    """Mark a fixed sequence opener whose set input is rejected.

    Public rendering rejects this configuration before calling the
    opener, so it does not need content-dependent set inference.
    """


@beartype
def sequence_surrogate_set_open(
    *,
    open_str: str,
) -> Callable[[list[Value]], str]:
    """Mark *open_str* as opening a sequence rather than a native set."""
    return SequenceSurrogateSetOpen(open_str=open_str)


@beartype
def fixed_open(
    *, open_str: str
) -> Callable[[list[Value] | dict[Scalar, Value]], str]:
    """Return an opener callable that always returns *open_str*.

    Use this as ``sequence_open``, ``set_open``, ``dict_open``, or
    ``ordered_map_open`` when the opening delimiter is a fixed string
    that does not depend on the collection contents.

    Example: ``fixed_open(open_str="[")([1, 2, 3])`` -> ``"["``.
    """
    return FixedOpen(open_str=open_str)


@beartype
def make_element_to_type(
    *,
    str_type: str | None,
    bool_type: str | None,
    int_type: str | None,
    float_type: str | None,
    bytes_type: str | None,
    mixed_numeric_type: str | None,
    date_type: str | None,
    datetime_type: str | None,
    time_type: str | None,
    list_template: str,
    enable_list_type: bool,
    dict_type_template: str | None,
    dict_value_to_type: Callable[[type | ListType | DictType], str | None]
    | None,
    fallback_value_type: str | None,
    wide_int_type: str | None,
    beyond_i64_type: str | None,
) -> Callable[[type | ListType | DictType], str | None]:
    """Create a recursive type resolver from scalar types and a list
    template.

    The *list_template* must contain ``{inner}`` which will be replaced
    with the recursively-resolved inner type name.  When
    *enable_list_type* is ``False`` the resolver returns ``None`` for
    ``ListType`` so the caller can fall back to a generic value type;
    *list_template* is then ignored.

    When *dict_type_template* is given it must contain ``{inner}``
    and is used to resolve ``DictType`` elements.  *fallback_value_type*
    is used when the dict value type is ``None`` or cannot be resolved.
    *dict_value_to_type*, where given, resolves the value type inside a
    ``DictType`` in place of this resolver, so a mapping element names
    the type the mapping opener would write (issue #4515).

    Example::

        go_element_to_type = make_element_to_type(
            dict_value_to_type=None,
            str_type="string",
            int_type="int",
            list_template="[]{inner}",
            dict_type_template="map[string]{inner}",
            fallback_value_type="any",
        )
    """
    collected_scalar_types: dict[type, str]
    effective_wide_int_type: str | None

    if wide_int_type is not None:
        effective_wide_int_type = wide_int_type
    else:
        effective_wide_int_type = int_type
    effective_beyond_i64_type: str | None

    if beyond_i64_type is not None:
        effective_beyond_i64_type = beyond_i64_type
    else:
        effective_beyond_i64_type = int_type
    collected_collected_scalar_types: dict[type, str] = {
        entry_py_type: entry_name
        for entry_py_type, entry_name in (
            (str, str_type),
            (bool, bool_type),
            (int, int_type),
            (float, float_type),
            (bytes, bytes_type),
            (MixedNumeric, mixed_numeric_type),
            (WideInt, effective_wide_int_type),
            (BeyondI64, effective_beyond_i64_type),
            (dt.date, date_type),
            (dt.datetime, datetime_type),
            (dt.time, time_type),
        )
        if entry_name is not None
    }
    collected_scalar_types = collected_collected_scalar_types
    scalar_types: dict[type, str] = collected_scalar_types

    @beartype
    def element_to_type(
        element_type: type | ListType | DictType,
    ) -> str | None:
        """Delegate to module-level implementation."""
        return _resolve_element_to_type(
            element_type=element_type,
            scalar_types=scalar_types,
            list_template=list_template,
            enable_list_type=enable_list_type,
            dict_type_template=dict_type_template,
            dict_value_to_type=dict_value_to_type,
            fallback_value_type=fallback_value_type,
        )

    return element_to_type


@beartype
def make_narrowed_empty_form(
    *,
    element_to_type: Callable[[type | ListType | DictType], str | None],
    template: str,
    fallback_type: str,
) -> Callable[[Sequence[list[Value]]], str]:
    """Return a ``narrowed_empty_form`` callback.

    The returned function reads the inferred element type of the first
    non-empty sibling list, maps it through *element_to_type*, and
    substitutes the resolved type name into *template* (which must
    contain ``{type}``).  *fallback_type* is used when the type cannot
    be resolved (heterogeneous siblings, or an element type that
    *element_to_type* does not handle).

    Example::

        narrowed_empty_form = make_narrowed_empty_form(
            element_to_type=mojo_element_to_type,
            template="List[{type}]()",
            fallback_type="String",
        )
    """

    @beartype
    def _narrowed_empty_form(siblings: Sequence[list[Value]]) -> str:
        """Compute the typed empty literal for the parent's siblings."""
        return template.format(
            type=_narrowed_type_name(
                items=siblings[0],
                element_to_type=element_to_type,
                fallback_type=fallback_type,
            )
        )

    return _narrowed_empty_form


@beartype
def _narrowed_type_name(
    *,
    items: list[Value],
    element_to_type: Callable[[type | ListType | DictType], str | None],
    fallback_type: str,
) -> str:
    """Resolve the type name a narrowed empty literal borrows from a
    non-empty sibling.

    Reads the inferred element type of *items*, maps it through
    *element_to_type*, and falls back to *fallback_type* when the type
    cannot be resolved (heterogeneous items, or an element type that
    *element_to_type* does not handle).
    """
    inner = infer_element_type(items=items)
    type_name = None
    if inner is not None:
        type_name = element_to_type(inner)
    if type_name is not None:
        return type_name
    return fallback_type


@beartype
def _resolve_element_to_type(
    *,
    element_type: type | ListType | DictType,
    scalar_types: dict[type, str],
    list_template: str,
    enable_list_type: bool,
    dict_type_template: str | None,
    dict_value_to_type: Callable[[type | ListType | DictType], str | None]
    | None,
    fallback_value_type: str | None,
) -> str | None:
    """Resolve a Python element type to a language type name."""
    match element_type:
        case DictType():
            if dict_type_template is None:
                return None
            resolved: str | None = None
            if element_type.value_type is not None:
                resolved = _resolve_dict_value_type(
                    value_type=element_type.value_type,
                    scalar_types=scalar_types,
                    list_template=list_template,
                    enable_list_type=enable_list_type,
                    dict_type_template=dict_type_template,
                    dict_value_to_type=dict_value_to_type,
                    fallback_value_type=fallback_value_type,
                )
            inner = fallback_value_type
            if resolved is not None:
                inner = resolved
            if inner is None:
                return None
            return dict_type_template.format(inner=inner)
        case ListType():
            inner = None
            if enable_list_type:
                inner = _resolve_element_to_type(
                    element_type=element_type.inner,
                    scalar_types=scalar_types,
                    list_template=list_template,
                    enable_list_type=enable_list_type,
                    dict_type_template=dict_type_template,
                    dict_value_to_type=dict_value_to_type,
                    fallback_value_type=fallback_value_type,
                )
            if inner is None:
                return None
            return list_template.format(inner=inner)
        case _:
            return scalar_types.get(element_type)


@beartype
def _resolve_dict_value_type(
    *,
    value_type: type | ListType | DictType,
    scalar_types: dict[type, str],
    list_template: str,
    enable_list_type: bool,
    dict_type_template: str | None,
    dict_value_to_type: Callable[[type | ListType | DictType], str | None]
    | None,
    fallback_value_type: str | None,
) -> str | None:
    """Resolve the value type a mapping element is written with.

    A mapping element names the type its own opener would give it, so
    where a caller hands over the resolver that opener uses, the value
    goes through that one.  Naming a value type the mapping renderer
    would not write leaves the element and its declared type disagreeing
    (issue #4515).
    """
    if dict_value_to_type is not None:
        return dict_value_to_type(value_type)
    return _resolve_element_to_type(
        element_type=value_type,
        scalar_types=scalar_types,
        list_template=list_template,
        enable_list_type=enable_list_type,
        dict_type_template=dict_type_template,
        dict_value_to_type=None,
        fallback_value_type=fallback_value_type,
    )


@beartype
@dataclass(frozen=True, kw_only=True)
class _TypeOpen:
    """Resolve a target type before spelling the collection delimiter."""

    element_to_type: Callable[[type | ListType | DictType], str | None]
    opener_template: str

    def __call__(
        self, element_type: type | ListType | DictType, /
    ) -> str | None:
        """Spell the opener for an inferred target type."""
        type_name = self.element_to_type(element_type)
        if type_name is None:
            return None
        return self.opener_template.format(type_name=type_name)


@beartype
def make_type_to_opener(
    *,
    element_to_type: Callable[[type | ListType | DictType], str | None],
    opener_template: str,
) -> Callable[[type | ListType | DictType], str | None]:
    """Create a typed collection opener from an element-to-type resolver.

    The *opener_template* must contain ``{type_name}`` which will be
    replaced with the resolved type name.

    Example::

        go_type_to_opener = make_type_to_opener(
            element_to_type=go_element_to_type,
            opener_template="[]{type_name}{{",
        )
    """
    return _TypeOpen(
        element_to_type=element_to_type, opener_template=opener_template
    )


@beartype
def _typed_signature(
    *,
    items: list[Value],
    type_to_opener: Callable[[type | ListType | DictType], str | None],
    fallback: str,
) -> CollectionSignature:
    """Retain the typed producer's target identity and stable fallback."""
    element_type = infer_element_type(items=items)
    type_name = None
    if element_type is not None:
        if isinstance(type_to_opener, _TypeOpen):
            type_name = type_to_opener.element_to_type(element_type)
        else:
            type_name = type_to_opener(element_type)
    uses_fallback = type_name is None or type_name == ""
    return CollectionSignature(
        type_key=fallback if uses_fallback else type_name,
        arity=None,
        arity_decision=False,
        fallback_decision=True,
        narrowing_decision=True,
        uses_fallback_decision=uses_fallback,
    )


@beartype
def _typed_collection_open_impl(
    items: list[Value],
    type_to_opener: Callable[[type | ListType | DictType], str | None],
    fallback: str,
) -> str:
    """Infer element type and return the opener or fallback."""
    element_type = infer_element_type(items=items)
    if element_type is None:
        return fallback
    opener = type_to_opener(element_type)
    if opener is not None and len(opener) > 0:
        return opener
    return fallback


@beartype
def typed_collection_open(
    *,
    type_to_opener: Callable[[type | ListType | DictType], str | None],
    fallback: str,
) -> Callable[[list[Value]], str]:
    """Return a callable that infers the common element type and
    delegates to *type_to_opener*.

    Works for both sequences and sets — any collection whose items
    are presented as a ``list[Value]``.

    When inference is not possible or *type_to_opener* returns
    ``None``, *fallback* is used instead.

    Example::

        def my_opener(element_type: type | ListType) -> str | None:
            if element_type is str:
                return "[]string{"
            return None

        sequence_open = typed_collection_open(
            type_to_opener=my_opener,
            fallback="[]any{",
        )
    """

    @beartype
    def _open(items: list[Value]) -> str:
        """Delegate to module-level implementation."""
        return _typed_collection_open_impl(
            items=items, type_to_opener=type_to_opener, fallback=fallback
        )

    @beartype
    def _signature(items: list[Value], /) -> CollectionSignature:
        """Infer the collection signature before rendering its opener."""
        return _typed_signature(
            items=items, type_to_opener=type_to_opener, fallback=fallback
        )

    return signature_open(render=_open, infer=_signature)


@beartype
def _typed_dict_open_impl(
    items: dict[Scalar, Value],
    type_to_opener: Callable[[type | ListType | DictType], str | None],
    fallback: str,
) -> str:
    """Infer value type and return the opener or fallback."""
    element_type = infer_element_type(items=list(items.values()))
    if element_type is None:
        return fallback
    opener = type_to_opener(element_type)
    if opener is not None and len(opener) > 0:
        return opener
    return fallback


@beartype
def typed_dict_open(
    *,
    type_to_opener: Callable[[type | ListType | DictType], str | None],
    fallback: str,
) -> Callable[[dict[Scalar, Value]], str]:
    """Return a ``dict_open`` callable that infers a common value type
    and delegates to *type_to_opener*.

    When inference is not possible or *type_to_opener* returns
    ``None``, *fallback* is used instead.

    Example::

        def my_opener(element_type: type | ListType) -> str | None:
            if element_type is str:
                return "map[string]string{"
            return None

        dict_open = typed_dict_open(
            type_to_opener=my_opener,
            fallback="map[string]any{",
        )
    """

    @beartype
    def _open(items: dict[Scalar, Value]) -> str:
        """Delegate to module-level implementation."""
        return _typed_dict_open_impl(
            items=items, type_to_opener=type_to_opener, fallback=fallback
        )

    @beartype
    def _signature(items: dict[Scalar, Value], /) -> CollectionSignature:
        """Infer the mapping signature before rendering its opener."""
        return _typed_signature(
            items=list(items.values()),
            type_to_opener=type_to_opener,
            fallback=fallback,
        )

    return signature_open(render=_open, infer=_signature)


@beartype
@dataclass(frozen=True, kw_only=True)
class CollectionType:
    """A literal opener and declared type from one inference decision."""

    opener: str
    declared_type: str


@beartype
def infer_collection_type(
    *,
    items: list[Value],
    element_to_type: Callable[[type | ListType | DictType], str | None],
    opener_template: str,
    declared_type_template: str,
    fallback: CollectionType,
) -> CollectionType:
    """Resolve an element type once for both literal and annotation."""
    element_type = infer_element_type(items=items)
    if element_type is None:
        return fallback
    type_name = element_to_type(element_type)
    if type_name is None or type_name == "":
        return fallback
    return CollectionType(
        opener=opener_template.format(type_name=type_name),
        declared_type=declared_type_template.format(type_name=type_name),
    )


@beartype
def collection_type_open[Items: list[Value] | dict[Scalar, Value]](
    *, infer: Callable[[Items], CollectionType], fallback_type: str
) -> SignatureOpen[Items]:
    """Keep an explicit target type as the collection's inference key."""

    @beartype
    def _render(items: Items, /) -> str:
        """Spell the opener selected with the target type."""
        return infer(items).opener

    @beartype
    def _signature(items: Items, /) -> CollectionSignature:
        """Keep target identity rather than comparing literal
        delimiters.
        """
        selected = infer(items)
        return CollectionSignature(
            type_key=selected.declared_type,
            arity=None,
            arity_decision=False,
            fallback_decision=True,
            narrowing_decision=True,
            uses_fallback_decision=selected.declared_type == fallback_type,
        )

    return signature_open(render=_render, infer=_signature)


@beartype
def validated_fixed_open[Items: list[Value] | dict[Scalar, Value]](
    *, render: Callable[[Items], str]
) -> SignatureOpen[Items]:
    """Preserve validation around a content-insensitive native
    delimiter.
    """
    return signature_open(
        render=render, infer=FixedOpen(open_str="").signature
    )


@beartype
@dataclass(frozen=True)
class TypeOpeners:
    """Resolved type-to-opener functions for sequences, dicts, and
    sets.
    """

    seq: Callable[[type | ListType | DictType], str | None]
    dict: Callable[[type | ListType | DictType], str | None]
    set: Callable[[type | ListType | DictType], str | None]
    seq_element_type: Callable[[type | ListType | DictType], str | None]
    dict_element_type: Callable[[type | ListType | DictType], str | None]


@beartype
class TypedOpenerConfig:
    """Configuration for typed collection openers in a language.

    Holds scalar type mappings and template strings needed to build
    type-to-opener functions.
    """

    def __init__(
        self,
        *,
        str_type: str | None,
        bool_type: str | None,
        int_type: str | None,
        float_type: str | None,
        bytes_type: str | None,
        mixed_numeric_type: str | None,
        date_type: str | None,
        datetime_type: str | None,
        time_type: str | None,
        list_template: str,
        sequence_opener_template: str,
        dict_opener_template: str,
        set_opener_template: str,
        dict_type_template: str | None,
        fallback_value_type: str | None,
        wide_int_type: str | None,
        beyond_i64_type: str,
    ) -> None:
        """Initialize with scalar type mappings and template strings."""
        self._str_type = str_type
        self._bool_type = bool_type
        self._int_type = int_type
        self._float_type = float_type
        self._bytes_type = bytes_type
        self._mixed_numeric_type = mixed_numeric_type
        self._date_type = date_type
        self._datetime_type = datetime_type
        self._time_type = time_type
        self._list_template = list_template
        self._sequence_opener_template = sequence_opener_template
        self._dict_opener_template = dict_opener_template
        self._set_opener_template = set_opener_template
        self._dict_type_template = dict_type_template
        self._fallback_value_type = fallback_value_type
        self._wide_int_type = wide_int_type
        self._beyond_i64_type = beyond_i64_type

    def type_name(self, py_type: type) -> str | None:
        """Look up the language type name for a Python type."""
        return self._scalar_types().get(py_type)

    def _scalar_types(self) -> dict[type, str]:
        """Build a dict mapping Python types to language type names."""
        collected_entries: dict[type, str]
        effective_self: str | None
        if self._wide_int_type is not None:
            effective_self = self._wide_int_type
        else:
            effective_self = self._int_type
        collected_collected_entries: dict[type, str] = {
            entry_py_type: entry_name
            for entry_py_type, entry_name in (
                (str, self._str_type),
                (bool, self._bool_type),
                (int, self._int_type),
                (float, self._float_type),
                (bytes, self._bytes_type),
                (MixedNumeric, self._mixed_numeric_type),
                (WideInt, effective_self),
                (BeyondI64, self._beyond_i64_type),
                (dt.date, self._date_type),
                (dt.datetime, self._datetime_type),
                (dt.time, self._time_type),
            )
            if entry_name is not None
        }
        collected_entries = collected_collected_entries
        return collected_entries

    def element_to_type(
        self,
        *,
        list_template: str | None,
        enable_list_type: bool,
        date_type: str | None,
        datetime_type: str | None,
        enable_dict_type: bool,
        dict_value_to_type: Callable[[type | ListType | DictType], str | None]
        | None,
        dict_key_type: str,
    ) -> Callable[[type | ListType | DictType], str | None]:
        """Build an element-to-type resolver.

        If *list_template* is given it overrides the default.  When
        *enable_list_type* is ``False`` the resolver returns ``None``
        for ``ListType`` so callers can fall back to a generic value
        type; *list_template* is then ignored.
        If *date_type* or *datetime_type* is given they override the
        base values.  When *enable_dict_type* is ``False`` the
        resolver will not handle ``DictType``.

        When *dict_key_type* is given, ``{key_type}`` placeholders in
        ``dict_type_template`` are resolved before the template is
        used.
        """
        raw_template = None
        if enable_dict_type:
            raw_template = self._dict_type_template
        resolved_template = raw_template
        if resolved_template is not None and len(dict_key_type) > 0:
            resolved_template = resolved_template.replace(
                "{key_type}", dict_key_type
            )
        effective_date_type = date_type
        if effective_date_type is None:
            effective_date_type = self._date_type
        effective_datetime_type = datetime_type
        if effective_datetime_type is None:
            effective_datetime_type = self._datetime_type
        effective_list_template = list_template
        if effective_list_template is None:
            effective_list_template = self._list_template
        effective_fallback_value_type = None
        if enable_dict_type:
            effective_fallback_value_type = self._fallback_value_type
        return make_element_to_type(
            dict_value_to_type=dict_value_to_type,
            str_type=self._str_type,
            bool_type=self._bool_type,
            int_type=self._int_type,
            wide_int_type=self._wide_int_type,
            beyond_i64_type=self._beyond_i64_type,
            float_type=self._float_type,
            bytes_type=self._bytes_type,
            mixed_numeric_type=self._mixed_numeric_type,
            date_type=(effective_date_type),
            datetime_type=(effective_datetime_type),
            time_type=self._time_type,
            list_template=(effective_list_template),
            enable_list_type=enable_list_type,
            dict_type_template=resolved_template,
            fallback_value_type=(effective_fallback_value_type),
        )

    def build(
        self,
        *,
        date_type: str | None,
        datetime_type: str | None,
        set_opener_template: str | None,
        narrow_dict_values: bool,
        narrow_list_values: bool,
        dict_key_type: str,
    ) -> TypeOpeners:
        """Build openers from the base scalar type mapping plus
        overrides.

        If *date_type* or *datetime_type* is given, they override the
        base values.  If *set_opener_template* is given it overrides
        the template used for ``set`` openers, allowing a single
        ``TypedOpenerConfig`` to serve multiple set formats.

        When *narrow_dict_values* is ``False``, the dict and set
        openers use a resolver that cannot resolve ``DictType``.
        Set this to ``False`` when the ``list_template``
        does not match the actual sequence format (e.g.
        ``Array<…>`` vs ``List<…>``), which would cause type
        mismatches in the generated code.

        *narrow_list_values* does the same for ``ListType``.  Set it to
        ``False`` when the active sequence format renders something the
        element type alone cannot name -- a Dart record under ``TUPLE``,
        whose arity is part of its type (issue #3925).

        When *dict_key_type* is given, ``{key_type}`` placeholders in
        ``dict_opener_template`` and ``dict_type_template`` are
        resolved before the templates are used.
        """
        dict_set_resolver = self.element_to_type(
            list_template=None,
            enable_list_type=narrow_list_values,
            date_type=date_type,
            datetime_type=datetime_type,
            enable_dict_type=narrow_dict_values,
            dict_value_to_type=None,
            dict_key_type=dict_key_type,
        )
        seq_resolver = self.element_to_type(
            list_template=None,
            enable_list_type=True,
            date_type=date_type,
            datetime_type=datetime_type,
            enable_dict_type=True,
            dict_value_to_type=dict_set_resolver,
            dict_key_type=dict_key_type,
        )
        if len(dict_key_type) > 0:
            resolved_dict_opener = self._dict_opener_template.replace(
                "{key_type}",
                dict_key_type,
            )
        else:
            resolved_dict_opener = self._dict_opener_template
        effective_opener_template = set_opener_template
        if effective_opener_template is None:
            effective_opener_template = self._set_opener_template
        return TypeOpeners(
            seq_element_type=seq_resolver,
            dict_element_type=dict_set_resolver,
            seq=make_type_to_opener(
                element_to_type=seq_resolver,
                opener_template=self._sequence_opener_template,
            ),
            dict=make_type_to_opener(
                element_to_type=dict_set_resolver,
                opener_template=resolved_dict_opener,
            ),
            set=make_type_to_opener(
                element_to_type=dict_set_resolver,
                opener_template=(effective_opener_template),
            ),
        )
