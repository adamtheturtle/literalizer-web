"""Resolve YAML and TOML comments and apply them to literalized output."""

import dataclasses
from collections.abc import Mapping
from io import StringIO

from beartype import beartype
from ruamel.yaml.comments import CommentedMap, CommentedSeq, CommentedSet
from tomlkit.toml_document import TOMLDocument

from literalizer._comments import (
    CollectionComments,
    ElementComments,
    apply_collection_comments,
    extract_toml_comments,
    extract_yaml_comments,
    literalize_yaml_scalar,
)
from literalizer._language import Language
from literalizer._parsing import get_yaml


@beartype
def _all_mapping_values_null(*, data: Mapping[object, object]) -> bool:
    """Return whether every mapping value is null."""
    return all(value is None for value in data.values())


@beartype
def _filter_null_dict_comments(
    *,
    data: CommentedMap,
    collection_comments: CollectionComments,
) -> CollectionComments:
    """Remove comments for null-valued dict entries.

    When a language skips null dict values, the associated comments
    are redistributed to the next non-null entry.
    """
    pending: list[str] = []
    filtered_elements_list: list[ElementComments] = []
    keys: list[object] = list(data)
    for key, ec in zip(keys, collection_comments.elements, strict=True):
        if data[key] is None:
            pending.extend(ec.before)
            if len(ec.inline) > 0:
                pending.append(ec.inline)
        else:
            new_before = (*pending, *ec.before)
            pending = []
            filtered_elements_list.append(
                dataclasses.replace(ec, before=new_before),
            )
    return dataclasses.replace(
        collection_comments,
        elements=tuple(filtered_elements_list),
        trailing=(*pending, *collection_comments.trailing),
    )


@beartype
@dataclasses.dataclass(frozen=True)
class ResolvedComments:
    """Result of resolving YAML comments for a collection or scalar."""

    result: str
    pending: CollectionComments | None
    pending_scalar_before: tuple[str, ...]
    """Already-formatted comment lines to prepend before the variable
    declaration.  Used for scalar before-comments when the language
    does not support them inline (see
    :attr:`~literalizer.Language.supports_scalar_before_comments`).
    """


@beartype
def _resolve_collection_comments(
    *,
    collection_comments: CollectionComments,
    base: str,
    language: Language,
    comment_prefix: str,
    comment_suffix: str,
    comment_line_prefix: str,
    structurally_applied: bool,
) -> ResolvedComments:
    """Resolve pre-extracted collection comments."""
    if language.supports_collection_comments and structurally_applied:
        # Collection comments are applied while the renderer still has
        # structural element boundaries.  Reapplying them here would have
        # to infer those boundaries from rendered lines, which is ambiguous
        # when a top-level element is itself multiline.
        return ResolvedComments(
            result=base,
            pending=None,
            pending_scalar_before=(),
        )
    if not language.supports_collection_comments:
        return ResolvedComments(
            result=base,
            pending=collection_comments,
            pending_scalar_before=(),
        )
    result = apply_collection_comments(
        collection_comments=collection_comments,
        base=base,
        comment_prefix=comment_prefix,
        comment_suffix=comment_suffix,
        comment_line_prefix=comment_line_prefix,
    )
    return ResolvedComments(
        result=result,
        pending=None,
        pending_scalar_before=(),
    )


@beartype
def _resolve_yaml_collection_comments(
    *,
    ruamel_data: CommentedSeq | CommentedMap,
    base: str,
    language: Language,
    comment_prefix: str,
    comment_suffix: str,
    comment_line_prefix: str,
) -> ResolvedComments:
    """Resolve comments for a YAML list or dict."""
    collection_comments = extract_yaml_comments(
        ruamel_data=ruamel_data,
        nested=False,
        hoist_nested_inline=False,
    )

    if language.skip_null_dict_values and isinstance(
        ruamel_data, CommentedMap
    ):
        collection_comments = _filter_null_dict_comments(
            data=ruamel_data,
            collection_comments=collection_comments,
        )

    return _resolve_collection_comments(
        collection_comments=collection_comments,
        base=base,
        language=language,
        comment_prefix=comment_prefix,
        comment_suffix=comment_suffix,
        comment_line_prefix=comment_line_prefix,
        structurally_applied=not (
            language.skip_null_dict_values
            and isinstance(ruamel_data, CommentedMap)
            and _all_mapping_values_null(data=ruamel_data)
        ),
    )


@beartype
def resolve_yaml_comments(
    *,
    yaml_string: str,
    raw_data: object,
    base: str,
    language: Language,
    comment_prefix: str,
    comment_suffix: str,
    comment_line_prefix: str,
    line_prefix: str,
) -> ResolvedComments:
    """Resolve comments using the already-parsed round-trip YAML data.

    *raw_data* is the comment-preserving structure produced by
    :func:`_parse_yaml` (a :class:`CommentedMap`, :class:`CommentedSeq`,
    :class:`CommentedSet`, or scalar).  Scalars still need a separate
    token scan because :meth:`YAML.load` discards comment tokens that
    are not attached to a collection.
    """
    # https://sourceforge.net/p/ruamel-yaml/tickets/328/
    match raw_data:
        case CommentedSet():
            return _resolve_collection_comments(
                collection_comments=extract_yaml_comments(
                    ruamel_data=raw_data,
                    nested=False,
                    hoist_nested_inline=False,
                ),
                base=base,
                language=language,
                comment_prefix=comment_prefix,
                comment_suffix=comment_suffix,
                comment_line_prefix=comment_line_prefix,
                structurally_applied=True,
            )
        case CommentedSeq() | CommentedMap():
            return _resolve_yaml_collection_comments(
                ruamel_data=raw_data,
                base=base,
                language=language,
                comment_prefix=comment_prefix,
                comment_suffix=comment_suffix,
                comment_line_prefix=comment_line_prefix,
            )
        case _:
            stream = StringIO(initial_value=yaml_string)
            tokens = get_yaml().scan(stream=stream)
            scalar_result = literalize_yaml_scalar(
                tokens=tokens,
                base=base,
                comment_prefix=comment_prefix,
                comment_suffix=comment_suffix,
                line_prefix=line_prefix,
                supports_scalar_before_comments=(
                    language.supports_scalar_before_comments
                ),
                supports_scalar_inline_comments=(
                    language.supports_scalar_inline_comments
                ),
            )
            return ResolvedComments(
                result=scalar_result.result,
                pending=None,
                pending_scalar_before=scalar_result.pending_before,
            )


@beartype
def resolve_toml_comments(
    *,
    toml_doc: TOMLDocument,
    base: str,
    language: Language,
    comment_prefix: str,
    comment_suffix: str,
    comment_line_prefix: str,
) -> ResolvedComments:
    """Extract and resolve comments from a tomlkit document."""
    return _resolve_collection_comments(
        collection_comments=extract_toml_comments(toml_doc=toml_doc),
        base=base,
        language=language,
        comment_prefix=comment_prefix,
        comment_suffix=comment_suffix,
        comment_line_prefix=comment_line_prefix,
        # The renderer applies these while it still knows where each
        # element begins, the way it does for YAML (issue #4483).
        structurally_applied=True,
    )
