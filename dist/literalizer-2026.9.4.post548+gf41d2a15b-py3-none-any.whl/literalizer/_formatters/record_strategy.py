"""Language-agnostic orchestration for the ``RECORD`` heterogeneous
strategy.

The ``RECORD`` strategy renders record-shaped dicts (non-empty,
string-keyed) as generated struct/record declarations plus matching
literals, rather than a homogeneous map.  Shape detection lives in
:mod:`literalizer._formatters.type_inference`; this module owns the
parts that are the same for every target language (document-order
shape naming, post-order declaration emission) and delegates the
language-specific syntax to a :class:`RecordRenderer`.

Declaration field types are derived from the raw field value through
the language's own collection openers (the same opener functions the
value formatter uses), not by re-parsing the formatted literal.
Because a record field is formatted with no sibling override, the
opener a language returns for the field's value is exactly the one it
emitted (including a widening to an ``any``-typed container), so the
declared type still matches the rendered literal.  The behavior caches
the first-seen :class:`RecordFieldType` request per shape during
literal rendering; the preamble (assembled after all literals are
formatted) reads that cache.

Rust keeps its own copy of this logic because it additionally
supports optional-field unification; this module deliberately omits
that (out of scope for the non-Rust ports), so
:attr:`RecordShape.optional_keys` is always empty here.  Splitting
same-key-set shapes whose field types conflict (issue #2888) is
supported behind the ``split_conflicting_field_types`` flag of
:func:`build_record_strategy`; because this module has no
optional-field unification its refinement is simpler than Rust's (no
absent-key wildcard rule), and it reuses each language's own
:attr:`RecordRenderer.field_type` hook as the field-type signature
rather than a separate mirror function.  This module also supports
``record_shape_names`` (custom per-shape struct names, keyed by the
shape's key-set).
"""

import dataclasses
import functools
import re
from collections import Counter
from collections.abc import Callable, Hashable, Mapping, Sequence

from beartype import beartype

from literalizer._formatters.type_inference import (
    RecordShape,
    collect_record_shapes,
    drop_unrecordizable_nested_sibling_maps,
)
from literalizer._language import (
    HeterogeneousBehavior,
    RenderedRecordLiteral,
    no_compute_call_slot_wrap_ids,
    no_compute_wrap_ids,
    no_empty_container_literal_overrides,
)
from literalizer._types import Scalar, Value, ValueInput
from literalizer.exceptions import UnrepresentableInputError

# A shared record renderer may use a conventional ASCII identifier, or an
# escaped identifier in the syntax used by Zig, Kotlin, and Swift.  Languages
# that need another spelling must make ``field_identifier`` produce one of
# these forms (or reject the key themselves) so a generated declaration and
# literal never interpolate arbitrary JSON-key text as source code.
_RECORD_FIELD_IDENTIFIER = re.compile(
    pattern=(
        r"^(?:[A-Za-z_][A-Za-z0-9_]*|`[A-Za-z_][A-Za-z0-9_]*`|"
        r'@"(?:[^"\\]|\\(?:["\\nrt]|x[0-9A-Fa-f]{2}))*")$'
    ),
)


@beartype
@dataclasses.dataclass(frozen=True)
class RecordDeclarationField:
    """One resolved field of a generated record declaration."""

    identifier: str
    type_name: str


@beartype
@dataclasses.dataclass(frozen=True)
class RecordLiteralField:
    """One resolved field of a generated record literal.

    ``formatted`` is the already-formatted field value produced by the
    normal value formatter.  ``type_name`` is the exact declared member
    type resolved through :attr:`RecordRenderer.field_type`.
    """

    identifier: str
    formatted: str
    type_name: str


@beartype
@dataclasses.dataclass(frozen=True)
class RecordFieldType:
    """The structured input to :attr:`RecordRenderer.field_type`.

    ``value`` is the raw field value (first-seen for its shape); a
    language maps it to a declared type through its own collection
    openers / scalar mapping rather than prefix-matching a formatted
    literal.  ``record_name`` is the generated declaration name when
    ``value`` is itself a nested record-shaped dict (resolved here, the
    one piece a language cannot recover from the value alone), and
    ``None`` otherwise.  ``element_record_name`` is the analogous
    generated name when ``value`` is a non-empty list whose every
    element is a record-shaped dict of one shared shape (a sibling list
    spanning more than one record shape is rejected before formatting),
    so a language that types such a list precisely -- e.g. C++
    ``std::vector<RecordN>`` -- can name the element struct; it is
    ``None`` for every other value, including a list of plain scalars.
    Languages that widen a record-dict list to a single catch-all
    element type (Go ``[]any``, Java ``Object[]``) ignore it.
    """

    value: Value
    record_name: str | None
    element_record_name: str | None


@beartype
@dataclasses.dataclass(frozen=True)
class RecordRenderer:
    """Per-language syntax hooks for the ``RECORD`` strategy.

    ``name_prefix`` is the auto-naming prefix (``Record`` -> ``Record0``,
    ``Record1``, ...).  ``record_shape_names`` maps a shape's key-set
    (``frozenset`` of its keys) to a custom struct name; a mapped shape
    uses that name and the auto ``{prefix}{index}`` counter advances
    only for the shapes with no custom name (mirrors Rust).
    ``field_identifier`` maps an original dict key to a lexical field
    identifier (identity for most languages, PascalCase for Go).  Its result
    must be a conventional ASCII identifier, a backtick-escaped identifier,
    or a quoted Zig-style identifier; the shared renderer rejects any other
    result before it returns target source.  This makes the mapping safe to
    use consistently in both declarations and literals.
    ``field_type`` maps a :class:`RecordFieldType`
    (raw field value plus any resolved nested-record name) to its
    declared type, using the language's own collection openers rather
    than re-parsing the formatted literal.  ``render_declaration`` builds
    one declaration block from the resolved fields, and
    ``render_literal`` builds the literal as a
    :class:`RenderedRecordLiteral` (structured pieces; the shared code
    in :mod:`literalizer._literalize` assembles the compact or multiline
    form from them, so no language flattens then re-parses).
    """

    name_prefix: str
    record_shape_names: Mapping[frozenset[str], str]
    field_identifier: Callable[[str], str]
    field_identifier_key: Callable[[str], str]
    """How two field identifiers are compared for collision.

    Identity for a language whose identifiers are distinct exactly when
    they are spelled differently.  Nim's are style-insensitive -- ``aB``
    and ``ab`` name the same field -- so it folds the spelling here
    rather than letting the two through (issue #3960).
    """
    field_type: Callable[[RecordFieldType], str]
    render_declaration: Callable[
        [str, Sequence[RecordDeclarationField]],
        str,
    ]
    render_literal: Callable[
        [str, Sequence[RecordLiteralField]],
        RenderedRecordLiteral,
    ]
    field_type_names_nested_records: bool
    """Whether a field type spells the name of a record inside it.

    A language that writes a heterogeneous list as one carrier type
    (``[]any``, ``object[]``) types the field the same however the
    records inside it are shaped, so two instances holding differently
    shaped ones still share a declaration.  A language that spells the
    record instead cannot, so its refinement reads those shapes as part
    of the signature (issue #4500).
    """
    suppress_custom_name_declarations: bool
    """Whether a shape named through ``record_shape_names`` is declared
    by the caller rather than emitted in this literal's preamble.

    C++ uses this for starter-code types: the mapping supplies a type name
    for the aggregate literal, but emitting ``struct`` again would conflict
    with the declaration already in the surrounding program.
    """


@beartype
@dataclasses.dataclass(frozen=True)
class RecordStrategy:
    """Configuration a language wires into its record strategy.

    ``record_name_for_value`` exposes the name assigned to a rendered
    record dict after :attr:`HeterogeneousBehavior.compute_record_shapes`
    has run.  A language whose collection literal must spell its element
    type (for example C++14, which has no class-template argument
    deduction) can use it to type a surrounding record sequence.
    """

    behavior: HeterogeneousBehavior
    preamble: Callable[[Value], tuple[str, ...]]
    record_name_for_value: Callable[[ValueInput], str | None] | None


@beartype
@dataclasses.dataclass(frozen=True)
class ActiveRecordStrategy(RecordStrategy):
    """Record strategy whose active callbacks are always available."""

    record_name_for_value: Callable[[ValueInput], str | None]


@beartype
def nested_record_sequence_type(
    *,
    value: Value,
    record_name_for_value: Callable[[ValueInput], str | None],
) -> tuple[int, str] | None:
    """Return ``(depth, record_name)`` for a uniform nested record list.

    Every sequence level must be non-empty, every branch must have the same
    depth, and every leaf dict must render as the same generated record type.
    """
    record_name = record_name_for_value(value)
    if record_name is not None:
        return (0, record_name)
    if not isinstance(value, list) or len(value) == 0:
        return None
    child_types = {
        nested_record_sequence_type(
            value=item,
            record_name_for_value=record_name_for_value,
        )
        for item in value
    }
    if len(child_types) != 1:
        return None
    (child_type,) = child_types
    if child_type is None:
        return None
    depth, name = child_type
    return (depth + 1, name)


@beartype
def identity_field_identifier_key(identifier: str, /) -> str:
    """Compare two field identifiers by their spelling alone."""
    return identifier


@beartype
def _validate_field_identifiers(
    *,
    renderer: RecordRenderer,
    shapes: Sequence[RecordShape],
) -> None:
    """Reject keys whose rendered field spelling is not lexical source.

    The shared strategy uses the spelling in both the declaration and literal.
    Validating it while shapes are computed ensures invalid JSON keys fail
    during data checking instead of yielding a complete, non-compiling target
    file.
    """
    for shape in shapes:
        identifiers: set[str] = set()
        for key in shape.keys:
            identifier = renderer.field_identifier(key)
            if _RECORD_FIELD_IDENTIFIER.match(string=identifier) is None:
                msg = (
                    f"cannot represent the dict key {key!r} as a lexical "
                    "field identifier under the RECORD heterogeneous strategy"
                )
                raise UnrepresentableInputError(msg)
            comparison = renderer.field_identifier_key(identifier)
            if comparison in identifiers:
                msg = (
                    f"cannot represent the dict key {key!r} under the "
                    "RECORD heterogeneous strategy: its field identifier "
                    f"{identifier!r} collides with another key in the same "
                    "record"
                )
                raise UnrepresentableInputError(msg)
            identifiers.add(comparison)


@beartype
@dataclasses.dataclass(frozen=True, kw_only=True)
class _FieldVariantRecordShape(RecordShape):
    """A record shape split off from same-key-set dicts whose field
    types conflict (issue #2888).

    Mirrors Rust's ``_FieldVariantRecordShape``: two dicts with equal
    key tuples share one :class:`RecordShape`, but when a field's
    declared type differs between them (e.g. the nested record under a
    key has different fields, or a different scalar type) they cannot
    share one generated declaration -- the declaration would take the
    field types of the first dict and the literal for the other dict
    would not compile.  :func:`_refine_record_shapes` gives each
    conflicting group its own instance; ``variant`` (numbered in
    document order of each group's first dict) keeps the instances
    distinct so every shape-keyed lookup treats each group as a
    separate record shape.
    """

    variant: int


@beartype
def _record_dicts_in_document_order(
    *,
    data: Value,
    shapes_by_id: Mapping[int, RecordShape],
) -> list[dict[Scalar, Value]]:
    """Return every record-shaped dict in *data*, in document order.

    A dict aliased into the tree more than once (e.g. via a YAML
    anchor) appears once.
    """
    ordered: list[dict[Scalar, Value]] = []
    seen: set[int] = set()

    def walk(node: Value) -> None:
        """Append record dicts under *node* in document order."""
        match node:
            case dict():
                if id(node) in shapes_by_id and id(node) not in seen:
                    seen.add(id(node))
                    ordered.append(node)
                for child in node.values():
                    walk(node=child)
            case list():
                for item in node:
                    walk(node=item)
            case _:
                return

    walk(node=data)
    return ordered


@beartype
def _group_token_strings(
    *,
    instances: Sequence[dict[Scalar, Value]],
    group_of: Mapping[int, Hashable],
) -> dict[int, str]:
    """Assign a stable, distinct string to each current refinement
    group, mapping ``id(instance)`` to its group's string.

    The strings stand in for the (not-yet-assigned) generated record
    names when a nested record dict is fed to a language's
    :attr:`RecordRenderer.field_type` hook during signature
    computation: two dicts in the same group get the same string, so
    the hook returns the same field type for a nested record they
    share, and different strings otherwise.  Numbered in document order
    so the result is deterministic across runs.
    """
    index_of_group: dict[Hashable, int] = {}
    string_of_id: dict[int, str] = {}
    for instance in instances:
        token = group_of[id(instance)]
        if token not in index_of_group:
            index_of_group[token] = len(index_of_group)
        string_of_id[id(instance)] = (
            f"\x00record-group-{index_of_group[token]}"
        )
    return string_of_id


@beartype
def _list_element_token(
    *,
    field_value: Value,
    id_to_shape: Mapping[int, RecordShape],
    token_string_of: Mapping[int, str],
) -> str | None:
    """Return the group string of the first element when *field_value*
    is a non-empty list whose every element is a record-shaped dict,
    else ``None``.

    Mirrors :func:`_list_element_record_name` but at signature level,
    substituting the current refinement-group string for the (unknown)
    generated name.  When the elements land in different groups the
    list spans more than one record shape and is rejected before
    formatting, so the first element's string is a fine deterministic
    stand-in for the whole list.
    """
    if not isinstance(field_value, list) or len(field_value) == 0:
        return None
    if any(
        not (isinstance(item, dict) and id(item) in id_to_shape)
        for item in field_value
    ):
        return None
    return token_string_of[id(field_value[0])]


@beartype
def _nested_record_tokens(
    *,
    field_value: Value,
    id_to_shape: Mapping[int, RecordShape],
    recordizable_ids: frozenset[int],
    token_string_of: Mapping[int, str],
) -> tuple[str, ...]:
    """Return the refinement groups of the records inside a field.

    A record dict can sit anywhere inside a field value, including
    beside other types in a heterogeneous list, where the language's
    field type names it only as the mapping it would otherwise be.
    Two instances whose nested records fall in different groups cannot
    share one declaration, so those groups join the signature (issue
    #4500).

    The groups are read as a set: how many records a field holds, and
    in what order, is already part of the field type the language
    itself returns.
    """
    tokens: set[str] = set()
    pending: list[Value] = [field_value]
    while len(pending) > 0:
        value = pending.pop()
        match value:
            case dict():
                if id(value) in id_to_shape:
                    tokens.add(token_string_of[id(value)])
                    pending.extend(value.values())
                elif id(value) not in recordizable_ids:
                    # A mapping that was never a record candidate --
                    # an ordered map, or one whose keys are not all
                    # names -- still holds records that are written as
                    # records and named in this field's type, so the
                    # walk goes through it (issue #4754).
                    pending.extend(value.values())
                # A mapping that was a candidate and is absent from
                # ``id_to_shape`` is one the widening pass took out;
                # what it holds is written as a value of that mapping
                # rather than as a record, so the walk stops rather
                # than undoing the widening.
            case list() | set():
                pending.extend(value)
            case _:
                continue
    return tuple(sorted(tokens))


@beartype
def _instance_signature(
    *,
    instance: dict[Scalar, Value],
    shape: RecordShape,
    id_to_shape: Mapping[int, RecordShape],
    recordizable_ids: frozenset[int],
    token_string_of: Mapping[int, str],
    field_type: Callable[[RecordFieldType], str],
    field_type_names_nested_records: bool,
) -> tuple[str, ...]:
    """Return the per-key declared field types of *instance*, in
    shape-key order.

    Each key's entry is the language's own
    :attr:`RecordRenderer.field_type` output for that field value, with
    any nested record dict represented by its current refinement-group
    string rather than a generated name (see
    :func:`_group_token_strings`).  Because this reuses the very hook
    that types the emitted declaration, two dicts whose signatures
    differ would be declared with different field types and so cannot
    share one generated declaration; a widening language (Go ``[]any``)
    returns the same type for values it collapses, so those do not
    split.
    """
    signature: list[str] = []
    for key in shape.keys:
        field_value = instance[key]
        nested_name = None
        if isinstance(field_value, dict) and id(field_value) in id_to_shape:
            nested_name = token_string_of[id(field_value)]
        element_name = _list_element_token(
            field_value=field_value,
            id_to_shape=id_to_shape,
            token_string_of=token_string_of,
        )
        request = RecordFieldType(
            value=field_value,
            record_name=nested_name,
            element_record_name=element_name,
        )
        signature.append(field_type(request))
        if field_type_names_nested_records:
            signature.append(
                repr(
                    _nested_record_tokens(
                        field_value=field_value,
                        id_to_shape=id_to_shape,
                        recordizable_ids=recordizable_ids,
                        token_string_of=token_string_of,
                    )
                )
            )
    return tuple(signature)


@beartype
def _regroup_by_field_signatures(
    *,
    instances: Sequence[dict[Scalar, Value]],
    id_to_shape: Mapping[int, RecordShape],
    recordizable_ids: frozenset[int],
    group_of: Mapping[int, Hashable],
    field_type: Callable[[RecordFieldType], str],
    field_type_names_nested_records: bool,
) -> dict[int, Hashable]:
    """Run one refinement round: split each group whose members'
    field-type signatures disagree, keeping agreeing groups whole.

    Unlike Rust there are no optional keys here, so every member of a
    group has the same key set and a group agrees exactly when all its
    members share one signature.
    """
    token_string_of = _group_token_strings(
        instances=instances,
        group_of=group_of,
    )
    members_by_group: dict[Hashable, list[dict[Scalar, Value]]] = {}
    for instance in instances:
        members_by_group.setdefault(group_of[id(instance)], []).append(
            instance
        )
    new_group_of: dict[int, Hashable] = {}
    for token, members in members_by_group.items():
        signatures = [
            _instance_signature(
                instance=member,
                shape=id_to_shape[id(member)],
                id_to_shape=id_to_shape,
                recordizable_ids=recordizable_ids,
                token_string_of=token_string_of,
                field_type=field_type,
                field_type_names_nested_records=(
                    field_type_names_nested_records
                ),
            )
            for member in members
        ]
        if len(set(signatures)) == 1:
            for member in members:
                new_group_of[id(member)] = token
        else:
            for member, signature in zip(members, signatures, strict=True):
                new_group_of[id(member)] = (token, signature)
    return new_group_of


@beartype
def _partition(
    *,
    instances: Sequence[dict[Scalar, Value]],
    group_of: Mapping[int, Hashable],
) -> frozenset[tuple[int, ...]]:
    """Return the grouping of *instances* induced by *group_of* in a
    form comparable across refinement rounds (group tokens change
    representation between rounds even when the grouping does not).
    """
    ids_by_group: dict[Hashable, list[int]] = {}
    for instance in instances:
        ids_by_group.setdefault(group_of[id(instance)], []).append(
            id(instance)
        )
    return frozenset(tuple(ids) for ids in ids_by_group.values())


@beartype
def _materialize_refined_shapes(
    *,
    instances: Sequence[dict[Scalar, Value]],
    shapes_by_id: Mapping[int, RecordShape],
    group_of: Mapping[int, Hashable],
) -> dict[int, RecordShape]:
    """Map each dict to its refined shape.

    A shape whose dicts all landed in one group keeps its original
    :class:`RecordShape` object, so unaffected inputs render exactly as
    before; a split shape's groups become
    :class:`_FieldVariantRecordShape` instances numbered in document
    order of each group's first dict.
    """
    tokens_by_shape: dict[RecordShape, set[Hashable]] = {}
    for instance in instances:
        tokens_by_shape.setdefault(shapes_by_id[id(instance)], set()).add(
            group_of[id(instance)]
        )
    shape_for_token: dict[Hashable, RecordShape] = {}
    variant_counter: Counter[RecordShape] = Counter()
    refined: dict[int, RecordShape] = {}
    for instance in instances:
        token = group_of[id(instance)]
        base = shapes_by_id[id(instance)]
        if token not in shape_for_token:
            if len(tokens_by_shape[base]) == 1:
                shape_for_token[token] = base
            else:
                shape_for_token[token] = _FieldVariantRecordShape(
                    keys=base.keys,
                    optional_keys=base.optional_keys,
                    variant=variant_counter[base],
                )
                variant_counter[base] += 1
        refined[id(instance)] = shape_for_token[token]
    return refined


@beartype
def _refine_record_shapes(
    *,
    data: Value,
    shapes_by_id: Mapping[int, RecordShape],
    recordizable_ids: frozenset[int],
    field_type: Callable[[RecordFieldType], str],
    field_type_names_nested_records: bool,
) -> dict[int, RecordShape]:
    """Split record shapes whose dicts disagree on a field's declared
    type (issue #2888).

    *shapes_by_id* keys shapes by key tuple, so two dicts with the same
    keys share a shape even when a field's value type differs; declaring
    the field with the type from the first dict then makes the literal
    for the other dict fail to compile.  This pass splits each shape's
    dicts into groups by per-field type signature so each group gets its
    own declaration.  Sibling lists spanning split groups then fail
    :func:`~literalizer._checks.check_data`'s mixed-record-shape gate
    (the honest heterogeneous-siblings outcome) instead of silently
    emitting mismatched field types, while groups that never share a
    list each render as a genuinely distinct declaration that compiles.

    Signatures reference nested records by group, so the grouping is
    computed to a fixed point: splitting a nested shape can in turn
    split the shape of the dicts embedding it.
    """
    instances = _record_dicts_in_document_order(
        data=data,
        shapes_by_id=shapes_by_id,
    )
    group_of: dict[int, Hashable] = {
        id(instance): shapes_by_id[id(instance)] for instance in instances
    }
    while True:
        regrouped = _regroup_by_field_signatures(
            instances=instances,
            id_to_shape=shapes_by_id,
            recordizable_ids=recordizable_ids,
            group_of=group_of,
            field_type=field_type,
            field_type_names_nested_records=field_type_names_nested_records,
        )
        old_partition = _partition(instances=instances, group_of=group_of)
        new_partition = _partition(instances=instances, group_of=regrouped)
        if new_partition == old_partition:
            break
        group_of = regrouped
    return _materialize_refined_shapes(
        instances=instances,
        shapes_by_id=shapes_by_id,
        group_of=group_of,
    )


@beartype
def _ordered_record_shapes(
    *,
    data: Value,
    shapes_by_id: Mapping[int, RecordShape],
) -> list[RecordShape]:
    """Return record shapes in document order, one per distinct shape."""
    ordered: list[RecordShape] = []
    seen: set[RecordShape] = set()
    _accumulate_ordered_shapes(
        data=data,
        shapes_by_id=shapes_by_id,
        ordered=ordered,
        seen=seen,
    )
    return ordered


@beartype
def _accumulate_ordered_shapes(
    *,
    data: Value,
    shapes_by_id: Mapping[int, RecordShape],
    ordered: list[RecordShape],
    seen: set[RecordShape],
) -> None:
    """Walk *data* appending each newly-seen record shape to *ordered*."""
    match data:
        case dict():
            if id(data) in shapes_by_id:
                shape = shapes_by_id[id(data)]
                if shape not in seen:
                    seen.add(shape)
                    ordered.append(shape)
            for value in data.values():
                _accumulate_ordered_shapes(
                    data=value,
                    shapes_by_id=shapes_by_id,
                    ordered=ordered,
                    seen=seen,
                )
        case list():
            for item in data:
                _accumulate_ordered_shapes(
                    data=item,
                    shapes_by_id=shapes_by_id,
                    ordered=ordered,
                    seen=seen,
                )
        case _:
            return


@beartype
def _assign_names(
    *,
    shapes: Sequence[RecordShape],
    prefix: str,
    record_shape_names: Mapping[frozenset[str], str],
    reject_split_key_sets: bool,
) -> dict[RecordShape, str]:
    """Assign struct names in *shapes* order.

    A shape whose key-set is mapped in *record_shape_names* takes the
    custom name; every other shape gets ``{prefix}{index}`` where
    *index* advances only for the auto-named shapes (mirrors Rust's
    ``_compute_shapes``/``_build_record_preamble``).

    When *reject_split_key_sets* is set (field-type splitting is on) and
    more than one distinct shape carries a custom-named key set (same
    keys but conflicting field types -- see
    :func:`_refine_record_shapes`), the custom name cannot identify one
    declaration, so the input is rejected rather than emitting duplicate
    declarations under that name (mirrors Rust's
    ``_assign_record_struct_names``).
    """
    key_set_counts = Counter(frozenset(shape.keys) for shape in shapes)
    names: dict[RecordShape, str] = {}
    prefix_index = 0
    for shape in shapes:
        key_set = frozenset(shape.keys)
        custom = record_shape_names.get(key_set)
        if custom is None:
            names[shape] = f"{prefix}{prefix_index}"
            prefix_index += 1
        elif reject_split_key_sets and key_set_counts[key_set] > 1:
            sorted_keys = ", ".join(sorted(key_set))
            msg = (
                f"record_shape_names maps the key set {{{sorted_keys}}} "
                f"to {custom!r}, but the data contains multiple distinct "
                f"record shapes with that key set (their field types "
                f"differ), so one custom name cannot identify one "
                f"generated declaration"
            )
            raise UnrepresentableInputError(msg)
        else:
            names[shape] = custom
    return names


@beartype
def _accumulate_emit_order(
    *,
    data: Value,
    shapes_by_id: Mapping[int, RecordShape],
    emit_ordered: list[RecordShape],
    emit_seen: set[RecordShape],
) -> None:
    """Walk *data* post-order so a shape is emitted after its
    dependencies (nested records declared before their parents).
    """
    match data:
        case dict():
            for value in data.values():
                _accumulate_emit_order(
                    data=value,
                    shapes_by_id=shapes_by_id,
                    emit_ordered=emit_ordered,
                    emit_seen=emit_seen,
                )
            if id(data) in shapes_by_id:
                shape = shapes_by_id[id(data)]
                if shape not in emit_seen:
                    emit_seen.add(shape)
                    emit_ordered.append(shape)
        case list():
            for item in data:
                _accumulate_emit_order(
                    data=item,
                    shapes_by_id=shapes_by_id,
                    emit_ordered=emit_ordered,
                    emit_seen=emit_seen,
                )
        case _:
            return


@beartype
def _list_element_record_name(
    *,
    field_value: Value,
    id_to_shape: Mapping[int, RecordShape],
    name_by_shape: Mapping[RecordShape, str],
) -> str | None:
    """Return the generated record name for *field_value* when it is a
    non-empty list whose every element is a record-shaped dict of one
    shared shape, else ``None``.

    A list mixing record dicts with other values returns ``None`` (the
    language types it through its own openers).  A sibling list
    spanning more than one record shape is rejected by
    :func:`literalizer._checks.check_data` before any value is
    formatted, so every element of an all-record-dict list that reaches
    here shares one shape and the first element's resolved name applies
    to the whole list.
    """
    if not isinstance(field_value, list) or len(field_value) == 0:
        return None
    collected_shapes: list[RecordShape | None] = []
    for entry_item in field_value:
        effective_id_to_shape = None
        if isinstance(entry_item, dict):
            effective_id_to_shape = id_to_shape.get(id(entry_item))
        collected_shapes.append(effective_id_to_shape)
    shapes = collected_shapes
    if any(shape is None for shape in shapes):
        return None
    # Every element is a record-shaped dict; the upstream mixed-shape
    # guard guarantees one shared shape, so the first element names the
    # whole list.
    return name_by_shape[id_to_shape[id(field_value[0])]]


@beartype
def _build_derecordized_map_open(
    *,
    open_str: str,
) -> Callable[[], str]:
    """Wrap the fixed widened-map opener as an opener provider.

    :attr:`~literalizer._language.HeterogeneousBehavior.dict_open_for_wrap_ids`
    is a zero-argument provider so a language whose widened opener
    depends on the data pass can defer the choice; a fixed opener
    simply closes over its string.
    """

    def _open() -> str:
        """Return the fixed widened-map opener."""
        return open_str

    return _open


@beartype
def _accumulate_field_requests(
    *,
    value: Value,
    shapes_by_id: Mapping[int, RecordShape],
    request_by_shape: dict[RecordShape, dict[str, RecordFieldType]],
    field_type_request: Callable[[Value], RecordFieldType],
) -> None:
    """Seed declaration types during a metadata-only shape pass."""
    if isinstance(value, dict):
        shape = shapes_by_id.get(id(value))
        if shape is not None and shape not in request_by_shape:
            request_by_shape[shape] = {
                key: field_type_request(value[key]) for key in shape.keys
            }
        for child in value.values():
            _accumulate_field_requests(
                value=child,
                shapes_by_id=shapes_by_id,
                request_by_shape=request_by_shape,
                field_type_request=field_type_request,
            )
    elif isinstance(value, list):
        for child in value:
            _accumulate_field_requests(
                value=child,
                shapes_by_id=shapes_by_id,
                request_by_shape=request_by_shape,
                field_type_request=field_type_request,
            )


@beartype
def _alias_record_ids(
    id_map: Mapping[int, int],
    *,
    id_to_shape: dict[int, RecordShape],
) -> None:
    """Make source containers reuse shapes inferred from resolved refs."""
    id_to_shape.update(
        {
            source_id: id_to_shape[inferred_id]
            for inferred_id, source_id in id_map.items()
            if inferred_id in id_to_shape
        }
    )


@beartype
def _collect_strategy_shapes(
    *,
    data: Value,
    renderer: RecordRenderer,
    widen_unrecordizable_nested_sibling_maps: bool,
    split_conflicting_field_types: bool,
) -> Mapping[int, RecordShape]:
    """Collect and refine the record shapes for the selected strategy."""
    raw_shapes_by_id = collect_record_shapes(data=data)
    widened_shapes_by_id = raw_shapes_by_id
    if widen_unrecordizable_nested_sibling_maps:
        widened_shapes_by_id = drop_unrecordizable_nested_sibling_maps(
            data=data,
            shapes_by_id=raw_shapes_by_id,
        )
    shapes_by_id = widened_shapes_by_id
    if split_conflicting_field_types:
        shapes_by_id = _refine_record_shapes(
            data=data,
            shapes_by_id=widened_shapes_by_id,
            recordizable_ids=frozenset(raw_shapes_by_id),
            field_type=renderer.field_type,
            field_type_names_nested_records=(
                renderer.field_type_names_nested_records
            ),
        )
    return shapes_by_id


@beartype
def _compute_wrap_ids(data: Value) -> frozenset[int]:
    """Return ids of maps widened out of the record-shape mapping."""
    raw_shapes_by_id = collect_record_shapes(data=data)
    widened_shapes_by_id = drop_unrecordizable_nested_sibling_maps(
        data=data,
        shapes_by_id=raw_shapes_by_id,
    )
    return frozenset(set(raw_shapes_by_id) - set(widened_shapes_by_id))


@beartype
def _identity_scalar_wrapper(_raw: Scalar, formatted: str) -> str:
    """Leave a scalar unchanged inside a top-type widened map."""
    return formatted


@beartype
def _record_name_for_value(
    value: ValueInput,
    /,
    *,
    id_to_shape: Mapping[int, RecordShape],
    name_by_shape: Mapping[RecordShape, str],
) -> str | None:
    """Return *value*'s assigned record name, if it is rendered as
    a record.
    """
    shape = id_to_shape.get(id(value))
    if shape is not None:
        return name_by_shape.get(shape)
    return None


@dataclasses.dataclass(slots=True, kw_only=True)
class _RecordStrategyState:
    """Mutable caches and callbacks owned by one record strategy.

    These methods replace closures created inside the runtime-checked
    :func:`build_record_strategy` boundary.  Like those closures, the methods
    have no decorators, so formatting a record does not add a second runtime
    type check at every node.
    """

    renderer: RecordRenderer
    split_conflicting_field_types: bool
    widen_unrecordizable_nested_sibling_maps: bool
    name_by_shape: dict[RecordShape, str]
    id_to_shape: dict[int, RecordShape]
    request_by_shape: dict[RecordShape, dict[str, RecordFieldType]]
    emit_order: list[RecordShape]
    preamble_by_value: dict[str, tuple[str, ...]]

    def compute_shapes(self, data: Value) -> Mapping[int, RecordShape]:
        """Assign record shapes and reset the per-pass caches."""
        shapes_by_id = _collect_strategy_shapes(
            data=data,
            renderer=self.renderer,
            widen_unrecordizable_nested_sibling_maps=(
                self.widen_unrecordizable_nested_sibling_maps
            ),
            split_conflicting_field_types=self.split_conflicting_field_types,
        )
        self.name_by_shape.clear()
        self.id_to_shape.clear()
        self.request_by_shape.clear()
        self.emit_order.clear()
        self.id_to_shape.update(shapes_by_id)
        ordered = _ordered_record_shapes(
            data=data,
            shapes_by_id=shapes_by_id,
        )
        _validate_field_identifiers(renderer=self.renderer, shapes=ordered)
        self.name_by_shape.update(
            _assign_names(
                shapes=ordered,
                prefix=self.renderer.name_prefix,
                record_shape_names=self.renderer.record_shape_names,
                reject_split_key_sets=self.split_conflicting_field_types,
            ),
        )
        _accumulate_emit_order(
            data=data,
            shapes_by_id=shapes_by_id,
            emit_ordered=self.emit_order,
            emit_seen=set(),
        )
        _accumulate_field_requests(
            value=data,
            shapes_by_id=shapes_by_id,
            request_by_shape=self.request_by_shape,
            field_type_request=self.field_type_request,
        )
        return shapes_by_id

    def field_type_request(self, field_value: Value) -> RecordFieldType:
        """Build the structured field-type request for *field_value*."""
        nested_name = None
        if (
            isinstance(field_value, dict)
            and id(field_value) in self.id_to_shape
        ):
            nested_name = self.name_by_shape.get(
                self.id_to_shape[id(field_value)],
            )
        element_name = _list_element_record_name(
            field_value=field_value,
            id_to_shape=self.id_to_shape,
            name_by_shape=self.name_by_shape,
        )
        return RecordFieldType(
            value=field_value,
            record_name=nested_name,
            element_record_name=element_name,
        )

    def render_literal(
        self,
        value: dict[Scalar, Value],
        fields: Mapping[str, str],
    ) -> RenderedRecordLiteral | None:
        """Render a record dict and cache its declaration field types."""
        if id(value) not in self.id_to_shape:
            return None
        shape = self.id_to_shape[id(value)]
        _ = self.request_by_shape.setdefault(
            shape,
            {
                key: self.field_type_request(field_value=value[key])
                for key in shape.keys
            },
        )
        literal_fields = [
            RecordLiteralField(
                identifier=self.renderer.field_identifier(key),
                formatted=fields[key],
                type_name=self.renderer.field_type(
                    self.field_type_request(field_value=value[key]),
                ),
            )
            for key in shape.keys
        ]
        return self.renderer.render_literal(
            self.name_by_shape[shape],
            literal_fields,
        )

    def preamble(self, data: Value, /) -> tuple[str, ...]:
        """Build declarations in dependency order for one rendered
        value.
        """
        blocks: list[str] = []
        for shape in self.emit_order:
            if (
                self.renderer.suppress_custom_name_declarations
                and frozenset(shape.keys) in self.renderer.record_shape_names
            ):
                continue
            requests = self.request_by_shape[shape]
            fields = [
                RecordDeclarationField(
                    identifier=self.renderer.field_identifier(key),
                    type_name=self.renderer.field_type(requests[key]),
                )
                for key in shape.keys
            ]
            blocks.append(
                self.renderer.render_declaration(
                    self.name_by_shape[shape],
                    fields,
                ),
            )
        return self.preamble_by_value.setdefault(repr(data), tuple(blocks))


@beartype
def build_record_strategy(
    *,
    renderer: RecordRenderer,
    split_conflicting_field_types: bool,
    widen_unrecordizable_nested_sibling_maps: bool,
    derecordized_map_open: str | None,
) -> ActiveRecordStrategy:
    """Build the behavior + preamble for the ``RECORD`` strategy.

    The two share per-pass caches: ``compute_record_shapes`` (run first,
    during data checking) assigns the document-order names, and
    ``render_record_literal`` records the first-seen
    :class:`RecordFieldType` request per shape so the preamble can
    derive each field's declared type from the raw value through the
    language's own collection openers.

    When *split_conflicting_field_types* is set, ``compute_record_shapes``
    additionally runs :func:`_refine_record_shapes` so same-key-set dicts
    whose declared field types conflict resolve to distinct record shapes
    (issue #2888); a language opts in once its
    :attr:`RecordRenderer.field_type` hook is a faithful field-type
    signature (widening hooks are checked for polarity first).  Left off,
    the strategy behaves exactly as before.

    When *widen_unrecordizable_nested_sibling_maps* is set, nested maps
    whose sibling instances cannot share one record shape are dropped
    from the shape mapping before field-type refinement (issue #2910).
    They consequently fall through to the language's plain-map renderer;
    their ids are exposed through ``compute_wrap_ids`` so the shared
    heterogeneous checks treat their scalar children as representable by
    the language's widened map value type.  The identity scalar wrapper
    leaves those children unchanged in languages such as Go, whose top
    type accepts the original literals directly.  Such a language can
    provide *derecordized_map_open* to force the corresponding widened
    literal opener even when one map's raw values look homogeneous.
    """
    state = _RecordStrategyState(
        renderer=renderer,
        split_conflicting_field_types=split_conflicting_field_types,
        widen_unrecordizable_nested_sibling_maps=(
            widen_unrecordizable_nested_sibling_maps
        ),
        name_by_shape={},
        id_to_shape={},
        request_by_shape={},
        emit_order=[],
        preamble_by_value={},
    )
    record_name_for_value = functools.partial(
        _record_name_for_value,
        id_to_shape=state.id_to_shape,
        name_by_shape=state.name_by_shape,
    )

    effective_compute_wrap_ids = no_compute_wrap_ids
    if widen_unrecordizable_nested_sibling_maps:
        effective_compute_wrap_ids = _compute_wrap_ids
    effective_wrap_scalar = None
    if widen_unrecordizable_nested_sibling_maps:
        effective_wrap_scalar = _identity_scalar_wrapper
    effective_dict_open_for_wrap_ids = None
    if derecordized_map_open is not None:
        effective_dict_open_for_wrap_ids = _build_derecordized_map_open(
            open_str=derecordized_map_open
        )
    behavior = HeterogeneousBehavior(
        skip_scalar_checks=False,
        compute_wrap_ids=(effective_compute_wrap_ids),
        wrap_scalar=(effective_wrap_scalar),
        wrap_non_scalar=None,
        wrap_empty_container=None,
        empty_container_literal_overrides=no_empty_container_literal_overrides,
        compute_call_slot_wrap_ids=no_compute_call_slot_wrap_ids,
        dict_open_for_wrap_ids=(effective_dict_open_for_wrap_ids),
        widens_nested_maps_by_wrapping_scalars=False,
        widens_unrecordizable_nested_sibling_maps=(
            widen_unrecordizable_nested_sibling_maps
        ),
        render_record_literal=state.render_literal,
        compute_record_shapes=state.compute_shapes,
        render_tuple_literal=None,
        compute_tuple_list_ids=None,
        alias_record_ids=functools.partial(
            _alias_record_ids,
            id_to_shape=state.id_to_shape,
        ),
    )
    return ActiveRecordStrategy(
        behavior=behavior,
        preamble=state.preamble,
        record_name_for_value=record_name_for_value,
    )
