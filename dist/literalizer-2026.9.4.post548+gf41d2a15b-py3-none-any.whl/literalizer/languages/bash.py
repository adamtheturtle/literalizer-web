"""Bash language specification."""

import dataclasses
import datetime
import enum
import re
from collections.abc import Callable, Sequence
from functools import cached_property
from typing import ClassVar

from beartype import beartype

from literalizer._checks import (
    guard_collection_nesting_depth,
    reject_stringified_dict_key_collisions,
)
from literalizer._formatters.collection_openers import (
    fixed_open,
)
from literalizer._formatters.format_dates import (
    format_date_iso,
    format_datetime_epoch,
    format_datetime_iso,
    format_time_iso,
)
from literalizer._formatters.format_entries import (
    format_bytes_base64,
    format_bytes_hex,
    passthrough_sequence_entry,
    passthrough_set_entry,
    variable_formatter,
)
from literalizer._formatters.format_floats import (
    format_float_fixed,
    format_float_repr,
    format_float_scientific,
)
from literalizer._formatters.format_strings import (
    reject_nul_string_formatter,
)
from literalizer._language import (
    NO_CALL_PARAMETER_LIMIT,
    NO_HETEROGENEOUS_BEHAVIOR,
    NON_KEBAB_REF_CASES,
    BareIntegerWidthStrategies,
    CallParameterShadowing,
    CallStyle,
    CommandCallStyle,
    CommentConfig,
    DateFormatConfig,
    DateFormatEnum,
    DatetimeFormatConfig,
    DatetimeFormatEnum,
    DeclarationStyleConfig,
    DictFormatConfig,
    FloatSpecialsMixin,
    HeterogeneousBehavior,
    IdentifierCase,
    JsonType,
    LanguageCls,
    ModifierCombination,
    NewVariableNameSyntax,
    OrderedMapFormatConfig,
    RoundTripCapability,
    SequenceFormatConfig,
    SetFormatConfig,
    StubReturn,
    TrailingCommaConfig,
    VariantMetadata,
    body_preamble_from_scalars,
    default_sequence_binding_declarations,
    default_wrap_calls_with_declarations,
    identity_call_arg,
    identity_call_ref_identifier,
    identity_call_statement,
    identity_call_target,
    identity_constructor_target,
    never_inhibits_consuming_form,
    no_call_binding_body_preamble,
    no_call_binding_file_pragmas,
    no_call_stub,
    no_data_preamble,
    no_format_integer_beyond_i64,
    no_format_integer_widened,
    no_leading_preamble,
    no_type_hint_preamble,
    reject_nulls,
    wrap_combined_in_file_noop,
    wrap_in_file_noop,
)
from literalizer._types import Value
from literalizer.exceptions import (
    CallArgNotSupportedError,
    InvalidDictKeyError,
    UnrepresentableStringError,
)

_MAX_STRINGIFIED_COLLECTION_DEPTH = 12


@beartype
def _format_string_double(value: str) -> str:
    r"""Format a value as an expansion-free Bash double-quoted word.

    Bash does not interpret ``\n`` or ``\t`` inside double quotes, so
    control characters remain literal.  Characters that retain special
    meaning inside double quotes are escaped to prevent expansion or
    command substitution.
    """
    escaped = (
        value.replace("\\", "\\\\")
        .replace('"', '\\"')
        .replace("$", "\\$")
        .replace("`", "\\`")
    )
    return f'"{escaped}"'


@beartype
def _format_string_single(value: str) -> str:
    r"""Format a string for Bash single-quoted context.

    Bash single-quoted strings are completely literal — no escape
    sequences are recognized. The only way to embed a single quote is
    to end the quoted region, insert an escaped single quote, and open
    a new quoted region: ``'\''``.

    Backslashes, newlines, tabs, and all other characters are kept
    verbatim.
    """
    escaped = value.replace("'", r"'\''")
    return f"'{escaped}'"


_format_string_double_safe = reject_nul_string_formatter(
    _format_string_double,
    language_name="Bash",
)
_format_string_single_safe = reject_nul_string_formatter(
    _format_string_single,
    language_name="Bash",
)


@beartype
def _escape_bash_nested_expression(value: str, /) -> str:
    """Escape Bash source for an outer double-quoted collection value.

    Existing escapes protecting expansion characters need another layer of
    protection so the outer double-quoted parse leaves them intact for the
    nested expression.
    """
    escaped: list[str] = []
    index = 0
    while index < len(value):
        character = value[index]
        if (
            character == "\\"
            and index + 1 < len(value)
            and value[index + 1] in {"$", "`"}
        ):
            escaped.append("\\\\" + "\\" + value[index + 1])
            index += 2
            continue
        escaped.append(
            {"\\": "\\\\", '"': '\\"', "$": "\\$", "`": "\\`"}.get(
                character,
                character,
            )
        )
        index += 1
    return "".join(escaped)


@beartype
def _to_bash_value(item: str) -> str:
    """Quote an item if it is a nested array or dict expression.

    Bash does not support nested array literals, so any value that is
    itself an array or associative-array expression (starting with
    ``(``) is double-quoted with special characters escaped.
    """
    if item.startswith("("):
        escaped = _escape_bash_nested_expression(item)
        return f'"{escaped}"'
    return item


@beartype
def _format_bash_sequence_entry(original: Value, item: str) -> str:
    """Format a Bash indexed-array element, quoting nested collections."""
    if isinstance(original, (list, dict, set)):
        escaped = _escape_bash_nested_expression(item)
        return f'"{escaped}"'
    return item


@beartype
def _format_bash_dict_entry(
    key: str,
    _raw_value: Value,
    formatted_value: str,
) -> str:
    """Format a Bash associative-array entry as ``[key]=value``."""
    return f"[{key}]={_to_bash_value(item=formatted_value)}"


_DELETE_CHARACTER = "\x7f"


@beartype
def _reject_delete_in_compound(*, data: Value) -> None:
    r"""Reject U+007F in a value a compound assignment would carry.

    Bash keeps the byte through a simple ``name=value`` assignment but
    inserts a spurious ``\x01`` before it inside the bracketed
    compound form an array or associative array uses, so a string in a
    collection loses its value (issue #4462).
    """
    match data:
        case str() if _DELETE_CHARACTER in data:
            raise UnrepresentableStringError(
                language_name="Bash",
                character_name="DELETE",
            )
        case dict():
            for key, value in data.items():
                _reject_delete_in_compound(data=key)
                _reject_delete_in_compound(data=value)
        case list() | set():
            for value in data:
                _reject_delete_in_compound(data=value)
        case _:
            return


@beartype
def _bash_validate_spec_for_data(_self: "Bash", data: Value) -> None:
    """Raise for values and dict keys that Bash cannot represent."""
    reject_nulls(data=data, language_name="Bash")
    # A lone scalar is emitted as a simple assignment, which keeps the
    # byte; anything else goes through a compound assignment.
    if not isinstance(data, str):
        _reject_delete_in_compound(data=data)
    guard_collection_nesting_depth(
        data=data,
        language_name="Bash",
        maximum_depth=_MAX_STRINGIFIED_COLLECTION_DEPTH,
    )
    _bash_validate_dict_keys(data=data)
    reject_stringified_dict_key_collisions(data=data, language_name="Bash")


@beartype
def _bash_validate_dict_keys(data: Value) -> None:
    """Raise InvalidDictKeyError for any empty or non-printable-ASCII key.

    Bash associative arrays reject empty-string subscripts at runtime,
    and control characters cannot be expressed in a Bash double-quoted
    key literal.
    """
    match data:
        case dict():
            for raw_key in data:
                rendered_key = raw_key
                if not isinstance(rendered_key, str):
                    rendered_key = f"{raw_key!r}"
                if (
                    rendered_key == ""
                    or not rendered_key.isprintable()
                    or not rendered_key.isascii()
                ):
                    msg = (
                        f"Bash does not support the dict key {raw_key!r}. "
                        "Associative-array keys must be non-empty "
                        "printable ASCII."
                    )
                    raise InvalidDictKeyError(msg)
            for v in data.values():
                _bash_validate_dict_keys(data=v)
        case list():
            for item in data:
                _bash_validate_dict_keys(data=item)
        case _:
            pass


@beartype
def _bash_call_stub(
    parts: Sequence[str],
    _params: Sequence[str],
    _stub_return: StubReturn,
    _args: Sequence[Value],
    /,
) -> tuple[str, ...]:
    """Return a Bash function stub that accepts any arguments."""
    return (f"{'.'.join(parts)}() {{ :; }}",)


@beartype
def _format_variable_declaration(
    name: str,
    value: str,
    data: Value,
    _modifiers: frozenset[enum.Enum],
) -> str:
    """Format a Bash ``declare`` variable declaration."""
    is_associative_initializer = (
        isinstance(data, dict)
        and bool(data)
        and value.lstrip().startswith("(")
    )
    flag = ""
    if is_associative_initializer:
        flag = " -A"
    return f"declare{flag} {name}={value}"


@beartype
def _format_call_variable_declaration(
    name: str,
    value: str,
    _data: Value,
    _modifiers: frozenset[enum.Enum],
) -> str:
    """Format a Bash ``declare`` binding whose right-hand side is a
    call.

    The literal-binding template assigns the right-hand side as a value
    word (``declare name=42``); binding a call result instead requires
    command substitution (``declare name="$(target arg1 arg2)"``) so
    the shell runs the command and captures its output.  A call result
    is a scalar string, so the associative-array ``-A`` flag never
    applies.
    """
    return f'declare {name}="$({value})"'


@beartype
@dataclasses.dataclass(frozen=True, kw_only=True)
class Bash(metaclass=LanguageCls):
    """Bash language specification."""

    reserved_module_identifiers: ClassVar[frozenset[str]] = frozenset()
    immutable_variable_modifiers: ClassVar[frozenset[enum.Enum]] = frozenset()
    wrap_in_file_tolerates_pre_indent = True
    module_name_shares_variable_scope = False
    reserved_variable_identifier_pattern: ClassVar[re.Pattern[str] | None] = (
        None
    )
    reserved_call_parameter_identifiers: ClassVar[frozenset[str]] = frozenset()
    reserved_call_parameter_identifier_pattern: ClassVar[
        re.Pattern[str] | None
    ] = None
    accepts_type_name_call_target = True
    declares_type_name_call_target = True
    dotted_call_root_shares_entrypoint_namespace = True
    reserved_bare_call_target_identifiers: ClassVar[frozenset[str]] = (
        frozenset()
    )
    reserved_call_target_head_identifiers: ClassVar[frozenset[str]] = (
        frozenset()
    )
    contextual_call_target_identifiers: ClassVar[frozenset[str]] = frozenset()
    call_parameter_shadowing = CallParameterShadowing.ALLOWED
    reserved_call_target_keywords_case_sensitive = True
    module_name_must_start_uppercase = False
    new_variable_name_syntax = NewVariableNameSyntax.ASCII
    max_variable_identifier_length: ClassVar[int | None] = None
    call_target_name_syntax: ClassVar[NewVariableNameSyntax | None] = None
    supports_multiline_dict_layout = True
    pools_map_integer_width = True

    stringifies_nested_collections = True

    format_integer_widened = no_format_integer_widened
    format_integer_beyond_i64 = no_format_integer_beyond_i64
    format_constructor_target: ClassVar["staticmethod[[str], str]"] = (
        staticmethod(identity_constructor_target)
    )
    sequence_binding_declarations = default_sequence_binding_declarations
    format_call_binding_body_preamble = no_call_binding_body_preamble
    format_call_binding_file_pragmas = no_call_binding_file_pragmas

    leading_preamble = no_leading_preamble
    extension = ".sh"
    pygments_name = "bash"
    supports_special_floats = True
    supports_variable_names = True
    supports_no_variable_wrap_in_file = False
    wraps_data_dependent_preamble_in_body = False
    dict_supports_heterogeneous_values = True
    supports_dotted_calls = True
    has_free_function_calls = True
    reserved_identifiers: ClassVar[frozenset[str]] = frozenset()
    declares_call_parameter_names = True
    reserved_variable_identifiers_case_sensitive: bool = True
    reserved_variable_identifiers: frozenset[str] = frozenset(
        {
            "!",
            "case",
            "coproc",
            "do",
            "done",
            "elif",
            "else",
            "esac",
            "fi",
            "for",
            "function",
            "if",
            "in",
            "select",
            "then",
            "time",
            "until",
            "while",
        }
    )
    allows_empty_call_parens = True
    supports_dotted_call_stub = True
    call_returns_expression = True
    supports_json_call_result_binding = False
    supports_zero_parameter_calls = True
    max_call_parameters = NO_CALL_PARAMETER_LIMIT
    supports_inline_multiline_dict_args = True
    supports_standalone_comments_in_wrapped_calls = True
    supports_multi_param_call_wrapper_stub = True
    supports_dict_literal_as_free_expression = True
    supports_module_name = False
    supports_empty_dict_key = False
    supports_call_style = True
    supports_default_dict_key_type = False
    supports_default_dict_value_type = False
    supports_default_sequence_element_type = False
    supports_default_set_element_type = False
    supports_default_ordered_map_value_type = False
    json_type_variant_name_suffix: ClassVar[str | None] = None
    supports_non_ascii_string_literals = True
    supports_multiline_string_literals = False
    supports_empty_sibling_sequence_type_hints = True
    supports_typed_dict_open = False
    language_id: ClassVar[str] = "bash"
    variant_metadata: ClassVar[VariantMetadata] = VariantMetadata(
        round_trip_capabilities=frozenset(
            {
                RoundTripCapability.I64_BOUNDARIES,
                RoundTripCapability.INTERPOLATION_STRINGS,
            }
        ),
        modifier_sequence_format_overrides={},
        string_literals_escape_null_byte=False,
        supports_ref_elements_in_tuple_strategy=False,
    )
    supports_record_struct_name_prefix = False
    supports_record_shape_names = False
    record_shape_names_emit_declarations = False
    supports_non_string_dict_keys = True
    checks_raw_control_dict_keys_separately = True

    format_call_arg: ClassVar["staticmethod[[Value, str], str]"] = (
        staticmethod(
            identity_call_arg,
        )
    )
    """Callable that rewrites a formatted direct call argument."""

    class DateFormats(DateFormatEnum):
        """Date format options for Bash."""

        _value_: DateFormatConfig

        ISO = DateFormatConfig(
            formatter=format_date_iso, type_produced=str, preamble_lines=()
        )

    class DatetimeFormats(DatetimeFormatEnum):
        """Datetime format options for Bash."""

        _value_: DatetimeFormatConfig

        ISO = DatetimeFormatConfig(
            formatter=format_datetime_iso,
            type_produced=str,
            preamble_lines=(),
        )

        EPOCH = DatetimeFormatConfig(
            formatter=format_datetime_epoch,
            type_produced=int,
            preamble_lines=(),
        )

    class BytesFormats(enum.Enum):
        """Bytes formatting options."""

        _value_: Callable[[bytes], str]

        HEX = enum.member(value=format_bytes_hex)
        BASE64 = enum.member(value=format_bytes_base64)

        def __call__(self, data: bytes, /) -> str:
            """Format bytes."""
            return self._value_(data)

    class SequenceFormats(enum.Enum):
        """Sequence type options for Bash."""

        ARRAY = SequenceFormatConfig(
            sequence_open=fixed_open(open_str="("),
            close=")",
            supports_heterogeneity=True,
            single_element_trailing_comma=False,
            single_element_template=None,
            supports_trailing_comma=True,
            empty_sequence=None,
            preamble_lines=(),
            format_entry=passthrough_sequence_entry,
            typed_opener_fallback=None,
            uses_typed_literal_for_scalars=False,
            requires_uniform_record_shapes=False,
            declared_type=None,
            narrowed_empty_form=None,
        )

    class SetFormats(enum.Enum):
        """Set type options for Bash."""

        SET = SetFormatConfig(
            set_open=fixed_open(open_str="("),
            close=")",
            empty_set=None,
            preamble_lines=(),
            set_opener_template="",
            supports_heterogeneity=True,
            supports_trailing_comma=True,
        )

    class CommentFormats(enum.Enum):
        """Comment style options."""

        HASH = CommentConfig(
            prefix="#",
            suffix="",
        )

    class DeclarationStyles(enum.Enum):
        """Declaration style options."""

        DECLARE = DeclarationStyleConfig(
            formatter=_format_variable_declaration,
            supports_redefinition=True,
        )

    class DictEntryStyles(enum.Enum):
        """Dict entry style options."""

        DEFAULT = enum.auto()

    class DictFormats(enum.Enum):
        """Dict/map format options."""

        DEFAULT = enum.auto()

    class EmptyDictKey(enum.Enum):
        """Empty dict key options."""

        ALLOW = enum.auto()

    class FloatFormats(
        FloatSpecialsMixin,
        enum.Enum,
        positive_infinity="inf",
        negative_infinity="-inf",
        nan="nan",
    ):
        """Float format options."""

        REPR = enum.member(value=format_float_repr)
        SCIENTIFIC = enum.member(value=format_float_scientific)
        FIXED = enum.member(value=format_float_fixed)

    class IntegerFormats(enum.Enum):
        """Integer format options."""

        DECIMAL = enum.auto()

    class NumericLiteralSuffixes(enum.Enum):
        """Numeric literal suffix options."""

        NONE = enum.auto()

    class NumericSeparators(enum.Enum):
        """Numeric separator options."""

        NONE = enum.auto()

    class NumericStyles(enum.Enum):
        """Numeric literal style options."""

        OVERLOADED = enum.auto()

    class StringFormats(enum.Enum):
        """String format options."""

        _value_: Callable[[str], str]

        DOUBLE = enum.member(value=_format_string_double_safe)
        SINGLE = enum.member(value=_format_string_single_safe)

        def __call__(self, value: str, /) -> str:
            """Format a string."""
            return self._value_(value)

    class TrailingCommas(enum.Enum):
        """Trailing comma options."""

        NO = TrailingCommaConfig(multiline_trailing_comma=False)

    date_formats = DateFormats
    datetime_formats = DatetimeFormats
    bytes_formats = BytesFormats
    sequence_formats = SequenceFormats
    set_formats = SetFormats
    comment_formats = CommentFormats

    class VariableTypeHints(enum.Enum):
        """Variable type hint options."""

        NEVER = enum.auto()
        SAFE = enum.auto()

    variable_type_hints_formats = VariableTypeHints
    declaration_styles = DeclarationStyles
    dict_entry_styles = DictEntryStyles
    dict_formats = DictFormats
    empty_dict_keys = EmptyDictKey
    float_formats = FloatFormats
    integer_formats = IntegerFormats
    integer_width_strategies = BareIntegerWidthStrategies
    numeric_literal_suffixes = NumericLiteralSuffixes
    numeric_separators = NumericSeparators
    numeric_styles = NumericStyles
    string_formats = StringFormats
    trailing_commas = TrailingCommas

    class StatementTerminatorStyles(enum.Enum):
        """Statement terminator options."""

        SEMICOLON = enum.auto()

    statement_terminator_styles = StatementTerminatorStyles

    class CallStyles(enum.Enum):
        """Bash call style options."""

        COMMAND = CommandCallStyle(arg_separator=" ")

    call_styles = CallStyles

    class Modifiers(enum.Enum):
        """C++/Java/C#-style declaration modifiers: this language has none."""

    modifiers = Modifiers

    class HeterogeneousStrategies(enum.Enum):
        """Heterogeneous-scalar strategy options — this language only
        supports raising.
        """

        ERROR = NO_HETEROGENEOUS_BEHAVIOR

    heterogeneous_strategies = HeterogeneousStrategies

    class JsonTypes(JsonType):
        """Empty: this language has no JSON value-type variants."""

    json_types = JsonTypes

    class BoolFormats(enum.Enum):
        """Empty: this language has no alternative boolean formats."""

    bool_formats = BoolFormats

    class VersionFormats(enum.Enum):
        """Version options for Bash."""

        V5_1 = enum.auto()

    version_formats = VersionFormats

    modifier_combinations: ClassVar[tuple[ModifierCombination, ...]] = ()
    identifier_cases: ClassVar[tuple[IdentifierCase, ...]] = (
        IdentifierCase.SNAKE,
        IdentifierCase.UPPER_SNAKE,
    )
    supported_ref_cases: ClassVar[frozenset[IdentifierCase]] = (
        NON_KEBAB_REF_CASES
    )

    validate_spec_for_data = _bash_validate_spec_for_data

    @cached_property
    def format_call_statement(self) -> Callable[[str], str]:
        """Return call-statement formatting for this language."""
        return identity_call_statement

    wrap_calls_with_declarations = default_wrap_calls_with_declarations

    @staticmethod
    def validate_call_arg(value: Value) -> None:
        """Reject list, dict, and set values as Bash call arguments.

        Bash commands take space-separated positional arguments and
        have no syntax for inline compound literals — ``cmd (1 2 3)``
        parses as ``cmd`` followed by a nested ``(...)`` child-process
        group, and ``cmd (["k"]=v)`` likewise.  Callers that need to
        pass a collection must declare it as a variable first and
        pass the name via a ``$ref`` marker.
        """
        if isinstance(value, (list, dict, set, frozenset)):
            raise CallArgNotSupportedError(
                language_name="Bash",
                reason=(
                    f"{type(value).__name__} values have no inline "
                    "literal form in a Bash command invocation; "
                    "declare the collection as a variable and pass "
                    "it via a $ref marker instead"
                ),
            )

    @staticmethod
    def wrap_in_file(
        content: str,
        variable_name: str,
        body_preamble: tuple[str, ...],
    ) -> str:
        """Wrap code in a valid file (no-op)."""
        return wrap_in_file_noop(
            content=content,
            variable_name=variable_name,
            body_preamble=body_preamble,
        )

    @staticmethod
    def wrap_combined_in_file(
        declaration: str,
        assignment: str,
        variable_name: str,
        body_preamble: tuple[str, ...],
    ) -> str:
        """Wrap declaration and assignment in a valid file (no-op)."""
        return wrap_combined_in_file_noop(
            declaration=declaration,
            assignment=assignment,
            variable_name=variable_name,
            body_preamble=body_preamble,
        )

    date_format: DateFormats = DateFormats.ISO
    datetime_format: DatetimeFormats = DatetimeFormats.ISO
    bytes_format: BytesFormats = BytesFormats.HEX
    sequence_format: SequenceFormats = SequenceFormats.ARRAY
    set_format: SetFormats = SetFormats.SET
    variable_type_hints: VariableTypeHints = VariableTypeHints.NEVER
    comment_format: CommentFormats = CommentFormats.HASH
    declaration_style: DeclarationStyles = DeclarationStyles.DECLARE
    dict_entry_style: DictEntryStyles = DictEntryStyles.DEFAULT
    dict_format: DictFormats = DictFormats.DEFAULT
    float_format: FloatFormats = FloatFormats.REPR
    integer_format: IntegerFormats = IntegerFormats.DECIMAL
    integer_width_strategy: BareIntegerWidthStrategies = (
        BareIntegerWidthStrategies.BARE
    )
    numeric_literal_suffix: NumericLiteralSuffixes = (
        NumericLiteralSuffixes.NONE
    )
    numeric_separator: NumericSeparators = NumericSeparators.NONE
    numeric_style: NumericStyles = NumericStyles.OVERLOADED
    string_format: StringFormats = StringFormats.DOUBLE
    trailing_comma: TrailingCommas = TrailingCommas.NO
    statement_terminator_style: StatementTerminatorStyles = (
        StatementTerminatorStyles.SEMICOLON
    )
    call_style: CallStyles = CallStyles.COMMAND
    heterogeneous_strategy: HeterogeneousStrategies = (
        HeterogeneousStrategies.ERROR
    )
    # Keep in sync with the ``Lint Bash`` step of
    # ``.github/workflows/lint.yml``. The ``bash`` preinstalled on
    # ``ubuntu-latest`` both runs and lints the fixtures; that runner
    # default (the 5.x series) is ``>=`` this ``V5_1`` default and serves
    # as the pinned floor. Bash has no ``--langversion``-style flag, so
    # the runner default is the pin; the step's ``BASH_VERSINFO`` guard
    # fails the job if it ever drifts below 5.1.
    language_version: VersionFormats = VersionFormats.V5_1
    indent: str = "    "

    null_literal: ClassVar[str] = '""'
    true_literal: ClassVar[str] = "true"
    false_literal: ClassVar[str] = "false"
    indent_closing_delimiter: ClassVar[bool] = False
    element_separator: ClassVar[str] = " "
    skip_null_dict_values: ClassVar[bool] = False
    supports_collection_comments: ClassVar[bool] = True
    supports_scalar_before_comments: ClassVar[bool] = False
    supports_scalar_inline_comments: ClassVar[bool] = True
    statement_terminator: ClassVar[str] = ""
    static_preamble: ClassVar[Sequence[str]] = ()
    static_body_preamble: ClassVar[Sequence[str]] = ()
    special_float_preamble: ClassVar[tuple[str, ...]] = ()

    @cached_property
    def format_integer(self) -> Callable[[int], str]:
        """Format an int value as a literal."""
        return str

    @cached_property
    def format_sequence_entry(self) -> Callable[[Value, str], str]:
        """Format a sequence entry."""
        return _format_bash_sequence_entry

    @cached_property
    def format_set_entry(self) -> Callable[[Value, str], str]:
        """Format a set entry."""
        return passthrough_set_entry

    @cached_property
    def data_dependent_preamble(self) -> Callable[[Value], tuple[str, ...]]:
        """Return data-dependent preamble lines."""
        return no_data_preamble

    @cached_property
    def heterogeneous_behavior(self) -> HeterogeneousBehavior:
        """Return the heterogeneous-behavior config."""
        return self.heterogeneous_strategy.value

    @cached_property
    def call_data_dependent_preamble(
        self,
    ) -> Callable[[Value], tuple[str, ...]]:
        """Return data-dependent preamble lines for call rendering."""
        return self.data_dependent_preamble

    @cached_property
    def type_hint_collection_preamble_lines(
        self,
    ) -> Callable[[frozenset[type]], tuple[str, ...]]:
        """Return preamble lines for empty-collection type hints."""
        return no_type_hint_preamble

    @cached_property
    def format_call_stub(
        self,
    ) -> Callable[
        [Sequence[str], Sequence[str], StubReturn, Sequence[Value]],
        tuple[str, ...],
    ]:
        """Return stub declarations for a call expression."""
        return _bash_call_stub

    @cached_property
    def format_call_preamble_stub(
        self,
    ) -> Callable[
        [Sequence[str], Sequence[str], StubReturn, Sequence[Value]],
        tuple[str, ...],
    ]:
        """Return file-scope stubs for a call expression."""
        return no_call_stub

    @cached_property
    def call_style_config(self) -> CallStyle:
        """Configuration for the chosen call style."""
        return self.call_style.value

    @cached_property
    def format_call_target(self) -> Callable[[Sequence[str]], str]:
        """Rewrite a dotted call target into the language's call
        syntax.
        """
        return identity_call_target

    @cached_property
    def format_call_ref_identifier(
        self,
    ) -> Callable[[str, Value | None], str]:
        """Rewrite a ``{"$ref": "name"}`` identifier into the
        language's call expression syntax.
        """
        return identity_call_ref_identifier

    @cached_property
    def format_call_arg_ref_identifier(
        self,
    ) -> Callable[[str, Value | None], str]:
        """Rewrite a ``{"$ref": "name"}`` identifier in a call-argument
        context.

        Delegates to :attr:`format_call_ref_identifier`.  Override this to
        allow call-argument ``$ref`` values that would otherwise be rejected.
        """
        return self.format_call_ref_identifier

    @cached_property
    def format_call_arg_ref_identifier_consumable(
        self,
    ) -> Callable[[str, Value | None], str]:
        """Format a ``$ref`` the caller authorized as consumable.

        Delegates to :attr:`format_call_arg_ref_identifier`.  Override
        this to opt into a consuming form (e.g. C++ ``std::move``).
        """
        return self.format_call_arg_ref_identifier

    @cached_property
    def consumable_ref_value_inhibits_consuming_form(
        self,
    ) -> Callable[[Value], bool]:
        """Predicate deciding whether a ref's underlying value type
        inhibits the consume form.

        Delegates to :data:`never_inhibits_consuming_form`.  Languages
        whose consume operator rejects certain value types (notably
        the Mojo ``^`` on register-trivial scalars) override this.
        """
        return never_inhibits_consuming_form

    @cached_property
    def sequence_format_config(self) -> SequenceFormatConfig:
        """Configuration for the chosen sequence format."""
        return self.sequence_format.value

    @cached_property
    def set_format_config(self) -> SetFormatConfig:
        """Configuration for the chosen set format."""
        return self.set_format.value

    @cached_property
    def sequence_open(self) -> Callable[[list[Value]], str]:
        """Callable that returns the opening delimiter for a sequence."""
        return self.sequence_format.value.sequence_open

    @cached_property
    def dict_format_config(self) -> DictFormatConfig:
        """Configuration for dict formatting."""
        return DictFormatConfig(
            dict_open=fixed_open(open_str="("),
            close=")",
            format_entry=_format_bash_dict_entry,
            empty_dict=None,
            preamble_lines=(),
            narrowed_open=None,
            supports_trailing_comma=True,
            narrowed_empty_form=None,
        )

    @cached_property
    def trailing_comma_config(self) -> TrailingCommaConfig:
        """Configuration for trailing-comma behavior."""
        return self.trailing_comma.value

    @cached_property
    def format_bytes(self) -> Callable[[bytes], str]:
        """Callable that formats a bytes value as a string literal."""
        return self.bytes_format

    @cached_property
    def format_date(self) -> Callable[[datetime.date], str]:
        """Callable that formats a date as a string literal."""
        return self.date_format

    @cached_property
    def format_datetime(self) -> Callable[[datetime.datetime], str]:
        """Callable that formats a datetime as a string literal."""
        return self.datetime_format

    @cached_property
    def format_time(self) -> Callable[[datetime.time], str]:
        """Callable that formats a time as a string literal."""
        return format_time_iso

    @cached_property
    def format_string(self) -> Callable[[str], str]:
        """Callable that formats a string value as a quoted literal."""
        return self.string_format

    @cached_property
    def format_float(self) -> Callable[[float], str]:
        """Callable that formats a float value as a literal."""
        return self.float_format

    @cached_property
    def comment_config(self) -> CommentConfig:
        """Configuration for the language's comment syntax."""
        return self.comment_format.value

    @cached_property
    def ordered_map_format_config(self) -> OrderedMapFormatConfig:
        """Configuration for ordered-map formatting."""
        return OrderedMapFormatConfig(
            ordered_map_open=fixed_open(open_str="("),
            close=")",
            preamble_lines=(),
        )

    @cached_property
    def format_ordered_map_entry(self) -> Callable[[str, Value, str], str]:
        """Callable that formats one ordered-map entry."""
        return _format_bash_dict_entry

    @cached_property
    def format_variable_declaration(
        self,
    ) -> Callable[[str, str, Value, frozenset[enum.Enum]], str]:
        """Callable that formats a new variable declaration."""
        return self.declaration_style.value.formatter

    @cached_property
    def format_variable_assignment(
        self,
    ) -> Callable[[str, str, Value], str]:
        """Callable that formats an assignment to an existing variable."""
        return variable_formatter(template="{name}={value}")

    @cached_property
    def format_call_variable_declaration(
        self,
    ) -> Callable[[str, str, Value, frozenset[enum.Enum]], str]:
        """Callable that formats a declaration binding a call expression.

        The literal-binding template assigns the right-hand side as a
        value word; a call result must be command-substituted with
        ``"$(...)"`` so the shell runs the command and captures its
        output instead of assigning the command name verbatim.
        """
        return _format_call_variable_declaration

    @cached_property
    def format_call_variable_assignment(
        self,
    ) -> Callable[[str, str, Value], str]:
        """Callable that formats an assignment binding a call
        expression.

        The existing-variable counterpart of
        :attr:`format_call_variable_declaration`: a bare
        ``name="$(...)"`` with no ``declare`` keyword, matching the
        literal-binding assignment template.
        """
        return variable_formatter(template='{name}="$({value})"')

    @cached_property
    def scalar_preamble(self) -> dict[type, tuple[str, ...]]:
        """Per-instance scalar preamble (Bash needs none)."""
        return {}

    @cached_property
    def scalar_body_preamble(self) -> dict[type, tuple[str, ...]]:
        """Per-instance scalar body preamble (Bash needs none)."""
        return {}

    @cached_property
    def compute_body_preamble(
        self,
    ) -> Callable[[frozenset[type], Value], tuple[str, ...]]:
        """Compute body-preamble lines from the scalar map."""
        return body_preamble_from_scalars(
            scalar_body_preamble=self.scalar_body_preamble,
            format_lines=tuple,
        )
