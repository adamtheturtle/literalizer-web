"""Nim language specification."""

import dataclasses
import datetime
import enum
import re
from collections.abc import Callable, Mapping, Sequence
from functools import cached_property, partial
from types import MappingProxyType
from typing import ClassVar, assert_never

from beartype import beartype

from literalizer._checks import (
    reject_ragged_nested_sequences,
)
from literalizer._formatters.collection_openers import (
    fixed_open,
    sequence_surrogate_set_open,
)
from literalizer._formatters.format_dates import (
    date_ymd_formatter,
    datetime_ymdhms_formatter,
    format_date_iso,
    format_datetime_epoch,
    format_datetime_iso,
    format_time_iso,
)
from literalizer._formatters.format_entries import (
    dict_entry_with_separator,
    format_bytes_base64,
    format_bytes_hex,
    passthrough_sequence_entry,
    passthrough_set_entry,
    variable_declaration_formatter,
    variable_formatter,
)
from literalizer._formatters.format_floats import (
    format_float_fixed,
    format_float_repr,
    format_float_scientific,
)
from literalizer._formatters.format_integers import (
    I64_MAX,
    I64_MIN,
    format_integer_binary,
    format_integer_hex,
    format_integer_octal,
    format_integer_underscore,
    make_overflow_fallback_formatter,
    raise_for_unrepresentable_int,
)
from literalizer._formatters.format_strings import (
    format_string_backslash_nul_hex,
)
from literalizer._formatters.record_strategy import (
    RecordDeclarationField,
    RecordFieldType,
    RecordLiteralField,
    RecordRenderer,
    RecordStrategy,
    build_record_strategy,
)
from literalizer._formatters.type_inference import (
    WideInt,
    infer_element_type,
    int_widening_tier,
    record_shape_for_dict,
)
from literalizer._heterogeneous import (
    collect_heterogeneous_container_ids,
    collect_sibling_map_wrap_ids,
    iter_wrapped_scalars,
)
from literalizer._language import (
    NO_CALL_PARAMETER_LIMIT,
    NO_HETEROGENEOUS_BEHAVIOR,
    NON_KEBAB_REF_CASES,
    BareIntegerWidthStrategies,
    CallParameterShadowing,
    CallStyle,
    CommentConfig,
    DateFormatConfig,
    DateFormatEnum,
    DatetimeFormatConfig,
    DatetimeFormatEnum,
    DeclarationStyleConfig,
    DictFormatConfig,
    FloatSpecialsMixin,
    HeterogeneousBehavior,
    IdentifierCase,
    JsonType,
    LanguageCls,
    ModifierCombination,
    NewVariableNameSyntax,
    OrderedMapFormatConfig,
    PositionalCallStyle,
    RenderedRecordLiteral,
    RoundTripCapability,
    SequenceFormatConfig,
    SetFormatConfig,
    StubReturn,
    TrailingCommaConfig,
    VariantMetadata,
    body_preamble_from_scalars,
    default_sequence_binding_declarations,
    default_wrap_calls_with_declarations,
    identity_call_arg,
    identity_call_ref_identifier,
    identity_call_statement,
    identity_call_target,
    identity_constructor_target,
    never_inhibits_consuming_form,
    no_call_binding_body_preamble,
    no_call_binding_file_pragmas,
    no_call_stub,
    no_compute_call_slot_wrap_ids,
    no_data_preamble,
    no_empty_container_literal_overrides,
    no_format_integer_beyond_i64,
    no_leading_preamble,
    no_type_hint_preamble,
    no_validate_call_arg,
    wrap_combined_in_file_noop,
    wrap_in_file_noop,
)
from literalizer._types import OrderedMap, Scalar, Value
from literalizer.exceptions import (
    IncompatibleFormatsError,
    UnrepresentableInputError,
)

_NIM_JSON_MACRO = "%*"
_TRAILING_LINE_WHITESPACE = re.compile(pattern=r"[ \t]+(?=\n)")


@beartype
def _reject_uninferrable_native_sequences(*, data: Value) -> None:
    """Reject native Nim sequences whose element type is ambiguous."""
    match data:
        case dict():
            for child in data.values():
                _reject_uninferrable_native_sequences(data=child)
        case list():
            all_empty_lists = len(data) > 0 and all(
                item == [] for item in data
            )
            if (
                len(data) > 0
                and not all_empty_lists
                and (infer_element_type(items=data) is None)
            ):
                msg = (
                    "Nim native sequences require one inferable element "
                    "type; this sequence contains incompatible elements"
                )
                raise UnrepresentableInputError(msg)
            for child in data:
                _reject_uninferrable_native_sequences(data=child)
        case _:
            return


@beartype
def _reject_distinct_record_list_ordered_map_values(*, data: Value) -> None:
    """Reject ordered maps whose record-list values have distinct
    types.
    """
    match data:
        case OrderedMap():
            record_shapes = {
                shape
                for value in data.values()
                if isinstance(value, list)
                for item in value
                if isinstance(item, dict)
                and not isinstance(item, OrderedMap)
                and (shape := record_shape_for_dict(value=item)) is not None
            }
            if len(record_shapes) > 1:
                msg = (
                    "Nim ordered tables require one value type; record-list "
                    "values with distinct record shapes have no common type"
                )
                raise UnrepresentableInputError(msg)
            for child in data.values():
                _reject_distinct_record_list_ordered_map_values(data=child)
        case dict():
            for child in data.values():
                _reject_distinct_record_list_ordered_map_values(data=child)
        case list():
            for child in data:
                _reject_distinct_record_list_ordered_map_values(data=child)
        case _:
            return


@beartype
def _format_string_multiline(value: str) -> str:
    r"""Format *value* as a raw Nim triple-quoted string when safe."""
    if value.startswith(("\n", '"')) or value.endswith('"'):
        return format_string_backslash_nul_hex(value=value)
    if (
        '"""' in value
        or "\x00" in value
        or "\r" in value
        or bool(_TRAILING_LINE_WHITESPACE.search(string=value))
    ):
        return format_string_backslash_nul_hex(value=value)
    return f'"""{value}"""'


@beartype
def _nim_json_value_expression(raw_value: Value, value: str, /) -> str:
    """Wrap a scalar *value* in ``%*``.

    Values produced by the JSON-mode container openers already begin
    with ``%*`` and explicit ``newJArray()`` / ``newJObject()`` /
    ``newJNull()`` builders begin with ``newJ``; both are
    ``JsonNode`` typed and skip the extra wrap so the output does not
    accumulate redundant macros.
    """
    if isinstance(raw_value, (dict, list, set)):
        return value
    return f"{_NIM_JSON_MACRO}({value})"


@beartype
def _format_nim_json_call_arg(raw_value: Value, formatted: str) -> str:
    """Format a direct Nim call argument as ``JsonNode``."""
    return _nim_json_value_expression(raw_value, formatted)


@beartype
def _format_nim_json_assignment(name: str, value: str, data: Value) -> str:
    """Assign a rendered literal to a Nim ``JsonNode`` binding."""
    return f"{name} = {_nim_json_value_expression(data, value)}"


@beartype
def _nim_json_declaration_formatter(
    *,
    declaration_style: enum.Enum,
    json_type: str,
) -> Callable[[str, str, Value, frozenset[enum.Enum]], str]:
    """Return a declaration formatter for ``JsonNode`` output."""

    def _formatter(
        name: str,
        value: str,
        data: Value,
        _modifiers: frozenset[enum.Enum],
    ) -> str:
        """Format a JSON-backed declaration."""
        expr = _nim_json_value_expression(data, value)
        keyword = declaration_style.name.lower()
        return f"{keyword} {name}: {json_type} = {expr}"

    return _formatter


@beartype
def _is_nim_reference_binding(*, value: Value, formatted_value: str) -> bool:
    """Return whether *value* was resolved to a binding elsewhere.

    A marker is emitted as the bare identifier it names rather than as
    a literal.  The formatted-value check distinguishes that resolved
    marker from ordinary JSON data whose sole key happens to be ``$ref``.
    """
    return (
        isinstance(value, dict)
        and len(value) == 1
        and isinstance(value.get("$ref"), str)
        and not formatted_value.lstrip().startswith("{")
    )


@beartype
def _apply_nim_variable_declaration(
    *,
    name: str,
    value: str,
    _data: Value,
    uses_typed_literal_for_scalars: bool,
    keyword: str,
    force_sequence: bool,
    uses_json_wrap: bool,
) -> str:
    """Format a declaration, using ``@`` for flat sequences of
    simple scalars.
    """
    use_sequence = (
        isinstance(_data, list)
        and len(_data) > 0
        and (
            force_sequence
            or (
                uses_typed_literal_for_scalars
                and all(
                    isinstance(item, (str, int, float, bool, bytes))
                    for item in _data
                )
            )
        )
    )
    if use_sequence:
        return f"{keyword} {name} = @{value}"
    if force_sequence or not uses_json_wrap:
        return f"{keyword} {name} = {value}"
    if _is_nim_reference_binding(
        value=_data,
        formatted_value=value,
    ):
        # The value names a binding declared above, whose own
        # declaration already chose its type.  Converting it with
        # ``%*`` would need an ``import json`` that nothing else in
        # the file asks for, and would retype a sequence the caller
        # bound deliberately (issue #4768).
        return f"{keyword} {name} = {value}"
    return f"{keyword} {name} = %* {value}"


@beartype
def _make_variable_declaration(
    *,
    uses_typed_literal_for_scalars: bool,
    keyword: str,
    force_sequence: bool,
    uses_json_wrap: bool,
) -> Callable[[str, str, Value, frozenset[enum.Enum]], str]:
    """Create a Nim variable declaration formatter."""

    def _format(
        name: str,
        value: str,
        _data: Value,
        _modifiers: frozenset[enum.Enum],
    ) -> str:
        """Delegate to module-level implementation."""
        return _apply_nim_variable_declaration(
            name=name,
            value=value,
            _data=_data,
            uses_typed_literal_for_scalars=uses_typed_literal_for_scalars,
            keyword=keyword,
            force_sequence=force_sequence,
            uses_json_wrap=uses_json_wrap,
        )

    return _format


@beartype
def _apply_nim_variable_assignment(
    *,
    name: str,
    value: str,
    _data: Value,
    uses_typed_literal_for_scalars: bool,
    uses_json_wrap: bool,
) -> str:
    """Format an assignment, using ``@`` for flat sequences of
    simple scalars.
    """
    if (
        uses_typed_literal_for_scalars
        and isinstance(_data, list)
        and (len(_data) > 0)
        and all(
            isinstance(item, (str, int, float, bool, bytes)) for item in _data
        )
    ):
        return f"{name} = @{value}"
    if not uses_json_wrap:
        return f"{name} = {value}"
    return f"{name} = %* {value}"


@beartype
def _make_variable_assignment(
    *,
    uses_typed_literal_for_scalars: bool,
    uses_json_wrap: bool,
) -> Callable[[str, str, Value], str]:
    """Create a Nim variable assignment formatter."""

    def _format(name: str, value: str, _data: Value) -> str:
        """Delegate to module-level implementation."""
        return _apply_nim_variable_assignment(
            name=name,
            value=value,
            _data=_data,
            uses_typed_literal_for_scalars=uses_typed_literal_for_scalars,
            uses_json_wrap=uses_json_wrap,
        )

    return _format


@beartype
@dataclasses.dataclass(frozen=True)
class _VariantSignature:
    """Name and optional field info for one Nim object variant branch.

    ``field_name`` and ``field_type`` are ``None`` for unit variants
    (e.g. ``vkNull``); for payload-carrying variants they're the field
    identifier and Nim type used inside the ``of`` branch.
    """

    kind_name: str
    field_name: str | None
    field_type: str | None


@beartype
def _nim_temporal_variant_signature(
    *,
    value: datetime.date | datetime.time,
    date_type: str,
    datetime_type: str,
) -> _VariantSignature:
    """Return the object-variant signature for one temporal value."""
    match value:
        case datetime.datetime():
            return _VariantSignature(
                kind_name="vkDateTime",
                field_name="dateTimeVal",
                field_type=datetime_type,
            )
        case datetime.date():
            return _VariantSignature(
                kind_name="vkDate",
                field_name="dateVal",
                field_type=date_type,
            )
        case _:
            return _VariantSignature(
                kind_name="vkTime",
                field_name="timeVal",
                field_type="string",
            )


@beartype
def _nim_variant_for_scalar(
    *,
    value: Scalar,
    date_type: str,
    datetime_type: str,
) -> _VariantSignature:
    """Return the Nim object-variant signature for *value*."""
    match value:
        case bool():
            signature = _VariantSignature(
                kind_name="vkBool",
                field_name="boolVal",
                field_type="bool",
            )
        case int():
            signature = _VariantSignature(
                kind_name="vkInt",
                field_name="intVal",
                field_type="int",
            )
        case float():
            signature = _VariantSignature(
                kind_name="vkFloat",
                field_name="floatVal",
                field_type="float",
            )
        case str():
            signature = _VariantSignature(
                kind_name="vkStr",
                field_name="strVal",
                field_type="string",
            )
        case bytes():
            signature = _VariantSignature(
                kind_name="vkBytes",
                field_name="bytesVal",
                field_type="string",
            )
        case datetime.datetime() | datetime.date() | datetime.time():
            signature = _nim_temporal_variant_signature(
                value=value,
                date_type=date_type,
                datetime_type=datetime_type,
            )
        case None:
            signature = _VariantSignature(
                kind_name="vkNull",
                field_name=None,
                field_type=None,
            )
        case _ as unreachable:
            assert_never(unreachable)
    return signature


@beartype
@dataclasses.dataclass(frozen=True)
class _HeterogeneousStrategyConfig:
    """Configuration for one Nim heterogeneous-values strategy.

    ``build_behavior`` produces the
    :class:`~literalizer._language.HeterogeneousBehavior` exposed on a
    Nim instance.  ``build_preamble`` produces the data-dependent
    preamble callable (e.g. the object-variant type declaration).  Both
    receive the Nim instance's configurable variant-type name and
    scalar type names so the resulting functions can close over them.
    ``resolves_per_instance`` distinguishes strategies such as ``RECORD``
    whose real behavior and preamble come from instance configuration.
    """

    build_behavior: Callable[[str, str, str], HeterogeneousBehavior]
    build_preamble: Callable[
        [str, str, str, str],
        Callable[[Value], tuple[str, ...]],
    ]
    resolves_per_instance: bool


@beartype
def _build_error_behavior(
    _variant_name: str,
    _date_type: str,
    _datetime_type: str,
    /,
) -> HeterogeneousBehavior:
    """ERROR strategy: no wrapping, no skipping of checks."""
    return NO_HETEROGENEOUS_BEHAVIOR


@beartype
def _build_error_preamble(
    _variant_name: str,
    _date_type: str,
    _datetime_type: str,
    _indent: str,
    /,
) -> Callable[[Value], tuple[str, ...]]:
    """ERROR strategy: no data-dependent preamble."""
    return no_data_preamble


@beartype
def _needs_json_wrap_for_field(field_type: str | None) -> bool:
    """Return whether *field_type* requires ``%*`` to convert a
    formatted scalar into the variant payload.

    The Nim ``NIM`` date / datetime formats emit a table-literal string
    like ``{"year": ..., ...}`` that only becomes a value when
    ``%*``-converted to a :class:`json.JsonNode`.
    """
    return field_type == "JsonNode"


class _NimContainerKind(enum.Enum):
    """Kinds of native Nim container represented by a shape."""

    LIST = enum.auto()
    DICT = enum.auto()


class _NimShapeMarker(enum.Enum):
    """Non-concrete child states in a native Nim container shape."""

    EMPTY = enum.auto()
    MIXED = enum.auto()


@beartype
@dataclasses.dataclass(frozen=True, slots=True)
class _NimContainerShape:
    """The native Nim type shape inferred for a container."""

    kind: _NimContainerKind
    child: "type | _NimContainerShape | _NimShapeMarker"


type _NimLiteralShape = type | _NimContainerShape


@beartype
def _nim_child_shape(
    *, child_types: set[_NimLiteralShape]
) -> _NimLiteralShape | _NimShapeMarker:
    """Return the common child shape, or an empty/mixed marker."""
    if len(child_types) == 0:
        return _NimShapeMarker.EMPTY
    if len(child_types) == 1:
        return next(iter(child_types))
    return _NimShapeMarker.MIXED


@beartype
def _nim_container_children(item: Value) -> list[Value] | None:
    """Return the direct children of a supported container."""
    match item:
        case dict():
            return list(item.values())
        case list():
            return list(item)
        case _:
            return None


@beartype
def _nim_literal_shape(item: Value) -> _NimLiteralShape:
    """Return the native Nim type shape inferred for *item*.

    Python's ``type`` alone is not enough for nested collections: two dicts
    can both be ``dict`` while rendering as incompatible
    ``Table[string, seq[string]]`` and ``Table[string, seq[int]]``. Keep the
    integer widening tier in the shape as well, matching the magnitude-aware
    collection-literal inference.
    """
    child_types: set[type | _NimContainerShape]
    match item:
        case bool():
            return bool
        case int():
            tier = int_widening_tier(items=[item])
            return int if tier is None else tier
        case list():
            child_types = {_nim_literal_shape(item=child) for child in item}
            return _NimContainerShape(
                kind=_NimContainerKind.LIST,
                child=_nim_child_shape(child_types=child_types),
            )
        case dict() if not isinstance(item, OrderedMap):
            child_types = {
                _nim_literal_shape(item=child) for child in item.values()
            }
            return _NimContainerShape(
                kind=_NimContainerKind.DICT,
                child=_nim_child_shape(child_types=child_types),
            )
        case _:
            return type(item)


@beartype
def _mark_nim_object_variant_wrap_ids(
    *, item: Value, wrap_ids: set[int]
) -> None:
    """Mark containers that require a recursive value type."""
    children = _nim_container_children(item=item)
    if children is None:
        return
    for child in children:
        _mark_nim_object_variant_wrap_ids(item=child, wrap_ids=wrap_ids)
    # Empty containers need a concrete type when placed beside a populated
    # container; null is only representable by vkNull.
    if len(children) == 0 or any(child is None for child in children):
        wrap_ids.add(id(item))
        return
    # Collections widen integer siblings to their widest native Nim element
    # type. Match that decision here so a list such as ``[1, 2**31]`` stays a
    # native ``seq[int64]`` rather than being treated as mixed and wrapped.
    widening_tier = int_widening_tier(items=children)
    child_types: set[type | _NimContainerShape]
    if widening_tier is not None:
        child_types = {widening_tier}
    else:
        child_types = {_nim_literal_shape(item=child) for child in children}
    containers = [
        child for child in children if isinstance(child, (list, dict))
    ]
    # A native parent must use Value for any child container that already uses
    # recursive Value elements, even when their native shapes match.
    if len(child_types) > 1 or any(
        id(child) in wrap_ids for child in containers
    ):
        wrap_ids.add(id(item))


@beartype
def _close_nim_object_variant_wrap_ids(
    *, item: Value, ancestor_wrapped: bool, wrap_ids: set[int]
) -> None:
    """Mark nested containers below an already wrapped container."""
    children = _nim_container_children(item=item)
    if children is None:
        return
    wrapped = ancestor_wrapped or id(item) in wrap_ids
    if ancestor_wrapped:
        wrap_ids.add(id(item))
    for child in children:
        _close_nim_object_variant_wrap_ids(
            item=child,
            ancestor_wrapped=(wrapped and isinstance(child, (list, dict))),
            wrap_ids=wrap_ids,
        )


@beartype
def _nim_object_variant_wrap_ids(*, data: Value) -> frozenset[int]:
    """Return containers whose children need the recursive ``Value`` type.

    The Nim object variant has list and table payloads as well as scalar
    payloads. Once a container is represented by ``Value``, every container
    below it must use the same recursive element/value type too; otherwise
    (for example) ``Value(... tableVal: Table[string, int])`` cannot satisfy
    a ``Table[string, Value]`` field.
    """
    wrap_ids = set(
        collect_heterogeneous_container_ids(data=data)
        | collect_sibling_map_wrap_ids(data=data)
    )
    _mark_nim_object_variant_wrap_ids(item=data, wrap_ids=wrap_ids)
    # Close over nested containers after the bottom-up decision above. This
    # gives every list/table payload its declared seq[Value] or
    # Table[string, Value] type, including otherwise homogeneous children.
    _close_nim_object_variant_wrap_ids(
        item=data,
        ancestor_wrapped=False,
        wrap_ids=wrap_ids,
    )
    return frozenset(wrap_ids)


@beartype
def _nim_wrapped_container_kinds(
    *, data: Value, wrap_ids: frozenset[int]
) -> tuple[bool, bool]:
    """Return whether a wrapped child needs the list or table branch."""
    has_list = False
    has_table = False

    def _visit(item: Value) -> None:
        """Find container branches used by wrapped children."""
        nonlocal has_list, has_table
        match item:
            case dict():
                children = list(item.values())
            case list():
                children = list(item)
            case _:
                return
        for child in children:
            if id(item) in wrap_ids:
                if isinstance(child, list):
                    has_list = True
                elif isinstance(child, dict) and not isinstance(
                    child, OrderedMap
                ):
                    has_table = True
            _visit(item=child)

    _visit(item=data)
    return (has_list, has_table)


@beartype
def _wrap_nim_collection(
    raw_value: Value, formatted: str, *, variant_name: str
) -> str:
    """Wrap a nested native collection in its recursive branch."""
    match raw_value:
        case list():
            payload = formatted
            if len(raw_value) == 0:
                payload = f"newSeq[{variant_name}]()"
            return f"{variant_name}(kind: vkList, listVal: {payload})"
        case dict() if not isinstance(raw_value, OrderedMap):
            payload = formatted
            if len(raw_value) == 0:
                payload = f"initTable[string, {variant_name}]()"
            return f"{variant_name}(kind: vkTable, tableVal: {payload})"
        case _:
            msg = (
                "Nim OBJECT_VARIANT cannot represent a set or ordered "
                "map alongside another value type"
            )
            raise UnrepresentableInputError(msg)


@beartype
def _build_object_variant_behavior(
    variant_name: str,
    date_type: str,
    datetime_type: str,
    /,
) -> HeterogeneousBehavior:
    """OBJECT_VARIANT strategy: wrap scalars and skip scalar checks."""

    def _compute(data: Value) -> frozenset[int]:
        """Return container ids whose children should use ``Value``."""
        return _nim_object_variant_wrap_ids(data=data)

    def _wrap(raw_value: Scalar, formatted: str) -> str:
        """Wrap a scalar as ``{variant_name}(kind: ..., ...Val: ...)``."""
        signature = _nim_variant_for_scalar(
            value=raw_value,
            date_type=date_type,
            datetime_type=datetime_type,
        )
        if signature.field_name is None:
            return f"{variant_name}(kind: {signature.kind_name})"
        payload = formatted
        if _needs_json_wrap_for_field(field_type=signature.field_type):
            payload = f"%*{formatted}"
        return (
            f"{variant_name}(kind: {signature.kind_name}, "
            f"{signature.field_name}: {payload})"
        )

    _wrap_non_scalar = partial(_wrap_nim_collection, variant_name=variant_name)

    return HeterogeneousBehavior(
        skip_scalar_checks=True,
        compute_wrap_ids=_compute,
        wrap_scalar=_wrap,
        wrap_non_scalar=_wrap_non_scalar,
        wrap_empty_container=None,
        empty_container_literal_overrides=no_empty_container_literal_overrides,
        compute_call_slot_wrap_ids=no_compute_call_slot_wrap_ids,
        dict_open_for_wrap_ids=None,
        widens_nested_maps_by_wrapping_scalars=True,
        widens_unrecordizable_nested_sibling_maps=False,
        render_record_literal=None,
        compute_record_shapes=None,
        render_tuple_literal=None,
        compute_tuple_list_ids=None,
        alias_record_ids=None,
    )


@beartype
def _build_object_variant_preamble(
    variant_name: str,
    date_type: str,
    datetime_type: str,
    indent: str,
    /,
    *,
    compute_wrap_ids: Callable[[Value], frozenset[int]],
) -> Callable[[Value], tuple[str, ...]]:
    """Emit an object-variant ``type`` block for wrapped scalars.

    ``OBJECT_VARIANT`` supplies its broad collector, while ``RECORD``
    uses the same value carrier only for maps excluded from record
    rendering by its shared nested-map fallback and supplies that
    narrower collector.
    """

    def _preamble(data: Value, /) -> tuple[str, ...]:
        """Build the object-variant type declaration for *data*."""
        wrap_ids = compute_wrap_ids(data)
        if len(wrap_ids) == 0:
            return ()
        scalars = iter_wrapped_scalars(data=data, wrap_ids=wrap_ids)
        variants: list[_VariantSignature] = []
        seen: set[str] = set()
        for scalar in scalars:
            signature = _nim_variant_for_scalar(
                value=scalar,
                date_type=date_type,
                datetime_type=datetime_type,
            )
            if signature.kind_name in seen:
                continue
            seen.add(signature.kind_name)
            variants.append(signature)
        has_list, has_table = _nim_wrapped_container_kinds(
            data=data,
            wrap_ids=wrap_ids,
        )
        if has_list:
            variants.append(
                _VariantSignature(
                    kind_name="vkList",
                    field_name="listVal",
                    field_type=f"seq[{variant_name}]",
                )
            )
        if has_table:
            variants.append(
                _VariantSignature(
                    kind_name="vkTable",
                    field_name="tableVal",
                    field_type=f"Table[string, {variant_name}]",
                )
            )
        if len(variants) == 0:
            return ()
        half_indent = " " * (len(indent) // 2)
        kind_type = f"{variant_name}Kind"
        lines: list[str] = [
            "type",
            f"{half_indent}{kind_type} = enum",
            f"{indent}{', '.join(v.kind_name for v in variants)}",
            f"{half_indent}{variant_name} = object",
            f"{indent}case kind: {kind_type}",
        ]
        for variant in variants:
            if variant.field_name is None:
                lines.append(f"{indent}of {variant.kind_name}: discard")
            else:
                lines.append(
                    f"{indent}of {variant.kind_name}: "
                    f"{variant.field_name}: {variant.field_type}"
                )
        return tuple(lines)

    return _preamble


@beartype
def _build_default_object_variant_preamble(
    variant_name: str,
    date_type: str,
    datetime_type: str,
    indent: str,
    /,
) -> Callable[[Value], tuple[str, ...]]:
    """Build the broad ``OBJECT_VARIANT`` preamble."""

    def _compute_wrap_ids(data: Value, /) -> frozenset[int]:
        """Collect every heterogeneous container requiring a variant."""
        return _nim_object_variant_wrap_ids(data=data)

    return _build_object_variant_preamble(
        variant_name,
        date_type,
        datetime_type,
        indent,
        compute_wrap_ids=_compute_wrap_ids,
    )


# The ``RECORD`` strategy supports only auto ``Record0``/``Record1``/...
# names (no ``record_shape_names``, consistent with the other non-Rust
# ports), so the shared renderer always gets an empty custom-name
# mapping.
_NIM_NO_RECORD_SHAPE_NAMES: Mapping[frozenset[str], str] = MappingProxyType[
    frozenset[str], str
](
    mapping={},
)


_NIM_IDENTIFIER = re.compile(pattern=r"[A-Za-z](_?[A-Za-z0-9])*")
"""What a Nim identifier is written as.

An identifier starts with a letter and separates the rest with single
underscores, so a leading, trailing or doubled underscore is not one
(issue #4505).
"""


@beartype
def _nim_record_field_identifier(
    key: str, /, *, reserved_identifiers: frozenset[str]
) -> str:
    """Return the Nim ``object`` field name for a dict *key*.

    Nim has style-insensitive identifiers that accept the original
    key, but the generated declaration and ``Record0(field: value,
    ...)`` literal read most naturally in the conventional Nim
    ``camelCase`` (e.g. ``display_name`` -> ``displayName``); the same
    conversion is applied to both so they always agree.
    """
    identifier = IdentifierCase.CAMEL.convert(name=key)
    folded = _nim_field_identifier_key(identifier)
    if folded in {
        _nim_field_identifier_key(reserved)
        for reserved in reserved_identifiers
    }:
        msg = f"Nim record field name {identifier!r} is reserved"
        raise UnrepresentableInputError(msg)
    if _NIM_IDENTIFIER.fullmatch(string=identifier) is None:
        msg = (
            f"Nim cannot represent the dict key {key!r} as an object "
            f"field name: {identifier!r} is not a Nim identifier, which "
            "starts with a letter and separates the rest with single "
            "underscores"
        )
        raise UnrepresentableInputError(msg)
    return identifier


@beartype
def _nim_field_identifier_key(identifier: str, /) -> str:
    """Fold a field identifier the way the compiler compares one.

    Nim identifiers are style-insensitive: the first character is
    compared as written, and the rest ignore case and underscores, so
    ``aB``, ``a_b`` and ``ab`` all name one field (issue #3960).
    """
    head, tail = identifier[:1], identifier[1:]
    return head + tail.replace("_", "").lower()


@beartype
def _nim_render_record_declaration(
    name: str,
    fields: Sequence[RecordDeclarationField],
    /,
    *,
    indent: str,
) -> str:
    """Render a Nim ``type Name = object`` declaration with one
    indented ``field: Type`` member per resolved field.

    Emitted at module scope by the data-dependent preamble (each
    fixture is its own compilation unit, so file-scope ``type``
    sections never collide); the matching record *literal* stays in
    the value position via the normal value path.
    """
    lines = [f"type {name} = object"]
    lines += [
        f"{indent}{field.identifier}: {field.type_name}" for field in fields
    ]
    return "\n".join(lines)


@beartype
def _nim_record_literal(
    name: str,
    fields: Sequence[RecordLiteralField],
    /,
) -> RenderedRecordLiteral:
    """Render a Nim ``Name(field: value, ...)`` object-construction
    literal as structured pieces for the shared compact/multiline
    layout code.

    A trailing comma after the last field is valid in a Nim object
    constructor, so the language-wide trailing-comma config applies
    unchanged in the multiline form.
    """
    return RenderedRecordLiteral(
        head=f"{name}(",
        entries=tuple(
            f"{field.identifier}: {field.formatted}" for field in fields
        ),
        closer=")",
        compact_pad="",
    )


@beartype
def _nim_call_stub(
    parts: Sequence[str],
    _params: Sequence[str],
    stub_return: StubReturn,
    _args: Sequence[Value],
    /,
    *,
    indent: str,
) -> tuple[str, ...]:
    """Return Nim stub declarations for a call name.

    VOID stubs use templates with ``varargs[untyped]``.  VALUE stubs use
    generic ``proc`` definitions with ``{.discardable.}`` because the
    ``{.discardable.}`` pragma is not valid on templates in Nim 2.x, and
    calling a value-returning template at statement level raises a
    compiler error without it.

    For single-part names the stub is emitted at module scope.  For
    dotted names object types are built bottom-up so that the Uniform
    Function Call Syntax of Nim lets the caller write
    ``app.client.fetch(x)`` as sugar for ``fetch(app.client, x)``.
    """
    method = parts[-1]

    if stub_return is StubReturn.VOID:
        if len(parts) == 1:
            return (f"template {method}(args: varargs[untyped]) = discard",)
        chain = list(parts[:-1])
        holder = chain[-1]
        holder_type = f"{holder.title()}Type"
        lines: list[str] = [f"type {holder_type} = object"]
        for i in range(len(chain) - 2, -1, -1):
            outer = chain[i]
            inner = chain[i + 1]
            inner_type = f"{inner.title()}Type"
            outer_type = f"{outer.title()}Type"
            lines.extend(
                [
                    f"type {outer_type} = object",
                    f"{indent}{inner}: {inner_type}",
                ]
            )
        lines.append(
            f"template {method}(self: {holder_type};"
            f" args: varargs[untyped]) = discard"
        )
        root = chain[0]
        root_type = f"{root.title()}Type"
        lines.append(f"var {root}: {root_type}")
        return tuple(lines)

    # VALUE: use a generic proc instead of a template
    type_params = [f"T{i}" for i in range(len(_params))]
    type_clause = ""
    if len(type_params) > 0:
        type_clause = f"[{', '.join(type_params)}]"
    if len(parts) == 1:
        params_str = "; ".join(
            f"{p}: {t}" for p, t in zip(_params, type_params, strict=True)
        )
        return (
            (
                f"proc {method}{type_clause}"
                f"({params_str}): int {{.discardable.}} = 0"
            ),
        )
    chain = list(parts[:-1])
    holder = chain[-1]
    holder_type = f"{holder.title()}Type"
    lines = [f"type {holder_type} = object"]
    for i in range(len(chain) - 2, -1, -1):
        outer = chain[i]
        inner = chain[i + 1]
        inner_type = f"{inner.title()}Type"
        outer_type = f"{outer.title()}Type"
        lines.extend(
            [
                f"type {outer_type} = object",
                f"{indent}{inner}: {inner_type}",
            ]
        )
    params_str = "; ".join(
        f"{p}: {t}" for p, t in zip(_params, type_params, strict=True)
    )
    if params_str != "":
        self_and_params = f"self: {holder_type}; {params_str}"
    else:
        self_and_params = f"self: {holder_type}"
    lines.append(
        f"proc {method}{type_clause}"
        f"({self_and_params}): int {{.discardable.}} = 0"
    )
    root = chain[0]
    root_type = f"{root.title()}Type"
    lines.append(f"var {root}: {root_type}")
    return tuple(lines)


@beartype
@dataclasses.dataclass(frozen=True, kw_only=True)
class Nim(metaclass=LanguageCls):
    """Nim language specification.

    Args:
        date_format: How to format :class:`datetime.date` values.

            * ``date_formats.NIM`` — table literal,
              e.g. ``{"year": 2024, "month": 1, "day": 15}``.
            * ``date_formats.ISO`` — ISO 8601 quoted string,
              e.g. ``"2024-01-15"``.

        datetime_format: How to format :class:`datetime.datetime` values.

            * ``datetime_formats.NIM`` — table literal,
              e.g. ``{"year": 2024, "month": 1, "day": 15,
              "hour": 12, "minute": 30, "second": 0}``.
            * ``datetime_formats.ISO`` — ISO 8601 quoted string,
              e.g. ``"2024-01-15T12:30:00"``.
    """

    reserved_module_identifiers: ClassVar[frozenset[str]] = frozenset()
    immutable_variable_modifiers: ClassVar[frozenset[enum.Enum]] = frozenset()
    module_name_shares_variable_scope = False
    reserved_variable_identifier_pattern: ClassVar[re.Pattern[str] | None] = (
        None
    )
    reserved_call_parameter_identifiers: ClassVar[frozenset[str]] = frozenset()
    reserved_call_parameter_identifier_pattern: ClassVar[
        re.Pattern[str] | None
    ] = None
    accepts_type_name_call_target = True
    declares_type_name_call_target = True
    dotted_call_root_shares_entrypoint_namespace = True
    reserved_bare_call_target_identifiers: ClassVar[frozenset[str]] = (
        frozenset()
    )
    reserved_call_target_head_identifiers: ClassVar[frozenset[str]] = (
        frozenset()
    )
    contextual_call_target_identifiers: ClassVar[frozenset[str]] = frozenset()
    call_parameter_shadowing = CallParameterShadowing.ALLOWED
    reserved_call_target_keywords_case_sensitive = True
    module_name_must_start_uppercase = False
    max_variable_identifier_length: ClassVar[int | None] = None
    call_target_name_syntax: ClassVar[NewVariableNameSyntax | None] = None
    supports_multiline_dict_layout = True
    pools_map_integer_width = True

    format_integer_beyond_i64 = no_format_integer_beyond_i64
    format_constructor_target: ClassVar["staticmethod[[str], str]"] = (
        staticmethod(identity_constructor_target)
    )
    sequence_binding_declarations = default_sequence_binding_declarations
    format_call_binding_body_preamble = no_call_binding_body_preamble
    format_call_binding_file_pragmas = no_call_binding_file_pragmas

    leading_preamble = no_leading_preamble
    extension = ".nim"
    pygments_name = "nim"
    stringifies_nested_collections = False
    supports_special_floats = True
    supports_variable_names = True
    wrap_in_file_tolerates_pre_indent: ClassVar[bool] = False
    supports_no_variable_wrap_in_file = False
    wraps_data_dependent_preamble_in_body = False
    dict_supports_heterogeneous_values = False
    supports_dotted_calls = True
    has_free_function_calls = True
    reserved_identifiers: ClassVar[frozenset[str]] = frozenset()
    new_variable_name_syntax: ClassVar[NewVariableNameSyntax] = (
        # A Nim identifier may not begin with an underscore
        # (issue #3914), and its lexer takes an underscore only
        # between two letters or digits, so a trailing or doubled one
        # is refused as well (issue #4770).
        NewVariableNameSyntax.ASCII_SEPARATING_UNDERSCORE
    )
    declares_call_parameter_names = True
    reserved_variable_identifiers_case_sensitive: bool = True
    reserved_variable_identifiers: frozenset[str] = frozenset(
        {
            "addr",
            "and",
            "as",
            "asm",
            "atomic",
            "bind",
            "block",
            "break",
            "case",
            "cast",
            "concept",
            "const",
            "continue",
            "converter",
            "defer",
            "discard",
            "distinct",
            "div",
            "do",
            "elif",
            "else",
            "end",
            "enum",
            "except",
            "export",
            "finally",
            "for",
            "from",
            "func",
            "generic",
            "if",
            "import",
            "in",
            "include",
            "interface",
            "is",
            "isnot",
            "iterator",
            "let",
            "macro",
            "method",
            "mixin",
            "mod",
            "nil",
            "not",
            "notin",
            "object",
            "of",
            "or",
            "out",
            "proc",
            "ptr",
            "raise",
            "ref",
            "return",
            "shl",
            "shr",
            "static",
            "template",
            "try",
            "tuple",
            "type",
            "using",
            "var",
            "when",
            "while",
            "with",
            "xor",
            "yield",
        }
    )
    allows_empty_call_parens = True
    supports_dotted_call_stub = True
    call_returns_expression = True
    supports_json_call_result_binding = False
    supports_zero_parameter_calls = True
    max_call_parameters = NO_CALL_PARAMETER_LIMIT
    supports_inline_multiline_dict_args = True
    supports_standalone_comments_in_wrapped_calls = True
    supports_multi_param_call_wrapper_stub = True
    supports_dict_literal_as_free_expression = True
    supports_module_name = False
    supports_empty_dict_key = False
    supports_call_style = True
    supports_default_dict_key_type = False
    supports_default_dict_value_type = False
    supports_default_sequence_element_type = False
    supports_default_set_element_type = False
    supports_default_ordered_map_value_type = False
    json_type_variant_name_suffix: ClassVar[str | None] = None
    supports_non_ascii_string_literals = True
    supports_multiline_string_literals = True
    supports_empty_sibling_sequence_type_hints = True
    supports_typed_dict_open = False
    language_id: ClassVar[str] = "nim"
    variant_metadata: ClassVar[VariantMetadata] = VariantMetadata(
        round_trip_capabilities=frozenset(
            {
                RoundTripCapability.I64_BOUNDARIES,
                RoundTripCapability.INTERPOLATION_STRINGS,
                RoundTripCapability.EMBEDDED_NUL,
            }
        ),
        modifier_sequence_format_overrides={},
        string_literals_escape_null_byte=True,
        supports_ref_elements_in_tuple_strategy=False,
    )
    supports_record_struct_name_prefix = True
    supports_record_shape_names = False
    record_shape_names_emit_declarations = False
    supports_non_string_dict_keys = False
    checks_raw_control_dict_keys_separately = False

    class DateFormats(DateFormatEnum):
        """Date format options for Nim."""

        _value_: DateFormatConfig

        NIM = DateFormatConfig(
            formatter=date_ymd_formatter(
                template='{{"year": {year}, "month": {month}, "day": {day}}}',
            ),
            preamble_lines=(),
            type_produced=datetime.date,
        )
        ISO = DateFormatConfig(
            formatter=format_date_iso,
            preamble_lines=(),
            type_produced=str,
        )

    class DatetimeFormats(DatetimeFormatEnum):
        """Datetime format options for Nim."""

        _value_: DatetimeFormatConfig

        NIM = DatetimeFormatConfig(
            formatter=datetime_ymdhms_formatter(
                template='{{"year": {year}, "month": {month}, '
                '"day": {day}, "hour": {hour}, '
                '"minute": {minute}, "second": {second}}}',
                millisecond_template=None,
            ),
            preamble_lines=(),
            type_produced=datetime.datetime,
        )
        ISO = DatetimeFormatConfig(
            formatter=format_datetime_iso,
            preamble_lines=(),
            type_produced=str,
        )

        EPOCH = DatetimeFormatConfig(
            formatter=format_datetime_epoch,
            type_produced=int,
            preamble_lines=(),
        )

    class BytesFormats(enum.Enum):
        """Bytes formatting options."""

        _value_: Callable[[bytes], str]

        HEX = enum.member(value=format_bytes_hex)
        BASE64 = enum.member(value=format_bytes_base64)

        def __call__(self, data: bytes, /) -> str:
            """Format bytes."""
            return self._value_(data)

    class SequenceFormats(enum.Enum):
        """Sequence type options for Nim."""

        SEQ = SequenceFormatConfig(
            sequence_open=fixed_open(open_str="["),
            close="]",
            supports_heterogeneity=False,
            single_element_trailing_comma=False,
            single_element_template=None,
            supports_trailing_comma=True,
            empty_sequence=None,
            preamble_lines=(),
            format_entry=passthrough_sequence_entry,
            typed_opener_fallback=None,
            uses_typed_literal_for_scalars=True,
            requires_uniform_record_shapes=False,
            declared_type=None,
            narrowed_empty_form=None,
        )
        ARRAY = SequenceFormatConfig(
            sequence_open=fixed_open(open_str="["),
            close="]",
            supports_heterogeneity=True,
            single_element_trailing_comma=False,
            single_element_template=None,
            supports_trailing_comma=True,
            empty_sequence=None,
            preamble_lines=(),
            format_entry=passthrough_sequence_entry,
            typed_opener_fallback=None,
            uses_typed_literal_for_scalars=False,
            requires_uniform_record_shapes=False,
            declared_type=None,
            narrowed_empty_form=None,
        )

    class SetFormats(enum.Enum):
        """Set type options for Nim."""

        SET = SetFormatConfig(
            set_open=sequence_surrogate_set_open(fixed_open(open_str="[")),
            close="]",
            empty_set=None,
            preamble_lines=(),
            set_opener_template="",
            supports_heterogeneity=True,
            supports_trailing_comma=True,
        )

    class CommentFormats(enum.Enum):
        """Comment style options."""

        HASH = CommentConfig(
            prefix="#",
            suffix="",
        )
        BLOCK = CommentConfig(
            prefix="#[",
            suffix=" ]#",
        )

    class DeclarationStyles(enum.Enum):
        """Declaration style options."""

        VAR = DeclarationStyleConfig(
            formatter=variable_declaration_formatter(
                template="var {name} = {value}"
            ),
            supports_redefinition=True,
        )
        LET = DeclarationStyleConfig(
            formatter=variable_declaration_formatter(
                template="let {name} = {value}"
            ),
            supports_redefinition=False,
        )
        CONST = DeclarationStyleConfig(
            formatter=variable_declaration_formatter(
                template="const {name} = {value}"
            ),
            supports_redefinition=False,
        )

    class DictEntryStyles(enum.Enum):
        """Dict entry style options."""

        DEFAULT = enum.auto()

    class DictFormats(enum.Enum):
        """Dict/map format options."""

        DEFAULT = enum.auto()

    class EmptyDictKey(enum.Enum):
        """Empty dict key options."""

        ALLOW = enum.auto()

    class FloatFormats(
        FloatSpecialsMixin,
        enum.Enum,
        positive_infinity="Inf",
        negative_infinity="-Inf",
        nan="NaN",
    ):
        """Float format options."""

        REPR = enum.member(value=format_float_repr)
        SCIENTIFIC = enum.member(value=format_float_scientific)
        FIXED = enum.member(value=format_float_fixed)

    class IntegerFormats(enum.Enum):
        """Integer format options."""

        DECIMAL = MappingProxyType(
            mapping={
                "NONE": str,
                "UNDERSCORE": format_integer_underscore,
            }
        )
        HEX = MappingProxyType(
            mapping={
                "NONE": format_integer_hex,
                "UNDERSCORE": format_integer_hex,
            }
        )
        OCTAL = MappingProxyType(
            mapping={
                "NONE": format_integer_octal,
                "UNDERSCORE": format_integer_octal,
            }
        )
        BINARY = MappingProxyType(
            mapping={
                "NONE": format_integer_binary,
                "UNDERSCORE": format_integer_binary,
            }
        )

        def get_formatter(
            self,
            numeric_separator: enum.Enum,
        ) -> Callable[[int], str]:
            """Return the integer formatter for the given separator."""
            formatter: Callable[[int], str] = self.value[
                numeric_separator.name
            ]
            return formatter

    class NumericLiteralSuffixes(enum.Enum):
        """Numeric literal suffix options."""

        NONE = enum.auto()

    class NumericSeparators(enum.Enum):
        """Numeric separator options."""

        NONE = enum.auto()
        UNDERSCORE = enum.auto()

    class NumericStyles(enum.Enum):
        """Numeric literal style options."""

        OVERLOADED = enum.auto()

    class StringFormats(enum.Enum):
        """String format options."""

        _value_: Callable[[str], str]

        DOUBLE = enum.member(value=format_string_backslash_nul_hex)
        MULTILINE = enum.member(value=_format_string_multiline)

        def __call__(self, value: str, /) -> str:
            """Format a string."""
            return self._value_(value)

    class TrailingCommas(enum.Enum):
        """Trailing comma options."""

        YES = TrailingCommaConfig(multiline_trailing_comma=True)
        NO = TrailingCommaConfig(multiline_trailing_comma=False)

    date_formats = DateFormats
    datetime_formats = DatetimeFormats
    bytes_formats = BytesFormats
    sequence_formats = SequenceFormats
    set_formats = SetFormats
    comment_formats = CommentFormats

    class VariableTypeHints(enum.Enum):
        """Variable type hint options."""

        NEVER = enum.auto()
        SAFE = enum.auto()

    variable_type_hints_formats = VariableTypeHints

    class JsonTypes(JsonType):
        """JSON value type options for Nim."""

        JSON_NODE = "JsonNode"
        """Standard-library ``json.JsonNode`` value constructed via
        the ``%*`` macro.
        """

    json_types = JsonTypes
    declaration_styles = DeclarationStyles
    dict_entry_styles = DictEntryStyles
    dict_formats = DictFormats
    empty_dict_keys = EmptyDictKey
    float_formats = FloatFormats
    integer_formats = IntegerFormats
    integer_width_strategies = BareIntegerWidthStrategies
    numeric_literal_suffixes = NumericLiteralSuffixes
    numeric_separators = NumericSeparators
    numeric_styles = NumericStyles
    string_formats = StringFormats
    trailing_commas = TrailingCommas

    class StatementTerminatorStyles(enum.Enum):
        """Statement terminator options."""

        SEMICOLON = enum.auto()

    statement_terminator_styles = StatementTerminatorStyles

    class CallStyles(enum.Enum):
        """Nim call style options."""

        POSITIONAL = PositionalCallStyle(
            arg_separator=", ", parenthesize_each_arg=False
        )

    call_styles = CallStyles

    class Modifiers(enum.Enum):
        """C++/Java/C#-style declaration modifiers: this language has none."""

    modifiers = Modifiers

    class HeterogeneousStrategies(enum.Enum):
        """Strategy for representing dicts or lists whose scalar values
        span more than one Nim type.
        """

        ERROR = _HeterogeneousStrategyConfig(
            build_behavior=_build_error_behavior,
            build_preamble=_build_error_preamble,
            resolves_per_instance=False,
        )
        """Raise
        :exc:`~literalizer.exceptions.HeterogeneousScalarCollectionError`
        (or
        :exc:`~literalizer.exceptions.HeterogeneousSiblingListsError`)
        when scalar values of mixed types appear in a container that
        cannot represent them.  This is the default, matching the
        strict-typing convention of Nim when tables and sequences are
        used without JSON wrapping.
        """

        OBJECT_VARIANT = _HeterogeneousStrategyConfig(
            build_behavior=_build_object_variant_behavior,
            build_preamble=_build_default_object_variant_preamble,
            resolves_per_instance=False,
        )
        """Auto-generate a Nim object variant in the preamble containing
        only the branches actually present in the data, and wrap each
        heterogeneous scalar value as
        ``{VariantName}(kind: vkX, xVal: value)``.

        Switches the dict rendering from ``%* {key: value}`` (which
        relies on the ``json`` module) to ``{key: value}.toTable`` so
        that the object-variant values can be stored directly.  Nested
        sequences emit ``@[...]`` at every level, and the ``json``
        import is dropped unless a date or datetime format still
        produces a ``JsonNode`` payload.

        The variant-type name is configurable via
        :attr:`Nim.heterogeneous_value_variant_name` (default
        ``"Value"``).  Incompatible with ``DeclarationStyles.CONST``:
        ``.toTable`` and ``@[]`` are runtime constructors, so
        ``CONST`` requires a compile-time-expressible initializer.
        """

        RECORD = _HeterogeneousStrategyConfig(
            build_behavior=_build_error_behavior,
            build_preamble=_build_error_preamble,
            resolves_per_instance=True,
        )
        """Render each record-shaped dict (non-empty, string-keyed) as a
        generated module-scope ``type Record0 = object`` declaration plus
        a matching ``Record0(field: value, ...)`` literal, so a dict
        mixing scalars with a container is representable even though a
        Nim ``Table`` requires a homogeneous value type.

        Like ``OBJECT_VARIANT`` this switches collections to their
        native Nim constructors (``@[...]``, ``{...}.toTable``) so a
        ``seq``/``Table`` field is well-typed, but it wraps no scalars
        and emits no ``json``/``%*`` rendering.  Auto names
        ``Record0``, ``Record1``, ... (prefix configurable via
        :attr:`Nim.record_struct_name_prefix`); **no**
        ``record_shape_names``, **no** ``record_unify_optional_fields``,
        consistent with the other non-Rust ports.  Its behavior and
        struct preamble need the per-instance renderer, so they are
        resolved in :attr:`heterogeneous_behavior` /
        :attr:`data_dependent_preamble` rather than from the enum
        member's config builders (it reuses the no-op ``ERROR``
        builders, kept a distinct member by
        :class:`_HeterogeneousStrategyConfig`'s identity equality).
        Incompatible with ``DeclarationStyles.CONST`` for the same
        reason as ``OBJECT_VARIANT``: ``@[...]`` / ``.toTable`` are
        runtime constructors.
        """

    heterogeneous_strategies = HeterogeneousStrategies

    class BoolFormats(enum.Enum):
        """Empty: this language has no alternative boolean formats."""

    bool_formats = BoolFormats

    class VersionFormats(enum.Enum):
        """Version options for Nim."""

        V2 = enum.auto()

    version_formats = VersionFormats

    modifier_combinations: ClassVar[tuple[ModifierCombination, ...]] = ()
    identifier_cases: ClassVar[tuple[IdentifierCase, ...]] = (
        IdentifierCase.CAMEL,
        IdentifierCase.PASCAL,
    )
    supported_ref_cases: ClassVar[frozenset[IdentifierCase]] = (
        NON_KEBAB_REF_CASES
    )

    def validate_spec_for_data(self, data: Value) -> None:
        """Reject a native sequence containing only ``nil``.

        Nim cannot infer an element type for a top-level ``@[nil, ...]``
        expression.  JSON-backed rendering supplies ``JsonNode`` instead,
        while record fields receive an explicit ``seq[pointer]`` type from
        the record renderer, so only a top-level native sequence needs this
        guard.
        """
        if self.declaration_style is type(self.declaration_style).CONST:
            # A ``const`` renders a bare Nim literal, whose nested
            # arrays carry their length in their type; the other styles
            # render a ``JsonNode``, which does not (issue #3924).
            reject_ragged_nested_sequences(
                data=data,
                language_name="Nim",
                record_fields_are_independent=False,
                list_elements_are_independent=False,
            )
        if self._uses_record:
            _reject_uninferrable_native_sequences(data=data)
            _reject_distinct_record_list_ordered_map_values(data=data)
        if (
            self._uses_native_nim_collections
            and isinstance(data, list)
            and (len(data) > 0)
            and all(item is None for item in data)
        ):
            msg = (
                "Nim cannot infer an element type for a native sequence "
                "containing only null values"
            )
            raise UnrepresentableInputError(msg)

    @cached_property
    def validate_call_arg(self) -> Callable[[Value], None]:
        """Return call-argument validation for this language."""
        return no_validate_call_arg

    @cached_property
    def format_call_statement(self) -> Callable[[str], str]:
        """Return call-statement formatting for this language."""
        return identity_call_statement

    wrap_calls_with_declarations = default_wrap_calls_with_declarations

    @staticmethod
    def wrap_in_file(
        content: str,
        variable_name: str,
        body_preamble: tuple[str, ...],
    ) -> str:
        """Wrap code in a valid file (no-op)."""
        return wrap_in_file_noop(
            content=content,
            variable_name=variable_name,
            body_preamble=body_preamble,
        )

    @staticmethod
    def wrap_combined_in_file(
        declaration: str,
        assignment: str,
        variable_name: str,
        body_preamble: tuple[str, ...],
    ) -> str:
        """Wrap declaration and assignment in a valid file (no-op)."""
        return wrap_combined_in_file_noop(
            declaration=declaration,
            assignment=assignment,
            variable_name=variable_name,
            body_preamble=body_preamble,
        )

    date_format: DateFormats = DateFormats.NIM
    datetime_format: DatetimeFormats = DatetimeFormats.NIM
    bytes_format: BytesFormats = BytesFormats.HEX
    sequence_format: SequenceFormats = SequenceFormats.SEQ
    set_format: SetFormats = SetFormats.SET
    variable_type_hints: VariableTypeHints = VariableTypeHints.NEVER
    comment_format: CommentFormats = CommentFormats.HASH
    declaration_style: DeclarationStyles = DeclarationStyles.VAR
    dict_entry_style: DictEntryStyles = DictEntryStyles.DEFAULT
    dict_format: DictFormats = DictFormats.DEFAULT
    float_format: FloatFormats = FloatFormats.REPR
    integer_format: IntegerFormats = IntegerFormats.DECIMAL
    integer_width_strategy: BareIntegerWidthStrategies = (
        BareIntegerWidthStrategies.BARE
    )
    numeric_literal_suffix: NumericLiteralSuffixes = (
        NumericLiteralSuffixes.NONE
    )
    numeric_separator: NumericSeparators = NumericSeparators.NONE
    numeric_style: NumericStyles = NumericStyles.OVERLOADED
    string_format: StringFormats = StringFormats.DOUBLE
    trailing_comma: TrailingCommas = TrailingCommas.NO
    statement_terminator_style: StatementTerminatorStyles = (
        StatementTerminatorStyles.SEMICOLON
    )
    heterogeneous_strategy: HeterogeneousStrategies = (
        HeterogeneousStrategies.ERROR
    )
    json_type: JsonTypes | None = None
    heterogeneous_value_variant_name: str = "Value"
    record_struct_name_prefix: str = "Record"
    call_style: CallStyles = CallStyles.POSITIONAL
    # Keep in sync with the ``NIM_VERSION`` pin in the ``lint-nim`` job
    # of ``.github/workflows/lint.yml``; the pinned compiler must be
    # ``>=`` this ``V2`` (Nim 2.x) default.
    language_version: VersionFormats = VersionFormats.V2
    indent: str = "    "

    def __post_init__(self) -> None:
        """Validate that incompatible formats are not combined.

        ``OBJECT_VARIANT`` and ``RECORD`` replace the JSON-based
        rendering for Nim with runtime ``.toTable`` / ``@[]``
        constructors, so ``CONST`` (which requires a
        compile-time-expressible initializer) cannot be combined with
        either.  ``json_type`` uses the runtime ``%*`` macro for the
        same reason and is likewise incompatible with ``CONST``.
        """
        _decl_cls = type(self.declaration_style)
        _strategy_cls = type(self.heterogeneous_strategy)
        if self.declaration_style is _decl_cls.CONST and (
            self.heterogeneous_strategy
            in {_strategy_cls.OBJECT_VARIANT, _strategy_cls.RECORD}
        ):
            msg = (
                "Nim CONST requires a constant-expression initializer, "
                f"but {self.heterogeneous_strategy.name} produces runtime "
                ".toTable / @[] calls which are not constant expressions. "
                "Use VAR or LET instead."
            )
            raise IncompatibleFormatsError(msg)
        if (
            self.json_type is not None
            and self.declaration_style is _decl_cls.CONST
        ):
            msg = (
                "Nim json_type uses the runtime %* macro, which is not a "
                "constant-expression initializer. Use VAR or LET instead."
            )
            raise IncompatibleFormatsError(msg)

    null_literal: ClassVar[str] = "nil"
    true_literal: ClassVar[str] = "true"
    false_literal: ClassVar[str] = "false"
    indent_closing_delimiter: ClassVar[bool] = False
    element_separator: ClassVar[str] = ", "
    skip_null_dict_values: ClassVar[bool] = False
    supports_collection_comments: ClassVar[bool] = True
    supports_scalar_before_comments: ClassVar[bool] = False
    supports_scalar_inline_comments: ClassVar[bool] = True
    statement_terminator: ClassVar[str] = ""
    static_preamble: ClassVar[Sequence[str]] = ()
    static_body_preamble: ClassVar[Sequence[str]] = ()
    special_float_preamble: ClassVar[tuple[str, ...]] = ()

    @cached_property
    def call_style_config(self) -> CallStyle:
        """Configuration for the chosen call style."""
        return self.call_style.value

    @cached_property
    def format_string(self) -> Callable[[str], str]:
        """Format a string value as a quoted literal."""
        return self.string_format

    @cached_property
    def format_sequence_entry(self) -> Callable[[Value, str], str]:
        """Format a sequence entry."""
        return passthrough_sequence_entry

    @cached_property
    def format_set_entry(self) -> Callable[[Value, str], str]:
        """Format a set entry."""
        return passthrough_set_entry

    @cached_property
    def _heterogeneous_variant_date_type(self) -> str:
        """Nim type used for :class:`datetime.date` variant payloads."""
        if self.date_format.value.type_produced is str:
            return "string"
        return "JsonNode"

    @cached_property
    def _heterogeneous_variant_datetime_type(self) -> str:
        """Nim type used for :class:`datetime.datetime` variant
        payloads.
        """
        produced = self.datetime_format.value.type_produced
        if produced is str:
            return "string"
        if produced is int:
            return "int"
        return "JsonNode"

    @cached_property
    def data_dependent_preamble(self) -> Callable[[Value], tuple[str, ...]]:
        """Return data-dependent preamble lines.

        For ``HeterogeneousStrategies.RECORD`` emits one
        ``type Record0 = object`` block per distinct record shape in
        the data, preceded by ``import tables`` and the
        ``UnusedImport`` opt-out: a non-record dict (the empty dict, or
        an ordered map) renders as a runtime ``Table`` that needs the
        import, while a pure-record fixture leaves it unused, so the
        pragma keeps the always-present import warning-free rather than
        making the import data-dependent.  For
        ``HeterogeneousStrategies.OBJECT_VARIANT`` emits
        a Nim ``type`` block declaring the object variant used to wrap
        heterogeneous scalars.  For ``HeterogeneousStrategies.ERROR``
        emits ``("import json",)`` when the rendered output will use
        the ``%*`` JSON-construction operator (every variable
        declaration / assignment except ``const`` declarations and
        ``@``-prefixed sequences of simple scalars); importing
        ``json`` unconditionally would trigger the Nim compiler's
        ``UnusedImport`` warning.  Under ``json_type`` the rendered
        output always uses ``%*`` (and ``newJ*`` builders), so the
        import is emitted unconditionally and takes precedence over
        any configured heterogeneous strategy.
        """
        if self._uses_json_node:

            def _json_preamble(_data: Value, /) -> tuple[str, ...]:
                """Always import std/json for ``JsonNode`` output."""
                return ("import json",)

            return _json_preamble
        if self._uses_record:
            record_preamble = self._record_strategy.preamble
            variant_preamble = _build_object_variant_preamble(
                self.heterogeneous_value_variant_name,
                self._heterogeneous_variant_date_type,
                self._heterogeneous_variant_datetime_type,
                self.indent,
                compute_wrap_ids=(
                    self._record_strategy.behavior.compute_wrap_ids
                ),
            )

            def _record_preamble(data: Value, /) -> tuple[str, ...]:
                """Emit value-variant and record ``object`` type blocks,
                preceded by the ``UnusedImport`` opt-out and ``import
                tables``.
                """
                return (
                    "{.warning[UnusedImport]:off.}",
                    "import tables",
                    *variant_preamble(data),
                    *record_preamble(data),
                )

            return _record_preamble
        strategy_preamble = self.heterogeneous_strategy.value.build_preamble(
            self.heterogeneous_value_variant_name,
            self._heterogeneous_variant_date_type,
            self._heterogeneous_variant_datetime_type,
            self.indent,
        )
        if self._uses_object_variant:
            return strategy_preamble
        is_const = self.declaration_style is self.declaration_styles.CONST
        uses_typed_literal = (
            self.sequence_format.value.uses_typed_literal_for_scalars
        )

        def _preamble(data: Value, /) -> tuple[str, ...]:
            """Decide whether ``import json`` is required for *data*."""
            if is_const:
                return ()
            renders_as_at_sequence = (
                isinstance(data, list)
                and bool(data)
                and uses_typed_literal
                and all(
                    isinstance(item, (str, int, float, bool, bytes))
                    for item in data
                )
            )
            if renders_as_at_sequence:
                return ()
            return ("import json",)

        return _preamble

    @cached_property
    def heterogeneous_behavior(self) -> HeterogeneousBehavior:
        """Return the behavior for the chosen heterogeneous strategy.

        ``json_type`` relaxes scalar-type checks unconditionally,
        because the ``%*`` macro accepts heterogeneous JSON values.
        ``RECORD`` resolves to the shared record behavior (its value
        needs the per-instance renderer, so it cannot be stored on the
        enum member); ``ERROR`` and ``OBJECT_VARIANT`` use their
        config-built behaviors.
        """
        if self._uses_json_node:
            return dataclasses.replace(
                NO_HETEROGENEOUS_BEHAVIOR,
                skip_scalar_checks=True,
                wrap_non_scalar=passthrough_sequence_entry,
            )
        if self._uses_record:
            return self._record_strategy.behavior
        return self.heterogeneous_strategy.value.build_behavior(
            self.heterogeneous_value_variant_name,
            self._heterogeneous_variant_date_type,
            self._heterogeneous_variant_datetime_type,
        )

    @cached_property
    def _uses_json_node(self) -> bool:
        """Whether the instance is configured to render values as
        ``JsonNode`` via the ``%*`` macro.
        """
        return self.json_type is not None

    @cached_property
    def _uses_object_variant(self) -> bool:
        """Whether the instance is configured for the OBJECT_VARIANT
        heterogeneous strategy.
        """
        cls = type(self.heterogeneous_strategy)
        return self.heterogeneous_strategy is cls.OBJECT_VARIANT

    @cached_property
    def _uses_record(self) -> bool:
        """Whether the instance is configured for the RECORD
        heterogeneous strategy.
        """
        return self.heterogeneous_strategy.value.resolves_per_instance

    @cached_property
    def _uses_native_nim_collections(self) -> bool:
        """Whether collections render with their native Nim
        constructors (``@[...]`` / ``{...}.toTable``) rather than the
        ``%*`` JSON form.

        Both ``OBJECT_VARIANT`` (its wrapped values are native objects)
        and ``RECORD`` (its struct fields must be well-typed ``seq`` /
        ``Table`` values) need this; the default ``ERROR`` strategy
        keeps the JSON rendering.
        """
        return self._uses_object_variant or self._uses_record

    @beartype
    def _nim_list_field_type(self, *, value: list[Value]) -> str:
        """Infer the Nim sequence field type from its elements."""
        if len(value) == 0:
            element_type = "string"
        else:
            element_type = "int64"
            if infer_element_type(items=value) is not WideInt:
                element_type = self._nim_value_field_type(value[0])
        return f"seq[{element_type}]"

    def _nim_temporal_field_type(self, value: datetime.date, /) -> str:
        """Resolve the field type for the selected temporal representation."""
        if isinstance(value, datetime.datetime):
            return self._heterogeneous_variant_datetime_type
        return self._heterogeneous_variant_date_type

    def _nim_value_field_type(
        self,
        value: Value,
        /,
    ) -> str:
        """Return the Nim ``object`` field type for a raw
        (non-nested-record) record field value, derived structurally.

        ``None`` maps to the Nim ``pointer`` type, whose only value is
        ``nil`` (the null literal this port emits), matching how the
        other ports give a null field their top type.  Other scalars
        map to their Nim type and a homogeneous list maps to
        ``seq[<element type>]`` (an empty list keeps the
        ``newSeq[string]()`` placeholder element type the value
        formatter widens it to).  A ``date`` / ``datetime`` is the
        spec-driven Nim type only when the active format renders it as
        a plain ``string`` (ISO) or ``int`` (epoch); under the default
        ``NIM`` table-literal format it would need a ``%*``
        :class:`json.JsonNode` the record literal cannot carry, so it
        is rejected.  A set, an ordered map or a non-record dict as a
        record field is out of scope for the base ``RECORD`` port (the
        cross-language decision is tracked in #2317; Rust rejects these
        too) and is rejected with :exc:`UnrepresentableInputError` so
        the case is skipped rather than emitting non-compiling Nim.
        """
        match value:
            case None:
                field_type = "pointer"
            case bool():
                field_type = "bool"
            case int():
                field_type = "int"
            case float():
                field_type = "float"
            case str() | bytes() | datetime.time():
                field_type = "string"
            case datetime.date():
                field_type = self._nim_temporal_field_type(value)
            case list():
                field_type = self._nim_list_field_type(value=value)
            case _:
                msg = (
                    "Nim cannot represent a set or non-record-dict "
                    "field under the RECORD heterogeneous strategy"
                )
                raise UnrepresentableInputError(msg)
        if field_type == "JsonNode":
            msg = (
                "Nim cannot represent a NIM-table-literal date/datetime "
                "field under the RECORD heterogeneous strategy; use the "
                "ISO or EPOCH format"
            )
            raise UnrepresentableInputError(msg)
        return field_type

    def _nim_record_field_type(self, request: RecordFieldType, /) -> str:
        """Return the Nim ``object`` field type for a record field.

        A field whose value is itself a nested record-shaped dict uses
        that record's generated name; a list whose every element is a
        record-shaped dict of one shared shape is typed
        ``seq[<that name>]`` (a Nim ``seq`` is element-typed, unlike
        the ``[]any`` Go widens such a list to).  Every other value is
        typed structurally from the raw value via
        :meth:`_nim_value_field_type`.
        """
        if request.record_name is not None:
            return request.record_name
        if request.element_record_name is not None:
            return f"seq[{request.element_record_name}]"
        if (
            isinstance(request.value, dict)
            and not isinstance(request.value, OrderedMap)
            and record_shape_for_dict(value=request.value) is not None
        ):
            return f"Table[string, {self.heterogeneous_value_variant_name}]"
        return self._nim_value_field_type(request.value)

    @cached_property
    def _record_renderer(self) -> RecordRenderer:
        """Nim syntax hooks for the ``RECORD`` strategy."""
        return RecordRenderer(
            name_prefix=self.record_struct_name_prefix,
            record_shape_names=_NIM_NO_RECORD_SHAPE_NAMES,
            field_identifier=partial(
                _nim_record_field_identifier,
                reserved_identifiers=self.reserved_variable_identifiers,
            ),
            field_identifier_key=_nim_field_identifier_key,
            field_type=self._nim_record_field_type,
            render_declaration=partial(
                _nim_render_record_declaration,
                indent=self.indent,
            ),
            render_literal=_nim_record_literal,
            field_type_names_nested_records=False,
            suppress_custom_name_declarations=False,
        )

    @cached_property
    def _record_strategy(self) -> RecordStrategy:
        """Behavior + ``type``-declaration preamble for ``RECORD``."""
        strategy = build_record_strategy(
            renderer=self._record_renderer,
            split_conflicting_field_types=True,
            widen_unrecordizable_nested_sibling_maps=True,
            derecordized_map_open=None,
        )
        variant_behavior = _build_object_variant_behavior(
            self.heterogeneous_value_variant_name,
            self._heterogeneous_variant_date_type,
            self._heterogeneous_variant_datetime_type,
        )
        return dataclasses.replace(
            strategy,
            behavior=dataclasses.replace(
                strategy.behavior,
                wrap_scalar=variant_behavior.wrap_scalar,
                widens_nested_maps_by_wrapping_scalars=True,
            ),
        )

    @cached_property
    def type_hint_collection_preamble_lines(
        self,
    ) -> Callable[[frozenset[type]], tuple[str, ...]]:
        """Return preamble lines for empty-collection type hints."""
        return no_type_hint_preamble

    @cached_property
    def format_call_stub(
        self,
    ) -> Callable[
        [Sequence[str], Sequence[str], StubReturn, Sequence[Value]],
        tuple[str, ...],
    ]:
        """Return stub declarations for a call expression."""
        return partial(_nim_call_stub, indent=self.indent)

    @cached_property
    def format_call_preamble_stub(
        self,
    ) -> Callable[
        [Sequence[str], Sequence[str], StubReturn, Sequence[Value]],
        tuple[str, ...],
    ]:
        """Return file-scope stubs for a call expression."""
        return no_call_stub

    @cached_property
    def call_data_dependent_preamble(
        self,
    ) -> Callable[[Value], tuple[str, ...]]:
        """Return data-dependent preamble lines for a call context.

        For ``HeterogeneousStrategies.RECORD`` emits the
        ``type Record0 = object`` blocks a record-shaped call argument's
        literal references, preceded -- exactly as the non-call
        :attr:`data_dependent_preamble` -- by the ``UnusedImport``
        opt-out and ``import tables`` (``dict_format_config`` no longer
        contributes it under ``RECORD``).  The opt-out is needed both
        for a record-only call (the import is then unused) and because
        a ``varargs[untyped]`` stub never evaluates its arguments, so
        even a non-record dict argument's ``{...}.toTable`` would leave
        the import unused.  For
        ``HeterogeneousStrategies.OBJECT_VARIANT`` emits the Nim
        ``type`` block declaring the object variant used to wrap
        heterogeneous scalars; the call rendering references that type
        by name, so the declaration must be present.  For other
        strategies, call arguments are inline literals that never use
        ``%*``, so ``import json`` is never needed in a call context.

        ``json_type`` wraps every call argument in ``%*``, so the
        ``import json`` line is contributed unconditionally here too.
        """
        if self._uses_json_node:

            def _json_call_preamble(_data: Value, /) -> tuple[str, ...]:
                """Always import std/json for ``JsonNode`` call
                arguments.

                Suppress ``UnusedImport`` because the stub uses
                ``varargs[untyped]`` and never evaluates the wrapped
                ``%*(...)`` expressions, so the Nim compiler treats the
                ``json`` import as unused.
                """
                return (
                    "{.warning[UnusedImport]:off.}",
                    "import json",
                )

            return _json_call_preamble
        if self._uses_record:
            record_preamble = self._record_strategy.preamble
            variant_preamble = _build_object_variant_preamble(
                self.heterogeneous_value_variant_name,
                self._heterogeneous_variant_date_type,
                self._heterogeneous_variant_datetime_type,
                self.indent,
                compute_wrap_ids=(
                    self._record_strategy.behavior.compute_wrap_ids
                ),
            )

            def _record_call_preamble(data: Value, /) -> tuple[str, ...]:
                """Suppress UnusedImport for ``tables`` and emit it plus
                the generated ``object`` type blocks (identical to the
                non-call :attr:`data_dependent_preamble`: a non-record
                dict argument needs the import, a record-only call
                leaves it harmlessly suppressed).
                """
                return (
                    "{.warning[UnusedImport]:off.}",
                    "import tables",
                    *variant_preamble(data),
                    *record_preamble(data),
                )

            return _record_call_preamble
        if self._uses_object_variant:
            strategy_preamble = (
                self.heterogeneous_strategy.value.build_preamble(
                    self.heterogeneous_value_variant_name,
                    self._heterogeneous_variant_date_type,
                    self._heterogeneous_variant_datetime_type,
                    self.indent,
                )
            )

            def _preamble(data: Value, /) -> tuple[str, ...]:
                """Suppress UnusedImport for ``tables`` and emit the
                object-variant type block.

                The ``import tables`` line is contributed by
                :attr:`dict_format_config` so that ``{...}.toTable``
                renders correctly, but the call stub uses
                ``varargs[untyped]`` and never evaluates its arguments,
                so the Nim compiler treats the import as unused.
                """
                return (
                    "{.warning[UnusedImport]:off.}",
                    *strategy_preamble(data),
                )

            return _preamble
        return no_data_preamble

    @cached_property
    def format_call_target(self) -> Callable[[Sequence[str]], str]:
        """Rewrite a dotted call target into the language's call
        syntax.
        """
        return identity_call_target

    @cached_property
    def format_call_ref_identifier(
        self,
    ) -> Callable[[str, Value | None], str]:
        """Rewrite a ``{"$ref": "name"}`` identifier into the
        language's call expression syntax.
        """
        return identity_call_ref_identifier

    @cached_property
    def format_call_arg_ref_identifier(
        self,
    ) -> Callable[[str, Value | None], str]:
        """Rewrite a ``{"$ref": "name"}`` identifier in a call-argument
        context.

        Delegates to :attr:`format_call_ref_identifier`.  Override this to
        allow call-argument ``$ref`` values that would otherwise be rejected.
        """
        return self.format_call_ref_identifier

    @cached_property
    def format_call_arg_ref_identifier_consumable(
        self,
    ) -> Callable[[str, Value | None], str]:
        """Format a ``$ref`` the caller authorized as consumable.

        Delegates to :attr:`format_call_arg_ref_identifier`.  Override
        this to opt into a consuming form (e.g. C++ ``std::move``).
        """
        return self.format_call_arg_ref_identifier

    @cached_property
    def consumable_ref_value_inhibits_consuming_form(
        self,
    ) -> Callable[[Value], bool]:
        """Predicate deciding whether a ref's underlying value type
        inhibits the consume form.

        Delegates to :data:`never_inhibits_consuming_form`.  Languages
        whose consume operator rejects certain value types (notably
        the Mojo ``^`` on register-trivial scalars) override this.
        """
        return never_inhibits_consuming_form

    @cached_property
    def sequence_format_config(self) -> SequenceFormatConfig:
        """Configuration for the chosen sequence format.

        ``json_type`` wraps every sequence literal in the ``%*`` macro so
        it renders as a ``JsonNode`` array, and widens an empty sequence
        to ``newJArray()`` (the explicit JSON array builder).
        ``OBJECT_VARIANT`` and ``RECORD`` replace the JSON-array opener
        with ``@[`` so nested sequences render as Nim-native ``seq``
        literals at every level (the declaration formatter no longer
        adds a leading ``@`` because ``uses_typed_literal_for_scalars``
        is turned off).  Empty sequences widen to ``newSeq[string]()`` so
        the compiler does not reject ``var x = @[]`` with "cannot
        infer the type of the sequence" -- and, under ``RECORD``, so the
        widened element type matches the ``seq[string]`` an empty-list
        record field is declared.
        """
        base = self.sequence_format.value
        if self._uses_json_node:
            return dataclasses.replace(
                base,
                sequence_open=fixed_open(open_str=f"{_NIM_JSON_MACRO}(["),
                close="])",
                supports_heterogeneity=True,
                uses_typed_literal_for_scalars=False,
                preamble_lines=(),
                empty_sequence="newJArray()",
            )
        if not self._uses_native_nim_collections:
            return base
        return dataclasses.replace(
            base,
            sequence_open=fixed_open(open_str="@["),
            uses_typed_literal_for_scalars=False,
            preamble_lines=(),
            empty_sequence="newSeq[string]()",
        )

    @cached_property
    def set_format_config(self) -> SetFormatConfig:
        """Configuration for the chosen set format.

        ``json_type`` renders a set as a JSON array via ``%*([...])``
        because JSON has no native set type; empty sets widen to
        ``newJArray()`` for the same reason empty sequences do.
        """
        if self._uses_json_node:
            return dataclasses.replace(
                self.set_format.value,
                set_open=sequence_surrogate_set_open(
                    fixed_open(open_str=f"{_NIM_JSON_MACRO}([")
                ),
                close="])",
                empty_set="newJArray()",
                preamble_lines=(),
            )
        return self.set_format.value

    @cached_property
    def sequence_open(self) -> Callable[[list[Value]], str]:
        """Callable that returns the opening delimiter for a sequence."""
        return self.sequence_format_config.sequence_open

    @cached_property
    def dict_format_config(self) -> DictFormatConfig:
        """Configuration for dict formatting.

        ``OBJECT_VARIANT`` and ``RECORD`` append ``.toTable`` to the
        closing brace so every rendered (non-record) dict becomes a
        runtime :class:`tables.Table`.  An empty dict widens to
        ``initTable[string, string]()`` so the compiler does not reject
        ``{}.toTable``: an empty ``{}`` literal is an empty set rather
        than a table, so the call does not resolve and the key/value
        types cannot be inferred.  This mirrors the ``newSeq[string]()``
        widening for empty sequences.

        ``OBJECT_VARIANT`` always wraps its dicts as tables, so it
        carries the ``import tables`` preamble here.  Under ``RECORD`` a
        record-shaped dict never reaches this config (it is intercepted
        by the record renderer and emitted as a ``Record0(...)``
        literal), so ``import tables`` would be an ``UnusedImport`` for
        the common record-only fixture; the import is instead added by
        :attr:`data_dependent_preamble` only when the data still carries
        a genuinely non-record dict that renders as a table.

        ``json_type`` takes precedence: every dict literal is wrapped in
        ``%*({...})`` so it renders as a JSON object, and an empty dict
        widens to ``newJObject()`` (the explicit builder).  The
        ``import json`` line that powers ``%*`` is contributed by
        :attr:`data_dependent_preamble`, not by this config, so a
        heterogeneous-strategy-free fixture still imports it exactly
        once.
        """
        if self._uses_json_node:
            return DictFormatConfig(
                dict_open=fixed_open(open_str=f"{_NIM_JSON_MACRO}({{"),
                close="})",
                format_entry=dict_entry_with_separator(
                    separator=": ",
                    format_value=passthrough_sequence_entry,
                ),
                empty_dict="newJObject()",
                preamble_lines=(),
                narrowed_open=None,
                supports_trailing_comma=True,
                narrowed_empty_form=None,
            )
        effective_preamble_lines: tuple[str, ...]
        if self._uses_native_nim_collections:
            if self._uses_record:
                effective_preamble_lines = ()
            else:
                effective_preamble_lines = ("import tables",)
            return DictFormatConfig(
                dict_open=fixed_open(open_str="{"),
                close="}.toTable",
                format_entry=dict_entry_with_separator(
                    separator=": ",
                    format_value=passthrough_sequence_entry,
                ),
                empty_dict="initTable[string, string]()",
                preamble_lines=(effective_preamble_lines),
                narrowed_open=None,
                supports_trailing_comma=True,
                narrowed_empty_form=None,
            )
        return DictFormatConfig(
            dict_open=fixed_open(open_str="{"),
            close="}",
            format_entry=dict_entry_with_separator(
                separator=": ",
                format_value=passthrough_sequence_entry,
            ),
            empty_dict=None,
            preamble_lines=(),
            narrowed_open=None,
            supports_trailing_comma=True,
            narrowed_empty_form=None,
        )

    @cached_property
    def trailing_comma_config(self) -> TrailingCommaConfig:
        """Configuration for trailing-comma behavior."""
        return self.trailing_comma.value

    @cached_property
    def format_bytes(self) -> Callable[[bytes], str]:
        """Callable that formats a bytes value as a string literal."""
        return self.bytes_format

    @cached_property
    def format_date(self) -> Callable[[datetime.date], str]:
        """Callable that formats a date as a string literal.

        ``json_type`` overrides the configured ``date_format`` with the
        ISO 8601 string form because the ``NIM`` table-literal form
        would not round-trip through JSON.
        """
        if self._uses_json_node:
            return format_date_iso
        return self.date_format

    @cached_property
    def format_datetime(self) -> Callable[[datetime.datetime], str]:
        """Callable that formats a datetime as a string literal.

        ``json_type`` overrides the configured ``datetime_format`` with
        the ISO 8601 string form unless the user has explicitly chosen
        the ``EPOCH`` integer form, which remains a valid JSON number.
        """
        if (
            self._uses_json_node
            and self.datetime_format.value.type_produced is not int
        ):
            return format_datetime_iso
        return self.datetime_format

    @cached_property
    def format_time(self) -> Callable[[datetime.time], str]:
        """Callable that formats a time as a string literal."""
        return format_time_iso

    @cached_property
    def format_float(self) -> Callable[[float], str]:
        """Callable that formats a float value as a literal."""
        return self.float_format

    @cached_property
    def format_integer(self) -> Callable[[int], str]:
        """Callable that formats an int value as a literal."""
        base = self.integer_format.get_formatter(
            numeric_separator=self.numeric_separator,
        )
        is_decimal = self.integer_format is type(self.integer_format).DECIMAL

        def _format(value: int, /) -> str:
            """Keep non-decimal ``int64.low`` within the Nim parser
            range.
            """
            if value == I64_MIN and not is_decimal:
                return f"cast[int]({base(-value)}'u64)"
            return base(value)

        return make_overflow_fallback_formatter(
            base=_format,
            fallback=raise_for_unrepresentable_int(language_name="Nim"),
            min_value=I64_MIN,
            max_value=I64_MAX,
        )

    @cached_property
    def format_integer_widened(self) -> Callable[[int], str]:
        """Format every integer as an explicitly typed ``int64``.

        A non-decimal format writes the sign outside the literal, so
        the magnitude of ``int64.low`` is read as a positive ``int64``
        first and rejected as out of range.  That one value is written
        as its two's-complement bit pattern cast from ``uint64``, which
        keeps the base the format asked for (issue #3937).
        """
        base = self.integer_format.get_formatter(
            numeric_separator=self.numeric_separator,
        )
        is_decimal = self.integer_format is type(self.integer_format).DECIMAL

        def _format(value: int, /) -> str:
            """Format one integer as an ``int64`` literal."""
            if value == I64_MIN and not is_decimal:
                magnitude = base(-value)
                return f"cast[int64]({magnitude}'u64)"
            return f"{base(value)}'i64"

        return _format

    @cached_property
    def comment_config(self) -> CommentConfig:
        """Configuration for the language's comment syntax."""
        return self.comment_format.value

    @cached_property
    def ordered_map_format_config(self) -> OrderedMapFormatConfig:
        """Configuration for ordered-map formatting.

        ``OBJECT_VARIANT`` and ``RECORD`` render an ordered map with its
        native ``{...}.toOrderedTable`` constructor (an ordered map is
        never record-shaped, so ``RECORD`` leaves it on this path).
        ``json_type`` renders an ordered map as a JSON object (the
        ``%*`` macro preserves object-key insertion order in the
        rendered output).
        """
        if self._uses_json_node:
            return OrderedMapFormatConfig(
                ordered_map_open=fixed_open(open_str=f"{_NIM_JSON_MACRO}({{"),
                close="})",
                preamble_lines=(),
            )
        if self._uses_native_nim_collections:
            return OrderedMapFormatConfig(
                ordered_map_open=fixed_open(open_str="{"),
                close="}.toOrderedTable",
                preamble_lines=("import tables",),
            )
        return OrderedMapFormatConfig(
            ordered_map_open=fixed_open(open_str="{"),
            close="}",
            preamble_lines=(),
        )

    @cached_property
    def format_ordered_map_entry(self) -> Callable[[str, Value, str], str]:
        """Callable that formats one ordered-map entry."""
        return dict_entry_with_separator(
            separator=": ",
            format_value=passthrough_sequence_entry,
        )

    @cached_property
    def format_variable_declaration(
        self,
    ) -> Callable[[str, str, Value, frozenset[enum.Enum]], str]:
        """Callable that formats a new variable declaration.

        Under ``json_type`` the declaration carries an explicit
        ``: JsonNode`` type annotation and the right-hand side is wrapped
        by ``%*`` only when the value is not already a ``JsonNode``
        expression (the wrapping check in
        :func:`_nim_json_value_expression` skips re-wrapping ``%*(...)``
        and ``newJ*`` builders so the rendered output stays flat).
        """
        json_type = self.json_type
        if json_type is not None:
            return _nim_json_declaration_formatter(
                declaration_style=self.declaration_style,
                json_type=json_type.value,
            )
        is_const = self.declaration_style is self.declaration_styles.CONST
        return _make_variable_declaration(
            uses_typed_literal_for_scalars=(
                self.sequence_format_config.uses_typed_literal_for_scalars
            ),
            keyword=self.declaration_style.name.lower(),
            force_sequence=is_const,
            uses_json_wrap=not self._uses_native_nim_collections,
        )

    @cached_property
    def format_variable_assignment(
        self,
    ) -> Callable[[str, str, Value], str]:
        """Callable that formats an assignment to an existing variable.

        Under ``json_type`` the assigned expression is wrapped by ``%*``
        through the same helper as the declaration form so the two
        halves of a combined declaration / assignment stay consistent.
        """
        if self._uses_json_node:
            return _format_nim_json_assignment
        return _make_variable_assignment(
            uses_typed_literal_for_scalars=(
                self.sequence_format_config.uses_typed_literal_for_scalars
            ),
            uses_json_wrap=not self._uses_native_nim_collections,
        )

    @cached_property
    def format_call_arg(self) -> Callable[[Value, str], str]:
        """Callable that rewrites a formatted direct call argument.

        Under ``json_type`` every call argument is wrapped in ``%*`` so
        the underlying proc receives a ``JsonNode``; under any other
        mode call arguments pass through unchanged.
        """
        if self._uses_json_node:
            return _format_nim_json_call_arg
        return identity_call_arg

    @cached_property
    def format_call_variable_declaration(
        self,
    ) -> Callable[[str, str, Value, frozenset[enum.Enum]], str]:
        """Callable that formats a declaration binding a call result.

        The literal-binding declaration prefixes the right-hand side
        with the ``%*`` json macro (or ``@`` for sequences) chosen from
        the parsed literal's type; that JSON-constructs a literal and is
        invalid for a call result.  The plain ``<keyword> <name> =
        <value>`` declaration-style formatter binds the call result
        directly with no wrapping.
        """
        return self.declaration_style.value.formatter

    @cached_property
    def format_call_variable_assignment(
        self,
    ) -> Callable[[str, str, Value], str]:
        """Callable that formats an assignment binding a call result.

        The call-expression counterpart of
        :attr:`format_variable_assignment`; the ``%*``/``@`` wrapping is
        dropped since a call result is bound directly.  Unlike the
        declaration form this carries no ``var``/``let``/``const``
        keyword, so it does not reuse the declaration-style formatter.
        """
        return variable_formatter(template="{name} = {value}")

    @cached_property
    def scalar_preamble(self) -> dict[type, tuple[str, ...]]:
        """Per-instance scalar preamble for Nim scalar types.

        Under the default ``ERROR`` heterogeneous strategy
        ``import json`` is added by :attr:`data_dependent_preamble`
        only when the rendered output uses ``%*``.  Under
        ``OBJECT_VARIANT`` scalars are emitted as native Nim values,
        except that the ``NIM`` date / datetime formats still
        produce a :class:`json.JsonNode` payload and require
        ``import json`` whenever a date or datetime is present.
        Under ``json_type`` the ``import json`` line is contributed
        unconditionally by :attr:`data_dependent_preamble`, so this
        method returns an empty per-scalar map to avoid duplicating it.
        """
        if self._uses_json_node:
            return {}
        date_preamble: tuple[str, ...]
        datetime_preamble: tuple[str, ...]
        if self._uses_object_variant:
            json_import = ("import json",)
            date_preamble = json_import
            if self.date_format.value.type_produced is str:
                date_preamble = ()
            datetime_preamble = json_import
            if self.datetime_format.value.type_produced in {str, int}:
                datetime_preamble = ()
            return {
                datetime.date: date_preamble,
                datetime.datetime: datetime_preamble,
            }
        return {
            datetime.date: self.date_format.value.preamble_lines,
            datetime.datetime: self.datetime_format.value.preamble_lines,
        }

    @cached_property
    def scalar_body_preamble(self) -> dict[type, tuple[str, ...]]:
        """Per-instance scalar body preamble (Nim needs none)."""
        return {}

    @cached_property
    def compute_body_preamble(
        self,
    ) -> Callable[[frozenset[type], Value], tuple[str, ...]]:
        """Compute body-preamble lines from the scalar map."""
        return body_preamble_from_scalars(
            scalar_body_preamble=self.scalar_body_preamble,
            format_lines=tuple,
        )
