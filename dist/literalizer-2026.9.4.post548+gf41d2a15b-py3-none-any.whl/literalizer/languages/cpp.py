"""C++ language specification."""

import dataclasses
import datetime
import enum
import functools
import itertools
import json
import re
from collections.abc import Callable, Mapping, Sequence
from functools import cached_property
from types import MappingProxyType
from typing import ClassVar, TypeGuard

from beartype import beartype

from literalizer._checks import scalar_type_bucket
from literalizer._formatters.collection_openers import (
    fixed_open,
    make_element_to_type,
    sequence_surrogate_set_open,
)
from literalizer._formatters.format_dates import (
    format_date_iso,
    format_datetime_epoch,
    format_datetime_iso,
    format_time_iso,
)
from literalizer._formatters.format_entries import (
    braced_dict_entry,
    dict_entry_with_separator,
    format_bytes_base64,
    format_bytes_hex,
    passthrough_sequence_entry,
    passthrough_set_entry,
    variable_formatter,
)
from literalizer._formatters.format_floats import (
    data_has_special_float,
    format_float_fixed,
    format_float_repr,
    format_float_scientific,
)
from literalizer._formatters.format_integers import (
    I64_MAX,
    I64_MIN,
    U64_MAX,
    format_integer_binary,
    format_integer_hex,
    format_integer_octal_c_style,
    format_integer_tick,
    make_i64_min_safe_formatter,
    make_long_suffix_formatter,
    make_negative_nondecimal_i64_formatter,
    make_overflow_fallback_formatter,
    make_ull_fallback,
)
from literalizer._formatters.format_strings import (
    format_string_backslash_nul_octal,
)
from literalizer._formatters.record_strategy import (
    ActiveRecordStrategy,
    RecordDeclarationField,
    RecordFieldType,
    RecordLiteralField,
    RecordRenderer,
    build_record_strategy,
    identity_field_identifier_key,
    nested_record_sequence_type,
)
from literalizer._formatters.tuple_strategy import (
    is_tuple_eligible,
)
from literalizer._formatters.type_inference import (
    BeyondI64,
    DictType,
    ListType,
    WideInt,
    collect_record_shapes,
    infer_element_type,
    record_shape_for_dict,
    set_sort_key,
)
from literalizer._heterogeneous import iter_wrapped_scalars
from literalizer._json_native_document import (
    register_json_native_document_fast,
)
from literalizer._language import (
    NO_CALL_PARAMETER_LIMIT,
    NO_HETEROGENEOUS_BEHAVIOR,
    NON_KEBAB_REF_CASES,
    BareIntegerWidthStrategies,
    CallParameterShadowing,
    CallStyle,
    CommentConfig,
    DateFormatConfig,
    DateFormatEnum,
    DatetimeFormatConfig,
    DatetimeFormatEnum,
    DictFormatConfig,
    FloatSpecialsMixin,
    HeterogeneousBehavior,
    IdentifierCase,
    JsonType,
    LanguageCls,
    ModifierCombination,
    NewVariableNameSyntax,
    OrderedMapFormatConfig,
    PositionalCallStyle,
    RecordMapValueTypings,
    RenderedRecordLiteral,
    RenderedTupleLiteral,
    RoundTripCapability,
    SequenceFormatConfig,
    SetFormatConfig,
    StubReturn,
    TrailingCommaConfig,
    VariantMetadata,
    body_preamble_from_scalars,
    date_scalar_preamble,
    default_format_call_variable_assignment,
    default_format_call_variable_declaration,
    default_sequence_binding_declarations,
    default_wrap_calls_with_declarations,
    identity_call_arg,
    identity_call_ref_identifier,
    identity_call_statement,
    identity_call_target,
    identity_constructor_target,
    no_call_binding_body_preamble,
    no_call_binding_file_pragmas,
    no_call_stub,
    no_compute_call_slot_wrap_ids,
    no_compute_wrap_ids,
    no_data_preamble,
    no_empty_container_literal_overrides,
    no_format_integer_beyond_i64,
    no_format_integer_widened,
    no_leading_preamble,
    no_type_hint_preamble,
    no_validate_call_arg,
    prepend_body_preamble,
)
from literalizer._types import OrderedMap, Scalar, Value, ValueInput
from literalizer.exceptions import (
    IncompatibleFormatsError,
    InvalidCppRawStringDelimiterError,
    InvalidRecordNameError,
    UnrepresentableInputError,
    UnrepresentableIntegerError,
    UnrepresentableSpecialFloatError,
)

_TRAILING_LINE_WHITESPACE = re.compile(pattern=r"[ \t]+(?=\n)")
_JSON_INTEGER_TOKEN = re.compile(pattern=r"-?(?:0|[1-9][0-9]*)\Z")
_CPP_RAW_STRING_DELIMITER_MAX_LENGTH = 16
_CPP_RAW_STRING_DELIMITER_CHARACTERS = frozenset(
    "abcdefghijklmnopqrstuvwxyz"
    "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    "0123456789"
    "_{}[]#<>%:;.?*+-/^&|~!=,\"'",
)


@dataclasses.dataclass(frozen=True, slots=True)
class _CppRecordListShape:
    """The distinct element shapes in a C++ record list."""

    elements: tuple["_CppRecordValueShape", ...]


@dataclasses.dataclass(frozen=True, slots=True)
class _CppRecordShape:
    """The keys and value shapes in a C++ record."""

    keys: tuple[Scalar, ...]
    values: tuple["_CppRecordValueShape", ...]


type _CppRecordValueShape = str | _CppRecordListShape | _CppRecordShape


@dataclasses.dataclass(frozen=True, slots=True)
class _CppArrayShape:
    """The size and distinct element shapes in a C++ array."""

    length: int
    elements: tuple["_CppArrayNestedShape", ...]


@dataclasses.dataclass(frozen=True, slots=True)
class _CppArrayMapShape:
    """The value shapes in a map nested within a C++ array."""

    values: tuple["_CppArrayNestedShape", ...]


type _CppArrayNestedShape = str | _CppArrayShape | _CppArrayMapShape


@beartype
def _cpp_record_value_shape(value: Value, /) -> _CppRecordValueShape:
    """Return the generated-record shape required by *value*."""
    if isinstance(value, list):
        return _CppRecordListShape(
            elements=tuple(
                dict.fromkeys(_cpp_record_value_shape(item) for item in value)
            ),
        )
    if isinstance(value, dict) and not isinstance(value, OrderedMap):
        return _CppRecordShape(
            keys=tuple(value),
            values=tuple(
                _cpp_record_value_shape(item) for item in value.values()
            ),
        )
    return type(value).__name__


@beartype
def _cpp_array_nested_shape(value: Value, /) -> _CppArrayNestedShape:
    """Return a structural type shape for a nested C++ array value."""
    if isinstance(value, list):
        return _CppArrayShape(
            length=len(value),
            elements=tuple(
                dict.fromkeys(_cpp_array_nested_shape(item) for item in value)
            ),
        )
    if isinstance(value, dict):
        return _CppArrayMapShape(
            values=tuple(
                _cpp_array_nested_shape(item) for item in value.values()
            ),
        )
    return type(value).__name__


@beartype
def _reject_distinct_record_list_ordered_map_values(data: Value, /) -> None:
    """Reject ordered-map values requiring different C++ record lists."""
    if isinstance(data, OrderedMap):
        values = list(data.values())
        all_are_record_lists = all(
            isinstance(value, list)
            and len(value) > 0
            and all(isinstance(element, dict) for element in value)
            for value in values
        )
        shapes = {_cpp_record_value_shape(value) for value in values}
        if all_are_record_lists and len(shapes) > 1:
            msg = (
                "C++ RECORD ordered maps require one compatible value "
                "type; these record-list values have distinct shapes"
            )
            raise UnrepresentableInputError(msg)
    if isinstance(data, dict):
        for child in data.values():
            _reject_distinct_record_list_ordered_map_values(child)
    elif isinstance(data, (list, set)):
        for child in data:
            _reject_distinct_record_list_ordered_map_values(child)


@beartype
def _reject_incompatible_nested_cpp_arrays(data: Value, /) -> None:
    """Reject nested arrays whose elements need distinct variant arms."""
    if isinstance(data, list):
        nested = [item for item in data if isinstance(item, list)]
        if len(nested) == len(data) and len(nested) > 1:
            shapes = {_cpp_array_nested_shape(item) for item in nested}
            if len(shapes) > 1:
                msg = (
                    "C++ ARRAY cannot construct nested heterogeneous "
                    "values with incompatible element types"
                )
                raise UnrepresentableInputError(msg)
        for child in data:
            _reject_incompatible_nested_cpp_arrays(child)
    elif isinstance(data, dict):
        for child in data.values():
            _reject_incompatible_nested_cpp_arrays(child)


@beartype
def _format_string_cpp_escaped(value: str) -> str:
    r"""Format *value* without embedding a null byte in a C++ literal."""
    segments = value.split(sep="\0")
    if len(segments) == 1:
        return format_string_backslash_nul_octal(value=value)
    formatted_segments = [
        format_string_backslash_nul_octal(value=segment)
        for segment in segments
    ]
    return " + '\\0' + ".join(
        [f"std::string{{{formatted_segments[0]}}}", *formatted_segments[1:]],
    )


@beartype
def _raw_string_delimiters(*, base: str) -> itertools.chain[str]:
    """Return C++ raw-string delimiter candidates for *base*.

    The empty delimiter is always first. Numeric suffixes start at zero and
    stop before the complete delimiter would exceed C++'s 16-character
    limit.
    """
    suffix_width = _CPP_RAW_STRING_DELIMITER_MAX_LENGTH - len(base)
    if suffix_width != 0:
        suffix_indexes = range(10**suffix_width)
    else:
        suffix_indexes = range(0)
    suffixed = (f"{base}{index}" for index in suffix_indexes)
    return itertools.chain(("", base), suffixed)


@beartype
def _format_string_multiline_with_delimiter_base(
    value: str,
    *,
    delimiter_base: str,
) -> str:
    r"""Format *value* as a C++ raw string with a safe delimiter."""
    if (
        "\0" in value
        or "\r" in value
        or _TRAILING_LINE_WHITESPACE.search(string=value) is not None
    ):
        return _format_string_cpp_escaped(value=value)
    for delimiter in _raw_string_delimiters(base=delimiter_base):
        if f'){delimiter}"' not in value:
            return f'R"{delimiter}({value}){delimiter}"'
    return _format_string_cpp_escaped(value=value)


@beartype
def _format_string_multiline(value: str) -> str:
    """Format *value* with the default multiline delimiter base."""
    return _format_string_multiline_with_delimiter_base(
        value=value,
        delimiter_base="x",
    )


class _CppModifiers(enum.Enum):
    """Declaration modifiers supported by C++.

    Each member's value is the C++ keyword it renders to.  Declaration
    order matches canonical C++ modifier order (``static`` before
    ``const``).

    Exposed as :attr:`Cpp.Modifiers` / :attr:`Cpp.modifiers`.
    """

    STATIC = "static"
    """Storage: internal linkage at namespace scope, or per-class
    storage inside a class.
    """

    CONST = "const"
    """Immutability: the variable cannot be reassigned."""


_INT32_MIN = -(1 << 31)
_INT32_MAX = (1 << 31) - 1
_PASCAL_CASE_IDENTIFIER = re.compile(pattern=r"^[A-Z][A-Za-z0-9_]*$")
_CPP_FIELD_IDENTIFIER = re.compile(pattern=r"^[A-Za-z_][A-Za-z0-9_]*$")


_IntTypeResolver = Callable[[list[int]], str]


@beartype
def _narrowest_cpp_int_type(values: list[int]) -> str:
    """Return the narrowest C++ integer type holding every value in
    *values*: ``int`` when every value fits in 32 bits, ``long long``
    when every value fits in signed 64 bits, else
    ``unsigned long long``.  Empty inputs return ``"int"``.  ``long``
    is skipped because its width is platform-dependent (32-bit on
    Windows, 64-bit on Unix).
    """
    if len(values) == 0:
        return "int"
    if any(not I64_MIN <= v <= I64_MAX for v in values):
        # The only C++ type holding a value above ``LLONG_MAX`` is
        # unsigned, which no negative sibling narrows to, so a
        # collection mixing the two fits no single type (issue #4570).
        if any(v > I64_MAX for v in values) and any(v < 0 for v in values):
            negative = min(values)
            beyond = max(values)
            msg = (
                f"C++ cannot represent negative integer {negative} "
                f"alongside {beyond}, which is above the signed 64-bit "
                "range: no single C++ integer type holds both."
            )
            raise UnrepresentableIntegerError(msg)
        return "unsigned long long"
    if all(_INT32_MIN <= v <= _INT32_MAX for v in values):
        return "int"
    return "long long"


@beartype
def _static_int_resolver(int_type: str) -> _IntTypeResolver:
    """Return a resolver that always yields *int_type*."""

    def _resolve(_values: list[int]) -> str:
        """Return the fixed int type, ignoring values."""
        return int_type

    return _resolve


@beartype
def _collect_int_leaves(
    *,
    items: list[Value],
    element_type: type | ListType | DictType,
) -> list[int]:
    """Collect int values that would occupy the int leaf of
    *element_type* when *items* is resolved to its C++ type.
    """
    if (
        element_type is int
        or element_type is WideInt
        or element_type is BeyondI64
    ):
        return [
            item
            for item in items
            if isinstance(item, int) and not isinstance(item, bool)
        ]
    if isinstance(element_type, ListType):
        return [
            leaf
            for item in items
            if isinstance(item, list)
            for leaf in _collect_int_leaves(
                items=item,
                element_type=element_type.inner,
            )
        ]
    if (
        isinstance(element_type, DictType)
        and element_type.value_type is not None
    ):
        return [
            leaf
            for item in items
            if isinstance(item, dict)
            for leaf in _collect_int_leaves(
                items=list(item.values()),
                element_type=element_type.value_type,
            )
        ]
    return []


@beartype
def _collect_direct_ints(items: list[Value]) -> list[int]:
    """Collect int values that are direct items (not nested in
    sub-collections).  Excludes booleans.
    """
    return [
        item
        for item in items
        if isinstance(item, int) and not isinstance(item, bool)
    ]


@beartype
def _format_date_cpp(value: datetime.date) -> str:
    """Format a date as a C++ chrono year_month_day literal."""
    return (
        f"std::chrono::year_month_day{{"
        f"std::chrono::year{{{value.year}}}, "
        f"std::chrono::month{{{value.month}}}, "
        f"std::chrono::day{{{value.day}}}}}"
    )


@beartype
def _format_datetime_cpp(value: datetime.datetime) -> str:
    """Format a datetime as a C++ chrono time_point construction."""
    ymd = _format_date_cpp(value=value)
    parts = [f"std::chrono::sys_days{{{ymd}}}"]
    if value.hour != 0:
        parts.append(f"std::chrono::hours{{{value.hour}}}")
    if value.minute != 0:
        parts.append(f"std::chrono::minutes{{{value.minute}}}")
    if value.second != 0:
        parts.append(f"std::chrono::seconds{{{value.second}}}")
    if value.microsecond != 0:
        parts.append(f"std::chrono::microseconds{{{value.microsecond}}}")
    return f"std::chrono::system_clock::time_point{{{' + '.join(parts)}}}"


@beartype
def _make_cpp_element_to_type(
    *,
    enable_list_type: bool,
    int_type: str,
    date_type: str | None,
    datetime_type: str | None,
    dict_type_name: str,
) -> Callable[[type | ListType | DictType], str | None]:
    """Build the C++ element-to-type resolver.

    *enable_list_type* is ``False`` under the ``ARRAY`` sequence
    format, whose type carries the length this resolver has no value to
    read (issue #3948).
    """
    return make_element_to_type(
        dict_value_to_type=None,
        str_type="std::string",
        bool_type="bool",
        int_type=int_type,
        float_type="double",
        mixed_numeric_type="double",
        bytes_type="std::string",
        date_type=date_type,
        datetime_type=datetime_type,
        time_type="std::string",
        list_template="std::vector<{inner}>",
        enable_list_type=enable_list_type,
        dict_type_template=f"{dict_type_name}<std::string, {{inner}}>",
        fallback_value_type=None,
        wide_int_type=None,
        beyond_i64_type=None,
    )


@beartype
def _cpp_value_inhibits_consuming_form(value: Value, /) -> bool:
    """Return ``True`` when ``std::move`` is unhelpful for *value*'s C++
    type.

    The literalize-generated C++ maps Python ``bool`` / ``int`` /
    ``float`` to ``bool`` / a narrow integer / ``double``, all of which
    are register-trivial.  ``date`` and ``datetime`` map to
    ``std::chrono::year_month_day`` and
    ``std::chrono::system_clock::time_point``, both also
    register-trivial.  Strings, bytes, lists, and dicts allocate or own
    heap storage, so ``std::move`` continues to deliver value for those.
    """
    if isinstance(value, (list, dict, set)):
        return False
    return isinstance(value, (bool, int, float, datetime.date))


@beartype
@dataclasses.dataclass(frozen=True)
class _CppTypeCtx:
    """Context for C++ type resolution with value-driven int narrowing.

    Bundles the date/datetime type strings (which are static) with an
    :data:`_IntTypeResolver` that picks the narrowest int type for a
    given collection of values.  Used wherever a type string is emitted
    so that the int type can be specialized per-collection.

    ``tuple_strategy`` is ``True`` under the ``TUPLE`` heterogeneous
    strategy: a tuple-eligible heterogeneous scalar array is then typed
    ``std::tuple<T0, ...>`` instead of
    ``std::vector<std::variant<...>>``, matching the
    ``std::make_tuple`` literal the strategy renders.
    """

    int_resolver: _IntTypeResolver
    date_type: str | None
    datetime_type: str | None
    tuple_strategy: bool
    variant_type_name: str
    dict_type_name: str
    record_name_for_value: Callable[[Value], str | None]
    """The name a mapping is rendered as, where it is rendered as one.

    Under the ``RECORD`` strategy a record-shaped mapping is written as
    a generated ``struct`` literal, so a variant alternative beside it
    has to name that ``struct`` rather than the mapping type the value
    would otherwise take (issue #4500).
    """

    sequence_is_array: bool
    """Whether a sequence renders as ``std::array``.

    An array's length is part of its type, so a value-driven type
    string spells it and the value-less resolver cannot name a
    sequence type at all (issue #3948).
    """

    def sequence_type(self, *, inner: str, length: int) -> str:
        """Return the type the active sequence format renders."""
        if self.sequence_is_array:
            return f"std::array<{inner}, {length}>"
        return f"std::vector<{inner}>"

    def dict_type(self, value_type: str, /) -> str:
        """Return the active string-keyed mapping type."""
        return f"{self.dict_type_name}<std::string, {value_type}>"

    def variant_type(self, types: Sequence[str], /) -> str:
        """Return the active heterogeneous-value carrier type."""
        if self.variant_type_name != "std::variant":
            return self.variant_type_name
        return f"{self.variant_type_name}<{', '.join(types)}>"

    def element_to_type(
        self,
        *,
        int_type: str,
    ) -> Callable[[type | ListType | DictType], str | None]:
        """Build an element-to-type resolver with the given *int_type*."""
        return _make_cpp_element_to_type(
            enable_list_type=not self.sequence_is_array,
            int_type=int_type,
            date_type=self.date_type,
            datetime_type=self.datetime_type,
            dict_type_name=self.dict_type_name,
        )


@beartype
def _cpp_array_type(
    *,
    items: list[Value],
    type_ctx: _CppTypeCtx,
) -> str | None:
    """Return the recursive ``std::array`` type for *items*."""
    if len(items) == 0:
        return "std::array<std::nullptr_t, 0>"
    int_type = type_ctx.int_resolver(
        [
            item
            for item in items
            if isinstance(item, int) and not isinstance(item, bool)
        ],
    )
    element_to_type = type_ctx.element_to_type(int_type=int_type)
    collected_element_types: list[str | None] = []
    for entry_item in items:
        if isinstance(entry_item, list):
            effective_cpp_array_type = _cpp_array_type(
                items=entry_item, type_ctx=type_ctx
            )
        else:
            effective_cpp_array_type = element_to_type(type(entry_item))
        collected_element_types.append(effective_cpp_array_type)
    element_types = collected_element_types
    first = element_types[0]
    if first is None or any(item != first for item in element_types):
        return None
    return type_ctx.sequence_type(inner=first, length=len(items))


@beartype
def _build_cpp_array_open(
    *,
    type_ctx: _CppTypeCtx,
) -> Callable[[list[Value]], str]:
    """Build an opener that emits ``std::array<T, N>`` with the int
    type narrowed to the narrowest that holds every int value.
    """

    def _open(items: list[Value]) -> str:
        """Return the typed ``std::array`` opener, or ``{`` on
        fallback.
        """
        type_name = _cpp_array_type(items=items, type_ctx=type_ctx)
        if type_name is None:
            return "{"
        return f"{type_name}{{"

    return _open


@beartype
def _make_initializer_list_config(
    *,
    type_ctx: _CppTypeCtx,
) -> SequenceFormatConfig:
    """Build an INITIALIZER_LIST sequence config."""
    return SequenceFormatConfig(
        sequence_open=_build_variant_sequence_open(type_ctx=type_ctx),
        close="}",
        supports_heterogeneity=True,
        single_element_trailing_comma=False,
        single_element_template=None,
        supports_trailing_comma=True,
        empty_sequence=None,
        preamble_lines=("#include <vector>",),
        format_entry=passthrough_sequence_entry,
        typed_opener_fallback=None,
        uses_typed_literal_for_scalars=False,
        requires_uniform_record_shapes=False,
        declared_type=None,
        narrowed_empty_form=lambda siblings: _cpp_narrowed_empty_sequence(
            siblings=siblings, type_ctx=type_ctx
        ),
    )


@beartype
def _make_array_config(
    *,
    type_ctx: _CppTypeCtx,
) -> SequenceFormatConfig:
    """Return the ARRAY sequence config."""
    return SequenceFormatConfig(
        sequence_open=_build_cpp_array_open(type_ctx=type_ctx),
        close="}",
        supports_heterogeneity=False,
        single_element_trailing_comma=False,
        single_element_template=None,
        supports_trailing_comma=True,
        empty_sequence=None,
        preamble_lines=("#include <array>",),
        format_entry=passthrough_sequence_entry,
        typed_opener_fallback=None,
        uses_typed_literal_for_scalars=False,
        requires_uniform_record_shapes=False,
        declared_type=None,
        narrowed_empty_form=None,
    )


@beartype
def _cpp_narrowed_empty_sequence(
    *, siblings: Sequence[list[Value]], type_ctx: _CppTypeCtx
) -> str:
    """Render an empty sequence with its non-empty cousin's type."""
    inner = _compute_element_type_for_items(
        items=siblings[0], type_ctx=type_ctx
    )
    return type_ctx.sequence_type(inner=inner, length=0) + "{}"


@beartype
@dataclasses.dataclass(frozen=True)
class _DictFormatOption:
    """A dict format bundled with its typed opener template."""

    config: DictFormatConfig
    opener_template: str


@beartype
@dataclasses.dataclass(frozen=True)
class _NumericLiteralSuffixConfig:
    """Configuration for a numeric literal suffix option."""

    int_resolver: _IntTypeResolver
    formatter_wrapper: Callable[[Callable[[int], str]], Callable[[int], str]]


@beartype
def _identity_wrapper(
    base: Callable[[int], str],
) -> Callable[[int], str]:
    """Return the formatter unchanged."""
    return base


@beartype
def _cpp_tuple_element_type(
    *,
    value: Value,
    type_ctx: _CppTypeCtx,
) -> str:
    """Return the C++ type for one tuple element.

    Tuple-eligible arrays are all-scalar (see
    :func:`~literalizer._formatters.tuple_strategy.is_tuple_eligible`),
    so *value* is always a scalar; each element's int width is narrowed
    to its own value so the declared type matches the
    ``std::make_tuple`` literal, whose integer arguments carry no width
    suffix.
    """
    if isinstance(value, int) and not isinstance(value, bool):
        int_type = type_ctx.int_resolver([value])
    else:
        int_type = "long long"
    element_to_type = type_ctx.element_to_type(int_type=int_type)
    return _compute_cpp_type(
        item=value,
        element_to_type=element_to_type,
        type_ctx=type_ctx,
    )


@beartype
def _cpp_tuple_type(
    *,
    items: list[Value],
    type_ctx: _CppTypeCtx,
) -> str:
    """Return ``std::tuple<T0, T1, ...>`` for a tuple-eligible array."""
    element_types = [
        _cpp_tuple_element_type(value=element, type_ctx=type_ctx)
        for element in items
    ]
    return f"std::tuple<{', '.join(element_types)}>"


@beartype
def _compute_cpp_type(
    *,
    item: Value,
    element_to_type: Callable[[type | ListType | DictType], str | None],
    type_ctx: _CppTypeCtx,
) -> str:
    """Return the C++ type string for a single value.

    *element_to_type* must have the int type already narrowed for the
    enclosing collection's variant arm (or homogeneous leaf).  When the
    value is a sub-collection, recursion re-narrows independently via
    *type_ctx*. Under the ``TUPLE`` strategy, a tuple-eligible
    heterogeneous scalar array is typed ``std::tuple<...>`` at every
    nesting level, allowing homogeneous enclosing lists to become
    ``std::vector<std::tuple<...>>``.
    """
    match item:
        case OrderedMap():
            omap_values = item.values()
            values: list[Value] = list(omap_values)
            value_type = _compute_element_type_for_items(
                items=values,
                type_ctx=type_ctx,
                in_mapping_value=True,
            )
            return f"std::vector<std::pair<std::string, {value_type}>>"
        case dict():
            record_name = type_ctx.record_name_for_value(item)
            if record_name is not None:
                return record_name
            values = list(item.values())
            value_type = _compute_element_type_for_items(
                items=values,
                type_ctx=type_ctx,
                in_mapping_value=True,
            )
            return type_ctx.dict_type(value_type)
        case list():
            if type_ctx.tuple_strategy and is_tuple_eligible(value=item):
                cpp_type = _cpp_tuple_type(items=item, type_ctx=type_ctx)
            else:
                inner_type = _compute_element_type_for_items(
                    items=item,
                    type_ctx=type_ctx,
                    in_mapping_value=False,
                )
                cpp_type = type_ctx.sequence_type(
                    inner=inner_type,
                    length=len(item),
                )
            return cpp_type
        case set():
            sorted_items: list[Value] = sorted(
                item,
                key=set_sort_key,
            )
            inner_type = _compute_element_type_for_items(
                items=sorted_items,
                type_ctx=type_ctx,
                in_mapping_value=False,
            )
            return type_ctx.sequence_type(
                inner=inner_type,
                length=len(sorted_items),
            )
        case _:
            scalar_type = element_to_type(type(item))
            resolved_result_1: str = "std::nullptr_t"
            if scalar_type is not None:
                resolved_result_1 = scalar_type
            return resolved_result_1


@beartype
def _collect_unique_cpp_types(
    *,
    items: list[Value],
    element_to_type: Callable[[type | ListType | DictType], str | None],
    type_ctx: _CppTypeCtx,
) -> list[str]:
    """Collect unique C++ type names for each item, preserving order."""
    unique_cpp_types: list[str] = []
    seen: set[str] = set()
    for item in items:
        item_type = _compute_cpp_type(
            item=item,
            element_to_type=element_to_type,
            type_ctx=type_ctx,
        )
        if item_type not in seen:
            seen.add(item_type)
            unique_cpp_types.append(item_type)
    return unique_cpp_types


@beartype
def _is_cpp_value_list(value: Value, /) -> TypeGuard[list[Value]]:
    """Narrow a parsed value to a recursively typed list."""
    return isinstance(value, list)


@beartype
def _infer_cpp_collection_element(
    *, items: list[Value], type_ctx: _CppTypeCtx
) -> type | ListType | DictType | None:
    """Infer a homogeneous type unless tuple rendering needs per-item
    types.
    """
    has_tuple_item = type_ctx.tuple_strategy and any(
        isinstance(item, list) and is_tuple_eligible(value=item)
        for item in items
    )
    element_type = None
    if not has_tuple_item:
        element_type = infer_element_type(items=items)
    return element_type


@beartype
def _compute_element_type_for_items(
    *,
    items: list[Value],
    type_ctx: _CppTypeCtx,
    **_ignored_context: bool,
) -> str:
    """Return the C++ element type for a collection of items.

    Returns a single type name when all items have the same C++ type,
    or ``std::variant<T1, T2, ...>`` for mixed types.  Returns
    ``std::nullptr_t`` for empty collections.  Narrows int-valued leaves
    to the narrowest C++ int type that holds the actual values.

    Under the ``TUPLE`` strategy, when any item is a tuple-eligible
    array, the homogeneous fast path is bypassed: each item is typed
    individually so a tuple-eligible array becomes ``std::tuple<...>``
    (the fast path would otherwise widen a uniform list-of-arrays to
    ``std::vector<std::variant<...>>``).
    """
    if len(items) == 0:
        return "std::nullptr_t"
    element_type = _infer_cpp_collection_element(
        items=items, type_ctx=type_ctx
    )
    if element_type is not None:
        match element_type:
            case DictType(value_type=None, values=dict_values):
                value_type = _compute_element_type_for_items(
                    items=list(dict_values),
                    type_ctx=type_ctx,
                    in_mapping_value=True,
                )
                return type_ctx.dict_type(value_type)
            case _:
                int_leaves = _collect_int_leaves(
                    items=items,
                    element_type=element_type,
                )
                homogeneous_int_type = type_ctx.int_resolver(int_leaves)
                element_to_type = type_ctx.element_to_type(
                    int_type=homogeneous_int_type,
                )
                cpp_type = element_to_type(element_type)
                if cpp_type is not None:
                    return cpp_type
    sibling_lists = [item for item in items if isinstance(item, list)]
    if (
        not type_ctx.tuple_strategy
        and len(sibling_lists) == len(items)
        and len({len(item) for item in sibling_lists}) == 1
        and bool(sibling_lists[0])
        and any(
            any(
                _is_cpp_value_list(item) and len(item) == 0
                for item in position
            )
            and any(_is_cpp_value_list(item) and item for item in position)
            for position in zip(*sibling_lists, strict=True)
        )
    ):
        positional_types = [
            _compute_element_type_for_items(
                items=list(position), type_ctx=type_ctx
            )
            for position in zip(*sibling_lists, strict=True)
        ]
        if len(set(positional_types)) == 1:
            inner = positional_types[0]
        else:
            inner = type_ctx.variant_type(positional_types)
        return type_ctx.sequence_type(
            inner=inner,
            length=len(sibling_lists[0]),
        )
    variant_int_type = type_ctx.int_resolver(
        _collect_direct_ints(items=items),
    )
    variant_element_to_type = type_ctx.element_to_type(
        int_type=variant_int_type,
    )
    match _collect_unique_cpp_types(
        items=items,
        element_to_type=variant_element_to_type,
        type_ctx=type_ctx,
    ):
        case [single]:
            return single
        case types:
            return type_ctx.variant_type(types)


@beartype
def _items_need_variant(
    items: list[Value],
    element_to_type: Callable[[type | ListType | DictType], str | None],
    *,
    type_ctx: _CppTypeCtx,
    tuple_list_ids: frozenset[int],
    record_dict_ids: frozenset[int],
) -> bool:
    """Check whether a collection's items need ``std::variant``."""
    if len(items) == 0:
        return False
    # ``infer_element_type`` deliberately has no fixed-size tuple arm,
    # so a homogeneous list of C++ tuple-strategy lists would otherwise
    # look heterogeneous here even though its declared element type is
    # one ``std::tuple<...>``.  The nested tuple collector has already
    # established that every item is such a tuple.
    if all(
        isinstance(item, list) and id(item) in tuple_list_ids for item in items
    ):
        return False
    element_type = infer_element_type(items=items)
    if element_type is None:
        # Python types can differ while their rendered C++ types agree
        # (for example ``date`` and ``time`` both become
        # ``std::string``).  Nested tuple containers are likewise
        # outside the generic inference model.  Decide from the actual
        # C++ types, then keep walking an agreed container type in case
        # one of its descendants still needs a carrier.
        types = _collect_unique_cpp_types(
            items=items,
            element_to_type=element_to_type,
            type_ctx=type_ctx,
        )
        if len(types) != 1:
            return True
    else:
        match element_type:
            case DictType(value_type=vt):
                if vt is None or element_to_type(vt) is None:
                    return True
            case other if element_to_type(other) is None:
                return True
            case _:
                pass
    return any(
        _needs_variant_type(
            data=v,
            element_to_type=element_to_type,
            type_ctx=type_ctx,
            tuple_list_ids=tuple_list_ids,
            record_dict_ids=record_dict_ids,
        )
        for v in items
    )


@beartype
def _needs_variant_type(
    data: Value,
    element_to_type: Callable[[type | ListType | DictType], str | None],
    *,
    type_ctx: _CppTypeCtx,
    tuple_list_ids: frozenset[int],
    record_dict_ids: frozenset[int],
) -> bool:
    """Check whether *data* would produce ``std::variant`` or
    ``std::nullptr_t`` types in the generated C++ code.

    Used to determine whether ``#include <variant>`` is needed.
    """
    match data:
        case set():
            sorted_items: list[Value] = sorted(
                data,
                key=set_sort_key,
            )
            return _items_need_variant(
                items=sorted_items,
                element_to_type=element_to_type,
                type_ctx=type_ctx,
                tuple_list_ids=tuple_list_ids,
                record_dict_ids=record_dict_ids,
            )
        case list():
            if id(data) in tuple_list_ids:
                return False
            return _items_need_variant(
                items=data,
                element_to_type=element_to_type,
                type_ctx=type_ctx,
                tuple_list_ids=tuple_list_ids,
                record_dict_ids=record_dict_ids,
            )
        case dict():
            if id(data) in record_dict_ids:
                # A record gives every field its own declared type.  Do
                # not mistake its mixed fields for a map value variant,
                # but keep walking so a genuinely dynamic nested field
                # still requests the carrier it needs.
                return any(
                    _needs_variant_type(
                        data=value,
                        element_to_type=element_to_type,
                        type_ctx=type_ctx,
                        tuple_list_ids=tuple_list_ids,
                        record_dict_ids=record_dict_ids,
                    )
                    for value in data.values()
                )
            return _items_need_variant(
                items=list(data.values()),
                element_to_type=element_to_type,
                type_ctx=type_ctx,
                tuple_list_ids=tuple_list_ids,
                record_dict_ids=record_dict_ids,
            )
        case _:
            return False


@beartype
def _has_empty_collection(data: Value) -> bool:
    """Check whether *data* contains any empty list/dict/set/omap.

    Empty collections produce ``std::nullptr_t`` placeholders, which
    require ``#include <cstddef>``.
    """
    match data:
        case list() | set() | dict() if len(data) == 0:
            return True
        case list():
            return any(_has_empty_collection(data=v) for v in data)
        case dict():
            mapping_values = data.values()
            return any(_has_empty_collection(data=v) for v in mapping_values)
        case _:
            return False


@beartype
def _build_variant_preamble(
    *,
    type_ctx: _CppTypeCtx,
    tuple_list_ids: frozenset[int],
    record_dict_ids: frozenset[int],
) -> Callable[[Value], tuple[str, ...]]:
    """Build a data preamble for the active variant implementation."""
    element_to_type = type_ctx.element_to_type(int_type="long long")

    def _variant_preamble(data: Value, /) -> tuple[str, ...]:
        """Return headers required by variant/nullptr_t usage."""
        lines: list[str] = []
        if _has_empty_collection(data=data):
            lines.append("#include <cstddef>")
        if _needs_variant_type(
            data=data,
            element_to_type=element_to_type,
            type_ctx=type_ctx,
            tuple_list_ids=tuple_list_ids,
            record_dict_ids=record_dict_ids,
        ):
            if type_ctx.variant_type_name == "std::variant":
                lines.append("#include <variant>")
            else:
                name = type_ctx.variant_type_name
                lines.extend(
                    (
                        "#include <cstddef>",
                        "#include <memory>",
                        "#include <string>",
                        "#include <utility>",
                        f"struct {name} {{",
                        " private:",
                        "  struct Holder {",
                        "    Holder() = default;",
                        "    Holder(const Holder&) = delete;",
                        "    Holder(Holder&&) = delete;",
                        "    Holder& operator=(const Holder&) = delete;",
                        "    Holder& operator=(Holder&&) = delete;",
                        "    virtual ~Holder() = default;",
                        "  };",
                        (
                            "  template <typename T> struct "
                            "TypedHolder : Holder {"
                        ),
                        (
                            "    explicit TypedHolder(T value) "
                            ": value_(std::move(value)) {}"
                        ),
                        "    T& get() { return value_; }",
                        (
                            "    const T& get() const { return value_; }"
                            " // NOLINT(modernize-use-nodiscard)"
                        ),
                        "   private:",
                        "    T value_;",
                        "  }; // TypedHolder",
                        (
                            "  static std::shared_ptr<Holder> make_holder("
                            "const char* value) {"
                        ),
                        (
                            "    return std::make_shared<"
                            "TypedHolder<std::string>>"
                            "(value);"
                        ),
                        "  } // make_holder string",
                        (
                            "  template <typename T> static "
                            "std::shared_ptr<Holder> make_holder(T value) {"
                        ),
                        (
                            "    return std::make_shared<TypedHolder<T>>"
                            "(std::move(value));"
                        ),
                        "  } // make_holder generic",
                        "  std::shared_ptr<Holder> value_;",
                        " public:",
                        (
                            f"  {name}() : value_(new "
                            "TypedHolder<std::nullptr_t>(nullptr)) {}"
                        ),
                        (
                            f"  template <typename T> explicit {name}(T value)"
                            " : value_(make_holder(std::move(value))) {}"
                        ),
                        (
                            "  template <typename T> bool is() const"
                            " { // NOLINT(modernize-use-nodiscard)"
                        ),
                        (
                            "    return dynamic_cast<TypedHolder<T>*>"
                            "(value_.get()) != nullptr;"
                        ),
                        "  }",
                        "  template <typename T> T& get() {",
                        (
                            "    return static_cast<TypedHolder<T>*>"
                            "(value_.get())->get();"
                        ),
                        "  } // get",
                        "  template <typename T> const T& get() const {",
                        (
                            "    return static_cast<const TypedHolder<T>*>"
                            "(value_.get())->get();"
                        ),
                        "  } // get const",
                        "};",
                    )
                )
        return tuple(lines)

    return _variant_preamble


@beartype
def _build_tuple_preamble(
    *,
    type_ctx: _CppTypeCtx,
) -> Callable[[Value], tuple[str, ...]]:
    """Build the ``TUPLE``-strategy ``data_dependent_preamble``.

    Composes the variant preamble and additionally emits
    ``#include <tuple>`` whenever the data carries any tuple-eligible
    heterogeneous scalar array.  The ``<tuple>`` line is emitted off
    :func:`_cpp_tuple_list_ids` alone, so it fires even when the
    data has no record-shaped dicts at all (e.g. a bare top-level
    heterogeneous array).  The ``TUPLE`` preamble is built with no
    record dict ids, so this is the only source of the tuple header on
    this path.
    """

    def _tuple_preamble(data: Value, /) -> tuple[str, ...]:
        """Return the variant headers plus ``<tuple>`` when needed."""
        tuple_list_ids = _cpp_tuple_list_ids(data=data)
        # C++14 tuple output uses the separate record-preamble builder.
        # This path infers native std::variant headers for nested values.
        variant_preamble = _build_variant_preamble(
            type_ctx=type_ctx,
            tuple_list_ids=frozenset(),
            record_dict_ids=frozenset(),
        )
        lines = list(variant_preamble(data))
        if len(tuple_list_ids) > 0:
            lines.append("#include <tuple>")
        return tuple(lines)

    return _tuple_preamble


@beartype
def _render_cpp_tuple(
    value: list[Value],
    elements: Sequence[str],
) -> RenderedTupleLiteral:
    """Render a heterogeneous scalar array as ``std::make_tuple(...)``.

    :func:`_cpp_tuple_list_ids` only marks arrays spanning at least two
    scalar buckets, so the call always has at least two arguments.  The
    shared layout assembler joins *elements* into the compact
    ``std::make_tuple(a, b)`` or one-per-line multiline form; *value* is
    unused because every element arrives already formatted.
    """
    del value
    return RenderedTupleLiteral(
        head="std::make_tuple(",
        entries=tuple(elements),
        closer=")",
        compact_pad="",
        # ``std::make_tuple(a, b,)`` is a syntax error (function call,
        # not a braced initializer), so suppress the trailing comma the
        # language-wide config would otherwise add in multiline form.
        multiline_trailing_comma=False,
    )


_CPP_RECORD_AS_MAP_VALUE_MSG = (
    "Cpp cannot represent a record as the value of a mapping that is "
    "not itself a record under the RECORD heterogeneous strategy: the "
    "mapping's value type is inferred from the dict the record was "
    "written from, so it would name a map where the literal writes a "
    "struct"
)


@beartype
def _check_cpp_record_naming(*, node: Value) -> None:
    """Raise if a record is the direct value of a non-record mapping.

    An enclosing mapping types its values itself: an ordered map of
    lists of records writes ``std::vector<RecordN>`` and composes those
    into a variant where the lists differ.  A record dict sitting
    directly in that slot has no such type -- the opener infers the map
    the dict was written from -- so the declaration would name a map
    where the literal writes ``RecordN{...}`` (issue #4754).
    """
    match node:
        case dict():
            enclosing_is_record = record_shape_for_dict(
                value=node
            ) is not None and not isinstance(node, OrderedMap)
            for value in node.values():
                if (
                    not enclosing_is_record
                    and isinstance(value, dict)
                    and not isinstance(value, OrderedMap)
                    and record_shape_for_dict(value=value) is not None
                ):
                    raise UnrepresentableInputError(
                        _CPP_RECORD_AS_MAP_VALUE_MSG
                    )
                _check_cpp_record_naming(node=value)
        case list() | set():
            for item in node:
                _check_cpp_record_naming(node=item)
        case _:
            return


_MIN_CPP_TUPLE_ARITY = 2


@beartype
def _is_cpp_tuple_eligible(*, value: list[Value]) -> bool:
    """Return whether a list can use C++'s positional tuple form.

    Call arguments can contain ``{"$ref": name}`` placeholders.  They are
    later emitted as bare identifiers, which are valid ``std::make_tuple``
    arguments but are not scalars while the tuple ids are being collected.
    Treat those placeholders as positional tuple elements so validation and
    formatting agree.  A list containing a reference still needs another
    element: a one-element list remains an ordinary sequence.
    """
    if is_tuple_eligible(value=value):
        return True
    if len(value) < _MIN_CPP_TUPLE_ARITY:
        return False
    has_reference = False
    for item in value:
        if scalar_type_bucket(value=item) is not None:
            continue
        if (
            isinstance(item, dict)
            and len(item) == 1
            and isinstance(
                item.get("$ref"),
                str,
            )
        ):
            has_reference = True
            continue
        return False
    return has_reference


@beartype
def _cpp_tuple_list_ids(data: Value) -> frozenset[int]:
    """Return C++ tuple-eligible lists at every nesting level.

    Unlike the shared tuple strategy, C++ can use a nested tuple as a
    homogeneous outer sequence's element type.  Traverse every container
    so ``[[1, "x"]]`` becomes ``std::vector<std::tuple<int, std::string>>``
    rather than a vector of variant vectors.
    """
    ids: set[int] = set()

    def _collect(value: Value) -> None:
        """Collect tuple-eligible lists reachable from *value*."""
        match value:
            case list():
                if _is_cpp_tuple_eligible(value=value):
                    ids.add(id(value))
                for item in value:
                    _collect(value=item)
            case dict():
                for item in value.values():
                    _collect(value=item)
            case _:
                return

    _collect(value=data)
    return frozenset(ids)


@beartype
def _cpp14_widened_sibling_map_ids(
    *,
    children: list[Value],
    type_ctx: _CppTypeCtx,
    excluded_ids: frozenset[int],
) -> frozenset[int]:
    """Return sibling maps widened to a carrier-typed value.

    Sibling maps whose values do not share one type are all written
    with the carrier as their value type, so each of their values needs
    the explicit construction the carrier asks for.  Siblings appear
    under a list and equally under a mapping (issue #4569).
    """
    siblings = [
        child
        for child in children
        if isinstance(child, dict)
        and not isinstance(child, OrderedMap)
        and id(child) not in excluded_ids
    ]
    sibling_values = [
        child_value for sibling in siblings for child_value in sibling.values()
    ]
    if len(siblings) > 1 and (
        _compute_element_type_for_items(
            items=sibling_values,
            type_ctx=type_ctx,
        )
        == type_ctx.variant_type_name
    ):
        return frozenset(id(sibling) for sibling in siblings)
    return frozenset[int]()


@beartype
def _cpp14_variant_parent_ids(
    *,
    data: Value,
    type_ctx: _CppTypeCtx,
    excluded_ids: frozenset[int],
) -> frozenset[int]:
    """Return containers whose children initialize the fallback variant.

    C++14's generated carrier has an explicit converting constructor, so
    children of a ``Value``-typed collection must render as ``Value{...}``.
    Record and tuple literals have their own field/element types and are
    excluded even when generic collection inference would otherwise see
    them as heterogeneous.
    """
    ids: set[int] = set()

    def _collect(value: Value) -> None:
        """Collect carrier-typed parents recursively."""
        children: list[Value] = []
        type_children: list[Value]
        match value:
            case OrderedMap():
                children.extend(value.values())
                type_children = children
                ids.update(
                    _cpp14_widened_sibling_map_ids(
                        children=children,
                        type_ctx=type_ctx,
                        excluded_ids=excluded_ids,
                    )
                )
            case dict():
                children.extend(value.values())
                type_children = [
                    child
                    for child in children
                    if not (
                        isinstance(child, dict)
                        and len(child) == 1
                        and isinstance(child.get("$ref"), str)
                    )
                ]
                ids.update(
                    _cpp14_widened_sibling_map_ids(
                        children=children,
                        type_ctx=type_ctx,
                        excluded_ids=excluded_ids,
                    )
                )
            case list():
                children.extend(value)
                type_children = children
                ids.update(
                    _cpp14_widened_sibling_map_ids(
                        children=children,
                        type_ctx=type_ctx,
                        excluded_ids=excluded_ids,
                    )
                )
            case set():
                children.extend(
                    sorted(
                        value,
                        key=set_sort_key,
                    )
                )
                type_children = children
            case _:
                return
        if (
            id(value) not in excluded_ids
            and len(type_children) > 0
            and (
                _compute_element_type_for_items(
                    items=type_children, type_ctx=type_ctx
                )
                == type_ctx.variant_type_name
            )
        ):
            ids.add(id(value))
        for child in children:
            _collect(value=child)

    _collect(value=data)
    return frozenset(ids)


@beartype
def _cpp14_explicit_variant_behavior(
    *,
    base: HeterogeneousBehavior,
    type_ctx: _CppTypeCtx,
) -> HeterogeneousBehavior:
    """Add explicit fallback-variant construction to *base* behavior."""

    def _compute_wrap_ids(data: Value, /) -> frozenset[int]:
        """Combine strategy-specific and fallback-variant parent ids."""
        compute_record_shapes = base.compute_record_shapes
        if compute_record_shapes is None:
            record_ids = frozenset[int]()
        else:
            record_ids = frozenset(compute_record_shapes(data))
        compute_tuple_list_ids = base.compute_tuple_list_ids
        if compute_tuple_list_ids is None:
            tuple_ids = frozenset[int]()
        else:
            tuple_ids = compute_tuple_list_ids(data)
        return base.compute_wrap_ids(data) | _cpp14_variant_parent_ids(
            data=data,
            type_ctx=type_ctx,
            excluded_ids=record_ids | tuple_ids,
        )

    def _wrap(_raw_value: Value, formatted: str) -> str:
        """Direct-list-initialize the fallback carrier."""
        return f"{type_ctx.variant_type_name}{{{formatted}}}"

    def _compute_call_slot_wrap_ids(
        values: Sequence[Value],
        /,
    ) -> frozenset[int]:
        """Wrap divergent scalar call arguments passed as the carrier."""
        base_ids = base.compute_call_slot_wrap_ids(values)
        if (
            len(values) > 0
            and _compute_element_type_for_items(
                items=list(values), type_ctx=type_ctx
            )
            == type_ctx.variant_type_name
        ):
            return base_ids | frozenset(
                id(value)
                for value in values
                if isinstance(
                    value,
                    (
                        bool,
                        int,
                        float,
                        str,
                        bytes,
                        datetime.date,
                        datetime.time,
                    ),
                )
                or value is None
            )
        return base_ids

    return dataclasses.replace(
        base,
        compute_wrap_ids=_compute_wrap_ids,
        wrap_scalar=_wrap,
        wrap_non_scalar=_wrap,
        compute_call_slot_wrap_ids=_compute_call_slot_wrap_ids,
    )


_CPP_TUPLE_BEHAVIOR = HeterogeneousBehavior(
    skip_scalar_checks=False,
    compute_wrap_ids=no_compute_wrap_ids,
    wrap_scalar=None,
    wrap_non_scalar=None,
    wrap_empty_container=None,
    empty_container_literal_overrides=no_empty_container_literal_overrides,
    compute_call_slot_wrap_ids=no_compute_call_slot_wrap_ids,
    dict_open_for_wrap_ids=None,
    widens_nested_maps_by_wrapping_scalars=False,
    widens_unrecordizable_nested_sibling_maps=False,
    render_record_literal=None,
    compute_record_shapes=None,
    render_tuple_literal=_render_cpp_tuple,
    compute_tuple_list_ids=_cpp_tuple_list_ids,
    alias_record_ids=None,
)
"""``TUPLE`` strategy behavior: render fixed-length heterogeneous
scalar arrays as ``std::make_tuple`` literals.

C++ already represents the carved-out scalar checks via
``std::variant`` (``skip_scalar_checks`` is irrelevant -- the
sequence/dict formats report ``supports_heterogeneity``), so this only
adds the tuple render hook and the list-id collector.  The ``RECORD``
strategy is wired separately on the language (its behavior needs the
per-instance type context), so the ``TUPLE`` behavior does not compose
a record behavior here.
"""


# The ``RECORD`` strategy generates a plain aggregate ``struct`` per
# distinct record shape.  clang-tidy's
# ``cppcoreguidelines-pro-type-member-init`` requires every scalar
# member to carry an in-class initializer, while
# ``readability-redundant-member-init`` rejects one on a class-type
# member (its default constructor already value-initializes it).  So a
# field type that is a fundamental scalar gets a ``{}`` brace-or-equal
# initializer and a class type (``std::string``, ``std::vector<...>``,
# ``std::chrono::...``, a nested ``RecordN``) gets none.  These are
# exactly the scalar type names :func:`_make_cpp_element_to_type`
# emits, plus ``std::nullptr_t`` (a fundamental type, so it also needs
# the initializer and the redundant-init check does not apply).
_CPP_SCALAR_FIELD_TYPES: frozenset[str] = frozenset(
    {
        "bool",
        "double",
        "int",
        "long",
        "long long",
        "unsigned long long",
        "std::nullptr_t",
    },
)

_CPP_RECORD_MAP_VALUE = "LiteralizerRecordValue"
_CPP_RECORD_MAP_TYPE = f"std::map<std::string, {_CPP_RECORD_MAP_VALUE}>"


@beartype
@dataclasses.dataclass
class _CppWidenedMapNarrowing:
    """Per-pass cache of the widened fallback maps' narrow value type.

    ``value_type`` holds the single concrete C++ type shared by every
    scalar inside the maps the ``RECORD`` strategy widened out of the
    record-shape mapping, or ``None`` when those scalars mix C++ types
    and the ``LiteralizerRecordValue`` alias carrier is required (issue
    #3605).  Refreshed by the strategy's ``compute_wrap_ids`` hook,
    which the shared data checks run before any rendering; the alias
    preamble, the widened-map opener, and the record field-type hook
    all read the cached decision within the same pass.
    """

    value_type: str | None


@beartype
def _cpp_narrow_widened_map_value_type(
    *,
    data: Value,
    wrap_ids: frozenset[int],
    type_ctx: _CppTypeCtx,
    map_value_typing: RecordMapValueTypings,
) -> str | None:
    """Return the single C++ type every widened-map scalar shares.

    Returns ``None`` when the widened maps genuinely mix scalar types
    (the ``LiteralizerRecordValue`` alias carrier is then required),
    when there is nothing to widen, when *map_value_typing* asks for
    the alias carrier whatever the data holds, or under C++14, whose
    explicit fallback carrier replaces the record strategy's scalar
    wrapper with one that also serves heterogeneous containers and call
    slots and so cannot selectively leave the widened maps' scalars
    bare.
    """
    if map_value_typing is RecordMapValueTypings.WIDE:
        return None
    if type_ctx.variant_type_name != "std::variant":
        return None
    scalars = iter_wrapped_scalars(data=data, wrap_ids=wrap_ids)
    if len(scalars) == 0:
        return None
    value_type = _compute_element_type_for_items(
        items=list(scalars),
        type_ctx=type_ctx,
        in_mapping_value=True,
    )
    if value_type.startswith("std::variant<"):
        return None
    return value_type


@beartype
def _cpp_record_field_identifier(
    key: str, /, *, reserved_identifiers: frozenset[str]
) -> str:
    """Return the C++ ``struct`` member name for a dict *key*.

    C++ member identifiers are the dict keys verbatim (no case
    conversion), matching the designated-initializer literal form
    ``Record0{.id = 1, ...}``.
    """
    if key in reserved_identifiers:
        msg = f"C++ record field name {key!r} is reserved"
        raise UnrepresentableInputError(msg)
    return key


@beartype
def _cpp_record_literal(
    name: str,
    fields: Sequence[RecordLiteralField],
    /,
) -> RenderedRecordLiteral:
    """Render a C++ designated-initializer ``Name{.field = value, ...}``
    literal as structured pieces for the shared compact/multiline
    layout code.

    C++20 designated initializers must appear in declaration order; the
    shared strategy iterates the shape's keys in document order for both
    the declaration and the literal, so the orders always agree.  A
    trailing comma after the last initializer is valid in a
    brace-enclosed initializer list (unlike the ``std::make_tuple``
    call the ``TUPLE`` strategy renders), so the language-wide
    trailing-comma config applies unchanged.
    """
    return RenderedRecordLiteral(
        head=f"{name}{{",
        entries=tuple(
            f".{field.identifier} = {_cpp_record_member_value(field)}"
            for field in fields
        ),
        closer="}",
        compact_pad="",
    )


@beartype
def _cpp_record_literal_positional(
    name: str,
    fields: Sequence[RecordLiteralField],
    /,
) -> RenderedRecordLiteral:
    """Render a pre-C++20 positional aggregate initializer.

    C++14 and C++17 do not support designated initializers.  The shared
    record strategy preserves document order for both declarations and
    literals, so positional aggregate initialization remains well-formed.
    """
    return RenderedRecordLiteral(
        head=f"{name}{{",
        entries=tuple(_cpp_record_member_value(field) for field in fields),
        closer="}",
        compact_pad="",
    )


@beartype
def _cpp_record_member_value(field: RecordLiteralField, /) -> str:
    """Elide a record member's redundant aggregate type prefix.

    The containing aggregate fixes the member's target type, so an
    initializer beginning with that exact declared type and ``{`` can use
    C++'s nested braced-initializer form directly.
    """
    prefix = f"{field.type_name}{{"
    if field.formatted.startswith(prefix):
        return field.formatted.removeprefix(field.type_name)
    return field.formatted


@beartype
def _cpp_render_record_declaration(
    name: str,
    fields: Sequence[RecordDeclarationField],
    /,
) -> str:
    """Render a C++ aggregate ``struct Name { Type field{}; ... };``.

    A scalar field carries a ``{}`` in-class initializer so the
    aggregate satisfies clang-tidy's member-init check; a class-type
    field omits it (its default constructor already value-initializes
    it, which the redundant-init check would otherwise flag).
    """
    collected_members: list[str] = []
    for entry_field in fields:
        effective_value = ""
        if entry_field.type_name in _CPP_SCALAR_FIELD_TYPES:
            effective_value = "{}"
        collected_members.append(
            f"{entry_field.type_name} {entry_field.identifier}"
            f"{effective_value};"
        )
    members = " ".join(collected_members)
    return f"struct {name} {{ {members} }};"


@beartype
def _cpp_int_field_type(
    *,
    value: int,
    int_resolver: _IntTypeResolver,
) -> str:
    """Return the C++ field type for an integer record field.

    Mirrors the literal :attr:`Cpp.format_integer` emits: an integer
    inside signed 64-bit range follows the value-driven *int_resolver*
    (``int``/``long long``, or the suffix-forced ``long``), while a
    positive value beyond it is written with a ``ULL`` suffix by the
    overflow fallback and is therefore ``unsigned long long`` (a
    negative out-of-range value raises at format time, so that side is
    never reached).
    """
    if not I64_MIN <= value <= I64_MAX:
        return "unsigned long long"
    return int_resolver([value])


@beartype
def _all_record_shaped(
    items: list[Value],
    /,
) -> TypeGuard[list[dict[str, Value]]]:
    """Return whether *items* is a non-empty list whose every element
    is a record-shaped dict (non-empty, all-string-keyed, not an
    ordered map).

    Under the ``RECORD`` strategy such a list renders each element as a
    generated ``RecordN`` literal, so the C++ sequence opener widens to
    a ``std::vector`` whose element type is deduced from those literals
    (class-template argument deduction) rather than the homogeneous-map
    type the variant opener would otherwise emit.

    Uniformity of shape need not be checked here: a sibling list whose
    record-shaped dicts do not all share one shape is rejected for
    every ``RECORD`` language by the shared
    :func:`literalizer._checks.check_data` guard
    (:class:`~literalizer.exceptions.HeterogeneousSiblingListsError`)
    before any value is formatted, so a list reaching this predicate is
    always single-shape and the deduced ``std::vector<RecordN>`` is
    well-formed.
    """
    if len(items) == 0:
        return False
    return all(
        isinstance(item, dict)
        and not isinstance(item, OrderedMap)
        and record_shape_for_dict(value=item) is not None
        for item in items
    )


@beartype
def _cpp14_record_list_open(
    *,
    items: list[dict[str, Value]],
    record_shape_names: Mapping[frozenset[str], str],
    record_rendering_active: bool,
    record_name_for_value: Callable[[ValueInput], str | None],
) -> str | None:
    """Return an explicit C++14 vector opener for record literals."""
    first_item = items[0]
    keys = frozenset(first_item.keys())
    if all(frozenset(item.keys()) == keys for item in items):
        name = record_shape_names.get(keys)
        if name is not None:
            return f"std::vector<{name}>{{"
    if record_rendering_active:
        name = record_name_for_value(first_item)
        return f"std::vector<{name}>{{"
    return None


@beartype
def _cpp14_nested_record_list_open(*, depth: int, name: str) -> str:
    """Return the explicit C++14 vector opener for nested records."""
    element_type = name
    for _ in range(depth):
        element_type = f"std::vector<{element_type}>"
    return f"{element_type}{{"


@beartype
def _is_external_record_graph(
    *,
    data: Value,
    record_shape_names: Mapping[frozenset[str], str],
) -> bool:
    """Return whether *data* contains only caller-declared records.

    Such a graph does not need C++14's private variant carrier: each
    record field is supplied by the surrounding domain type.  Scalar values
    and homogeneous containers are harmless leaves; every dict must be a
    mapped record shape.
    """
    match data:
        case dict():
            shape = record_shape_for_dict(value=data)
            return (
                shape is not None
                and frozenset(shape.keys) in record_shape_names
                and all(
                    _is_external_record_graph(
                        data=value,
                        record_shape_names=record_shape_names,
                    )
                    for value in data.values()
                )
            )
        case list():
            return all(
                _is_external_record_graph(
                    data=value,
                    record_shape_names=record_shape_names,
                )
                for value in data
            )
        case _:
            return True


@beartype
def _contains_external_record(
    *,
    data: Value,
    record_shape_names: Mapping[frozenset[str], str],
) -> bool:
    """Return whether *data* contains a record mapped to external code."""
    match data:
        case dict():
            shape = record_shape_for_dict(value=data)
            return (
                shape is not None
                and frozenset(shape.keys) in record_shape_names
            ) or any(
                _contains_external_record(
                    data=value,
                    record_shape_names=record_shape_names,
                )
                for value in data.values()
            )
        case list():
            return any(
                _contains_external_record(
                    data=value,
                    record_shape_names=record_shape_names,
                )
                for value in data
            )
        case _:
            return False


@beartype
def _build_cpp_record_preamble(
    *,
    type_ctx: _CppTypeCtx,
    record_preamble: Callable[[Value], tuple[str, ...]],
    compute_wrap_ids: Callable[[Value], frozenset[int]],
    compute_carrier_ids: Callable[[Value], frozenset[int]],
    include_tuple_header: bool,
    record_shape_names: Mapping[frozenset[str], str],
    native_only: bool,
    map_value_typing: RecordMapValueTypings,
) -> Callable[[Value], tuple[str, ...]]:
    """Build the ``RECORD``-strategy ``data_dependent_preamble``.

    *compute_wrap_ids* names the maps whose values are widened, which
    the value alias is written for; *compute_carrier_ids* names every
    container the active behavior writes through the carrier, which a
    tuple-rendered list is not (issue #4568).

    Composes the ``std::variant`` / ``std::nullptr_t`` header lines (a
    record field may still be a heterogeneous list or an empty
    collection) followed by the generated ``struct`` declarations.  The
    headers precede the declarations so a declared field may name
    ``std::nullptr_t`` or ``std::variant``; the scalar/sequence headers
    (``<string>``, ``<vector>``, ``<chrono>``) are emitted earlier
    still, by the type-driven preamble the core assembles before this
    one.
    """

    def _record_pre(data: Value, /) -> tuple[str, ...]:
        """Return the ``std::variant`` / ``std::nullptr_t`` headers plus
        the ``struct`` declarations.
        """
        wrap_ids = compute_wrap_ids(data)
        carrier_ids = compute_carrier_ids(data)
        # Do not re-run the record strategy's shape computation here: its
        # render-time cache already holds the field requests that the
        # declaration preamble consumes.  The raw shape walk is enough to
        # distinguish individual struct fields from map values.
        if type_ctx.variant_type_name == "std::variant":
            record_dict_ids = frozenset[int]()
        else:
            record_dict_ids = frozenset(collect_record_shapes(data=data))
        # A list the active behavior wraps in the carrier is rendered
        # as a carrier-typed vector rather than a tuple, so it still
        # asks for the carrier declaration (issue #4568).
        tuple_list_ids = _cpp_tuple_list_ids(data=data) - carrier_ids
        effective_tuple_list_ids_2 = tuple_list_ids
        if type_ctx.variant_type_name == "std::variant":
            effective_tuple_list_ids_2 = frozenset[int]()
        variant_preamble = _build_variant_preamble(
            type_ctx=type_ctx,
            tuple_list_ids=(effective_tuple_list_ids_2),
            record_dict_ids=record_dict_ids,
        )
        value_alias: tuple[str, ...] = ()
        if native_only or (
            _contains_external_record(
                data=data,
                record_shape_names=record_shape_names,
            )
            and _is_external_record_graph(
                data=data,
                record_shape_names=record_shape_names,
            )
        ):
            headers = list[str]()
        else:
            headers = list(variant_preamble(data))
        if include_tuple_header and bool(tuple_list_ids):
            headers.append("#include <tuple>")
        if (
            len(wrap_ids) > 0
            and _cpp_narrow_widened_map_value_type(
                data=data,
                wrap_ids=wrap_ids,
                type_ctx=type_ctx,
                map_value_typing=map_value_typing,
            )
            is None
        ):
            # C++14's explicit fallback carrier wraps every widened
            # scalar in the carrier type, so the alias must name the
            # carrier even when the widened scalars share one concrete
            # C++ type.
            if type_ctx.variant_type_name != "std::variant":
                value_type = type_ctx.variant_type_name
            else:
                value_type = _compute_element_type_for_items(
                    items=list(
                        iter_wrapped_scalars(data=data, wrap_ids=wrap_ids),
                    ),
                    type_ctx=type_ctx,
                    in_mapping_value=True,
                )
            value_alias = (f"using {_CPP_RECORD_MAP_VALUE} = {value_type};",)
        return (*headers, *value_alias, *record_preamble(data))

    return _record_pre


@beartype
def _apply_cpp_variant_sequence_open(
    *,
    items: list[Value],
    type_ctx: _CppTypeCtx,
) -> str:
    """Return a typed ``std::vector`` opener."""
    inner = _compute_element_type_for_items(
        items=items,
        type_ctx=type_ctx,
        in_mapping_value=False,
    )
    return f"std::vector<{inner}>{{"


@beartype
def _apply_cpp_variant_dict_open(
    *,
    items: dict[Scalar, Value],
    type_ctx: _CppTypeCtx,
    opener_template: str,
) -> str:
    """Return a typed ``std::map`` or ``std::unordered_map`` opener."""
    value_type = _compute_element_type_for_items(
        items=list(items.values()),
        type_ctx=type_ctx,
        in_mapping_value=True,
    )
    map_kind = "std::map"
    if "unordered" in opener_template:
        map_kind = "std::unordered_map"
    return f"{map_kind}<std::string, {value_type}>{{"


@beartype
def _apply_cpp_variant_set_open(
    *,
    items: list[Value],
    type_ctx: _CppTypeCtx,
) -> str:
    """Return a typed, owning ``std::vector`` opener."""
    inner = _compute_element_type_for_items(
        items=items,
        type_ctx=type_ctx,
        in_mapping_value=False,
    )
    return f"std::vector<{inner}>{{"


@beartype
def _apply_cpp_variant_ordered_map_open(
    *,
    data: dict[Scalar, Value],
    type_ctx: _CppTypeCtx,
) -> str:
    """Return a typed ordered-map opener."""
    values: list[Value] = list(data.values())
    value_type = _compute_element_type_for_items(
        items=values,
        type_ctx=type_ctx,
        in_mapping_value=True,
    )
    return f"std::vector<std::pair<std::string, {value_type}>>{{"


@beartype
def _build_variant_sequence_open(
    *,
    type_ctx: _CppTypeCtx,
) -> Callable[[list[Value]], str]:
    """Build a sequence opener that uses ``std::variant`` for
    heterogeneous lists.
    """

    def _open(items: list[Value]) -> str:
        """Delegate to module-level implementation."""
        return _apply_cpp_variant_sequence_open(items=items, type_ctx=type_ctx)

    return _open


@beartype
def _build_variant_dict_open(
    *,
    type_ctx: _CppTypeCtx,
    opener_template: str,
) -> Callable[[dict[Scalar, Value]], str]:
    """Build a dict opener that uses ``std::variant`` for
    heterogeneous dict values.
    """

    def _open(items: dict[Scalar, Value]) -> str:
        """Delegate to module-level implementation."""
        return _apply_cpp_variant_dict_open(
            items=items,
            type_ctx=type_ctx,
            opener_template=opener_template,
        )

    return _open


@beartype
def _build_variant_set_open(
    *,
    type_ctx: _CppTypeCtx,
) -> Callable[[list[Value]], str]:
    """Build a set opener that uses a typed, owning ``std::vector``."""

    def _open(items: list[Value]) -> str:
        """Delegate to module-level implementation."""
        return _apply_cpp_variant_set_open(items=items, type_ctx=type_ctx)

    return _open


@beartype
def _build_variant_ordered_map_open(
    *,
    type_ctx: _CppTypeCtx,
) -> Callable[[dict[Scalar, Value]], str]:
    """Build an ordered-map opener that uses
    ``std::vector<std::pair<...>>``.
    """

    def _open(data: dict[Scalar, Value]) -> str:
        """Delegate to module-level implementation."""
        return _apply_cpp_variant_ordered_map_open(
            data=data,
            type_ctx=type_ctx,
        )

    return _open


@beartype
def _build_ordered_map_config(
    *,
    type_ctx: _CppTypeCtx,
) -> OrderedMapFormatConfig:
    """Build an ``OrderedMapFormatConfig`` with a variant opener."""
    return OrderedMapFormatConfig(
        ordered_map_open=_build_variant_ordered_map_open(type_ctx=type_ctx),
        close="}",
        preamble_lines=(
            "#include <utility>",
            "#include <vector>",
        ),
    )


@beartype
def _cpp_modifier_prefix(modifiers: frozenset[enum.Enum]) -> str:
    """Return the ``static const `` prefix for a C++ declaration,
    including a trailing space when non-empty.

    Values that are not :class:`_CppModifiers` members are ignored.
    """
    keywords = [m.value for m in _CppModifiers if m in modifiers]
    if len(keywords) == 0:
        return ""
    return " ".join(keywords) + " "


@beartype
@dataclasses.dataclass(frozen=True)
class _CppDeclarationStyleConfig:
    """Configuration for a Cpp declaration style.

    Unlike :class:`DeclarationStyleConfig`, this carries no
    ``formatter`` slot: Cpp builds its declaration formatter
    per-instance in :attr:`Cpp.format_variable_declaration` so it can
    close over the chosen date/datetime ``type_produced``.
    """

    supports_redefinition: bool


@beartype
def _format_variable_declaration(
    *,
    name: str,
    value: str,
    data: Value,
    modifiers: frozenset[enum.Enum],
    date_type: type,
    datetime_type: type,
) -> str:
    """Format a C++ variable declaration.

    * ``const auto*`` — string literal (``"..."``), required by
      ``readability-qualified-auto``.  Driven by the parsed *data*
      together with the chosen date/datetime ``type_produced``: bytes
      and strings without NULs render as quoted strings, and dates/datetimes
      do so when their format produces a :class:`str`.
    * ``auto`` — typed expression (e.g. ``std::vector<int>{...}``).

    When *modifiers* is non-empty, applicable modifier keywords
    (``static``, ``const``) are prepended.  ``const`` is not duplicated
    against the built-in ``const auto*`` for string literals.
    """
    if _renders_as_string_literal(
        data=data,
        date_type=date_type,
        datetime_type=datetime_type,
    ):
        type_keyword = "const auto*"
        extra = modifiers - {_CppModifiers.CONST}
    else:
        type_keyword = "auto"
        extra = modifiers
    prefix = _cpp_modifier_prefix(modifiers=extra)
    return f"{prefix}{type_keyword} {name} = {value};"


@beartype
def _renders_as_string_literal(
    *,
    data: Value,
    date_type: type,
    datetime_type: type,
) -> bool:
    """Return whether *data* renders as a C string literal.

    ``bytes`` and ``str`` always render as quoted strings in C++.
    ``datetime.datetime`` and ``datetime.date`` do so only when their
    format's ``type_produced`` is :class:`str` (the ISO variants);
    other variants render as ``std::chrono`` or numeric expressions.
    """
    match data:
        case str() if "\0" in data:
            return False
        case bytes() | str():
            return True
        case datetime.datetime():
            return datetime_type is str
        case datetime.date():
            return date_type is str
        case _:
            return False


@beartype
def _cpp_call_stub(
    parts: Sequence[str],
    _params: Sequence[str],
    stub_return: StubReturn,
    _args: Sequence[Value],
    /,
    *,
    supports_abbreviated_templates: bool,
    supports_nodiscard: bool,
) -> tuple[str, ...]:
    """Return C++ stub declarations for a call name."""
    if supports_abbreviated_templates:
        parameter_pack = "auto..."
        template_prefix = ""
    else:
        parameter_pack = "Args..."
        template_prefix = "template <typename... Args> "
    nodiscard_prefix = ""
    if supports_nodiscard:
        nodiscard_prefix = "[[nodiscard]] "
    if len(parts) == 1:
        return (
            (
                f"{template_prefix}auto {parts[0]}({parameter_pack}) "
                "{ return 0; }"
            ),
        )
    root = parts[0]
    method = parts[-1]
    fields = parts[1:-1]
    if len(fields) == 0:
        type_name = f"{root}Type_"
        if stub_return is StubReturn.VOID:
            method_decl = (
                f"{template_prefix}void {method}({parameter_pack}) const {{}}"
            )
        else:
            method_decl = (
                f"{template_prefix}{nodiscard_prefix}auto {method}"
                f"({parameter_pack}) const {{ return 0; }}"
            )
        return (
            f"struct {type_name} {{ {method_decl} }};",
            f"const {type_name} {root};",
        )
    lines: list[str] = []
    inner_type = f"{fields[-1]}Type_"
    if stub_return is StubReturn.VALUE:
        lines.append(
            f"struct {inner_type} {{"
            f" {template_prefix}{nodiscard_prefix}auto {method}"
            f"({parameter_pack}) const"
            f" {{ return 0; }} }};"
        )
    else:
        lines.append(
            f"struct {inner_type} {{ {template_prefix}void {method}"
            f"({parameter_pack}) const {{}} }};"
        )
    prev_type = inner_type
    for i in range(len(fields) - 2, -1, -1):
        curr_type = f"{fields[i]}Type_"
        lines.append(f"struct {curr_type} {{ {prev_type} {fields[i + 1]}; }};")
        prev_type = curr_type
    root_type = f"{root}Type_"
    lines.append(f"struct {root_type} {{ {prev_type} {fields[0]}; }};")
    lines.append(f"const {root_type} {root};")
    return tuple(lines)


_NLOHMANN_JSON_STATIC_PREAMBLE: tuple[str, ...] = (
    "#include <nlohmann/json.hpp>",
)

_NLOHMANN_JSON_SEQUENCE_CONFIG = SequenceFormatConfig(
    sequence_open=fixed_open(open_str="nlohmann::json::array({"),
    close="})",
    supports_heterogeneity=True,
    single_element_trailing_comma=False,
    single_element_template=None,
    supports_trailing_comma=True,
    empty_sequence="nlohmann::json::array({})",
    preamble_lines=(),
    format_entry=passthrough_sequence_entry,
    typed_opener_fallback=None,
    uses_typed_literal_for_scalars=False,
    requires_uniform_record_shapes=False,
    declared_type=None,
    narrowed_empty_form=None,
)


_NLOHMANN_JSON_SET_CONFIG = SetFormatConfig(
    set_open=sequence_surrogate_set_open(
        fixed_open(open_str="nlohmann::json::array({")
    ),
    close="})",
    empty_set="nlohmann::json::array({})",
    preamble_lines=(),
    set_opener_template="",
    supports_heterogeneity=True,
    supports_trailing_comma=True,
)


_NLOHMANN_JSON_DICT_CONFIG = DictFormatConfig(
    dict_open=fixed_open(open_str="nlohmann::json::object({"),
    close="})",
    format_entry=braced_dict_entry(format_value=passthrough_sequence_entry),
    empty_dict="nlohmann::json::object({})",
    preamble_lines=(),
    narrowed_open=None,
    supports_trailing_comma=True,
    narrowed_empty_form=None,
)


_NLOHMANN_JSON_ORDERED_MAP_CONFIG = OrderedMapFormatConfig(
    ordered_map_open=fixed_open(open_str="nlohmann::json::object({"),
    close="})",
    preamble_lines=(),
)


@beartype
def _cpp_nlohmann_json_value_expression(
    raw_value: Value, value: str, /
) -> str:
    """Wrap a scalar *value* in ``nlohmann::json(...)``.

    The explicit ``array`` and ``object`` factories in the collection
    configurations preserve empty-container intent and avoid the
    library's brace-initializer ambiguity for nested arrays; scalars
    need the wrapping constructor so a bare declaration still deduces
    to ``nlohmann::json``.
    """
    if isinstance(raw_value, (dict, list, set)):
        return value
    return f"nlohmann::json({value})"


@beartype
def _format_cpp_json_call_arg(raw_value: Value, formatted: str) -> str:
    """Format a direct call argument as structural ``nlohmann::json``."""
    return _cpp_nlohmann_json_value_expression(raw_value, formatted)


# C++ raw-string delimiter wrapping the inline JSON document under
# ``json_rendering=INLINE_DOCUMENT``.  The lexer terminates the raw
# string at the first byte sequence ``)json"``; JSON string encoding
# always escapes ``"`` inside string literals as ``\"``, so the
# rendered document can only contain the terminator through a string
# value that ends with ``)json``.  ``validate_spec_for_data`` rejects
# such inputs before rendering.
_NLOHMANN_JSON_PARSE_DELIMITER = "json"
_NLOHMANN_JSON_PARSE_TERMINATOR = f'){_NLOHMANN_JSON_PARSE_DELIMITER}"'


_NLOHMANN_INLINE_SEQUENCE_CONFIG = SequenceFormatConfig(
    sequence_open=fixed_open(open_str="["),
    close="]",
    supports_heterogeneity=True,
    single_element_trailing_comma=False,
    single_element_template=None,
    supports_trailing_comma=False,
    empty_sequence="[]",
    preamble_lines=(),
    format_entry=passthrough_sequence_entry,
    typed_opener_fallback=None,
    uses_typed_literal_for_scalars=False,
    requires_uniform_record_shapes=False,
    declared_type=None,
    narrowed_empty_form=None,
)


_NLOHMANN_INLINE_SET_CONFIG = SetFormatConfig(
    set_open=sequence_surrogate_set_open(fixed_open(open_str="[")),
    close="]",
    empty_set="[]",
    preamble_lines=(),
    set_opener_template="",
    supports_heterogeneity=True,
    supports_trailing_comma=False,
)


_NLOHMANN_INLINE_DICT_CONFIG = DictFormatConfig(
    dict_open=fixed_open(open_str="{"),
    close="}",
    format_entry=dict_entry_with_separator(
        separator=": ",
        format_value=passthrough_sequence_entry,
    ),
    empty_dict="{}",
    preamble_lines=(),
    narrowed_open=None,
    supports_trailing_comma=False,
    narrowed_empty_form=None,
)


_NLOHMANN_INLINE_ORDERED_MAP_CONFIG = OrderedMapFormatConfig(
    ordered_map_open=fixed_open(open_str="{"),
    close="}",
    preamble_lines=(),
)


@beartype
def _format_json_document_string(value: str) -> str:
    """Format a string as a JSON string literal.

    The literal is embedded in a C++ raw string, which applies no
    escape processing of its own, so JSON's encoding is the only one
    needed.
    """
    return json.dumps(obj=value, ensure_ascii=False)


@beartype
def _format_nlohmann_json_parse_overflow_int(value: int) -> str:
    """Format an integer outside the signed 64-bit range as a bare
    JSON number when ``nlohmann::json::parse`` can hold it exactly.

    ``parse`` stores integers above ``I64_MAX`` up to ``U64_MAX`` as
    ``number_unsigned_t``; anything wider only fits a ``double`` that
    loses precision, so it is rejected instead.
    """
    if 0 < value <= U64_MAX:
        return str(object=value)
    msg = (
        "Cpp json_rendering=INLINE_DOCUMENT cannot represent integer "
        f"{value}: nlohmann::json::parse stores integers outside "
        "[-2^63, 2^64 - 1] as doubles that lose precision."
    )
    raise UnrepresentableIntegerError(msg)


@beartype
def _validate_json_integer_token(value: int, token: str) -> str:
    """Return *token* when it is an integer in JSON number grammar."""
    if _JSON_INTEGER_TOKEN.fullmatch(string=token) is not None:
        return token
    msg = (
        "Cpp json_rendering=INLINE_DOCUMENT cannot render integer "
        f"{value} as {token!r}: the selected integer format does not "
        "produce a valid JSON integer token."
    )
    raise UnrepresentableIntegerError(msg)


@beartype
def _cpp_nlohmann_json_parse_expression(value: str, /) -> str:
    """Wrap a rendered JSON document in ``nlohmann::json::parse``.

    The two-argument default form throws ``json::parse_error`` on
    malformed input rather than yielding a silently discarded value;
    the rendered document is always well-formed by construction, and
    ``wrap_in_file`` already guards ``main`` with ``try``/``catch``
    under :attr:`Cpp.json_type`.
    """
    return (
        f'nlohmann::json::parse(R"{_NLOHMANN_JSON_PARSE_DELIMITER}'
        f'({value}){_NLOHMANN_JSON_PARSE_DELIMITER}")'
    )


@beartype
def _format_cpp_json_inline_call_arg(_raw_value: Value, formatted: str) -> str:
    """Format a direct call argument as a parsed inline JSON document."""
    return _cpp_nlohmann_json_parse_expression(formatted)


@beartype
@dataclasses.dataclass(frozen=True, kw_only=True)
class Cpp(metaclass=LanguageCls):
    """C++ language specification.

    Args:
        date_format: How to format :class:`datetime.date` values.

            * ``date_formats.CPP`` — ``std::chrono::year_month_day`` literal,
              e.g. ``std::chrono::year_month_day{std::chrono::year{2024},
              std::chrono::month{1}, std::chrono::day{15}}``.
            * ``date_formats.ISO`` — ISO 8601 quoted string,
              e.g. ``"2024-01-15"``.

        datetime_format: How to format :class:`datetime.datetime` values.

            * ``datetime_formats.CPP`` — ``std::chrono::sys_days`` with
              time-of-day durations,
              e.g. ``std::chrono::sys_days{...} + std::chrono::hours{12}
              + std::chrono::minutes{30}``.
            * ``datetime_formats.ISO`` — ISO 8601 quoted string,
              e.g. ``"2024-01-15T12:30:00"``.

        json_type: When set to ``json_types.NLOHMANN_JSON``, render values
            with structural ``nlohmann::json`` array and object factories
            instead of C++'s narrow ``std::vector`` / ``std::map`` /
            ``std::unordered_map`` collection types. Dict keys must be
            strings so they remain valid JSON object keys.

        json_rendering: When set to ``json_renderings.INLINE_DOCUMENT``,
            render the :attr:`json_type` value as one inline JSON
            document handed to ``nlohmann::json::parse`` in a
            ``R"json(...)json"`` raw string instead of structural
            ``nlohmann::json`` factory expressions. Readers see the data
            as JSON, at the cost of the structural form's compile-time
            validation. Requires :attr:`json_type`; non-finite floats
            and integers outside ``[-2^63, 2^64 - 1]`` are rejected
            because a JSON document cannot carry them exactly.

        record_map_value_typing: Value type for a ``RECORD`` strategy
            field whose map has no record shape of its own and so
            renders as a plain ``std::map``.

            * ``record_map_value_typings.NARROW`` — the concrete type
              every widened scalar in this input shares, e.g.
              ``std::map<std::string, std::string>``, falling back to
              the generated ``LiteralizerRecordValue`` alias when they
              span more than one type.  This is the default.
            * ``record_map_value_typings.WIDE`` — always the
              ``LiteralizerRecordValue`` alias, with each leaf wrapped
              in it.  Two inputs sharing one record shape then declare
              the field identically, so one input's literals compile
              against the other's ``struct``.  C++14 renders this way
              whatever the setting, because its explicit fallback
              carrier wraps every widened scalar already.

        multiline_raw_string_delimiter_base: Non-empty fallback delimiter
            base for ``string_formats.MULTILINE`` raw strings. The empty
            delimiter is still tried first. On a collision, Literalizer
            tries this base and then appends ``0``, ``1``, and so on while
            keeping the complete delimiter within C++'s 16-character limit.

        heterogeneous_value_variant_name: Name for C++14's generated
            heterogeneous-value carrier. The default is ``Value``. The
            carrier provides ``is<T>()`` and ``get<T>()`` for inspecting and
            retrieving its active value.
    """

    wrap_in_file_tolerates_pre_indent = True
    module_name_shares_variable_scope = False
    reserved_variable_identifier_pattern: ClassVar[re.Pattern[str] | None] = (
        None
    )
    reserved_call_parameter_identifiers: ClassVar[frozenset[str]] = frozenset()
    reserved_call_parameter_identifier_pattern: ClassVar[
        re.Pattern[str] | None
    ] = None
    accepts_type_name_call_target = True
    declares_type_name_call_target = True
    dotted_call_root_shares_entrypoint_namespace = True
    reserved_bare_call_target_identifiers: ClassVar[frozenset[str]] = (
        frozenset()
    )
    reserved_call_target_head_identifiers: ClassVar[frozenset[str]] = (
        frozenset()
    )
    contextual_call_target_identifiers: ClassVar[frozenset[str]] = frozenset()
    call_parameter_shadowing = CallParameterShadowing.ALLOWED
    reserved_call_target_keywords_case_sensitive = True
    module_name_must_start_uppercase = False
    new_variable_name_syntax = NewVariableNameSyntax.ASCII
    max_variable_identifier_length: ClassVar[int | None] = None
    call_target_name_syntax: ClassVar[NewVariableNameSyntax | None] = None
    supports_multiline_dict_layout = True
    pools_map_integer_width = True

    format_integer_widened = no_format_integer_widened
    format_integer_beyond_i64 = no_format_integer_beyond_i64
    format_constructor_target: ClassVar["staticmethod[[str], str]"] = (
        staticmethod(identity_constructor_target)
    )
    format_call_variable_declaration = default_format_call_variable_declaration
    format_call_variable_assignment = default_format_call_variable_assignment
    sequence_binding_declarations = default_sequence_binding_declarations
    format_call_binding_body_preamble = no_call_binding_body_preamble
    format_call_binding_file_pragmas = no_call_binding_file_pragmas

    module_name: str = "Module"

    leading_preamble = no_leading_preamble
    extension = ".cpp"
    pygments_name = "cpp"
    stringifies_nested_collections = False
    supports_special_floats = True
    supports_variable_names = True
    supports_no_variable_wrap_in_file = False
    wraps_data_dependent_preamble_in_body = False
    dict_supports_heterogeneous_values = True
    supports_dotted_calls = True
    has_free_function_calls = True
    reserved_identifiers: ClassVar[frozenset[str]] = frozenset()
    declares_call_parameter_names = True
    reserved_variable_identifiers_case_sensitive: bool = True
    reserved_variable_identifiers: frozenset[str] = frozenset(
        {
            "alignas",
            "alignof",
            "and",
            "and_eq",
            "asm",
            "auto",
            "bitand",
            "bitor",
            "bool",
            "break",
            "case",
            "catch",
            "char",
            "char16_t",
            "char32_t",
            "char8_t",
            "class",
            "co_await",
            "co_return",
            "co_yield",
            "compl",
            "concept",
            "const",
            "const_cast",
            "consteval",
            "constexpr",
            "constinit",
            "continue",
            "decltype",
            "default",
            "delete",
            "do",
            "double",
            "dynamic_cast",
            "else",
            "enum",
            "explicit",
            "export",
            "extern",
            "false",
            "float",
            "for",
            "friend",
            "goto",
            "if",
            "inline",
            "int",
            "long",
            "mutable",
            "namespace",
            "new",
            "noexcept",
            "not",
            "not_eq",
            "nullptr",
            "operator",
            "or",
            "or_eq",
            "override",
            "private",
            "protected",
            "public",
            "reflexpr",
            "register",
            "reinterpret_cast",
            "requires",
            "return",
            "short",
            "signed",
            "sizeof",
            "static",
            "static_assert",
            "static_cast",
            "struct",
            "switch",
            "template",
            "this",
            "thread_local",
            "throw",
            "true",
            "try",
            "typedef",
            "typeid",
            "typename",
            "union",
            "unsigned",
            "using",
            "virtual",
            "void",
            "volatile",
            "wchar_t",
            "while",
            "xor",
            "xor_eq",
        }
    )
    allows_empty_call_parens = True
    supports_dotted_call_stub = True
    call_returns_expression = True
    supports_json_call_result_binding = False
    supports_zero_parameter_calls = True
    max_call_parameters = NO_CALL_PARAMETER_LIMIT
    supports_inline_multiline_dict_args = True
    supports_standalone_comments_in_wrapped_calls = True
    supports_multi_param_call_wrapper_stub = True
    supports_dict_literal_as_free_expression = True
    reserved_module_identifiers: ClassVar[frozenset[str]] = frozenset(
        {
            "begin",
            "end",
            "import",
        }
    )
    supports_module_name = True
    supports_empty_dict_key = False
    supports_call_style = True
    supports_default_dict_key_type = False
    supports_default_dict_value_type = False
    supports_default_sequence_element_type = False
    supports_default_set_element_type = False
    supports_default_ordered_map_value_type = False
    json_type_variant_name_suffix: ClassVar[str | None] = None
    supports_non_ascii_string_literals = True
    supports_multiline_string_literals = True
    supports_empty_sibling_sequence_type_hints = True
    supports_typed_dict_open = False
    language_id: ClassVar[str] = "cpp"
    variant_metadata: ClassVar[VariantMetadata] = VariantMetadata(
        round_trip_capabilities=frozenset(
            {
                RoundTripCapability.I64_BOUNDARIES,
                RoundTripCapability.INTERPOLATION_STRINGS,
                RoundTripCapability.EMBEDDED_NUL,
            }
        ),
        modifier_sequence_format_overrides={},
        string_literals_escape_null_byte=True,
        supports_ref_elements_in_tuple_strategy=True,
    )
    supports_record_struct_name_prefix = True
    supports_record_shape_names = True
    record_shape_names_emit_declarations = False
    supports_non_string_dict_keys = False
    checks_raw_control_dict_keys_separately = False

    class DateFormats(DateFormatEnum):
        """Date format options for C++."""

        _value_: DateFormatConfig

        CPP = DateFormatConfig(
            formatter=_format_date_cpp,
            preamble_lines=("#include <chrono>",),
            type_produced=datetime.date,
        )
        ISO = DateFormatConfig(
            formatter=format_date_iso,
            preamble_lines=("#include <string>",),
            type_produced=str,
        )

        @property
        def cpp_type(self) -> str:
            """Return the C++ type name for this date format."""
            match self:
                case self.ISO:
                    return "std::string"
                case _:
                    return "std::chrono::year_month_day"

    class DatetimeFormats(DatetimeFormatEnum):
        """Datetime format options for C++."""

        _value_: DatetimeFormatConfig

        CPP = DatetimeFormatConfig(
            formatter=_format_datetime_cpp,
            preamble_lines=("#include <chrono>",),
            type_produced=datetime.datetime,
        )
        ISO = DatetimeFormatConfig(
            formatter=format_datetime_iso,
            preamble_lines=("#include <string>",),
            type_produced=str,
        )

        EPOCH = DatetimeFormatConfig(
            formatter=format_datetime_epoch,
            type_produced=int,
            preamble_lines=(),
        )

        @property
        def cpp_type(self) -> str:
            """Return the C++ type name for this datetime format."""
            match self:
                case self.ISO:
                    return "std::string"
                case self.EPOCH:
                    return "long long"
                case _:
                    return "std::chrono::system_clock::time_point"

    class BytesFormats(enum.Enum):
        """Bytes formatting options."""

        _value_: Callable[[bytes], str]

        HEX = enum.member(value=format_bytes_hex)
        BASE64 = enum.member(value=format_bytes_base64)

        def __call__(self, data: bytes, /) -> str:
            """Format bytes."""
            return self._value_(data)

    class SequenceFormats(enum.Enum):
        """Sequence type options for C++."""

        INITIALIZER_LIST = enum.member(value=_make_initializer_list_config)
        ARRAY = enum.member(value=_make_array_config)

        def get_config(
            self,
            *,
            type_ctx: _CppTypeCtx,
        ) -> SequenceFormatConfig:
            """Return the sequence format config for the given context."""
            factory: Callable[..., SequenceFormatConfig] = self.value
            return factory(type_ctx=type_ctx)

    class SetFormats(enum.Enum):
        """Set type options for C++."""

        SET = SetFormatConfig(
            set_open=sequence_surrogate_set_open(lambda _items: "{"),
            close="}",
            empty_set=None,
            preamble_lines=("#include <vector>",),
            set_opener_template="",
            supports_heterogeneity=True,
            supports_trailing_comma=True,
        )

        def get_config(
            self,
            *,
            type_ctx: _CppTypeCtx,
        ) -> SetFormatConfig:
            """Return the set format config with variant opener."""
            return dataclasses.replace(
                self.value,
                set_open=sequence_surrogate_set_open(
                    _build_variant_set_open(type_ctx=type_ctx)
                ),
            )

    class CommentFormats(enum.Enum):
        """Comment style options."""

        DOUBLE_SLASH = CommentConfig(
            prefix="//",
            suffix="",
        )
        BLOCK = CommentConfig(
            prefix="/*",
            suffix=" */",
        )

    class DeclarationStyles(enum.Enum):
        """Declaration style options."""

        AUTO = _CppDeclarationStyleConfig(supports_redefinition=True)

    class DictEntryStyles(enum.Enum):
        """Dict entry style options."""

        DEFAULT = enum.auto()

    class DictFormats(enum.Enum):
        """Dict/map format options."""

        MAP = _DictFormatOption(
            config=DictFormatConfig(
                dict_open=lambda _items: "{",
                close="}",
                format_entry=braced_dict_entry(
                    format_value=passthrough_sequence_entry
                ),
                empty_dict=None,
                preamble_lines=("#include <map>",),
                narrowed_open=None,
                supports_trailing_comma=True,
                narrowed_empty_form=None,
            ),
            opener_template="std::map<std::string, {type_name}>{{",
        )
        UNORDERED_MAP = _DictFormatOption(
            config=DictFormatConfig(
                dict_open=lambda _items: "{",
                close="}",
                format_entry=braced_dict_entry(
                    format_value=passthrough_sequence_entry
                ),
                empty_dict=None,
                preamble_lines=("#include <unordered_map>",),
                narrowed_open=None,
                supports_trailing_comma=True,
                narrowed_empty_form=None,
            ),
            opener_template=("std::unordered_map<std::string, {type_name}>{{"),
        )

        def get_config(
            self,
            *,
            type_ctx: _CppTypeCtx,
        ) -> DictFormatConfig:
            """Return the dict format config with variant opener."""
            option: _DictFormatOption = self.value
            return dataclasses.replace(
                option.config,
                dict_open=_build_variant_dict_open(
                    type_ctx=type_ctx,
                    opener_template=option.opener_template,
                ),
            )

    class EmptyDictKey(enum.Enum):
        """Empty dict key options."""

        ALLOW = enum.auto()

    class FloatFormats(
        FloatSpecialsMixin,
        enum.Enum,
        positive_infinity="static_cast<double>(INFINITY)",
        negative_infinity="-static_cast<double>(INFINITY)",
        nan="static_cast<double>(NAN)",
    ):
        """Float format options."""

        REPR = enum.member(value=format_float_repr)
        SCIENTIFIC = enum.member(value=format_float_scientific)
        FIXED = enum.member(value=format_float_fixed)

    class IntegerFormats(enum.Enum):
        """Integer format options."""

        DECIMAL = MappingProxyType(
            mapping={
                "NONE": str,
                "UNDERSCORE": format_integer_tick,
            }
        )
        HEX = MappingProxyType(
            mapping={
                "NONE": format_integer_hex,
                "UNDERSCORE": format_integer_hex,
            }
        )
        OCTAL = MappingProxyType(
            mapping={
                "NONE": format_integer_octal_c_style,
                "UNDERSCORE": format_integer_octal_c_style,
            }
        )
        BINARY = MappingProxyType(
            mapping={
                "NONE": format_integer_binary,
                "UNDERSCORE": format_integer_binary,
            }
        )

        def get_formatter(
            self,
            numeric_separator: enum.Enum,
        ) -> Callable[[int], str]:
            """Return the integer formatter for the given separator."""
            formatter: Callable[[int], str] = self.value[
                numeric_separator.name
            ]
            return formatter

    class NumericLiteralSuffixes(enum.Enum):
        """Numeric literal suffix options."""

        NONE = _NumericLiteralSuffixConfig(
            int_resolver=_narrowest_cpp_int_type,
            formatter_wrapper=_identity_wrapper,
        )
        AUTO = _NumericLiteralSuffixConfig(
            int_resolver=_static_int_resolver(int_type="long"),
            formatter_wrapper=make_long_suffix_formatter,
        )

        @property
        def int_resolver(self) -> _IntTypeResolver:
            """Return the value-driven int type resolver."""
            config: _NumericLiteralSuffixConfig = self.value
            return config.int_resolver

        def wrap_integer_formatter(
            self,
            base: Callable[[int], str],
        ) -> Callable[[int], str]:
            """Wrap the base integer formatter."""
            config: _NumericLiteralSuffixConfig = self.value
            return config.formatter_wrapper(base)

    class NumericSeparators(enum.Enum):
        """Numeric separator options."""

        NONE = enum.auto()
        UNDERSCORE = enum.auto()

    class NumericStyles(enum.Enum):
        """Numeric literal style options."""

        OVERLOADED = enum.auto()

    class StringFormats(enum.Enum):
        """String format options."""

        _value_: Callable[[str], str]

        DOUBLE = enum.member(value=_format_string_cpp_escaped)
        MULTILINE = enum.member(value=_format_string_multiline)

        def __call__(self, value: str, /) -> str:
            """Format a string."""
            return self._value_(value)

    class TrailingCommas(enum.Enum):
        """Trailing comma options."""

        YES = TrailingCommaConfig(multiline_trailing_comma=True)
        NO = TrailingCommaConfig(multiline_trailing_comma=False)

    immutable_variable_modifiers: ClassVar[frozenset[enum.Enum]] = frozenset(
        {
            _CppModifiers.CONST,
        }
    )
    Modifiers = _CppModifiers

    date_formats = DateFormats
    datetime_formats = DatetimeFormats
    bytes_formats = BytesFormats
    sequence_formats = SequenceFormats
    set_formats = SetFormats
    comment_formats = CommentFormats
    modifiers = _CppModifiers

    class HeterogeneousStrategies(enum.Enum):
        """Heterogeneous-scalar strategy options.

        C++ represents heterogeneous scalar collections with
        ``std::variant`` by default (``ERROR``); ``TUPLE`` additionally
        renders a fixed-length heterogeneous scalar array (a dict value
        or the document root, all elements scalar, spanning at least two
        scalar buckets) as ``std::make_tuple(...)`` typed
        ``std::tuple<...>``.  ``RECORD`` instead renders each
        record-shaped dict (non-empty, string-keyed) as a generated
        aggregate ``struct`` declared in the preamble plus a matching
        ``Record0{.field = value, ...}`` designated-initializer literal,
        so fields may mix scalars and containers that the homogeneous
        ``std::map`` cannot.
        """

        ERROR = enum.auto()
        TUPLE = enum.auto()
        RECORD = enum.auto()

    heterogeneous_strategies = HeterogeneousStrategies

    class BoolFormats(enum.Enum):
        """Empty: this language has no alternative boolean formats."""

    bool_formats = BoolFormats

    class VersionFormats(enum.Enum):
        """C++ language-standard targets.

        Select one with :attr:`Cpp.language_version`, for example
        ``Cpp(language_version=Cpp.version_formats.CPP17)``.  The
        default is :attr:`CPP20`.
        """

        CPP14 = enum.auto()
        """ISO C++14 (``-std=c++14``).

        Uses a local value carrier in place of ``std::variant``, positional
        aggregate initialization, ISO date/datetime strings, and explicit
        template parameter packs in generated call stubs.
        """

        CPP17 = enum.auto()
        """ISO C++17 (``-std=c++17``).

        Uses ``std::variant`` while retaining positional aggregate
        initialization, ISO date/datetime strings, and explicit template
        parameter packs in generated call stubs.
        """

        CPP20 = enum.auto()
        """ISO C++20 (``-std=c++20``; default)."""

    version_formats = VersionFormats

    class JsonTypes(JsonType):
        """JSON value type options for C++."""

        NLOHMANN_JSON = "nlohmann::json"
        """The ``nlohmann::json`` dynamic JSON value type from the
        ``nlohmann/json.hpp`` library.
        """

    json_types = JsonTypes

    class JsonRenderings(enum.Enum):
        """Rendering modes for :attr:`json_type` values."""

        INLINE_DOCUMENT = enum.auto()
        """Render the whole value as one inline JSON document handed to
        ``nlohmann::json::parse`` in a ``R"json(...)json"`` raw string,
        instead of structural ``nlohmann::json`` factory expressions.
        """

    json_renderings = JsonRenderings

    module_name_case: ClassVar[IdentifierCase] = IdentifierCase.SNAKE
    identifier_cases: ClassVar[tuple[IdentifierCase, ...]] = (
        IdentifierCase.SNAKE,
        IdentifierCase.UPPER_SNAKE,
        IdentifierCase.PASCAL,
        IdentifierCase.CAMEL,
    )
    supported_ref_cases: ClassVar[frozenset[IdentifierCase]] = (
        NON_KEBAB_REF_CASES
    )

    modifier_combinations: ClassVar[tuple[ModifierCombination, ...]] = (
        ModifierCombination(
            name="static_const",
            modifiers=frozenset(
                {_CppModifiers.STATIC, _CppModifiers.CONST},
            ),
        ),
    )

    def __post_init__(self) -> None:
        """Reject ``json_type`` combinations the generator cannot emit."""
        self._validate_multiline_raw_string_delimiter_base()
        self._validate_json_type_spec()
        self._validate_json_rendering_spec()
        self._validate_record_naming()

    def _validate_multiline_raw_string_delimiter_base(self) -> None:
        """Reject a delimiter base outside C++'s ``d-char`` grammar."""
        delimiter = self.multiline_raw_string_delimiter_base
        if delimiter == "":
            raise InvalidCppRawStringDelimiterError(
                delimiter=delimiter,
                reason="the fallback base must be non-empty",
            )
        if len(delimiter) > _CPP_RAW_STRING_DELIMITER_MAX_LENGTH:
            raise InvalidCppRawStringDelimiterError(
                delimiter=delimiter,
                reason="raw-string delimiters contain at most 16 characters",
            )
        invalid = sorted(set(delimiter) - _CPP_RAW_STRING_DELIMITER_CHARACTERS)
        if len(invalid) > 0:
            raise InvalidCppRawStringDelimiterError(
                delimiter=delimiter,
                reason=(
                    "these characters are not permitted by C++'s raw-string "
                    f"delimiter grammar: {invalid!r}"
                ),
            )

    def _validate_record_naming(self) -> None:
        """Validate externally declared C++ record type names.

        Mapped names are referenced but never declared by literalizer, so
        they must be unambiguous PascalCase C++ identifiers and must not
        collide with a generated ``RecordN`` name.
        """
        auto_name_pattern = re.compile(
            pattern=(
                rf"^{re.escape(pattern=self.record_struct_name_prefix)}\d+$"
            ),
        )
        value_name = self.heterogeneous_value_variant_name
        if _CPP_FIELD_IDENTIFIER.match(string=value_name) is None:
            msg = (
                f"heterogeneous_value_variant_name {value_name!r} must be "
                "a valid C++ identifier."
            )
            raise InvalidRecordNameError(msg)
        if value_name in self.reserved_variable_identifiers:
            msg = (
                f"heterogeneous_value_variant_name {value_name!r} is a "
                "reserved C++ identifier."
            )
            raise InvalidRecordNameError(msg)
        if auto_name_pattern.match(string=value_name) is not None:
            msg = (
                f"heterogeneous_value_variant_name {value_name!r} collides "
                f"with the auto-generated "
                f"{self.record_struct_name_prefix!r}-prefixed struct names."
            )
            raise InvalidRecordNameError(msg)
        seen_names: set[str] = set()
        for keys, name in self.record_shape_names.items():
            if _PASCAL_CASE_IDENTIFIER.match(string=name) is None:
                msg = (
                    f"record_shape_names entry for keys {sorted(keys)!r} "
                    f"maps to {name!r}, which is not a PascalCase C++ "
                    "identifier."
                )
                raise InvalidRecordNameError(msg)
            if auto_name_pattern.match(string=name) is not None:
                msg = (
                    f"record_shape_names entry for keys {sorted(keys)!r} "
                    f"maps to {name!r}, which collides with the "
                    f"auto-generated {self.record_struct_name_prefix!r}-"
                    "prefixed struct names."
                )
                raise InvalidRecordNameError(msg)
            if name in seen_names:
                msg = (
                    "record_shape_names maps multiple key-sets to "
                    f"{name!r}; externally declared type names must be "
                    "unique."
                )
                raise InvalidRecordNameError(msg)
            if name == value_name:
                msg = (
                    f"record_shape_names entry for keys {sorted(keys)!r} "
                    f"maps to {name!r}, which collides with "
                    "heterogeneous_value_variant_name."
                )
                raise InvalidRecordNameError(msg)
            seen_names.add(name)

    def _validate_json_type_spec(self) -> None:
        """Reject ``json_type`` combinations the generator cannot emit.

        Under ``json_type`` the rendered data becomes a single structural
        ``nlohmann::json`` expression. That is incompatible with the
        ``RECORD`` and ``TUPLE`` heterogeneous strategies, both of
        which generate type declarations (``struct``s for ``RECORD``,
        ``std::tuple<...>`` aliases for ``TUPLE``) that the json_type
        renderer would silently drop on the floor.
        """
        if not self._json_type_active:
            return
        rejected = {
            self.heterogeneous_strategies.RECORD: "struct",
            self.heterogeneous_strategies.TUPLE: "std::tuple<...>",
        }
        if self.heterogeneous_strategy in rejected:
            strategy_name = self.heterogeneous_strategy.name
            generated = rejected[self.heterogeneous_strategy]
            msg = (
                "Cpp json_type renders data as a structural "
                "nlohmann::json expression and is incompatible with "
                f"heterogeneous_strategy={strategy_name}, which generates "
                f"{generated} declarations. Use "
                "heterogeneous_strategy=ERROR."
            )
            raise IncompatibleFormatsError(msg)

    def _validate_json_rendering_spec(self) -> None:
        """Reject ``json_rendering`` without a JSON value type.

        The option chooses between renderings of a ``nlohmann::json``
        value, so it has no meaning for the narrow-typed default
        collections.
        """
        if self.json_rendering is not None and self.json_type is None:
            msg = (
                "Cpp json_rendering selects how json_type values are "
                "rendered and requires json_type to be set."
            )
            raise IncompatibleFormatsError(msg)

    def validate_spec_for_data(self, data: Value) -> None:
        """Validate C++-specific data/format combinations."""
        if self._record_strategy_active:
            _check_cpp_record_naming(node=data)
            _reject_distinct_record_list_ordered_map_values(data)
        if self.sequence_format is type(self.sequence_format).ARRAY:
            _reject_incompatible_nested_cpp_arrays(data)
        if self._json_type_active:
            self._validate_json_value_keys(data=data)
        if self._json_inline_document_active:
            if data_has_special_float(data=data):
                msg = (
                    "Cpp json_rendering=INLINE_DOCUMENT cannot represent "
                    "special floats because nlohmann::json::parse accepts "
                    "only finite numbers."
                )
                raise UnrepresentableSpecialFloatError(msg)
            self._validate_inline_document_strings(data=data)

    def _validate_json_value_keys(self, *, data: Value) -> None:
        """Reject non-string object keys for ``nlohmann::json``.

        ``OrderedMap`` is a subclass of :class:`dict`, so the ``dict``
        arm covers it as well.
        """
        match data:
            case dict():
                for key, value in data.items():
                    if not isinstance(key, str):
                        msg = (
                            "Cpp json_type can only represent dict keys "
                            "as JSON object strings, not "
                            f"{type(key).__name__}"
                        )
                        raise UnrepresentableInputError(msg)
                    self._validate_json_value_keys(data=value)
            case list() | set():
                for item in data:
                    self._validate_json_value_keys(data=item)
            case _:
                return

    def _validate_inline_document_strings(self, *, data: Value) -> None:
        """Reject strings the inline JSON raw string cannot hold.

        The C++ lexer ends the ``R"json(...)json"`` raw string at the
        first ``)json"`` byte sequence.  JSON encoding escapes every
        ``"`` inside a string literal, so the terminator can only be
        produced by a string value that ends with ``)json``, putting
        the sequence right before the literal's closing quote.
        """
        match data:
            case str():
                encoded = json.dumps(obj=data, ensure_ascii=False)
                if _NLOHMANN_JSON_PARSE_TERMINATOR in encoded:
                    msg = (
                        "Cpp json_rendering=INLINE_DOCUMENT cannot "
                        "represent a string whose JSON encoding contains "
                        "the raw-string terminator sequence "
                        f"{_NLOHMANN_JSON_PARSE_TERMINATOR!r}."
                    )
                    raise UnrepresentableInputError(msg)
            case dict():
                for key, value in data.items():
                    self._validate_inline_document_strings(data=key)
                    self._validate_inline_document_strings(data=value)
            case list() | set():
                for item in data:
                    self._validate_inline_document_strings(data=item)
            case _:
                return

    @cached_property
    def validate_call_arg(self) -> Callable[[Value], None]:
        """Return call-argument validation for this language."""
        return no_validate_call_arg

    @cached_property
    def format_call_statement(self) -> Callable[[str], str]:
        """Return call-statement formatting for this language."""
        return identity_call_statement

    wrap_calls_with_declarations = default_wrap_calls_with_declarations

    class VariableTypeHints(enum.Enum):
        """Variable type hint options."""

        NEVER = enum.auto()
        SAFE = enum.auto()

    variable_type_hints_formats = VariableTypeHints
    declaration_styles = DeclarationStyles
    dict_entry_styles = DictEntryStyles
    dict_formats = DictFormats
    empty_dict_keys = EmptyDictKey
    float_formats = FloatFormats
    integer_formats = IntegerFormats
    integer_width_strategies = BareIntegerWidthStrategies
    record_map_value_typings = RecordMapValueTypings
    numeric_literal_suffixes = NumericLiteralSuffixes
    numeric_separators = NumericSeparators
    numeric_styles = NumericStyles
    string_formats = StringFormats
    trailing_commas = TrailingCommas

    class StatementTerminatorStyles(enum.Enum):
        """Statement terminator options."""

        SEMICOLON = enum.auto()

    statement_terminator_styles = StatementTerminatorStyles

    class CallStyles(enum.Enum):
        """Cpp call style options."""

        POSITIONAL = PositionalCallStyle(
            arg_separator=", ", parenthesize_each_arg=False
        )

    call_styles = CallStyles

    @property
    def call_wrapper_entrypoint_name(self) -> str:
        """Return the generated complete-file entry-point name."""
        return self.module_name

    def wrap_in_file(
        self,
        content: str,
        variable_name: str,
        body_preamble: tuple[str, ...],
    ) -> str:
        """Wrap a C++ declaration in a main function.

        Under :attr:`json_type` the body is additionally wrapped in
        ``try { ... } catch (...) { return 1; }`` so potentially-throwing
        ``nlohmann::json`` construction cannot make ``main`` itself
        throwing — clang-tidy's
        ``bugprone-exception-escape`` check rejects an implicitly
        ``noexcept`` ``main`` that calls a function whose signature permits
        exceptions.
        """
        content = prepend_body_preamble(
            content=content,
            body_preamble=body_preamble,
        )
        use_line = ""
        if variable_name != "":
            use_line = f"\n{self.indent}(void){variable_name};"
        if self._json_type_active:
            return (
                f"int {self.module_name}() {{\n"
                f"{self.indent}try {{\n{content}{use_line}\n"
                f"{self.indent}{self.indent}return 0;\n"
                f"{self.indent}}} catch (...) {{\n"
                f"{self.indent}{self.indent}return 1;\n"
                f"{self.indent}}}\n}}"
            )
        return (
            f"int {self.module_name}() {{\n{content}{use_line}\n"
            f"{self.indent}return 0;\n}}"
        )

    def wrap_combined_in_file(
        self,
        declaration: str,
        assignment: str,
        variable_name: str,
        body_preamble: tuple[str, ...],
    ) -> str:
        """Wrap C++ declaration + assignment in a function body.

        Reads ``variable_name`` between the declaration and the
        assignment so the initial value is not a dead store flagged by
        clang-tidy's ``clang-analyzer-deadcode.DeadStores`` check.
        """
        mid_use = f"(void){variable_name};\n"
        return self.wrap_in_file(
            content=f"{declaration}\n{mid_use}{assignment}",
            variable_name=variable_name,
            body_preamble=body_preamble,
        )

    date_format: DateFormats = DateFormats.CPP
    datetime_format: DatetimeFormats = DatetimeFormats.CPP
    bytes_format: BytesFormats = BytesFormats.HEX
    sequence_format: SequenceFormats = SequenceFormats.INITIALIZER_LIST
    set_format: SetFormats = SetFormats.SET
    variable_type_hints: VariableTypeHints = VariableTypeHints.NEVER
    comment_format: CommentFormats = CommentFormats.DOUBLE_SLASH
    declaration_style: DeclarationStyles = DeclarationStyles.AUTO
    dict_entry_style: DictEntryStyles = DictEntryStyles.DEFAULT
    dict_format: DictFormats = DictFormats.MAP
    float_format: FloatFormats = FloatFormats.REPR
    integer_format: IntegerFormats = IntegerFormats.DECIMAL
    integer_width_strategy: BareIntegerWidthStrategies = (
        BareIntegerWidthStrategies.BARE
    )
    numeric_literal_suffix: NumericLiteralSuffixes = (
        NumericLiteralSuffixes.NONE
    )
    numeric_separator: NumericSeparators = NumericSeparators.NONE
    numeric_style: NumericStyles = NumericStyles.OVERLOADED
    string_format: StringFormats = StringFormats.DOUBLE
    trailing_comma: TrailingCommas = TrailingCommas.YES
    statement_terminator_style: StatementTerminatorStyles = (
        StatementTerminatorStyles.SEMICOLON
    )
    call_style: CallStyles = CallStyles.POSITIONAL
    heterogeneous_strategy: HeterogeneousStrategies = (
        HeterogeneousStrategies.ERROR
    )
    heterogeneous_value_variant_name: str = "Value"
    json_type: JsonTypes | None = None
    json_rendering: JsonRenderings | None = None
    record_struct_name_prefix: str = "Record"
    record_shape_names: Mapping[frozenset[str], str] = dataclasses.field(
        default_factory=lambda: MappingProxyType[frozenset[str], str](
            mapping={}
        ),
        hash=False,
    )
    record_map_value_typing: RecordMapValueTypings = (
        RecordMapValueTypings.NARROW
    )
    multiline_raw_string_delimiter_base: str = "x"
    # C++20 is the default checked by CI (see ``.github/workflows/lint.yml``).
    # Earlier standards remain available through ``VersionFormats``.
    language_version: VersionFormats = VersionFormats.CPP20
    indent: str = "    "

    _default_null_literal: ClassVar[str] = "nullptr"
    true_literal: ClassVar[str] = "true"
    false_literal: ClassVar[str] = "false"
    indent_closing_delimiter: ClassVar[bool] = False
    element_separator: ClassVar[str] = ", "
    skip_null_dict_values: ClassVar[bool] = False
    supports_scalar_before_comments: ClassVar[bool] = True
    supports_scalar_inline_comments: ClassVar[bool] = False
    statement_terminator: ClassVar[str] = ";"
    _default_static_preamble: ClassVar[Sequence[str]] = (
        "#include <initializer_list>",
    )
    static_body_preamble: ClassVar[Sequence[str]] = ()
    special_float_preamble: ClassVar[tuple[str, ...]] = ("#include <cmath>",)

    @cached_property
    def _json_type_active(self) -> bool:
        """Return whether C++ should render via ``nlohmann::json``."""
        return self.json_type is not None

    @cached_property
    def supports_collection_comments(self) -> bool:
        """Whether a comment can sit inside the rendered collection.

        The inline rendering hands one JSON document to
        ``nlohmann::json::parse``, and JSON has no comments, so one
        written inside it is a parse error rather than a comment.  The
        comments go before the declaration instead (issue #4471).
        """
        return not self._json_inline_document_active

    @cached_property
    def _json_inline_document_active(self) -> bool:
        """Return whether ``nlohmann::json`` values render as one
        inline JSON document handed to ``nlohmann::json::parse``.
        """
        return self.json_rendering is self.JsonRenderings.INLINE_DOCUMENT

    @cached_property
    def null_literal(self) -> str:
        """Null literal for the active C++ representation.

        ``nullptr`` constructs a null ``nlohmann::json`` value, so the
        default literal also serves the structural JSON rendering; the
        inline JSON document spells JSON's own ``null`` keyword.
        """
        if self._json_inline_document_active:
            return "null"
        return self._default_null_literal

    @cached_property
    def static_preamble(self) -> Sequence[str]:
        """Static preamble lines emitted once per file.

        Under :attr:`json_type` the ``nlohmann/json.hpp`` header replaces
        the default ``<initializer_list>`` include because every emitted
        expression constructs a ``nlohmann::json`` value.
        """
        if self._json_type_active:
            return _NLOHMANN_JSON_STATIC_PREAMBLE
        return self._default_static_preamble

    @cached_property
    def format_string(self) -> Callable[[str], str]:
        """Format a string value as a quoted literal.

        Under ``json_rendering=INLINE_DOCUMENT`` strings use JSON's own
        encoding: the document is embedded in a C++ raw string, so the
        configured C++ string format never applies.
        """
        if self._json_inline_document_active:
            return _format_json_document_string
        if self.string_format is self.string_formats.MULTILINE:
            if self.multiline_raw_string_delimiter_base == "x":
                return _format_string_multiline

            def _formatter(value: str) -> str:
                """Render with this C++ spec's delimiter base."""
                return _format_string_multiline_with_delimiter_base(
                    value=value,
                    delimiter_base=self.multiline_raw_string_delimiter_base,
                )

            return _formatter

        def _non_multiline_formatter(value: str) -> str:
            """Render with the selected non-multiline string format."""
            return self.string_format(value)

        return _non_multiline_formatter

    @cached_property
    def format_sequence_entry(self) -> Callable[[Value, str], str]:
        """Format a sequence entry."""
        return passthrough_sequence_entry

    @cached_property
    def format_set_entry(self) -> Callable[[Value, str], str]:
        """Format a set entry."""
        return passthrough_set_entry

    @cached_property
    def format_variable_assignment(self) -> Callable[[str, str, Value], str]:
        """Format an assignment to an existing variable."""
        if self._json_type_active:

            def _formatter(name: str, value: str, data: Value) -> str:
                """Assign a ``nlohmann::json`` value to an existing
                binding.
                """
                if self._json_inline_document_active:
                    expr = _cpp_nlohmann_json_parse_expression(value)
                else:
                    expr = _cpp_nlohmann_json_value_expression(data, value)
                return f"{name} = {expr};"

            return _formatter
        return variable_formatter(template="{name} = {value};")

    @cached_property
    def format_call_arg(self) -> Callable[[Value, str], str]:
        """Callable that rewrites a formatted direct call argument."""
        if self._json_inline_document_active:
            return _format_cpp_json_inline_call_arg
        if self._json_type_active:
            return _format_cpp_json_call_arg
        return identity_call_arg

    @cached_property
    def call_data_dependent_preamble(
        self,
    ) -> Callable[[Value], tuple[str, ...]]:
        """Return data-dependent preamble lines for call rendering."""
        return self.data_dependent_preamble

    @cached_property
    def type_hint_collection_preamble_lines(
        self,
    ) -> Callable[[frozenset[type]], tuple[str, ...]]:
        """Return preamble lines for empty-collection type hints."""
        return no_type_hint_preamble

    @cached_property
    def format_call_stub(
        self,
    ) -> Callable[
        [Sequence[str], Sequence[str], StubReturn, Sequence[Value]],
        tuple[str, ...],
    ]:
        """Return stub declarations for a call expression."""
        return no_call_stub

    @cached_property
    def format_call_preamble_stub(
        self,
    ) -> Callable[
        [Sequence[str], Sequence[str], StubReturn, Sequence[Value]],
        tuple[str, ...],
    ]:
        """Return file-scope stubs for a call expression."""

        def _formatter(
            parts: Sequence[str],
            params: Sequence[str],
            stub_return: StubReturn,
            args: Sequence[Value],
        ) -> tuple[str, ...]:
            """Render a stub in the selected C++ language mode."""
            return _cpp_call_stub(
                parts,
                params,
                stub_return,
                args,
                supports_abbreviated_templates=self._uses_cpp20,
                supports_nodiscard=(
                    self.language_version
                    in (
                        self.version_formats.CPP17,
                        self.version_formats.CPP20,
                    )
                ),
            )

        return _formatter

    @cached_property
    def format_call_target(self) -> Callable[[Sequence[str]], str]:
        """Rewrite a dotted call target into the language's call
        syntax.
        """
        return identity_call_target

    @cached_property
    def format_call_ref_identifier(
        self,
    ) -> Callable[[str, Value | None], str]:
        """Wrap a ``{"$ref": "name"}`` identifier in ``std::move()``,
        except for ``trivially-copyable`` scalars.

        A direct copy assignment (``auto my_data = my_var``) triggers
        clang-tidy ``performance-unnecessary-copy-initialization`` when
        the variable is never modified, so ``std::move`` is used for
        container-typed refs to satisfy the linter.  Applying
        ``std::move`` to a ``trivially-copyable`` scalar (``int``, ``bool``,
        ``float``) is itself a clang-tidy
        ``hicpp-move-const-arg`` / ``performance-move-const-arg``
        warning ("has no effect; remove std::move()"), so we drop the
        wrapper when the caller's ``ref_values`` identifies the ref as
        one of those types.  When the value is unknown we keep the
        historical ``std::move`` form.
        """

        def _format_cpp_ref_identifier(
            name: str, value: Value | None, /
        ) -> str:
            """Wrap the identifier in ``std::move()`` unless *value* is
            a ``trivially-copyable`` scalar.
            """
            if isinstance(value, (bool, int, float)):
                return name
            return f"std::move({name})"

        return _format_cpp_ref_identifier

    @cached_property
    def format_call_arg_ref_identifier(
        self,
    ) -> Callable[[str, Value | None], str]:
        """Emit a call-argument ``$ref`` as the bare identifier.

        ``std::move`` would consume the variable, which is unsafe when
        the caller may use it again in a later call (or after the
        ``literalize_call`` block).  Callers opt in to consuming a
        specific ref by listing it in ``literalize_call``'s
        ``consumable_refs`` set; in that case
        :attr:`format_call_arg_ref_identifier_consumable` is used
        instead and emits ``std::move(name)``.
        """
        return identity_call_ref_identifier

    @cached_property
    def format_call_arg_ref_identifier_consumable(
        self,
    ) -> Callable[[str, Value | None], str]:
        """Wrap a consumable call-argument ``$ref`` in ``std::move()``.

        Used only for refs the caller declared as consumable on
        :func:`~literalizer.literalize_call` and that appear in just
        one call argument, so the move cannot strand a later use.
        """

        def _format_cpp_ref_identifier_consumable(
            name: str, _value: Value | None, /
        ) -> str:
            """Wrap the identifier in ``std::move()``."""
            return f"std::move({name})"

        return _format_cpp_ref_identifier_consumable

    @cached_property
    def consumable_ref_value_inhibits_consuming_form(
        self,
    ) -> Callable[[Value], bool]:
        """Return ``True`` for ref values whose C++ type is register-
        trivial.

        ``clang-tidy``'s ``performance-move-const-arg`` rule (and the
        equivalent ``hicpp-move-const-arg``) reports ``std::move`` on a
        register-trivial value as an error: the move has no effect and
        the wrapping is wasteful.  The call site routes these refs
        through the non-consuming formatter so the emitted C++ compiles
        cleanly under ``--warnings-as-errors``.
        """
        return _cpp_value_inhibits_consuming_form

    @cached_property
    def _cpp_date_type(self) -> str:
        """Resolved C++ type name for the chosen date format."""
        return self._resolved_date_format.cpp_type

    @cached_property
    def _cpp_datetime_type(self) -> str:
        """Resolved C++ type name for the chosen datetime format."""
        return self._resolved_datetime_format.cpp_type

    @cached_property
    def _uses_cpp20(self) -> bool:
        """Return whether C++20-only syntax and chrono types are available."""
        return self.language_version is self.version_formats.CPP20

    @cached_property
    def _resolved_date_format(self) -> DateFormats:
        """Return the selected date representation for the target standard."""
        if not self._uses_cpp20 and self.date_format is self.date_formats.CPP:
            return self.date_formats.ISO
        return self.date_format

    @cached_property
    def _resolved_datetime_format(self) -> DatetimeFormats:
        """Return the selected datetime representation for the target."""
        if (
            not self._uses_cpp20
            and self.datetime_format is self.datetime_formats.CPP
        ):
            return self.datetime_formats.ISO
        return self.datetime_format

    @cached_property
    def _tuple_strategy_active(self) -> bool:
        """Return whether native tuple rendering is active.

        C++14 and later standards support the opt-in ``TUPLE`` mode.
        """
        return (
            self.heterogeneous_strategy
            is type(self.heterogeneous_strategy).TUPLE
        )

    @cached_property
    def _record_strategy_active(self) -> bool:
        """Return whether the ``RECORD`` heterogeneous strategy is set."""
        return (
            self.heterogeneous_strategy
            is type(self.heterogeneous_strategy).RECORD
        )

    @cached_property
    def _uses_cpp14_tuple_record_strategy(self) -> bool:
        """Return whether C++14 should compose native tuples and
        records.
        """
        return (
            self.language_version is self.version_formats.CPP14
            and self._tuple_strategy_active
        )

    def _cpp_record_field_type(self, request: RecordFieldType, /) -> str:
        """Return the C++ ``struct`` field type for a record field,
        derived structurally from the raw value.

        A field whose value is itself a nested record-shaped dict uses
        that record's generated name.  A record-shaped dict left without
        a name was widened to a plain fallback map; its declared type
        spells the concrete value type when every widened scalar shares
        one C++ type and the ``LiteralizerRecordValue`` alias carrier
        otherwise (issue #3605).  A field whose value is a list of
        record-shaped dicts (one shared shape) is typed
        ``std::vector<RecordN>`` to match the sequence opener's explicit
        element type in C++14 (and its class-template argument deduction
        from the ``RecordN`` literals in later standards).  This is the
        same name the shared strategy resolves, the one piece
        unrecoverable from the raw value.  Every other value is
        typed by the same :func:`_compute_cpp_type` the collection
        openers in the value formatter use, with the integer width
        narrowed to the field's own value so the declared type matches
        the rendered integer literal whether or not it carries a suffix
        (including the ``unsigned long long`` an out-of-range integer's
        ``ULL`` overflow literal needs).  A set or non-record dict field
        is out of scope for the base ``RECORD`` port (the cross-language
        decision is tracked in #2317) and is not reached by any record
        golden, so it falls through to the shared
        :func:`_compute_cpp_type` map / initializer-list handling.
        """
        if request.record_name is not None:
            return request.record_name
        if request.element_record_name is not None:
            return f"std::vector<{request.element_record_name}>"
        value = request.value
        if (
            isinstance(value, dict)
            and not isinstance(value, OrderedMap)
            and record_shape_for_dict(value=value) is not None
        ):
            narrow_value_type = self._record_map_narrowing.value_type
            if narrow_value_type is not None:
                return f"std::map<std::string, {narrow_value_type}>"
            return _CPP_RECORD_MAP_TYPE
        if isinstance(value, int) and not isinstance(value, bool):
            int_type = _cpp_int_field_type(
                value=value,
                int_resolver=self._type_ctx.int_resolver,
            )
        else:
            int_type = "long long"
        element_to_type = self._type_ctx.element_to_type(int_type=int_type)
        return _compute_cpp_type(
            item=value,
            element_to_type=element_to_type,
            type_ctx=self._type_ctx,
        )

    @cached_property
    def _record_renderer(self) -> RecordRenderer:
        """C++ syntax hooks for the ``RECORD`` strategy."""
        effective_render_literal = _cpp_record_literal_positional
        if self._uses_cpp20:
            effective_render_literal = _cpp_record_literal
        return RecordRenderer(
            name_prefix=self.record_struct_name_prefix,
            record_shape_names=self.record_shape_names,
            field_identifier=functools.partial(
                _cpp_record_field_identifier,
                reserved_identifiers=self.reserved_variable_identifiers,
            ),
            field_identifier_key=identity_field_identifier_key,
            field_type=self._cpp_record_field_type,
            render_declaration=_cpp_render_record_declaration,
            render_literal=(effective_render_literal),
            field_type_names_nested_records=True,
            suppress_custom_name_declarations=True,
        )

    @cached_property
    def _record_map_narrowing(self) -> _CppWidenedMapNarrowing:
        """Per-pass narrow-value-type cache for widened fallback maps."""
        return _CppWidenedMapNarrowing(value_type=None)

    @cached_property
    def _record_strategy(self) -> ActiveRecordStrategy:
        """Behavior + ``struct``-declaration preamble for ``RECORD``."""
        strategy = build_record_strategy(
            renderer=self._record_renderer,
            split_conflicting_field_types=True,
            widen_unrecordizable_nested_sibling_maps=True,
            derecordized_map_open=None,
        )
        narrowing = self._record_map_narrowing
        type_ctx = self._type_ctx
        base_compute_wrap_ids = strategy.behavior.compute_wrap_ids

        def _compute_wrap_ids(data: Value, /) -> frozenset[int]:
            """Refresh the narrow-type cache alongside the wrap ids."""
            wrap_ids = base_compute_wrap_ids(data)
            narrowing.value_type = _cpp_narrow_widened_map_value_type(
                data=data,
                wrap_ids=wrap_ids,
                type_ctx=type_ctx,
                map_value_typing=self.record_map_value_typing,
            )
            return wrap_ids

        def _wrap_scalar(_raw_value: Scalar, formatted: str) -> str:
            """Construct the shared value carrier for a widened map.

            When every widened scalar shares one concrete C++ type the
            plain map already holds the bare literal, so no carrier
            construction is needed (issue #3605).
            """
            if narrowing.value_type is not None:
                return formatted
            return f"{_CPP_RECORD_MAP_VALUE}{{{formatted}}}"

        def _widened_map_open() -> str:
            """Return the widened-map opener for the current pass."""
            if narrowing.value_type is not None:
                return f"std::map<std::string, {narrowing.value_type}>{{"
            return f"{_CPP_RECORD_MAP_TYPE}{{"

        return dataclasses.replace(
            strategy,
            behavior=dataclasses.replace(
                strategy.behavior,
                compute_wrap_ids=_compute_wrap_ids,
                wrap_scalar=_wrap_scalar,
                dict_open_for_wrap_ids=_widened_map_open,
                widens_nested_maps_by_wrapping_scalars=True,
            ),
        )

    @cached_property
    def _tuple_record_strategy(self) -> ActiveRecordStrategy:
        """Compose C++14's native tuple and record forms.

        A tuple-eligible field belongs to a generated record just as
        naturally as a scalar field.  Keeping the two native forms in
        one strategy prevents C++14 from falling back to the private
        ``LiteralizerVariant`` carrier for otherwise fixed-shape data.
        """

        def _field_type(request: RecordFieldType) -> str:
            """Resolve a tuple-eligible record field positionally."""
            value = request.value
            if isinstance(value, list) and is_tuple_eligible(value=value):
                return _cpp_tuple_type(items=value, type_ctx=self._type_ctx)
            return self._cpp_record_field_type(request)

        renderer = dataclasses.replace(
            self._record_renderer,
            field_type=_field_type,
        )
        strategy = build_record_strategy(
            renderer=renderer,
            split_conflicting_field_types=True,
            widen_unrecordizable_nested_sibling_maps=True,
            derecordized_map_open=f"{_CPP_RECORD_MAP_TYPE}{{",
        )

        behavior = dataclasses.replace(
            strategy.behavior,
            wrap_scalar=self._record_strategy.behavior.wrap_scalar,
            widens_nested_maps_by_wrapping_scalars=True,
            render_tuple_literal=_render_cpp_tuple,
            compute_tuple_list_ids=_cpp_tuple_list_ids,
        )
        return dataclasses.replace(strategy, behavior=behavior)

    def _rendered_record_name(self, value: Value, /) -> str | None:
        """Return the ``struct`` name *value* is rendered as, if any.

        Resolved when a type is needed rather than when the context is
        built, since the record strategy is itself built from that
        context.
        """
        if not self._record_strategy_active:
            return None
        lookup = self._record_strategy.record_name_for_value
        return lookup(value)

    @cached_property
    def _type_ctx(self) -> _CppTypeCtx:
        """Context bundle for C++ type resolution."""
        effective_variant_type_name = "std::variant"
        if self.language_version is self.version_formats.CPP14:
            effective_variant_type_name = self.heterogeneous_value_variant_name
        effective_dict_type_name = "std::map"
        if self.dict_format.name == "UNORDERED_MAP":
            effective_dict_type_name = "std::unordered_map"
        return _CppTypeCtx(
            int_resolver=self.numeric_literal_suffix.int_resolver,
            date_type=self._cpp_date_type,
            datetime_type=self._cpp_datetime_type,
            tuple_strategy=self._tuple_strategy_active,
            variant_type_name=(effective_variant_type_name),
            dict_type_name=(effective_dict_type_name),
            record_name_for_value=self._rendered_record_name,
            sequence_is_array=(
                self.sequence_format is type(self.sequence_format).ARRAY
                and not self._json_type_active
                and not self._json_inline_document_active
            ),
        )

    @cached_property
    def sequence_format_config(self) -> SequenceFormatConfig:
        """Configuration for the chosen sequence format."""
        if self._json_inline_document_active:
            return _NLOHMANN_INLINE_SEQUENCE_CONFIG
        if self._json_type_active:
            return _NLOHMANN_JSON_SEQUENCE_CONFIG
        return self.sequence_format.get_config(type_ctx=self._type_ctx)

    @cached_property
    def set_format_config(self) -> SetFormatConfig:
        """Configuration for the chosen set format.

        The inline JSON document renders a set as a JSON array because
        JSON has no set type.
        """
        if self._json_inline_document_active:
            return _NLOHMANN_INLINE_SET_CONFIG
        if self._json_type_active:
            return _NLOHMANN_JSON_SET_CONFIG
        return self.set_format.get_config(type_ctx=self._type_ctx)

    @cached_property
    def sequence_open(self) -> Callable[[list[Value]], str]:
        """Callable that returns the opening delimiter for a sequence.

        In C++14 a list whose every element has the same record shape may
        use an externally supplied ``record_shape_names`` type for its
        outer ``std::vector`` even when record rendering is inactive.  The
        elements themselves then retain their native map literals. JSON
        value rendering always keeps its JSON sequence opener.

        Under an active record strategy, a list whose every element is a
        record-shaped dict renders each element as an aggregate literal;
        the base opener would type such a list
        ``std::vector<std::map<...>>`` (the homogeneous-map element type)
        which the struct literals cannot initialize.  C++14 spells the
        assigned record element type explicitly; later standards use a
        bare ``std::vector{`` so class-template argument deduction infers
        it from the literals. Every other list keeps the base inferred
        opener.
        """
        base_open = self.sequence_format_config.sequence_open
        record_rendering_active = (
            self._record_strategy_active
            or self._uses_cpp14_tuple_record_strategy
        )
        if self._json_type_active:
            return base_open
        if not record_rendering_active and (
            self.language_version is not self.version_formats.CPP14
            or len(self.record_shape_names) == 0
        ):
            return base_open
        if self._record_strategy_active:
            record_strategy = self._record_strategy
        else:
            record_strategy = self._tuple_record_strategy
        record_name_for_value = record_strategy.record_name_for_value

        def _open(items: list[Value]) -> str:
            """Return the typed C++14 record-list opener when needed,
            else the record or base inferred opener.
            """
            base_items = items
            if _all_record_shaped(items):
                if self.language_version is self.version_formats.CPP14:
                    record_open = _cpp14_record_list_open(
                        items=items,
                        record_shape_names=self.record_shape_names,
                        record_rendering_active=record_rendering_active,
                        record_name_for_value=record_name_for_value,
                    )
                    if record_open is not None and record_open != "":
                        return record_open
                    return base_open(base_items)
                return "std::vector{"
            nested_type = nested_record_sequence_type(
                value=items,
                record_name_for_value=record_name_for_value,
            )
            if nested_type is not None:
                depth, name = nested_type
                if self.language_version is self.version_formats.CPP14:
                    return _cpp14_nested_record_list_open(
                        depth=depth,
                        name=name,
                    )
                return "std::vector{"
            return base_open(base_items)

        return _open

    @cached_property
    def trailing_comma_config(self) -> TrailingCommaConfig:
        """Configuration for trailing-comma behavior.

        The inline JSON document never emits trailing commas because
        the JSON spec rejects them in arrays and objects.
        """
        if self._json_inline_document_active:
            return TrailingCommaConfig(multiline_trailing_comma=False)
        return self.trailing_comma.value

    @cached_property
    def format_bytes(self) -> Callable[[bytes], str]:
        """Callable that formats a bytes value as a string literal."""
        return self.bytes_format

    @cached_property
    def format_date(self) -> Callable[[datetime.date], str]:
        """Callable that formats a date as a string literal."""
        if self._json_type_active:
            return format_date_iso
        return self._resolved_date_format

    @cached_property
    def format_datetime(self) -> Callable[[datetime.datetime], str]:
        """Callable that formats a datetime as a string literal."""
        if (
            self._json_type_active
            and self.datetime_format.value.type_produced is not int
        ):
            return format_datetime_iso
        return self._resolved_datetime_format

    @cached_property
    def format_time(self) -> Callable[[datetime.time], str]:
        """Callable that formats a time as a string literal."""
        return format_time_iso

    @cached_property
    def format_float(self) -> Callable[[float], str]:
        """Callable that formats a float value as a literal."""
        return self.float_format

    @cached_property
    def format_integer(self) -> Callable[[int], str]:
        """Callable that formats an int value as a literal.

        Under ``json_rendering=INLINE_DOCUMENT`` overflow values stay
        bare JSON numbers: the document reaches the C++ compiler inside
        a raw string, so the ``ULL``-suffix and ``I64_MIN``-safe forms
        the structural rendering needs would be invalid JSON tokens.
        """
        base_int_formatter = self.integer_format.get_formatter(
            numeric_separator=self.numeric_separator,
        )
        if self._json_inline_document_active:

            def format_json_integer(value: int) -> str:
                """Format and validate an integer for the JSON
                document.
                """
                return _validate_json_integer_token(
                    value=value,
                    token=base_int_formatter(value),
                )

            return make_overflow_fallback_formatter(
                base=format_json_integer,
                fallback=_format_nlohmann_json_parse_overflow_int,
                min_value=I64_MIN,
                max_value=I64_MAX,
            )
        base_int_formatter = (
            self.numeric_literal_suffix.wrap_integer_formatter(
                base=base_int_formatter,
            )
        )
        if self.integer_format is not type(self.integer_format).DECIMAL:
            base_int_formatter = make_negative_nondecimal_i64_formatter(
                base=base_int_formatter,
                suffix="LL",
            )
        return make_overflow_fallback_formatter(
            base=make_i64_min_safe_formatter(
                base=base_int_formatter,
            ),
            fallback=make_ull_fallback(language_name="C++"),
            min_value=I64_MIN,
            max_value=I64_MAX,
        )

    @cached_property
    def dict_format_config(self) -> DictFormatConfig:
        """Configuration for dict formatting."""
        if self._json_inline_document_active:
            return _NLOHMANN_INLINE_DICT_CONFIG
        if self._json_type_active:
            return _NLOHMANN_JSON_DICT_CONFIG
        return self.dict_format.get_config(type_ctx=self._type_ctx)

    @cached_property
    def comment_config(self) -> CommentConfig:
        """Configuration for the language's comment syntax."""
        return self.comment_format.value

    @cached_property
    def ordered_map_format_config(self) -> OrderedMapFormatConfig:
        """Configuration for ordered-map formatting.

        The inline JSON document reuses the JSON object form (JSON
        objects preserve insertion order in the rendered text).
        """
        if self._json_inline_document_active:
            return _NLOHMANN_INLINE_ORDERED_MAP_CONFIG
        if self._json_type_active:
            return _NLOHMANN_JSON_ORDERED_MAP_CONFIG
        config = _build_ordered_map_config(type_ctx=self._type_ctx)
        record_rendering_active = (
            self._record_strategy_active
            or self._uses_cpp14_tuple_record_strategy
        )
        if not record_rendering_active:
            return config
        if self._record_strategy_active:
            record_name_for_value = self._record_strategy.record_name_for_value
        else:
            record_name_for_value = (
                self._tuple_record_strategy.record_name_for_value
            )

        def _record_aware_open(data: dict[Scalar, Value]) -> str:
            """Type ordered-map values from rendered record lists."""
            values = list(data.values())
            if len(values) > 0 and all(
                isinstance(value, list) and _all_record_shaped(value)
                for value in values
            ):
                resolved_names = [
                    record_name_for_value(value[0])
                    for value in values
                    if isinstance(value, list) and bool(value)
                ]
                match resolved_names:
                    case [str() as record_name, *rest] if all(
                        name == record_name for name in rest
                    ):
                        value_type = f"std::vector<{record_name}>"
                        return (
                            "std::vector<std::pair<std::string, "
                            f"{value_type}>>{{"
                        )
                    case _:
                        pass
            return config.ordered_map_open(data)

        return dataclasses.replace(
            config,
            ordered_map_open=_record_aware_open,
        )

    @cached_property
    def format_ordered_map_entry(self) -> Callable[[str, Value, str], str]:
        """Callable that formats one ordered-map entry.

        The inline JSON document uses JSON's ``": "`` separator; the
        structural forms use braced ``{key, value}`` pairs.
        """
        if self._json_inline_document_active:
            return dict_entry_with_separator(
                separator=": ",
                format_value=passthrough_sequence_entry,
            )
        return braced_dict_entry(format_value=passthrough_sequence_entry)

    @cached_property
    def data_dependent_preamble(
        self,
    ) -> Callable[[Value], tuple[str, ...]]:
        """Build data-dependent preamble lines (variant and ``nullptr``
        headers, plus ``<tuple>`` under the ``TUPLE`` strategy or the
        generated ``struct`` declarations under ``RECORD``).
        """
        if self._json_type_active:
            return no_data_preamble
        if self._record_strategy_active:
            return _build_cpp_record_preamble(
                type_ctx=self._type_ctx,
                record_preamble=self._record_strategy.preamble,
                compute_wrap_ids=(
                    self._record_strategy.behavior.compute_wrap_ids
                ),
                compute_carrier_ids=(
                    self.heterogeneous_behavior.compute_wrap_ids
                ),
                include_tuple_header=False,
                record_shape_names=self.record_shape_names,
                native_only=False,
                map_value_typing=self.record_map_value_typing,
            )
        if self._uses_cpp14_tuple_record_strategy:
            return _build_cpp_record_preamble(
                type_ctx=self._type_ctx,
                record_preamble=self._tuple_record_strategy.preamble,
                compute_wrap_ids=(
                    self._tuple_record_strategy.behavior.compute_wrap_ids
                ),
                compute_carrier_ids=(
                    self.heterogeneous_behavior.compute_wrap_ids
                ),
                include_tuple_header=True,
                record_shape_names=self.record_shape_names,
                native_only=False,
                map_value_typing=self.record_map_value_typing,
            )
        if self._tuple_strategy_active:
            return _build_tuple_preamble(type_ctx=self._type_ctx)
        return _build_variant_preamble(
            type_ctx=self._type_ctx,
            tuple_list_ids=frozenset(),
            record_dict_ids=frozenset(),
        )

    @cached_property
    def heterogeneous_behavior(self) -> HeterogeneousBehavior:
        """Return the heterogeneous-behavior config.

        ``RECORD`` resolves to the shared record behavior (its value
        needs the per-instance renderer, so it cannot be stored on the
        enum member); ``TUPLE`` and ``ERROR`` use their static
        behaviors.
        """
        if self._json_type_active:
            return dataclasses.replace(
                NO_HETEROGENEOUS_BEHAVIOR,
                skip_scalar_checks=True,
            )
        if self._record_strategy_active:
            behavior = self._record_strategy.behavior
        elif self._uses_cpp14_tuple_record_strategy:
            behavior = self._tuple_record_strategy.behavior
        elif self._tuple_strategy_active:
            behavior = _CPP_TUPLE_BEHAVIOR
        else:
            behavior = NO_HETEROGENEOUS_BEHAVIOR
        if self.language_version is self.version_formats.CPP14:
            return _cpp14_explicit_variant_behavior(
                base=behavior,
                type_ctx=self._type_ctx,
            )
        return behavior

    @cached_property
    def format_variable_declaration(
        self,
    ) -> Callable[[str, str, Value, frozenset[enum.Enum]], str]:
        """Callable that formats a new variable declaration.

        Closes over the chosen date/datetime ``type_produced`` so the
        ``const auto*`` vs ``auto`` decision can be driven by the parsed
        :class:`Value` rather than the rendered text.
        """
        if self._json_type_active:

            def _json_formatter(
                name: str,
                value: str,
                data: Value,
                modifiers: frozenset[enum.Enum],
            ) -> str:
                """Render an ``auto``-deduced ``nlohmann::json``
                declaration.

                ``auto`` is used in place of the spelled-out
                ``nlohmann::json`` type so the binding is not analyzed by
                clang-tidy's ``misc-const-correctness`` check (which only
                considers explicitly-typed local variables); the deduced
                type is the same.
                """
                if self._json_inline_document_active:
                    expr = _cpp_nlohmann_json_parse_expression(value)
                else:
                    expr = _cpp_nlohmann_json_value_expression(data, value)
                prefix = _cpp_modifier_prefix(modifiers=modifiers)
                return f"{prefix}auto {name} = {expr};"

            return _json_formatter
        date_type = self._resolved_date_format.value.type_produced
        datetime_type = self._resolved_datetime_format.value.type_produced

        def _formatter(
            name: str,
            value: str,
            data: Value,
            modifiers: frozenset[enum.Enum],
        ) -> str:
            """Adapt :func:`_format_variable_declaration` to the
            positional formatter interface.
            """
            return _format_variable_declaration(
                name=name,
                value=value,
                data=data,
                modifiers=modifiers,
                date_type=date_type,
                datetime_type=datetime_type,
            )

        return _formatter

    @cached_property
    def scalar_preamble(self) -> dict[type, tuple[str, ...]]:
        """Per-instance scalar preamble computed from date/datetime format."""
        if self._json_type_active:
            return {}
        return date_scalar_preamble(
            date_format=self._resolved_date_format,
            datetime_format=self._resolved_datetime_format,
            extra={
                str: ("#include <string>",),
                bytes: ("#include <string>",),
                type(None): ("#include <cstddef>",),
            },
        )

    @cached_property
    def scalar_body_preamble(self) -> dict[type, tuple[str, ...]]:
        """Per-instance scalar body preamble (C++ needs none)."""
        return {}

    @cached_property
    def compute_body_preamble(
        self,
    ) -> Callable[[frozenset[type], Value], tuple[str, ...]]:
        """Compute body-preamble lines from the scalar map."""
        return body_preamble_from_scalars(
            scalar_body_preamble=self.scalar_body_preamble,
            format_lines=tuple,
        )

    @cached_property
    def call_style_config(self) -> CallStyle:
        """Configuration for the chosen call style."""
        return self.call_style.value


register_json_native_document_fast(language_cls=Cpp)
