"""Erlang language specification."""

import dataclasses
import datetime
import enum
import re
import textwrap
from collections.abc import Callable, Sequence
from functools import cached_property
from typing import ClassVar

from beartype import beartype

from literalizer._formatters.collection_openers import (
    fixed_open,
)
from literalizer._formatters.format_dates import (
    format_date_iso,
    format_datetime_epoch,
    format_datetime_iso,
    format_time_iso,
)
from literalizer._formatters.format_entries import (
    assignment_formatter_from_declaration,
    braced_dict_entry,
    dict_entry_with_separator,
    format_bytes_base64,
    passthrough_sequence_entry,
    passthrough_set_entry,
)
from literalizer._formatters.format_floats import (
    format_float_fixed,
    format_float_repr,
    format_float_scientific,
    reject_special_floats,
)
from literalizer._formatters.format_integers import (
    format_integer_binary_erlang,
    format_integer_hex_erlang,
)
from literalizer._formatters.format_strings import (
    make_backslash_string_formatter,
)
from literalizer._json_native_document import (
    register_json_native_document_fast,
)
from literalizer._language import (
    NO_CALL_PARAMETER_LIMIT,
    NO_HETEROGENEOUS_BEHAVIOR,
    NON_KEBAB_REF_CASES,
    BareIntegerWidthStrategies,
    CallParameterShadowing,
    CallStyle,
    CommentConfig,
    DateFormatConfig,
    DateFormatEnum,
    DatetimeFormatConfig,
    DatetimeFormatEnum,
    DeclarationStyleConfig,
    DictFormatConfig,
    FloatSpecialsMixin,
    HeterogeneousBehavior,
    IdentifierCase,
    JsonType,
    LanguageCls,
    ModifierCombination,
    NewVariableNameSyntax,
    OrderedMapFormatConfig,
    PositionalCallStyle,
    RoundTripCapability,
    SequenceFormatConfig,
    SetFormatConfig,
    StubReturn,
    TrailingCommaConfig,
    VariantMetadata,
    body_preamble_from_scalars,
    default_format_call_variable_assignment,
    default_format_call_variable_declaration,
    default_sequence_binding_declarations,
    default_wrap_calls_with_declarations,
    identity_call_arg,
    identity_call_statement,
    identity_constructor_target,
    never_inhibits_consuming_form,
    no_call_binding_body_preamble,
    no_call_binding_file_pragmas,
    no_call_stub,
    no_data_preamble,
    no_format_integer_beyond_i64,
    no_format_integer_widened,
    no_leading_preamble,
    no_type_hint_preamble,
    no_validate_call_arg,
    prepend_body_preamble,
)
from literalizer._statements import (
    insert_before_line_comment,
    line_comment_start,
)
from literalizer._types import Value
from literalizer.exceptions import (
    InvalidModuleNameError,
    UnrepresentableInputError,
    WrapCombinedInFileNotSupportedError,
)

_MAX_ATOM_LENGTH = 255

_format_quoted_string = make_backslash_string_formatter(
    quote_char='"',
    extra_replacements=[
        ("\0", "\\x{0}"),
        ("\x85", "\\x{85}"),
        ("\u2028", "\\x{2028}"),
        ("\u2029", "\\x{2029}"),
    ],
)


@beartype
def _format_string(value: str) -> str:
    """Format an Erlang char-list without illegal non-character tokens."""
    if "\ufffe" in value or "\uffff" in value:
        return (
            f"[{', '.join(str(object=ord(character)) for character in value)}]"
        )
    return _format_quoted_string(value=value)


@beartype
def _format_bytes(value: bytes) -> str:
    """Format bytes as an Erlang binary literal."""
    parts = ", ".join(f"{b}" for b in value)
    return f"<<{parts}>>"


@beartype
def _wrap_utf8_binary(quoted: str) -> str:
    """Wrap an already-double-quoted literal in ``<<".."/utf8>>``.

    Erlang's standard ``json:encode/1`` rejects the default ``"..."``
    string form (a list of code points): map keys would parse as lists
    rather than strings, and string values would emit as arrays of
    integers.  Under the
    ``OTP_JSON`` json_type every textual scalar (strings, ISO date /
    datetime / time strings, base64-encoded bytes) is wrapped in a
    UTF-8 binary literal so the standard ``json`` module accepts the
    rendered value directly.
    """
    return f"<<{quoted}/utf8>>"


@beartype
def _format_string_otp_json(value: str) -> str:
    """Format a string as an Erlang UTF-8 binary literal."""
    if "\ufffe" in value or "\uffff" in value:
        segments = ", ".join(f"{ord(character)}/utf8" for character in value)
        return f"<<{segments}>>"
    return _wrap_utf8_binary(quoted=_format_quoted_string(value=value))


@beartype
def _format_bytes_otp_json(value: bytes) -> str:
    """Format bytes as a base64-encoded UTF-8 binary literal.

    The default :func:`_format_bytes` emits a raw byte binary
    (``<<1, 2, 3>>``), which Erlang's ``json:encode/1`` rejects unless
    the bytes happen to form valid UTF-8.  Base64 is a JSON-safe ASCII
    encoding that round-trips arbitrary bytes through any JSON
    transport.
    """
    return _wrap_utf8_binary(quoted=format_bytes_base64(value=value))


@beartype
def _format_date_otp_json(value: datetime.date) -> str:
    """Format a date as an ISO 8601 UTF-8 binary literal."""
    return _wrap_utf8_binary(quoted=format_date_iso(value=value))


@beartype
def _format_datetime_otp_json(value: datetime.datetime) -> str:
    """Format a datetime as an ISO 8601 UTF-8 binary literal."""
    return _wrap_utf8_binary(quoted=format_datetime_iso(value=value))


@beartype
def _format_time_otp_json(value: datetime.time) -> str:
    """Format a time as an ISO 8601 UTF-8 binary literal."""
    return _wrap_utf8_binary(quoted=format_time_iso(value=value))


@beartype
def _validate_erlang_otp_json_data(*, data: Value) -> None:
    """Reject inputs ``OTP_JSON`` rendering cannot represent.

    Erlang's ``json:encode/1`` map keys must be JSON-encodable
    scalars; under :attr:`Erlang.json_type` the literalizer emits
    every textual scalar as a UTF-8 binary, so non-string keys
    (atoms, integers, tuples) would round-trip as something other
    than the user's original key.  The default Erlang renderer still
    accepts those keys.
    """
    match data:
        case dict():
            for key, value in data.items():
                if not isinstance(key, str):
                    msg = (
                        "Erlang(json_type=OTP_JSON) cannot represent "
                        f"dict key {key!r}: json:encode/1 requires "
                        "string keys."
                    )
                    raise UnrepresentableInputError(msg)
                _validate_erlang_otp_json_data(data=value)
        case list() | set():
            for item in data:
                _validate_erlang_otp_json_data(data=item)
        case _:
            return


@beartype
def _format_variable_declaration(
    name: str,
    value: str,
    _data: Value,
    _modifiers: frozenset[enum.Enum],
) -> str:
    """Format an Erlang variable declaration.

    The trailing ``,`` is Erlang's in-body statement separator so
    multiple declarations can be concatenated (e.g. between ``$ref``
    variable bindings and the following call); :meth:`Erlang.wrap_in_file`
    rewrites the final ``,`` to ``.`` when closing the ``x/0`` clause.
    """
    erlang_name = name[0].upper() + name[1:]
    return f"{erlang_name} = {value},"


@beartype
def _format_date_erlang(value: datetime.date) -> str:
    """Format a date as an Erlang ``{Year, Month, Day}`` tuple."""
    return f"{{{value.year}, {value.month}, {value.day}}}"


@beartype
def _format_datetime_erlang(value: datetime.datetime) -> str:
    """Format a datetime as an Erlang ``{{Y, M, D}, {H, Min, S}}``
    tuple.
    """
    return (
        f"{{{{{value.year}, {value.month}, {value.day}}}, "
        f"{{{value.hour}, {value.minute}, {value.second}}}}}"
    )


_ERLANG_UNQUOTED_ATOM = re.compile(pattern=r"[a-z][A-Za-z0-9_@]*")


@beartype
def _erlang_format_call_target(parts: Sequence[str], /) -> str:
    """Rewrite a call target for Erlang.

    A function name is an atom.  One that does not have the unquoted
    atom shape -- a dotted name like ``app.client.fetch``, a
    capitalized name (which would parse as a variable), or one led by
    an underscore (a wildcard pattern) -- is wrapped in single quotes
    so it still forms a valid atom (issue #3914).
    """
    name = ".".join(parts)
    if _ERLANG_UNQUOTED_ATOM.fullmatch(string=name) is not None:
        return name
    return f"'{name}'"


@beartype
def _erlang_format_call_ref_identifier(
    name: str, _value: Value | None, /
) -> str:
    """Capitalize a ``$ref`` name so it matches the declaration site.

    :func:`_format_variable_declaration` writes ``my_var = ...`` as
    ``My_var = ...`` because Erlang variables must start with an
    uppercase letter; ref arguments need the same transformation or
    they parse as lowercase atoms instead of the bound variable.
    Slicing rather than indexing keeps the empty-name path safe.
    """
    return name[:1].upper() + name[1:]


@beartype
def _erlang_call_stub(
    parts: Sequence[str],
    params: Sequence[str],
    stub_return: StubReturn,
    _args: Sequence[Value],
    /,
) -> tuple[str, ...]:
    """Return an Erlang module-level function stub for a call name.

    Dotted names like ``app.client.fetch`` are emitted as a quoted
    atom so the generated function name is syntactically valid.  A
    single stub is emitted per call name; unused arguments use the
    ``_`` pattern so no per-argument naming is needed.
    """
    body = "undefined"
    if stub_return is StubReturn.VOID:
        body = "ok"
    target = _erlang_format_call_target(parts)
    arg_list = ", ".join("_" for _ in params)
    return (f"{target}({arg_list}) -> {body}.",)


@beartype
@dataclasses.dataclass(frozen=True, kw_only=True)
class Erlang(metaclass=LanguageCls):
    """Erlang language specification.

    Args:
        date_format: Which date format to use.

            * ``date_formats.ISO`` — ISO 8601 string literal,
              e.g. ``"2024-01-15"``.
            * ``date_formats.ERLANG`` — Erlang date tuple,
              e.g. ``{2024, 1, 15}``.

        datetime_format: Which datetime format to use.

            * ``datetime_formats.ISO`` — ISO 8601 string literal,
              e.g. ``"2024-01-15T12:30:00+00:00"``.
            * ``datetime_formats.ERLANG`` — Erlang datetime tuple,
              e.g. ``{{2024, 1, 15}, {12, 30, 0}}``.

        sequence_format: Which Erlang sequence type to use.

            * ``sequence_formats.LIST`` — list literal,
              e.g. ``[1, 2, 3]``.
            * ``sequence_formats.TUPLE`` — tuple literal,
              e.g. ``{1, 2, 3}``.
    """

    immutable_variable_modifiers: ClassVar[frozenset[enum.Enum]] = frozenset()
    wrap_in_file_tolerates_pre_indent = True
    module_name_shares_variable_scope = False
    reserved_variable_identifier_pattern: ClassVar[re.Pattern[str] | None] = (
        None
    )
    reserved_call_parameter_identifiers: ClassVar[frozenset[str]] = frozenset()
    reserved_call_parameter_identifier_pattern: ClassVar[
        re.Pattern[str] | None
    ] = None
    accepts_type_name_call_target = True
    declares_type_name_call_target = True
    dotted_call_root_shares_entrypoint_namespace = True
    reserved_bare_call_target_identifiers: ClassVar[frozenset[str]] = (
        frozenset()
    )
    reserved_call_target_head_identifiers: ClassVar[frozenset[str]] = (
        frozenset()
    )
    contextual_call_target_identifiers: ClassVar[frozenset[str]] = frozenset()
    call_parameter_shadowing = CallParameterShadowing.ALLOWED
    reserved_call_target_keywords_case_sensitive = True
    module_name_must_start_uppercase = False
    new_variable_name_syntax = NewVariableNameSyntax.ASCII
    max_variable_identifier_length: ClassVar[int | None] = None
    call_target_name_syntax: ClassVar[NewVariableNameSyntax | None] = None
    supports_multiline_dict_layout = True
    pools_map_integer_width = True

    format_integer_widened = no_format_integer_widened
    format_integer_beyond_i64 = no_format_integer_beyond_i64
    format_constructor_target: ClassVar["staticmethod[[str], str]"] = (
        staticmethod(identity_constructor_target)
    )
    format_call_variable_declaration = default_format_call_variable_declaration
    format_call_variable_assignment = default_format_call_variable_assignment
    sequence_binding_declarations = default_sequence_binding_declarations
    format_call_binding_body_preamble = no_call_binding_body_preamble
    format_call_binding_file_pragmas = no_call_binding_file_pragmas

    module_name: str = "module"

    leading_preamble = no_leading_preamble
    extension = ".erl"
    pygments_name = "erlang"
    stringifies_nested_collections = False
    supports_special_floats = False
    supports_variable_names = True
    supports_no_variable_wrap_in_file = False
    wraps_data_dependent_preamble_in_body = False
    dict_supports_heterogeneous_values = True
    supports_dotted_calls = True
    has_free_function_calls = True
    reserved_identifiers: ClassVar[frozenset[str]] = frozenset()
    declares_call_parameter_names = True
    reserved_variable_identifiers_case_sensitive: bool = True
    reserved_variable_identifiers: frozenset[str] = frozenset({"_"})
    allows_empty_call_parens = True
    supports_dotted_call_stub = False
    call_returns_expression = True
    supports_json_call_result_binding = False
    supports_zero_parameter_calls = True
    max_call_parameters = NO_CALL_PARAMETER_LIMIT
    supports_inline_multiline_dict_args = True
    supports_standalone_comments_in_wrapped_calls = False
    supports_multi_param_call_wrapper_stub = True
    supports_dict_literal_as_free_expression = True
    reserved_module_identifiers: ClassVar[frozenset[str]] = frozenset(
        {
            "after",
            "and",
            "andalso",
            "band",
            "begin",
            "bnot",
            "bor",
            "bsl",
            "bsr",
            "bxor",
            "case",
            "catch",
            "cond",
            "div",
            "else",
            "end",
            "fun",
            "if",
            "let",
            "maybe",
            "not",
            "of",
            "or",
            "orelse",
            "receive",
            "rem",
            "try",
            "when",
            "xor",
        }
    )
    supports_module_name = True
    supports_empty_dict_key = False
    supports_call_style = True
    supports_default_dict_key_type = False
    supports_default_dict_value_type = False
    supports_default_sequence_element_type = False
    supports_default_set_element_type = False
    supports_default_ordered_map_value_type = False
    json_type_variant_name_suffix: ClassVar[str | None] = None
    supports_non_ascii_string_literals = True
    supports_multiline_string_literals = False
    supports_empty_sibling_sequence_type_hints = True
    supports_typed_dict_open = False
    language_id: ClassVar[str] = "erlang"
    variant_metadata: ClassVar[VariantMetadata] = VariantMetadata(
        round_trip_capabilities=frozenset(
            {
                RoundTripCapability.I64_BOUNDARIES,
                RoundTripCapability.INTERPOLATION_STRINGS,
                RoundTripCapability.EMBEDDED_NUL,
            }
        ),
        modifier_sequence_format_overrides={},
        string_literals_escape_null_byte=True,
        supports_ref_elements_in_tuple_strategy=False,
    )
    supports_record_struct_name_prefix = False
    supports_record_shape_names = False
    record_shape_names_emit_declarations = False
    supports_non_string_dict_keys = True
    checks_raw_control_dict_keys_separately = False

    format_call_arg: ClassVar["staticmethod[[Value, str], str]"] = (
        staticmethod(
            identity_call_arg,
        )
    )
    """Callable that rewrites a formatted direct call argument."""

    class DateFormats(DateFormatEnum):
        """Date format options for Erlang."""

        _value_: DateFormatConfig

        ISO = DateFormatConfig(
            formatter=format_date_iso, type_produced=str, preamble_lines=()
        )
        ERLANG = DateFormatConfig(
            formatter=_format_date_erlang,
            preamble_lines=(),
            type_produced=datetime.date,
        )

    class DatetimeFormats(DatetimeFormatEnum):
        """Datetime format options for Erlang."""

        _value_: DatetimeFormatConfig

        ISO = DatetimeFormatConfig(
            formatter=format_datetime_iso,
            type_produced=str,
            preamble_lines=(),
        )
        ERLANG = DatetimeFormatConfig(
            formatter=_format_datetime_erlang,
            preamble_lines=(),
            type_produced=datetime.datetime,
        )

        EPOCH = DatetimeFormatConfig(
            formatter=format_datetime_epoch,
            type_produced=int,
            preamble_lines=(),
        )

    class BytesFormats(enum.Enum):
        """Bytes formatting options."""

        _value_: Callable[[bytes], str]

        BINARY = enum.member(value=_format_bytes)
        BASE64 = enum.member(value=format_bytes_base64)

        def __call__(self, data: bytes, /) -> str:
            """Format bytes."""
            return self._value_(data)

    class SequenceFormats(enum.Enum):
        """Sequence type options for Erlang."""

        LIST = SequenceFormatConfig(
            sequence_open=fixed_open(open_str="["),
            close="]",
            supports_heterogeneity=True,
            single_element_trailing_comma=False,
            single_element_template=None,
            supports_trailing_comma=False,
            empty_sequence=None,
            preamble_lines=(),
            format_entry=passthrough_sequence_entry,
            typed_opener_fallback=None,
            uses_typed_literal_for_scalars=False,
            requires_uniform_record_shapes=False,
            declared_type=None,
            narrowed_empty_form=None,
        )
        TUPLE = SequenceFormatConfig(
            sequence_open=fixed_open(open_str="{"),
            close="}",
            supports_heterogeneity=True,
            single_element_trailing_comma=False,
            single_element_template=None,
            supports_trailing_comma=False,
            empty_sequence=None,
            preamble_lines=(),
            format_entry=passthrough_sequence_entry,
            typed_opener_fallback=None,
            uses_typed_literal_for_scalars=False,
            requires_uniform_record_shapes=False,
            declared_type=None,
            narrowed_empty_form=None,
        )

    class SetFormats(enum.Enum):
        """Set type options for Erlang."""

        SET = SetFormatConfig(
            set_open=fixed_open(open_str="sets:from_list(["),
            close="])",
            empty_set="sets:from_list([])",
            preamble_lines=(),
            set_opener_template="",
            supports_heterogeneity=True,
            supports_trailing_comma=True,
        )

    class CommentFormats(enum.Enum):
        """Comment style options."""

        PERCENT = CommentConfig(
            prefix="%",
            suffix="",
        )

    class DeclarationStyles(enum.Enum):
        """Declaration style options."""

        ASSIGN = DeclarationStyleConfig(
            formatter=_format_variable_declaration,
            supports_redefinition=False,
        )

    class DictEntryStyles(enum.Enum):
        """Dict entry style options."""

        DEFAULT = enum.auto()

    class DictFormats(enum.Enum):
        """Dict/map format options."""

        DEFAULT = enum.auto()

    class EmptyDictKey(enum.Enum):
        """Empty dict key options."""

        ALLOW = enum.auto()

    class FloatFormats(
        FloatSpecialsMixin,
        enum.Enum,
        positive_infinity="inf",
        negative_infinity="'-inf'",
        nan="nan",
    ):
        """Float format options."""

        REPR = enum.member(value=format_float_repr)
        SCIENTIFIC = enum.member(value=format_float_scientific)
        FIXED = enum.member(value=format_float_fixed)

    class IntegerFormats(enum.Enum):
        """Integer format options."""

        DECIMAL = enum.member(value=str)
        HEX = enum.member(value=format_integer_hex_erlang)
        BINARY = enum.member(value=format_integer_binary_erlang)

        def __call__(self, value: int, /) -> str:
            """Format an integer."""
            formatter: Callable[[int], str] = self.value
            return formatter(value)

    class NumericLiteralSuffixes(enum.Enum):
        """Numeric literal suffix options."""

        NONE = enum.auto()

    class NumericSeparators(enum.Enum):
        """Numeric separator options."""

        NONE = enum.auto()

    class NumericStyles(enum.Enum):
        """Numeric literal style options."""

        OVERLOADED = enum.auto()

    class StringFormats(enum.Enum):
        """String format options."""

        DOUBLE = enum.auto()

    class TrailingCommas(enum.Enum):
        """Trailing comma options."""

        NO = TrailingCommaConfig(multiline_trailing_comma=False)

    date_formats = DateFormats
    datetime_formats = DatetimeFormats
    bytes_formats = BytesFormats
    sequence_formats = SequenceFormats
    set_formats = SetFormats
    comment_formats = CommentFormats

    class VariableTypeHints(enum.Enum):
        """Variable type hint options."""

        NEVER = enum.auto()
        SAFE = enum.auto()

    variable_type_hints_formats = VariableTypeHints
    declaration_styles = DeclarationStyles
    dict_entry_styles = DictEntryStyles
    dict_formats = DictFormats
    empty_dict_keys = EmptyDictKey
    float_formats = FloatFormats
    integer_formats = IntegerFormats
    integer_width_strategies = BareIntegerWidthStrategies
    numeric_literal_suffixes = NumericLiteralSuffixes
    numeric_separators = NumericSeparators
    numeric_styles = NumericStyles
    string_formats = StringFormats
    trailing_commas = TrailingCommas

    class StatementTerminatorStyles(enum.Enum):
        """Statement terminator options."""

        SEMICOLON = enum.auto()

    statement_terminator_styles = StatementTerminatorStyles

    class CallStyles(enum.Enum):
        """Erlang call style options."""

        POSITIONAL = PositionalCallStyle(
            arg_separator=", ", parenthesize_each_arg=False
        )

    call_styles = CallStyles

    class Modifiers(enum.Enum):
        """C++/Java/C#-style declaration modifiers: this language has none."""

    modifiers = Modifiers

    class HeterogeneousStrategies(enum.Enum):
        """Heterogeneous-scalar strategy options — this language only
        supports raising.
        """

        ERROR = NO_HETEROGENEOUS_BEHAVIOR

    heterogeneous_strategies = HeterogeneousStrategies

    class BoolFormats(enum.Enum):
        """Empty: this language has no alternative boolean formats."""

    bool_formats = BoolFormats

    class VersionFormats(enum.Enum):
        """Version options for Erlang."""

        OTP_25 = enum.auto()

    version_formats = VersionFormats

    class JsonTypes(JsonType):
        """JSON value type options for Erlang."""

        OTP_JSON = enum.auto()
        """Erlang's built-in ``json`` module (``OTP_27`` and later).

        Renders strings, ISO dates / datetimes / times, and bytes
        (base64-encoded) as UTF-8 binary literals so
        ``json:encode/1`` accepts the value directly.  Null is emitted
        as the bare atom ``null``; sets render as JSON arrays.  Dict
        keys must be strings (validated upfront).
        """

    json_types = JsonTypes

    module_name_case: ClassVar[IdentifierCase] = IdentifierCase.SNAKE

    modifier_combinations: ClassVar[tuple[ModifierCombination, ...]] = ()
    identifier_cases: ClassVar[tuple[IdentifierCase, ...]] = (
        IdentifierCase.SNAKE,
    )
    supported_ref_cases: ClassVar[frozenset[IdentifierCase]] = (
        NON_KEBAB_REF_CASES
    )

    def __post_init__(self) -> None:
        """Validate that the module name is an unquoted Erlang atom."""
        if (
            len(self.module_name) <= _MAX_ATOM_LENGTH
            and re.fullmatch(
                pattern=r"[a-z][A-Za-z0-9_@]*",
                string=self.module_name,
            )
            is not None
        ):
            return
        raise InvalidModuleNameError(
            language_name=type(self).__name__,
            module_name=self.module_name,
        )

    @cached_property
    def validate_call_arg(self) -> Callable[[Value], None]:
        """Return call-argument validation for this language."""
        return no_validate_call_arg

    @cached_property
    def format_call_statement(self) -> Callable[[str], str]:
        """Return call-statement formatting for this language."""
        return identity_call_statement

    wrap_calls_with_declarations = default_wrap_calls_with_declarations

    def wrap_in_file(
        self,
        content: str,
        variable_name: str,
        body_preamble: tuple[str, ...],
    ) -> str:
        """Wrap an Erlang snippet in a module function.

        For the variable form, *body_preamble* lines are prepended
        inside ``x()`` and the function returns the bound variable.
        For the call form (empty *variable_name*), *body_preamble*
        lines are treated as module-level function definitions
        placed between ``-export`` and ``x()``; the call statements
        in *content* are terminated with ``,`` via
        :attr:`statement_terminator` and the trailing ``,`` is
        rewritten to ``.`` so ``x()`` ends on a valid clause.
        """
        if variable_name != "":
            body = prepend_body_preamble(
                content=content,
                body_preamble=body_preamble,
            )
            erlang_varname = variable_name[0].upper() + variable_name[1:]
            indented = textwrap.indent(text=body, prefix=self.indent)
            return (
                f"-module({self.module_name}).\n"
                f"-export([x/0]).\n"
                f"x() ->\n"
                f"{indented}\n"
                f"{self.indent}{erlang_varname}."
            )
        # The clause terminator replaces the last statement's separator,
        # which sits before any inline comment on that line rather than
        # at the end of it (issue #4664).
        stripped = content.rstrip()
        comment_start = line_comment_start(
            line=stripped.rsplit(sep="\n", maxsplit=1)[-1],
            quotes='"',
            line_comment_prefixes=("%",),
        )
        head, _, last = stripped.rpartition("\n")
        code = last[:comment_start].rstrip()
        gap = last[len(code) : comment_start]
        trimmed_last = f"{code.removesuffix(',')}{gap}{last[comment_start:]}"
        trimmed = trimmed_last
        if head != "":
            trimmed = f"{head}\n{trimmed_last}"
        indented = textwrap.indent(text=trimmed, prefix=self.indent)
        parts = [f"-module({self.module_name}).", "-export([x/0])."]
        parts.extend(body_preamble)
        parts.append("x() ->")
        parts.append(
            insert_before_line_comment(
                statement=indented,
                text=".",
                quotes='"',
                line_comment_prefixes=("%",),
            )
        )
        return "\n".join(parts)

    def wrap_call_variable_in_file(
        self,
        content: str,
        variable_name: str,
        body_preamble: tuple[str, ...],
    ) -> str:
        """Wrap a call-result variable binding in an Erlang module.

        :meth:`wrap_in_file`'s variable branch places *body_preamble*
        inside ``x()``, but for a call binding those lines are the
        module-level stub function definitions emitted by
        :func:`_erlang_call_stub`; nesting a function definition inside
        the ``x/0`` clause is a syntax error.  This hook hoists
        *body_preamble* to module scope between ``-export`` and ``x()``
        (matching the call-without-binding branch of
        :meth:`wrap_in_file`) while keeping the
        ``My_data = make_widget(...)`` binding and the trailing
        ``My_data.`` return inside ``x()``.
        """
        erlang_varname = variable_name[0].upper() + variable_name[1:]
        indented = textwrap.indent(text=content, prefix=self.indent)
        parts = [f"-module({self.module_name}).", "-export([x/0])."]
        parts.extend(body_preamble)
        parts.append("x() ->")
        parts.append(indented)
        parts.append(f"{self.indent}{erlang_varname}.")
        return "\n".join(parts)

    @staticmethod
    def wrap_combined_in_file(
        declaration: str,
        assignment: str,
        variable_name: str,
        body_preamble: tuple[str, ...],
    ) -> str:
        """Unsupported: literalize() rejects BothVariableForms
        upstream.
        """
        del declaration, assignment, variable_name, body_preamble
        raise WrapCombinedInFileNotSupportedError

    date_format: DateFormats = DateFormats.ISO
    datetime_format: DatetimeFormats = DatetimeFormats.ISO
    bytes_format: BytesFormats = BytesFormats.BINARY
    sequence_format: SequenceFormats = SequenceFormats.LIST
    set_format: SetFormats = SetFormats.SET
    variable_type_hints: VariableTypeHints = VariableTypeHints.NEVER
    comment_format: CommentFormats = CommentFormats.PERCENT
    declaration_style: DeclarationStyles = DeclarationStyles.ASSIGN
    dict_entry_style: DictEntryStyles = DictEntryStyles.DEFAULT
    dict_format: DictFormats = DictFormats.DEFAULT
    float_format: FloatFormats = FloatFormats.REPR
    integer_format: IntegerFormats = IntegerFormats.DECIMAL
    integer_width_strategy: BareIntegerWidthStrategies = (
        BareIntegerWidthStrategies.BARE
    )
    numeric_literal_suffix: NumericLiteralSuffixes = (
        NumericLiteralSuffixes.NONE
    )
    numeric_separator: NumericSeparators = NumericSeparators.NONE
    numeric_style: NumericStyles = NumericStyles.OVERLOADED
    string_format: StringFormats = StringFormats.DOUBLE
    trailing_comma: TrailingCommas = TrailingCommas.NO
    call_style: CallStyles = CallStyles.POSITIONAL
    statement_terminator_style: StatementTerminatorStyles = (
        StatementTerminatorStyles.SEMICOLON
    )
    heterogeneous_strategy: HeterogeneousStrategies = (
        HeterogeneousStrategies.ERROR
    )
    language_version: VersionFormats = VersionFormats.OTP_25
    json_type: JsonTypes | None = None
    indent: str = "    "

    true_literal: ClassVar[str] = "true"
    false_literal: ClassVar[str] = "false"
    indent_closing_delimiter: ClassVar[bool] = False
    element_separator: ClassVar[str] = ", "
    skip_null_dict_values: ClassVar[bool] = False
    supports_collection_comments: ClassVar[bool] = True
    supports_scalar_before_comments: ClassVar[bool] = False
    supports_scalar_inline_comments: ClassVar[bool] = False
    statement_terminator: ClassVar[str] = ","
    static_preamble: ClassVar[Sequence[str]] = ()
    static_body_preamble: ClassVar[Sequence[str]] = ()
    special_float_preamble: ClassVar[tuple[str, ...]] = ()

    @cached_property
    def _json_type_active(self) -> bool:
        """``True`` when ``OTP_JSON`` rendering is selected."""
        return self.json_type is not None

    @cached_property
    def null_literal(self) -> str:
        """Null literal: ``null`` under ``OTP_JSON``, ``undefined``
        otherwise.

        Erlang's ``json:encode/1`` rejects the bare atom ``undefined``
        (it is not in the documented set of accepted scalars) but
        encodes ``null`` as JSON ``null``.
        """
        if self._json_type_active:
            return "null"
        return "undefined"

    def validate_spec_for_data(self, data: Value) -> None:
        """Validate Erlang-specific data/format combinations.

        Under :attr:`json_type` every dict key must be a string so the
        rendered map keys (UTF-8 binaries) match what Erlang's
        ``json:encode/1`` expects.
        """
        if self._json_type_active:
            _validate_erlang_otp_json_data(data=data)

    @cached_property
    def format_string(self) -> Callable[[str], str]:
        """Format a string value as a quoted literal."""
        if self._json_type_active:
            return _format_string_otp_json
        return _format_string

    @cached_property
    def format_sequence_entry(self) -> Callable[[Value, str], str]:
        """Format a sequence entry."""
        return passthrough_sequence_entry

    @cached_property
    def format_set_entry(self) -> Callable[[Value, str], str]:
        """Format a set entry."""
        return passthrough_set_entry

    @cached_property
    def format_variable_assignment(self) -> Callable[[str, str, Value], str]:
        """Format an assignment to an existing variable."""
        return assignment_formatter_from_declaration(
            formatter=_format_variable_declaration,
        )

    @cached_property
    def data_dependent_preamble(self) -> Callable[[Value], tuple[str, ...]]:
        """Return data-dependent preamble lines."""
        return no_data_preamble

    @cached_property
    def heterogeneous_behavior(self) -> HeterogeneousBehavior:
        """Return the heterogeneous-behavior config."""
        return self.heterogeneous_strategy.value

    @cached_property
    def call_data_dependent_preamble(
        self,
    ) -> Callable[[Value], tuple[str, ...]]:
        """Return data-dependent preamble lines for call rendering."""
        return self.data_dependent_preamble

    @cached_property
    def type_hint_collection_preamble_lines(
        self,
    ) -> Callable[[frozenset[type]], tuple[str, ...]]:
        """Return preamble lines for empty-collection type hints."""
        return no_type_hint_preamble

    @cached_property
    def call_style_config(self) -> CallStyle:
        """Configuration for Erlang's call style."""
        return self.call_style.value

    @cached_property
    def format_call_stub(
        self,
    ) -> Callable[
        [Sequence[str], Sequence[str], StubReturn, Sequence[Value]],
        tuple[str, ...],
    ]:
        """Return stub declarations for a call expression."""
        return _erlang_call_stub

    @cached_property
    def format_call_preamble_stub(
        self,
    ) -> Callable[
        [Sequence[str], Sequence[str], StubReturn, Sequence[Value]],
        tuple[str, ...],
    ]:
        """Return file-scope stubs for a call expression."""
        return no_call_stub

    @cached_property
    def format_call_target(self) -> Callable[[Sequence[str]], str]:
        """Rewrite a dotted call target into the language's call
        syntax.
        """
        return _erlang_format_call_target

    @cached_property
    def format_call_ref_identifier(
        self,
    ) -> Callable[[str, Value | None], str]:
        """Capitalize a ``{"$ref": "name"}`` identifier so the call
        site references the declared Erlang variable.
        """
        return _erlang_format_call_ref_identifier

    @cached_property
    def format_call_arg_ref_identifier(
        self,
    ) -> Callable[[str, Value | None], str]:
        """Rewrite a ``{"$ref": "name"}`` identifier in a call-argument
        context.

        Delegates to :attr:`format_call_ref_identifier`.  Override this to
        allow call-argument ``$ref`` values that would otherwise be rejected.
        """
        return self.format_call_ref_identifier

    @cached_property
    def format_call_arg_ref_identifier_consumable(
        self,
    ) -> Callable[[str, Value | None], str]:
        """Format a ``$ref`` the caller authorized as consumable.

        Delegates to :attr:`format_call_arg_ref_identifier`.  Override
        this to opt into a consuming form (e.g. C++ ``std::move``).
        """
        return self.format_call_arg_ref_identifier

    @cached_property
    def consumable_ref_value_inhibits_consuming_form(
        self,
    ) -> Callable[[Value], bool]:
        """Predicate deciding whether a ref's underlying value type
        inhibits the consume form.

        Delegates to :data:`never_inhibits_consuming_form`.  Languages
        whose consume operator rejects certain value types (notably
        the Mojo ``^`` on register-trivial scalars) override this.
        """
        return never_inhibits_consuming_form

    @cached_property
    def sequence_format_config(self) -> SequenceFormatConfig:
        """Configuration for the chosen sequence format."""
        return self.sequence_format.value

    @cached_property
    def set_format_config(self) -> SetFormatConfig:
        """Configuration for the chosen set format."""
        if self._json_type_active:
            # Erlang's ``json:encode/1`` has no set type: render sets
            # as JSON arrays (Erlang lists) the same as sequences.
            return dataclasses.replace(
                self.set_format.value,
                set_open=fixed_open(open_str="["),
                close="]",
                empty_set="[]",
            )
        return self.set_format.value

    @cached_property
    def sequence_open(self) -> Callable[[list[Value]], str]:
        """Callable that returns the opening delimiter for a sequence."""
        return self.sequence_format.value.sequence_open

    @cached_property
    def dict_format_config(self) -> DictFormatConfig:
        """Configuration for dict formatting."""
        return DictFormatConfig(
            dict_open=fixed_open(open_str="#{"),
            close="}",
            format_entry=dict_entry_with_separator(
                separator=" => ",
                format_value=passthrough_sequence_entry,
            ),
            empty_dict=None,
            preamble_lines=(),
            narrowed_open=None,
            supports_trailing_comma=True,
            narrowed_empty_form=None,
        )

    @cached_property
    def trailing_comma_config(self) -> TrailingCommaConfig:
        """Configuration for trailing-comma behavior."""
        return self.trailing_comma.value

    @cached_property
    def format_bytes(self) -> Callable[[bytes], str]:
        """Callable that formats a bytes value as a string literal."""
        if self._json_type_active:
            return _format_bytes_otp_json
        return self.bytes_format

    @cached_property
    def format_date(self) -> Callable[[datetime.date], str]:
        """Callable that formats a date as a string literal."""
        if self._json_type_active:
            return _format_date_otp_json
        return self.date_format

    @cached_property
    def format_datetime(self) -> Callable[[datetime.datetime], str]:
        """Callable that formats a datetime as a string literal."""
        if self._json_type_active:
            return _format_datetime_otp_json
        return self.datetime_format

    @cached_property
    def format_time(self) -> Callable[[datetime.time], str]:
        """Callable that formats a time as a string literal."""
        if self._json_type_active:
            return _format_time_otp_json
        return format_time_iso

    @cached_property
    def format_float(self) -> Callable[[float], str]:
        """Callable that formats a float value as a literal."""
        return reject_special_floats(
            formatter=self.float_format,
            language_name="Erlang",
        )

    @cached_property
    def format_integer(self) -> Callable[[int], str]:
        """Callable that formats an int value as a literal."""
        return self.integer_format

    @cached_property
    def comment_config(self) -> CommentConfig:
        """Configuration for the language's comment syntax."""
        return self.comment_format.value

    @cached_property
    def ordered_map_format_config(self) -> OrderedMapFormatConfig:
        """Configuration for ordered-map formatting."""
        return OrderedMapFormatConfig(
            ordered_map_open=fixed_open(open_str="["),
            close="]",
            preamble_lines=(),
        )

    @cached_property
    def format_ordered_map_entry(self) -> Callable[[str, Value, str], str]:
        """Callable that formats one ordered-map entry."""
        return braced_dict_entry(format_value=passthrough_sequence_entry)

    @cached_property
    def format_variable_declaration(
        self,
    ) -> Callable[[str, str, Value, frozenset[enum.Enum]], str]:
        """Callable that formats a new variable declaration."""
        return self.declaration_style.value.formatter

    @cached_property
    def scalar_preamble(self) -> dict[type, tuple[str, ...]]:
        """Per-instance scalar preamble (Erlang needs none)."""
        return {}

    @cached_property
    def scalar_body_preamble(self) -> dict[type, tuple[str, ...]]:
        """Per-instance scalar body preamble (Erlang needs none)."""
        return {}

    @cached_property
    def compute_body_preamble(
        self,
    ) -> Callable[[frozenset[type], Value], tuple[str, ...]]:
        """Compute body-preamble lines from the scalar map."""
        return body_preamble_from_scalars(
            scalar_body_preamble=self.scalar_body_preamble,
            format_lines=tuple,
        )


register_json_native_document_fast(language_cls=Erlang)
