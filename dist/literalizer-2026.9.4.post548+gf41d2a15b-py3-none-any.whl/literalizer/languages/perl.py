"""Perl language specification."""

import dataclasses
import datetime
import enum
import math
import re
from collections.abc import Callable, Sequence
from functools import cached_property
from types import MappingProxyType
from typing import ClassVar

from beartype import beartype

from literalizer._checks import (
    reject_null_dict_keys,
    reject_stringified_dict_key_collisions,
)
from literalizer._formatters.collection_openers import (
    fixed_open,
)
from literalizer._formatters.format_dates import (
    date_ymd_formatter,
    format_date_iso,
    format_datetime_epoch,
    format_datetime_iso,
    format_time_iso,
    normalize_datetime_utc,
)
from literalizer._formatters.format_entries import (
    dict_entry_with_separator,
    format_bytes_base64,
    format_bytes_hex,
    passthrough_sequence_entry,
    passthrough_set_entry,
    variable_declaration_formatter,
    variable_formatter,
)
from literalizer._formatters.format_floats import (
    format_float_fixed,
    format_float_repr,
    format_float_scientific,
)
from literalizer._formatters.format_integers import (
    data_has_int_outside_range,
    format_integer_binary,
    format_integer_hex,
    format_integer_octal_c_style,
    format_integer_underscore,
    make_overflow_fallback_formatter,
)
from literalizer._formatters.format_strings import (
    format_string_backslash,
    format_string_backslash_single_minimal,
)
from literalizer._language import (
    NO_CALL_PARAMETER_LIMIT,
    NO_HETEROGENEOUS_BEHAVIOR,
    NON_KEBAB_REF_CASES,
    CallParameterShadowing,
    CallStyle,
    CommentConfig,
    DateFormatConfig,
    DateFormatEnum,
    DatetimeFormatConfig,
    DatetimeFormatEnum,
    DeclarationStyleConfig,
    DictFormatConfig,
    FloatSpecialsMixin,
    HeterogeneousBehavior,
    IdentifierCase,
    JsonType,
    LanguageCls,
    ModifierCombination,
    NewVariableNameSyntax,
    OrderedMapFormatConfig,
    PositionalCallStyle,
    RoundTripCapability,
    SequenceFormatConfig,
    SetFormatConfig,
    StubReturn,
    TrailingCommaConfig,
    VariantMetadata,
    body_preamble_from_scalars,
    date_scalar_preamble,
    default_format_call_variable_assignment,
    default_format_call_variable_declaration,
    default_sequence_binding_declarations,
    default_wrap_calls_with_declarations,
    identity_call_arg,
    identity_call_statement,
    identity_call_target,
    identity_constructor_target,
    never_inhibits_consuming_form,
    no_call_binding_body_preamble,
    no_call_binding_file_pragmas,
    no_call_stub,
    no_format_integer_beyond_i64,
    no_format_integer_widened,
    no_leading_preamble,
    no_type_hint_preamble,
    no_validate_call_arg,
    wrap_combined_in_file_noop,
    wrap_in_file_noop,
)
from literalizer._types import Value

_TRAILING_LINE_WHITESPACE = re.compile(pattern=r"[ \t]+(?=\n)")


_PERL_MIN_NORMAL_FLOAT = float.fromhex("0x1.0p-1022")


@beartype
def _format_perl_float_fixed(value: float) -> str:
    """Keep tiny fixed-point values within Perl's token limit."""
    magnitude = abs(value)
    if 0 < magnitude <= _PERL_MIN_NORMAL_FLOAT:
        return format_float_scientific(value=value)
    return format_float_fixed(value=value)


@beartype
def _format_perl_string_multiline(value: str) -> str:
    r"""Format *value* as a non-interpolating multiline Perl literal."""
    if (
        "\r" in value
        or "\0" in value
        or _TRAILING_LINE_WHITESPACE.search(string=value) is not None
    ):
        return _format_perl_string_double(value=value)
    return format_string_backslash_single_minimal(value=value)


@beartype
def _format_perl_string_single(value: str) -> str:
    """Fall back when a single-quoted source literal is not exact."""
    if "\0" in value or "\r" in value:
        return _format_perl_string_double(value=value)
    return format_string_backslash_single_minimal(value=value)


@beartype
def _perl_call_stub(
    parts: Sequence[str],
    _params: Sequence[str],
    _stub_return: StubReturn,
    _args: Sequence[Value],
    /,
) -> tuple[str, ...]:
    """Return Perl stub declarations for a call name.

    Perl's ``.`` is string concatenation, so a dotted target such as
    ``app.client.fetch("hello")`` parses as
    ``app() . client() . fetch("hello")`` when each name is a
    declared subroutine.  Declaring one empty ``sub`` per dotted part
    makes the expression compile cleanly.
    """
    return tuple(f"sub {part} {{}}" for part in parts)


@beartype
def _perl_format_call_ref_identifier(
    name: str, _value: Value | None, /
) -> str:
    """Prepend Perl's scalar ``$`` sigil to a ``$ref`` identifier."""
    return f"${name}"


_PERL_NV_INT_MIN = -(2**53)
_PERL_NV_INT_MAX = 2**53
_PERL_NV_EXACT_INTEGER_MAX = float(2**53)


@beartype
def _perl_math_bigfloat_preamble(data: Value, /) -> tuple[str, ...]:
    """Import ``Math::BigFloat`` when a large finite float needs it."""
    pending = [data]
    while len(pending) > 0:
        value = pending.pop()
        match value:
            case float() if (
                math.isfinite(value)
                and abs(value) >= _PERL_NV_EXACT_INTEGER_MAX
            ):
                return ("use Math::BigFloat;",)
            case dict():
                pending.extend(value.keys())
                pending.extend(value.values())
            case list() | set():
                pending.extend(value)
            case _:
                continue
    return ()


@beartype
def _format_perl_math_bigint_literal(value: int) -> str:
    """Format an integer as a Perl ``Math::BigInt->new("...")`` call.

    Used by the ``MATH_BIG_INT`` integer-width strategy for values
    outside the 53-bit range where Perl's default scalar (an NV float)
    silently loses precision.
    """
    return f'Math::BigInt->new("{value}")'


@beartype
def _perl_math_bigint_preamble(data: Value, /) -> tuple[str, ...]:
    """Return ``use Math::BigInt;`` if *data* contains an integer whose
    magnitude exceeds Perl's NV mantissa precision (2**53).
    """
    if data_has_int_outside_range(
        data=data,
        min_value=_PERL_NV_INT_MIN,
        max_value=_PERL_NV_INT_MAX,
    ):
        return ("use Math::BigInt;",)
    return ()


@beartype
def _format_perl_string_double(value: str) -> str:
    r"""Perl double-quoted string with non-ASCII escaped as ``\x{...}``.

    Without this, a non-ASCII character is emitted as its raw UTF-8
    bytes, which Perl decodes as Latin-1 unless the file declares
    ``use utf8;`` -- garbling any later encoding step.  The escape form
    keeps the output pure ASCII so the snippet round-trips regardless
    of source-file encoding.
    """
    base = (
        format_string_backslash(value=value)
        .replace("$", r"\$")
        .replace("@", r"\@")
        .replace("\0", r"\x{0}")
    )
    if base.isascii():
        return base
    collected_entries: list[str] = []
    for entry_char in base:
        effective_entry_char = entry_char
        if not effective_entry_char.isascii():
            effective_entry_char = f"\\x{{{ord(entry_char):x}}}"
        collected_entries.append(effective_entry_char)
    return "".join(collected_entries)


@beartype
def _format_perl_string_double_utf8(value: str) -> str:
    r"""Perl double-quoted string with non-ASCII emitted literally.

    Paired with a ``use utf8;`` preamble (see
    :func:`_perl_use_utf8_preamble`) so Perl decodes the source as
    UTF-8 and each non-ASCII character becomes one Unicode character
    rather than its raw byte sequence.  Matches the style a human Perl
    author would write in a UTF-8 source file.
    """
    return (
        format_string_backslash(value=value)
        .replace("$", r"\$")
        .replace("@", r"\@")
        .replace("\0", r"\x{0}")
    )


@beartype
def _data_has_non_ascii_string(*, data: Value) -> bool:
    """Return ``True`` if *data* contains a string with non-ASCII text.

    Descends into lists, sets, and both dict keys and values.  Used by
    the ``DOUBLE_UTF8`` string format to decide whether the
    ``use utf8;`` pragma needs to be added to the file preamble.
    """
    match data:
        case str():
            return not data.isascii()
        case list() | set():
            return any(_data_has_non_ascii_string(data=item) for item in data)
        case dict():
            return any(
                _data_has_non_ascii_string(data=item)
                for entry in data.items()
                for item in entry
            )
        case _:
            return False


@beartype
def _perl_use_utf8_preamble(data: Value, /) -> tuple[str, ...]:
    """Return ``use utf8;`` if *data* contains any non-ASCII string."""
    if _data_has_non_ascii_string(data=data):
        return ("use utf8;",)
    return ()


@beartype
def _format_datetime_perl(value: datetime.datetime) -> str:
    """Format a datetime as a Perl ``DateTime`` constructor."""
    if value.tzinfo is not None:
        value = normalize_datetime_utc(value=value, language_name="Perl")
    parts = (
        f"DateTime->new(year => {value.year}, "
        f"month => {value.month}, day => {value.day}, "
        f"hour => {value.hour}, minute => {value.minute}, "
        f"second => {value.second}"
    )
    if value.microsecond != 0:
        parts += f", nanosecond => {value.microsecond * 1000}"
    return parts + ", time_zone => 'UTC')"


@beartype
@dataclasses.dataclass(frozen=True)
class _BoolFormatConfig:
    """Configuration for a single Perl boolean format."""

    true_literal: str
    false_literal: str
    preamble_lines: tuple[str, ...]


@beartype
@dataclasses.dataclass(frozen=True, kw_only=True)
class Perl(metaclass=LanguageCls):
    r"""Perl language specification.

    Args:
        date_format: How to format :class:`datetime.date` values.

            * ``date_formats.PERL`` -- ``DateTime->new(...)`` call,
              e.g. ``DateTime->new(year => 2024, month => 1, day => 15)``.
            * ``date_formats.ISO`` -- ISO 8601 quoted string,
              e.g. ``"2024-01-15"``.

        datetime_format: How to format :class:`datetime.datetime` values.

            * ``datetime_formats.PERL`` -- ``DateTime->new(...)`` call,
              e.g. ``DateTime->new(year => 2024, month => 1, day => 15,
              hour => 12, minute => 30, second => 0,
              time_zone => 'UTC')``.
            * ``datetime_formats.ISO`` -- ISO 8601 quoted string,
              e.g. ``"2024-01-15T12:30:00+00:00"``.

        bool_format: How to format :class:`bool` values.  Perl has no
            native boolean type, so the choice trades off readability
            against round-trip fidelity through JSON and YAML libraries.

            * ``bool_formats.INTEGER`` -- bare ``1`` / ``0``. Re-encoding
              to JSON loses the boolean type.
            * ``bool_formats.JSON_PP_REF`` -- ``\1`` / ``\0`` scalar
              references, the conventional form used by ``JSON::PP``,
              ``JSON::XS``, ``Cpanel::JSON::XS`` and ``Mojo::JSON``.
              Round-trips back to JSON ``true`` / ``false`` with no
              ``use`` preamble required.
            * ``bool_formats.JSON_PP_SINGLETON`` (default) --
              ``JSON::PP::true`` /
              ``JSON::PP::false`` blessed singletons; adds a
              ``use JSON::PP;`` preamble (``JSON::PP`` is a core
              module).

            Only boolean *values* round-trip; Perl coerces every hash
            key to a string, so a boolean dict key cannot preserve any
            non-string representation regardless of ``bool_format``.

        string_format: How to format :class:`str` values.

            * ``string_formats.DOUBLE`` (default) -- double-quoted with
              every non-ASCII character escaped as ``\x{HHHH}``.  The
              output is pure ASCII and round-trips regardless of the
              surrounding source-file encoding.
            * ``string_formats.DOUBLE_UTF8`` -- double-quoted with
              non-ASCII characters emitted literally; contributes
              ``use utf8;`` to the file preamble whenever the
              literalized value contains a non-ASCII string, so Perl
              decodes the source as UTF-8.  Matches the style a human
              Perl author would write in a UTF-8 source file.
            * ``string_formats.SINGLE`` -- single-quoted, with only
              ``\\`` and ``\'`` recognized as escapes.  Non-ASCII
              characters are emitted literally and contribute
              ``use utf8;`` to the file preamble.
    """

    reserved_module_identifiers: ClassVar[frozenset[str]] = frozenset()
    immutable_variable_modifiers: ClassVar[frozenset[enum.Enum]] = frozenset()
    wrap_in_file_tolerates_pre_indent = True
    module_name_shares_variable_scope = False
    reserved_variable_identifier_pattern: ClassVar[re.Pattern[str] | None] = (
        None
    )
    reserved_call_parameter_identifiers: ClassVar[frozenset[str]] = frozenset()
    reserved_call_parameter_identifier_pattern: ClassVar[
        re.Pattern[str] | None
    ] = None
    accepts_type_name_call_target = True
    declares_type_name_call_target = True
    dotted_call_root_shares_entrypoint_namespace = True
    reserved_bare_call_target_identifiers: ClassVar[frozenset[str]] = (
        frozenset()
    )
    reserved_call_target_head_identifiers: ClassVar[frozenset[str]] = (
        frozenset()
    )
    contextual_call_target_identifiers: ClassVar[frozenset[str]] = frozenset()
    call_parameter_shadowing = CallParameterShadowing.ALLOWED
    reserved_call_target_keywords_case_sensitive = True
    module_name_must_start_uppercase = False
    new_variable_name_syntax = NewVariableNameSyntax.ASCII
    max_variable_identifier_length: ClassVar[int | None] = None
    call_target_name_syntax: ClassVar[NewVariableNameSyntax | None] = None
    supports_multiline_dict_layout = True
    pools_map_integer_width = True

    format_integer_widened = no_format_integer_widened
    format_integer_beyond_i64 = no_format_integer_beyond_i64
    format_constructor_target: ClassVar["staticmethod[[str], str]"] = (
        staticmethod(identity_constructor_target)
    )
    format_call_variable_declaration = default_format_call_variable_declaration
    format_call_variable_assignment = default_format_call_variable_assignment
    sequence_binding_declarations = default_sequence_binding_declarations
    format_call_binding_body_preamble = no_call_binding_body_preamble
    format_call_binding_file_pragmas = no_call_binding_file_pragmas

    leading_preamble = no_leading_preamble
    extension = ".pl"
    pygments_name = "perl"
    stringifies_nested_collections = False
    supports_special_floats = True
    supports_variable_names = True
    supports_no_variable_wrap_in_file = True
    wraps_data_dependent_preamble_in_body = False
    dict_supports_heterogeneous_values = True
    supports_dotted_calls = True
    has_free_function_calls = True
    reserved_identifiers: ClassVar[frozenset[str]] = frozenset()
    declares_call_parameter_names = True
    reserved_variable_identifiers_case_sensitive: bool = True
    reserved_variable_identifiers: frozenset[str] = frozenset(
        {
            "_",
            "BEGIN",
            "ARGV",
            "ENV",
            "INC",
            "SIG",
            "STDIN",
            "STDOUT",
            "STDERR",
            "CHECK",
            "CORE",
            "END",
            "INIT",
            "UNITCHECK",
            "case",
            "continue",
            "do",
            "else",
            "elsif",
            "for",
            "foreach",
            "if",
            "last",
            "my",
            "next",
            "our",
            "package",
            "redo",
            "ref",
            "rename",
            "require",
            "return",
            "state",
            "sub",
            "unless",
            "until",
            "use",
            "while",
        }
    )
    allows_empty_call_parens = True
    supports_dotted_call_stub = True
    call_returns_expression = True
    supports_json_call_result_binding = False
    supports_zero_parameter_calls = True
    max_call_parameters = NO_CALL_PARAMETER_LIMIT
    supports_inline_multiline_dict_args = True
    supports_standalone_comments_in_wrapped_calls = True
    supports_multi_param_call_wrapper_stub = True
    supports_dict_literal_as_free_expression = True
    supports_module_name = False
    supports_empty_dict_key = False
    supports_call_style = True
    supports_default_dict_key_type = False
    supports_default_dict_value_type = False
    supports_default_sequence_element_type = False
    supports_default_set_element_type = False
    supports_default_ordered_map_value_type = False
    json_type_variant_name_suffix: ClassVar[str | None] = None
    supports_non_ascii_string_literals = True
    supports_multiline_string_literals = False
    supports_empty_sibling_sequence_type_hints = True
    supports_typed_dict_open = False
    language_id: ClassVar[str] = "perl"
    variant_metadata: ClassVar[VariantMetadata] = VariantMetadata(
        round_trip_capabilities=frozenset(
            {
                RoundTripCapability.I64_BOUNDARIES,
                RoundTripCapability.INTERPOLATION_STRINGS,
                RoundTripCapability.EMBEDDED_NUL,
            }
        ),
        modifier_sequence_format_overrides={},
        string_literals_escape_null_byte=True,
        supports_ref_elements_in_tuple_strategy=False,
    )
    supports_record_struct_name_prefix = False
    supports_record_shape_names = False
    record_shape_names_emit_declarations = False
    supports_non_string_dict_keys = True
    checks_raw_control_dict_keys_separately = False

    format_call_arg: ClassVar["staticmethod[[Value, str], str]"] = (
        staticmethod(
            identity_call_arg,
        )
    )
    """Callable that rewrites a formatted direct call argument."""

    class DateFormats(DateFormatEnum):
        """Date format options for Perl."""

        _value_: DateFormatConfig

        PERL = DateFormatConfig(
            formatter=date_ymd_formatter(
                template="DateTime->new("
                "year => {year}, month => {month}, day => {day})",
            ),
            preamble_lines=("use DateTime;",),
            type_produced=datetime.date,
        )
        ISO = DateFormatConfig(
            formatter=format_date_iso, type_produced=str, preamble_lines=()
        )

    class DatetimeFormats(DatetimeFormatEnum):
        """Datetime format options for Perl."""

        _value_: DatetimeFormatConfig

        PERL = DatetimeFormatConfig(
            formatter=_format_datetime_perl,
            preamble_lines=("use DateTime;",),
            type_produced=datetime.datetime,
        )
        ISO = DatetimeFormatConfig(
            formatter=format_datetime_iso,
            type_produced=str,
            preamble_lines=(),
        )

        EPOCH = DatetimeFormatConfig(
            formatter=format_datetime_epoch,
            type_produced=int,
            preamble_lines=(),
        )

    class BoolFormats(enum.Enum):
        """Boolean format options for Perl."""

        INTEGER = _BoolFormatConfig(
            true_literal="1",
            false_literal="0",
            preamble_lines=(),
        )
        JSON_PP_REF = _BoolFormatConfig(
            true_literal=r"\1",
            false_literal=r"\0",
            preamble_lines=(),
        )
        JSON_PP_SINGLETON = _BoolFormatConfig(
            true_literal="JSON::PP::true",
            false_literal="JSON::PP::false",
            preamble_lines=("use JSON::PP;",),
        )

    class BytesFormats(enum.Enum):
        """Bytes formatting options."""

        _value_: Callable[[bytes], str]

        HEX = enum.member(value=format_bytes_hex)
        BASE64 = enum.member(value=format_bytes_base64)

        def __call__(self, data: bytes, /) -> str:
            """Format bytes."""
            return self._value_(data)

    class SequenceFormats(enum.Enum):
        """Sequence type options for Perl."""

        ARRAY = SequenceFormatConfig(
            sequence_open=fixed_open(open_str="["),
            close="]",
            supports_heterogeneity=True,
            single_element_trailing_comma=False,
            single_element_template=None,
            supports_trailing_comma=True,
            empty_sequence=None,
            preamble_lines=(),
            format_entry=passthrough_sequence_entry,
            typed_opener_fallback=None,
            uses_typed_literal_for_scalars=False,
            requires_uniform_record_shapes=False,
            declared_type=None,
            narrowed_empty_form=None,
        )

    class SetFormats(enum.Enum):
        """Set type options for Perl."""

        SET = SetFormatConfig(
            set_open=fixed_open(open_str="["),
            close="]",
            empty_set=None,
            preamble_lines=(),
            set_opener_template="",
            supports_heterogeneity=True,
            supports_trailing_comma=True,
        )

    class CommentFormats(enum.Enum):
        """Comment style options."""

        HASH = CommentConfig(
            prefix="#",
            suffix="",
        )

    class DeclarationStyles(enum.Enum):
        """Declaration style options."""

        MY = DeclarationStyleConfig(
            formatter=variable_declaration_formatter(
                template="my ${name} = {value};"
            ),
            supports_redefinition=True,
        )

    class DictEntryStyles(enum.Enum):
        """Dict entry style options."""

        DEFAULT = enum.auto()

    class DictFormats(enum.Enum):
        """Dict/map format options."""

        DEFAULT = enum.auto()

    class EmptyDictKey(enum.Enum):
        """Empty dict key options."""

        ALLOW = enum.auto()

    class FloatFormats(
        FloatSpecialsMixin,
        enum.Enum,
        positive_infinity="9**9**9",
        negative_infinity="-(9**9**9)",
        nan="(9**9**9) - (9**9**9)",
    ):
        """Float format options."""

        REPR = enum.member(value=format_float_repr)
        SCIENTIFIC = enum.member(value=format_float_scientific)
        FIXED = enum.member(value=_format_perl_float_fixed)

    class IntegerFormats(enum.Enum):
        """Integer format options."""

        DECIMAL = MappingProxyType(
            mapping={
                "NONE": str,
                "UNDERSCORE": format_integer_underscore,
            }
        )
        HEX = MappingProxyType(
            mapping={
                "NONE": format_integer_hex,
                "UNDERSCORE": format_integer_hex,
            }
        )
        OCTAL = MappingProxyType(
            mapping={
                "NONE": format_integer_octal_c_style,
                "UNDERSCORE": format_integer_octal_c_style,
            }
        )
        BINARY = MappingProxyType(
            mapping={
                "NONE": format_integer_binary,
                "UNDERSCORE": format_integer_binary,
            }
        )

        def get_formatter(
            self,
            numeric_separator: enum.Enum,
        ) -> Callable[[int], str]:
            """Return the integer formatter for the given separator."""
            formatter: Callable[[int], str] = self.value[
                numeric_separator.name
            ]
            return formatter

    class IntegerWidthStrategies(enum.Enum):
        """Integer-width rendering strategies.

        * ``BARE`` (default) - emit every integer as a bare numeric
          literal.  Values whose magnitude exceeds ``2**53`` silently
          lose precision on parse because Perl converts them to an NV
          float; this matches the historical behavior.
        * ``MATH_BIG_INT`` - wrap integers whose magnitude exceeds
          ``2**53`` as ``Math::BigInt->new("...")`` and emit a
          ``use Math::BigInt;`` preamble.  Smaller integers stay as
          bare literals.
        """

        BARE = enum.auto()
        MATH_BIG_INT = enum.auto()

    class NumericLiteralSuffixes(enum.Enum):
        """Numeric literal suffix options."""

        NONE = enum.auto()

    class NumericSeparators(enum.Enum):
        """Numeric separator options."""

        NONE = enum.auto()
        UNDERSCORE = enum.auto()

    class NumericStyles(enum.Enum):
        """Numeric literal style options."""

        OVERLOADED = enum.auto()

    class StringFormats(enum.Enum):
        """String format options."""

        _value_: Callable[[str], str]

        DOUBLE = enum.member(value=_format_perl_string_double)
        DOUBLE_UTF8 = enum.member(value=_format_perl_string_double_utf8)
        SINGLE = enum.member(value=_format_perl_string_single)
        MULTILINE = enum.member(value=_format_perl_string_multiline)

        def __call__(self, value: str, /) -> str:
            """Format a string."""
            return self._value_(value)

    class TrailingCommas(enum.Enum):
        """Trailing comma options."""

        YES = TrailingCommaConfig(multiline_trailing_comma=True)
        NO = TrailingCommaConfig(multiline_trailing_comma=False)

    date_formats = DateFormats
    datetime_formats = DatetimeFormats
    bool_formats = BoolFormats
    bytes_formats = BytesFormats
    sequence_formats = SequenceFormats
    set_formats = SetFormats
    comment_formats = CommentFormats

    class VariableTypeHints(enum.Enum):
        """Variable type hint options."""

        NEVER = enum.auto()
        SAFE = enum.auto()

    variable_type_hints_formats = VariableTypeHints
    declaration_styles = DeclarationStyles
    dict_entry_styles = DictEntryStyles
    dict_formats = DictFormats
    empty_dict_keys = EmptyDictKey
    float_formats = FloatFormats
    integer_formats = IntegerFormats
    integer_width_strategies = IntegerWidthStrategies
    numeric_literal_suffixes = NumericLiteralSuffixes
    numeric_separators = NumericSeparators
    numeric_styles = NumericStyles
    string_formats = StringFormats
    trailing_commas = TrailingCommas

    class StatementTerminatorStyles(enum.Enum):
        """Statement terminator options."""

        SEMICOLON = enum.auto()

    statement_terminator_styles = StatementTerminatorStyles

    class CallStyles(enum.Enum):
        """Perl call style options."""

        POSITIONAL = PositionalCallStyle(
            arg_separator=", ", parenthesize_each_arg=False
        )

    call_styles = CallStyles

    class Modifiers(enum.Enum):
        """C++/Java/C#-style declaration modifiers: this language has none."""

    modifiers = Modifiers

    class HeterogeneousStrategies(enum.Enum):
        """Heterogeneous-scalar strategy options — this language only
        supports raising.
        """

        ERROR = NO_HETEROGENEOUS_BEHAVIOR

    heterogeneous_strategies = HeterogeneousStrategies

    class JsonTypes(JsonType):
        """Empty: this language has no JSON value-type variants."""

    json_types = JsonTypes

    class VersionFormats(enum.Enum):
        """Version options for Perl."""

        V5_36 = enum.auto()

    version_formats = VersionFormats

    modifier_combinations: ClassVar[tuple[ModifierCombination, ...]] = ()
    identifier_cases: ClassVar[tuple[IdentifierCase, ...]] = (
        IdentifierCase.SNAKE,
        IdentifierCase.CAMEL,
    )
    supported_ref_cases: ClassVar[frozenset[IdentifierCase]] = (
        NON_KEBAB_REF_CASES
    )

    @staticmethod
    def validate_spec_for_data(data: Value) -> None:
        """Reject mapping keys that collapse in Perl hashes."""
        reject_stringified_dict_key_collisions(
            data=data,
            language_name="Perl",
        )
        reject_null_dict_keys(data=data, language_name="Perl")

    @cached_property
    def validate_call_arg(self) -> Callable[[Value], None]:
        """Return call-argument validation for this language."""
        return no_validate_call_arg

    @cached_property
    def format_call_statement(self) -> Callable[[str], str]:
        """Return call-statement formatting for this language."""
        return identity_call_statement

    wrap_calls_with_declarations = default_wrap_calls_with_declarations

    @staticmethod
    def wrap_in_file(
        content: str,
        variable_name: str,
        body_preamble: tuple[str, ...],
    ) -> str:
        """Wrap code in a valid file (no-op)."""
        return wrap_in_file_noop(
            content=content,
            variable_name=variable_name,
            body_preamble=body_preamble,
        )

    @staticmethod
    def wrap_combined_in_file(
        declaration: str,
        assignment: str,
        variable_name: str,
        body_preamble: tuple[str, ...],
    ) -> str:
        """Wrap declaration and assignment in a valid file (no-op)."""
        return wrap_combined_in_file_noop(
            declaration=declaration,
            assignment=assignment,
            variable_name=variable_name,
            body_preamble=body_preamble,
        )

    date_format: DateFormats = DateFormats.PERL
    datetime_format: DatetimeFormats = DatetimeFormats.PERL
    bool_format: BoolFormats = BoolFormats.JSON_PP_SINGLETON
    bytes_format: BytesFormats = BytesFormats.HEX
    sequence_format: SequenceFormats = SequenceFormats.ARRAY
    set_format: SetFormats = SetFormats.SET
    variable_type_hints: VariableTypeHints = VariableTypeHints.NEVER
    comment_format: CommentFormats = CommentFormats.HASH
    declaration_style: DeclarationStyles = DeclarationStyles.MY
    dict_entry_style: DictEntryStyles = DictEntryStyles.DEFAULT
    dict_format: DictFormats = DictFormats.DEFAULT
    float_format: FloatFormats = FloatFormats.REPR
    integer_format: IntegerFormats = IntegerFormats.DECIMAL
    integer_width_strategy: IntegerWidthStrategies = (
        IntegerWidthStrategies.BARE
    )
    numeric_literal_suffix: NumericLiteralSuffixes = (
        NumericLiteralSuffixes.NONE
    )
    numeric_separator: NumericSeparators = NumericSeparators.NONE
    numeric_style: NumericStyles = NumericStyles.OVERLOADED
    string_format: StringFormats = StringFormats.DOUBLE
    trailing_comma: TrailingCommas = TrailingCommas.YES
    statement_terminator_style: StatementTerminatorStyles = (
        StatementTerminatorStyles.SEMICOLON
    )
    call_style: CallStyles = CallStyles.POSITIONAL
    heterogeneous_strategy: HeterogeneousStrategies = (
        HeterogeneousStrategies.ERROR
    )
    # Keep in sync with the ``perl-version`` pin passed to
    # ``shogo82148/actions-setup-perl`` in ``.github/workflows/lint.yml``.
    language_version: VersionFormats = VersionFormats.V5_36
    indent: str = "    "

    null_literal: ClassVar[str] = "undef"
    indent_closing_delimiter: ClassVar[bool] = False
    element_separator: ClassVar[str] = ", "
    skip_null_dict_values: ClassVar[bool] = False
    supports_collection_comments: ClassVar[bool] = True
    supports_scalar_before_comments: ClassVar[bool] = True
    supports_scalar_inline_comments: ClassVar[bool] = False
    statement_terminator: ClassVar[str] = ";"
    static_preamble: ClassVar[Sequence[str]] = ()
    static_body_preamble: ClassVar[Sequence[str]] = ()
    special_float_preamble: ClassVar[tuple[str, ...]] = ()

    @cached_property
    def format_sequence_entry(self) -> Callable[[Value, str], str]:
        """Format a sequence entry."""
        return passthrough_sequence_entry

    @cached_property
    def format_set_entry(self) -> Callable[[Value, str], str]:
        """Format a set entry."""
        return passthrough_set_entry

    @cached_property
    def data_dependent_preamble(self) -> Callable[[Value], tuple[str, ...]]:
        """Return data-dependent preamble lines.

        Composes the ``MATH_BIG_INT`` integer-width contribution with
        the literal-Unicode string-format contribution so a value triggering
        both gets both preamble lines in a stable order.
        """
        effective_contributors: tuple[Callable[[Value], tuple[str, ...]], ...]
        if (
            self.integer_width_strategy
            is type(self.integer_width_strategy).MATH_BIG_INT
        ):
            effective_contributors = (_perl_math_bigint_preamble,)
        else:
            effective_contributors = ()
        effective_contributors_2: tuple[
            Callable[[Value], tuple[str, ...]], ...
        ]
        if self.string_format in {
            type(self.string_format).DOUBLE_UTF8,
            type(self.string_format).SINGLE,
        }:
            effective_contributors_2 = (_perl_use_utf8_preamble,)
        else:
            effective_contributors_2 = ()
        contributors: tuple[Callable[[Value], tuple[str, ...]], ...] = (
            _perl_math_bigfloat_preamble,
            *(effective_contributors),
            *(effective_contributors_2),
        )

        def _composed(data: Value, /) -> tuple[str, ...]:
            """Concatenate every contributor's preamble lines."""
            return tuple(line for fn in contributors for line in fn(data))

        return _composed

    @cached_property
    def heterogeneous_behavior(self) -> HeterogeneousBehavior:
        """Return the heterogeneous-behavior config."""
        return self.heterogeneous_strategy.value

    @cached_property
    def call_data_dependent_preamble(
        self,
    ) -> Callable[[Value], tuple[str, ...]]:
        """Return data-dependent preamble lines for call rendering."""
        return self.data_dependent_preamble

    @cached_property
    def type_hint_collection_preamble_lines(
        self,
    ) -> Callable[[frozenset[type]], tuple[str, ...]]:
        """Return preamble lines for empty-collection type hints."""
        return no_type_hint_preamble

    @cached_property
    def format_call_stub(
        self,
    ) -> Callable[
        [Sequence[str], Sequence[str], StubReturn, Sequence[Value]],
        tuple[str, ...],
    ]:
        """Return stub declarations for a call expression."""
        return _perl_call_stub

    @cached_property
    def format_call_preamble_stub(
        self,
    ) -> Callable[
        [Sequence[str], Sequence[str], StubReturn, Sequence[Value]],
        tuple[str, ...],
    ]:
        """Return file-scope stubs for a call expression."""
        return no_call_stub

    @cached_property
    def format_call_target(self) -> Callable[[Sequence[str]], str]:
        """Rewrite a dotted call target into the language's call
        syntax.
        """
        return identity_call_target

    @cached_property
    def format_call_ref_identifier(
        self,
    ) -> Callable[[str, Value | None], str]:
        """Rewrite a ``{"$ref": "name"}`` identifier into the
        language's call expression syntax.
        """
        return _perl_format_call_ref_identifier

    @cached_property
    def format_call_arg_ref_identifier(
        self,
    ) -> Callable[[str, Value | None], str]:
        """Rewrite a ``{"$ref": "name"}`` identifier in a call-argument
        context.

        Delegates to :attr:`format_call_ref_identifier`.  Override this to
        allow call-argument ``$ref`` values that would otherwise be rejected.
        """
        return self.format_call_ref_identifier

    @cached_property
    def format_call_arg_ref_identifier_consumable(
        self,
    ) -> Callable[[str, Value | None], str]:
        """Format a ``$ref`` the caller authorized as consumable.

        Delegates to :attr:`format_call_arg_ref_identifier`.  Override
        this to opt into a consuming form (e.g. C++ ``std::move``).
        """
        return self.format_call_arg_ref_identifier

    @cached_property
    def consumable_ref_value_inhibits_consuming_form(
        self,
    ) -> Callable[[Value], bool]:
        """Predicate deciding whether a ref's underlying value type
        inhibits the consume form.

        Delegates to :data:`never_inhibits_consuming_form`.  Languages
        whose consume operator rejects certain value types (notably
        the Mojo ``^`` on register-trivial scalars) override this.
        """
        return never_inhibits_consuming_form

    @cached_property
    def sequence_format_config(self) -> SequenceFormatConfig:
        """Configuration for the chosen sequence format."""
        return self.sequence_format.value

    @cached_property
    def set_format_config(self) -> SetFormatConfig:
        """Configuration for the chosen set format."""
        return self.set_format.value

    @cached_property
    def sequence_open(self) -> Callable[[list[Value]], str]:
        """Callable that returns the opening delimiter for a sequence."""
        return self.sequence_format.value.sequence_open

    @cached_property
    def dict_format_config(self) -> DictFormatConfig:
        """Configuration for dict formatting."""
        return DictFormatConfig(
            dict_open=fixed_open(open_str="{"),
            close="}",
            format_entry=dict_entry_with_separator(
                separator=" => ",
                format_value=passthrough_sequence_entry,
            ),
            empty_dict=None,
            preamble_lines=(),
            narrowed_open=None,
            supports_trailing_comma=True,
            narrowed_empty_form=None,
        )

    @cached_property
    def trailing_comma_config(self) -> TrailingCommaConfig:
        """Configuration for trailing-comma behavior."""
        return self.trailing_comma.value

    @cached_property
    def format_bytes(self) -> Callable[[bytes], str]:
        """Callable that formats a bytes value as a string literal."""
        return self.bytes_format

    @cached_property
    def format_date(self) -> Callable[[datetime.date], str]:
        """Callable that formats a date as a string literal."""
        return self.date_format

    @cached_property
    def format_datetime(self) -> Callable[[datetime.datetime], str]:
        """Callable that formats a datetime as a string literal."""
        return self.datetime_format

    @cached_property
    def format_time(self) -> Callable[[datetime.time], str]:
        """Callable that formats a time as a string literal."""
        return format_time_iso

    @cached_property
    def format_string(self) -> Callable[[str], str]:
        """Callable that formats a string value as a quoted literal."""
        return self.string_format

    @cached_property
    def format_float(self) -> Callable[[float], str]:
        """Callable that formats a float value as a literal."""
        formatter = self.float_format

        def format_numeric_float(value: float) -> str:
            """Force Perl to retain the value's numeric identity."""
            if value == 0.0 and math.copysign(1.0, value) < 0:
                return formatter(value)
            if (
                math.isfinite(value)
                and abs(value) >= _PERL_NV_EXACT_INTEGER_MAX
            ):
                return f'Math::BigFloat->new("{formatter(value)}")'
            return f"(0.0 + {formatter(value)})"

        return format_numeric_float

    @cached_property
    def format_integer(self) -> Callable[[int], str]:
        """Callable that formats an int value as a literal."""
        base = self.integer_format.get_formatter(
            numeric_separator=self.numeric_separator,
        )
        match self.integer_width_strategy.name:
            case "MATH_BIG_INT":
                return make_overflow_fallback_formatter(
                    base=base,
                    fallback=_format_perl_math_bigint_literal,
                    min_value=_PERL_NV_INT_MIN,
                    max_value=_PERL_NV_INT_MAX,
                )
            case _:
                return base

    @cached_property
    def comment_config(self) -> CommentConfig:
        """Configuration for the language's comment syntax."""
        return self.comment_format.value

    @cached_property
    def ordered_map_format_config(self) -> OrderedMapFormatConfig:
        """Configuration for ordered-map formatting."""
        return OrderedMapFormatConfig(
            ordered_map_open=fixed_open(open_str="{"),
            close="}",
            preamble_lines=(),
        )

    @cached_property
    def format_ordered_map_entry(self) -> Callable[[str, Value, str], str]:
        """Callable that formats one ordered-map entry."""
        return dict_entry_with_separator(
            separator=" => ",
            format_value=passthrough_sequence_entry,
        )

    @cached_property
    def format_variable_declaration(
        self,
    ) -> Callable[[str, str, Value, frozenset[enum.Enum]], str]:
        """Callable that formats a new variable declaration."""
        return self.declaration_style.value.formatter

    @cached_property
    def format_variable_assignment(
        self,
    ) -> Callable[[str, str, Value], str]:
        """Callable that formats an assignment to an existing variable."""
        return variable_formatter(template="${name} = {value};")

    @cached_property
    def true_literal(self) -> str:
        """Perl literal representing :data:`True`."""
        return self.bool_format.value.true_literal

    @cached_property
    def false_literal(self) -> str:
        """Perl literal representing :data:`False`."""
        return self.bool_format.value.false_literal

    @cached_property
    def scalar_preamble(self) -> dict[type, tuple[str, ...]]:
        """Per-instance scalar preamble computed from date/datetime/bool
        format.
        """
        bool_preamble = self.bool_format.value.preamble_lines
        extra: dict[type, tuple[str, ...]] | None
        extra = None
        if len(bool_preamble) > 0:
            extra = {bool: bool_preamble}
        return date_scalar_preamble(
            date_format=self.date_format,
            datetime_format=self.datetime_format,
            extra=extra,
        )

    @cached_property
    def scalar_body_preamble(self) -> dict[type, tuple[str, ...]]:
        """Per-instance scalar body preamble (Perl needs none)."""
        return {}

    @cached_property
    def compute_body_preamble(
        self,
    ) -> Callable[[frozenset[type], Value], tuple[str, ...]]:
        """Compute body-preamble lines from the scalar map."""
        return body_preamble_from_scalars(
            scalar_body_preamble=self.scalar_body_preamble,
            format_lines=tuple,
        )

    @cached_property
    def call_style_config(self) -> CallStyle:
        """Configuration for the chosen call style."""
        return self.call_style.value


# The variant planner accesses non-default enum members dynamically.
_PERL_INTEGER_BOOL_FORMAT = Perl.bool_formats.INTEGER
