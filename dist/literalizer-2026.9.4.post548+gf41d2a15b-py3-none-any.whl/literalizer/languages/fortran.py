"""Fortran language specification."""

import dataclasses
import datetime
import enum
import re
import textwrap
from collections.abc import Callable, Sequence
from functools import cached_property, partial
from typing import ClassVar

from beartype import beartype

from literalizer._formatters.collection_openers import (
    fixed_open,
)
from literalizer._formatters.fallbacks import nonempty_or_default
from literalizer._formatters.format_dates import (
    format_date_iso,
    format_datetime_epoch,
    format_datetime_iso,
    format_time_iso,
)
from literalizer._formatters.format_entries import (
    dict_entry_with_template,
    format_bytes_base64,
    passthrough_sequence_entry,
)
from literalizer._formatters.format_floats import (
    format_float_fixed,
    format_float_repr,
    format_float_scientific,
)
from literalizer._formatters.format_integers import (
    I64_MAX,
    I64_MIN,
    make_overflow_fallback_formatter,
    raise_for_unrepresentable_int,
)
from literalizer._formatters.format_strings import format_string_concat_control
from literalizer._language import (
    NO_CALL_PARAMETER_LIMIT,
    NO_HETEROGENEOUS_BEHAVIOR,
    NON_KEBAB_REF_CASES,
    BareIntegerWidthStrategies,
    CallParameterShadowing,
    CallStyle,
    CommentConfig,
    DateFormatConfig,
    DateFormatEnum,
    DatetimeFormatConfig,
    DatetimeFormatEnum,
    DeclarationStyleConfig,
    DictFormatConfig,
    FloatSpecialsMixin,
    HeterogeneousBehavior,
    IdentifierCase,
    JsonType,
    LanguageCls,
    ModifierCombination,
    NewVariableNameSyntax,
    OrderedMapFormatConfig,
    PositionalCallStyle,
    RoundTripCapability,
    SequenceFormatConfig,
    SetFormatConfig,
    StubReturn,
    TrailingCommaConfig,
    VariantMetadata,
    body_preamble_from_scalars,
    identity_call_ref_identifier,
    identity_constructor_target,
    never_inhibits_consuming_form,
    no_call_binding_body_preamble,
    no_call_binding_file_pragmas,
    no_call_stub,
    no_data_preamble,
    no_format_integer_beyond_i64,
    no_format_integer_widened,
    no_leading_preamble,
    no_type_hint_preamble,
    no_validate_call_arg,
    no_validate_spec_for_data,
    prepend_body_preamble,
)
from literalizer._types import Value

_FORTRAN_WRAP_COLUMN = 110
_FORTRAN_STRING_CHUNK_LENGTH = 105
_FORTRAN_LINE_LIMIT = 132
"""The longest physical line free-form Fortran 2018 source admits."""

_FORTRAN_LINE_MARGIN = 14
"""What a line still gains after the wrapper has measured it.

A piece takes a trailing continuation marker, and the whole program is
indented once it is wrapped in a file, so a line is measured against
the limit less this margin rather than against the limit itself.
"""

_FORTRAN_SAFE_COLUMN = _FORTRAN_LINE_LIMIT - _FORTRAN_LINE_MARGIN
"""How long a line may grow before the wrapper has to split it."""

_FORTRAN_CONTINUATION_PREFIX = "& "
"""What a continued physical line resumes with."""

_FORTRAN_ELEMENT_BREAK = ","
"""Where an expression prefers to break: between two elements."""

_FORTRAN_FALLBACK_BREAK = ",()[]"
"""Where an expression may break when no element boundary is in reach.

A ``&`` continuation sits between any two tokens, so a bracket serves
as well as a comma; a chain of nested constructors offers no comma
until its innermost level (issue #4473).
"""


@beartype
def _format_fortran_string_unwrapped(value: str) -> str:
    """Format one string fragment without source-line wrapping."""
    return format_string_concat_control(
        quote_char="'",
        quote_escape="''",
        control_char_template="achar({})",
        concat_operator=" // ",
    )(value)


@beartype
def _format_fortran_string(value: str) -> str:
    """Format a string with Fortran quoting and control escapes."""
    formatted = _format_fortran_string_unwrapped(value=value)
    if len(formatted) <= _FORTRAN_STRING_CHUNK_LENGTH:
        return formatted

    chunks: list[str] = []
    chunk = ""
    for character in value:
        candidate = chunk + character
        if (
            chunk != ""
            and len(_format_fortran_string_unwrapped(value=candidate))
            > _FORTRAN_STRING_CHUNK_LENGTH
        ):
            chunks.append(_format_fortran_string_unwrapped(value=chunk))
            chunk = character
        else:
            chunk = candidate
    chunks.append(_format_fortran_string_unwrapped(value=chunk))
    return " // &\n& ".join(chunks)


@beartype
def _format_fortran_bytes_hex(value: bytes) -> str:
    """Format hexadecimal bytes through the Fortran string formatter."""
    return _format_fortran_string(value=value.hex())


@beartype
def _format_fortran_bytes_base64(value: bytes) -> str:
    """Format base64 bytes through the Fortran string formatter."""
    encoded = format_bytes_base64(value=value)[1:-1]
    return _format_fortran_string(value=encoded)


@beartype
def _format_fortran_datetime_epoch(value: datetime.datetime, /) -> str:
    """Format a datetime as an int64 Fortran epoch literal."""
    return f"{format_datetime_epoch(value=value)}_int64"


@beartype
def _suffix_real64(
    formatter: Callable[[float], str],
) -> Callable[[float], str]:
    """Wrap *formatter* so its output is tagged with the ``_real64`` kind.

    The ``freal`` constructor declared in :attr:`Fortran.static_body_preamble`
    takes ``real(kind=real64)``, so every emitted finite-float literal needs
    the kind suffix; without it a value like ``1.7976931348623157e+308``
    would overflow the default single-precision real range at parse time.
    """

    @beartype
    def _suffixed(value: float, /) -> str:
        """Apply *formatter* and tag the result with the ``_real64``
        kind.
        """
        return f"{formatter(value)}_real64"

    return _suffixed


@beartype
def _apply_fortran_entry(
    *,
    original: Value,
    formatted: str,
    int_name: str,
    real_name: str,
    str_name: str,
    datetime_as_int: bool,
) -> str:
    """Wrap a formatted entry in its constructor call."""
    match original:
        case bool():
            return formatted
        case datetime.datetime():
            name = str_name
            if datetime_as_int:
                name = int_name
            return f"{name}({formatted})"
        case int():
            return f"{int_name}({formatted})"
        case float():
            return f"{real_name}({formatted})"
        case str() | bytes() | datetime.date() | datetime.time():
            return f"{str_name}({formatted})"
        case _:
            return formatted


@beartype
def _build_format_fortran_entry(
    *,
    int_name: str,
    real_name: str,
    str_name: str,
    datetime_as_int: bool,
) -> Callable[[Value, str], str]:
    """Build a formatter that wraps values in the appropriate
    constructor.
    """

    def _format_fortran_entry(original: Value, formatted: str) -> str:
        """Delegate to module-level implementation."""
        return _apply_fortran_entry(
            original=original,
            formatted=formatted,
            int_name=int_name,
            real_name=real_name,
            str_name=str_name,
            datetime_as_int=datetime_as_int,
        )

    return _format_fortran_entry


@beartype
def _fortran_comment_pos(line: str) -> int | None:
    """Return the index of the ``!`` comment character in *line* that
    lies outside any string literal, or ``None`` if there is no comment.
    """
    in_single_quote = False
    in_double_quote = False
    i = 0
    while i < len(line):
        c = line[i]
        match c:
            case "'" if not in_double_quote:
                if (
                    in_single_quote
                    and i + 1 < len(line)
                    and line[i + 1] == "'"
                ):
                    i += 2
                    continue
                in_single_quote = not in_single_quote
            case '"' if not in_single_quote:
                in_double_quote = not in_double_quote
            case "!" if not in_single_quote and not in_double_quote:
                return i
            case _:
                pass
        i += 1
    return None


@beartype
def _fortran_break_position(*, line: str, break_after: str) -> int | None:
    """Return the last place *line* may break, or ``None`` if nowhere.

    Only the leading window that fits on a physical line is considered,
    and a break character inside a string literal is content rather
    than a token boundary.  The columns a continuation prefix occupies
    are passed over, so a break always leaves a shorter remainder and
    the wrapping loop always advances.
    """
    in_single_quote = False
    break_at: int | None = None
    scan = line[:_FORTRAN_WRAP_COLUMN].replace("''", "  ")
    for index, character in enumerate(iterable=scan):
        if character == "'":
            in_single_quote = not in_single_quote
        elif (
            character in break_after
            and not in_single_quote
            and index >= len(_FORTRAN_CONTINUATION_PREFIX)
        ):
            break_at = index + 1
    return break_at


@beartype
def _wrap_fortran_expression_line(line: str, /) -> list[str]:
    """Split a long line, keeping any continuation marker it ends with.

    Wrapping runs over its own output, so a line already carrying a
    trailing ``&`` is left alone unless it is past the safe column even
    so, in which case the marker is set aside and put back on the last
    piece (issue #4474).
    """
    stripped = line.rstrip()
    if not stripped.endswith("&"):
        return _split_fortran_line(line=line)
    if len(line) <= _FORTRAN_SAFE_COLUMN:
        return [line]
    pieces = _split_fortran_line(line=stripped[:-1].rstrip())
    return [*pieces[:-1], f"{pieces[-1]} &"]


@beartype
def _split_fortran_line(*, line: str) -> list[str]:
    """Split a long expression line at token boundaries outside strings.

    A comma is preferred, so an expression breaks between its elements
    wherever it has any.  A line still past the safe column with no
    comma to break at falls back to breaking at a bracket, which is the
    only place a deeply nested constructor chain offers.
    """
    remaining = line
    wrapped: list[str] = []
    while len(remaining) > _FORTRAN_WRAP_COLUMN:
        break_at = _fortran_break_position(
            line=remaining,
            break_after=_FORTRAN_ELEMENT_BREAK,
        )
        if break_at is None and len(remaining) > _FORTRAN_SAFE_COLUMN:
            break_at = _fortran_break_position(
                line=remaining,
                break_after=_FORTRAN_FALLBACK_BREAK,
            )
        if break_at is None:
            break
        wrapped.append(remaining[:break_at].rstrip())
        remaining = (
            _FORTRAN_CONTINUATION_PREFIX + remaining[break_at:].lstrip()
        )
    wrapped.append(remaining)
    return wrapped


@beartype
def _add_continuation(value: str) -> str:
    """Add Fortran ``&`` line-continuation to non-comment, non-last
    lines.

    In Fortran free-form source a logical line may span multiple physical
    lines.  The ``&`` continuation character must be the last
    non-whitespace, non-comment character on the physical line.  Pure
    comment lines (blank or starting with ``!``) are transparent to the
    continuation mechanism and receive no ``&``.
    """
    lines = [
        wrapped
        for line in value.splitlines()
        for wrapped in _wrap_fortran_expression_line(line)
    ]
    if len(lines) <= 1:
        return value
    result: list[str] = []
    for i, line in enumerate(iterable=lines):
        is_last = i == len(lines) - 1
        stripped = line.strip()
        is_pure_comment = stripped == "" or stripped.startswith("!")
        if is_last or is_pure_comment or stripped.endswith("&"):
            result.append(line)
        else:
            pos = _fortran_comment_pos(line=line)
            if pos is not None:
                result.append(line[:pos].rstrip() + " &  " + line[pos:])
            else:
                result.append(line + " &")
    return "\n".join(result)


@beartype
def _wrap_fortran_source_lines(value: str, /) -> str:
    """Wrap each independent source line without joining statements."""
    return "\n".join(
        _add_continuation(value=line) for line in value.splitlines()
    )


@beartype
def _apply_fortran_variable_declaration(
    name: str,
    value: str,
    data: Value,
    format_entry: Callable[[Value, str], str],
) -> str:
    """Format a variable declaration and initialisation."""
    fval = format_entry(data, value)
    assignment = _add_continuation(value=f"{name} = {fval}")
    return f"type(fval_t) :: {name}\n{assignment}"


@beartype
def _build_format_variable_declaration(
    *,
    format_entry: Callable[[Value, str], str],
) -> Callable[[str, str, Value, frozenset[enum.Enum]], str]:
    """Build a variable declaration formatter."""

    def _format_variable_declaration(
        name: str,
        value: str,
        data: Value,
        _modifiers: frozenset[enum.Enum],
    ) -> str:
        """Delegate to module-level implementation."""
        return _apply_fortran_variable_declaration(
            name=name, value=value, data=data, format_entry=format_entry
        )

    return _format_variable_declaration


@beartype
def _apply_fortran_variable_assignment(
    name: str,
    value: str,
    data: Value,
    format_entry: Callable[[Value, str], str],
) -> str:
    """Format an assignment to an existing variable."""
    fval = format_entry(data, value)
    continued = _add_continuation(value=fval)
    return f"{name} = {continued}"


@beartype
def _build_format_variable_assignment(
    *,
    format_entry: Callable[[Value, str], str],
) -> Callable[[str, str, Value], str]:
    """Build a variable assignment formatter."""

    def _format_variable_assignment(name: str, value: str, data: Value) -> str:
        """Delegate to module-level implementation."""
        return _apply_fortran_variable_assignment(
            name=name, value=value, data=data, format_entry=format_entry
        )

    return _format_variable_assignment


@beartype
def _format_fortran_call_declaration(
    name: str,
    value: str,
    _data: Value,
    _modifiers: frozenset[enum.Enum],
) -> str:
    """Format a Fortran declaration binding a call result.

    A literal binding wraps the right-hand side in the ``fval_t``
    constructor matching the parsed literal's type (the integer, real,
    or string constructor).  That is wrong for a call: the call's
    return type is opaque to the renderer and the result is not the
    constructed type.

    Fortran has no type inference, so the binding still needs an
    explicit declared type.  No caller-supplied return-type hint is
    required: every generated Fortran call stub returns ``type(fval_t)``
    -- a ``StubReturn.VALUE`` stub is a ``function ... result(r)`` whose
    ``r`` is declared ``type(fval_t)`` -- so the call result's static
    type is always ``type(fval_t)``, exactly the type a Fortran literal
    binding already declares.  The only call-vs-literal difference is
    dropping the value-wrapping constructor, so the call result is bound
    directly to a plain ``type(fval_t)`` declaration.
    """
    continued = _add_continuation(value=value)
    return f"type(fval_t) :: {name}\n{name} = {continued}"


@beartype
def _format_fortran_call_assignment(
    name: str,
    value: str,
    _data: Value,
) -> str:
    """Format a Fortran reassignment binding a call result.

    The call-expression counterpart of
    :func:`_format_fortran_call_declaration`; the variable is already
    declared ``type(fval_t)``, so the call result is assigned directly
    with no ``fval_t``-constructor wrapping.
    """
    continued = _add_continuation(value=value)
    return f"{name} = {continued}"


@beartype
def _fortran_call_target(parts: Sequence[str], /) -> str:
    """Return the last component of a dotted call target as the Fortran
    procedure name.

    ``app.client.fetch`` produces ``fetch`` so the generated call and
    stub use a simple identifier that Fortran can declare as an internal
    procedure without object/module prefix notation.
    """
    return parts[-1]


@beartype
def _fortran_call_statement(call: str, /) -> str:
    """Prepend ``call `` to a Fortran subroutine-call statement.

    All top-level call statements in the generated output invoke void
    subroutines (or subroutines wrapping a value-returning function),
    which require the ``call`` keyword in Fortran.

    A multiline argument makes the statement span physical lines, and
    free-form Fortran continues a logical line only where a ``&`` says
    so, exactly as a multiline value binding already does (issue #4527).
    """
    return _add_continuation(value=f"call {call}")


@beartype
def _fortran_call_stub(
    parts: Sequence[str],
    params: Sequence[str],
    stub_return: StubReturn,
    _args: Sequence[Value],
    /,
    *,
    indent: str,
) -> tuple[str, ...]:
    """Return a Fortran internal-procedure stub for a call expression.

    VOID stubs emit a ``subroutine``; VALUE stubs emit a ``function``
    that returns ``type(fval_t)`` via ``fnull()``.  Both use ``implicit
    none`` and declare each parameter as ``type(fval_t), intent(in)``.
    The host program's ``use fval_m`` provides ``fval_t`` and ``fnull``
    via host association, so no additional ``use`` statement is needed.

    Leading underscores are stripped from parameter names so that a
    placeholder like ``_arg`` becomes the valid Fortran identifier
    ``arg``.
    """
    method = parts[-1]
    collected_clean_params = [
        nonempty_or_default(value=param.lstrip("_"), default=param)
        for param in params
    ]
    clean_params = collected_clean_params

    if stub_return is StubReturn.VOID:
        param_str = "()"
        if len(clean_params) > 0:
            param_str = f"({', '.join(clean_params)})"
        lines: list[str] = [f"subroutine {method}{param_str}"]
        lines.append(f"{indent}implicit none")
        if len(clean_params) > 0:
            joined = ", ".join(clean_params)
            lines.append(f"{indent}type(fval_t), intent(in) :: {joined}")
        lines.append(f"end subroutine {method}")
        return ("\n".join(lines),)

    param_str = "()"
    if len(clean_params) > 0:
        param_str = f"({', '.join(clean_params)})"
    lines = [f"function {method}{param_str} result(r)"]
    lines.append(f"{indent}implicit none")
    if len(clean_params) > 0:
        joined = ", ".join(clean_params)
        lines.append(f"{indent}type(fval_t), intent(in) :: {joined}")
    lines.append(f"{indent}type(fval_t) :: r")
    lines.append(f"{indent}r = fnull()")
    lines.append(f"end function {method}")
    return ("\n".join(lines),)


@beartype
@dataclasses.dataclass(frozen=True, kw_only=True)
class Fortran(metaclass=LanguageCls):
    """Fortran language specification."""

    immutable_variable_modifiers: ClassVar[frozenset[enum.Enum]] = frozenset()
    wrap_in_file_tolerates_pre_indent = True
    reserved_variable_identifier_pattern: ClassVar[re.Pattern[str] | None] = (
        None
    )
    reserved_call_parameter_identifiers: ClassVar[frozenset[str]] = frozenset()
    reserved_call_parameter_identifier_pattern: ClassVar[
        re.Pattern[str] | None
    ] = None
    accepts_type_name_call_target = True
    declares_type_name_call_target = True
    dotted_call_root_shares_entrypoint_namespace = True
    reserved_bare_call_target_identifiers: ClassVar[frozenset[str]] = (
        frozenset()
    )
    reserved_call_target_head_identifiers: ClassVar[frozenset[str]] = (
        frozenset()
    )
    contextual_call_target_identifiers: ClassVar[frozenset[str]] = frozenset()
    reserved_call_target_keywords_case_sensitive = True
    module_name_must_start_uppercase = False
    call_target_name_syntax: ClassVar[NewVariableNameSyntax | None] = None
    supports_multiline_dict_layout = True
    pools_map_integer_width = True

    new_variable_name_syntax: ClassVar[NewVariableNameSyntax] = (
        NewVariableNameSyntax.ASCII_LETTER_START
    )
    max_variable_identifier_length: ClassVar[int | None] = 63

    format_integer_widened = no_format_integer_widened
    format_integer_beyond_i64 = no_format_integer_beyond_i64
    format_constructor_target: ClassVar["staticmethod[[str], str]"] = (
        staticmethod(identity_constructor_target)
    )
    format_call_binding_body_preamble = no_call_binding_body_preamble
    format_call_binding_file_pragmas = no_call_binding_file_pragmas

    module_name: str = "Literalizer"

    leading_preamble = no_leading_preamble
    extension = ".f90"
    pygments_name = "fortran"
    stringifies_nested_collections = False
    supports_special_floats = True
    supports_variable_names = True
    supports_no_variable_wrap_in_file = False
    wraps_data_dependent_preamble_in_body = False
    dict_supports_heterogeneous_values = True
    supports_dotted_calls = True
    allows_empty_call_parens = True
    has_free_function_calls = True
    reserved_identifiers: ClassVar[frozenset[str]] = frozenset()
    # The stub declares the target and its parameters in one
    # statement, and this language treats that name as in scope
    # there.  An earlier dotted component names something else
    # (issue #4528).
    call_parameter_shadowing: ClassVar[CallParameterShadowing] = (
        CallParameterShadowing.TARGET_NAME
    )
    declares_call_parameter_names = True
    reserved_variable_identifiers_case_sensitive: bool = False
    reserved_variable_identifiers: frozenset[str] = frozenset(
        {
            "allocatable",
            "allocate",
            "assign",
            "assignment",
            "associate",
            "asynchronous",
            "backspace",
            "bind",
            "block",
            "blockdata",
            "call",
            "case",
            "class",
            "close",
            "codimension",
            "common",
            "contains",
            "contiguous",
            "continue",
            "critical",
            "data",
            "deallocate",
            "default",
            "deferred",
            "dimension",
            "do",
            "else",
            "elseif",
            "end",
            "entry",
            "enum",
            "enumerator",
            "equivalence",
            "error",
            "event",
            "exit",
            "extends",
            "external",
            "final",
            "forall",
            "format",
            "function",
            "generic",
            "go",
            "goto",
            "if",
            "implicit",
            "import",
            "include",
            "inquire",
            "intent",
            "interface",
            "intrinsic",
            "lock",
            "module",
            "namelist",
            "non_intrinsic",
            "nullify",
            "only",
            "open",
            "operator",
            "optional",
            "pointer",
            "private",
            "procedure",
            "program",
            "protected",
            "public",
            "pure",
            "read",
            "recursive",
            "result",
            "return",
            "rewind",
            "save",
            "select",
            "sequence",
            "stop",
            "submodule",
            "subroutine",
            "sync",
            "target",
            "then",
            "type",
            "unlock",
            "use",
            "value",
            "volatile",
            "wait",
            "where",
            "while",
            "write",
        }
    )
    supports_dotted_call_stub = False
    call_returns_expression = True
    supports_json_call_result_binding = False
    supports_zero_parameter_calls = True
    max_call_parameters = NO_CALL_PARAMETER_LIMIT
    supports_inline_multiline_dict_args = True
    supports_standalone_comments_in_wrapped_calls = True
    supports_multi_param_call_wrapper_stub = True
    supports_dict_literal_as_free_expression = True
    reserved_module_identifiers: ClassVar[frozenset[str]] = frozenset(
        {
            "begin",
            # The wrapped file always emits ``module fval_m`` for the
            # value carrier, so a wrapper of that name declares the
            # module twice (issue #4530).
            "fval_m",
        }
    )
    # A Fortran program unit and the variables it declares sit in one
    # scope, so ``program x`` cannot also declare ``x`` (issue #4530).
    module_name_shares_variable_scope: ClassVar[bool] = True
    supports_module_name = True
    supports_empty_dict_key = False
    supports_call_style = True
    supports_default_dict_key_type = False
    supports_default_dict_value_type = False
    supports_default_sequence_element_type = False
    supports_default_set_element_type = False
    supports_default_ordered_map_value_type = False
    json_type_variant_name_suffix: ClassVar[str | None] = None
    supports_non_ascii_string_literals = True
    supports_multiline_string_literals = False
    supports_empty_sibling_sequence_type_hints = True
    supports_typed_dict_open = False
    language_id: ClassVar[str] = "fortran"
    variant_metadata: ClassVar[VariantMetadata] = VariantMetadata(
        round_trip_capabilities=frozenset(
            {
                RoundTripCapability.I64_BOUNDARIES,
                RoundTripCapability.INTERPOLATION_STRINGS,
                RoundTripCapability.CONTROL_STRINGS,
                RoundTripCapability.EMBEDDED_NUL,
            }
        ),
        modifier_sequence_format_overrides={},
        string_literals_escape_null_byte=True,
        supports_ref_elements_in_tuple_strategy=False,
    )
    supports_record_struct_name_prefix = False
    supports_record_shape_names = False
    record_shape_names_emit_declarations = False
    supports_non_string_dict_keys = False
    checks_raw_control_dict_keys_separately = False

    class DateFormats(DateFormatEnum):
        """Date format options for Fortran."""

        _value_: DateFormatConfig

        ISO = DateFormatConfig(
            formatter=format_date_iso, type_produced=str, preamble_lines=()
        )

    class DatetimeFormats(DatetimeFormatEnum):
        """Datetime format options for Fortran."""

        _value_: DatetimeFormatConfig

        ISO = DatetimeFormatConfig(
            formatter=format_datetime_iso,
            type_produced=str,
            preamble_lines=(),
        )

        EPOCH = DatetimeFormatConfig(
            formatter=_format_fortran_datetime_epoch,
            type_produced=int,
            preamble_lines=(),
        )

    class BytesFormats(enum.Enum):
        """Bytes formatting options."""

        _value_: Callable[[bytes], str]

        HEX = enum.member(value=_format_fortran_bytes_hex)
        BASE64 = enum.member(value=_format_fortran_bytes_base64)

        def __call__(self, data: bytes, /) -> str:
            """Format bytes."""
            return self._value_(data)

    class SequenceFormats(enum.Enum):
        """Sequence type options for Fortran."""

        LIST = SequenceFormatConfig(
            sequence_open=fixed_open(open_str="flist([fval_t :: "),
            close="])",
            supports_heterogeneity=True,
            single_element_trailing_comma=False,
            single_element_template=None,
            supports_trailing_comma=False,
            empty_sequence=None,
            preamble_lines=(),
            format_entry=passthrough_sequence_entry,
            typed_opener_fallback=None,
            uses_typed_literal_for_scalars=False,
            requires_uniform_record_shapes=False,
            declared_type=None,
            narrowed_empty_form=None,
        )

    class SetFormats(enum.Enum):
        """Set type options for Fortran."""

        SET = SetFormatConfig(
            set_open=fixed_open(open_str="fset([fval_t :: "),
            close="])",
            empty_set=None,
            preamble_lines=(),
            set_opener_template="",
            supports_heterogeneity=True,
            supports_trailing_comma=True,
        )

    class CommentFormats(enum.Enum):
        """Comment style options."""

        EXCLAMATION = CommentConfig(
            prefix="!",
            suffix="",
        )

    class DeclarationStyles(enum.Enum):
        """Declaration style options."""

        TYPED = DeclarationStyleConfig(
            formatter=_build_format_variable_declaration(
                format_entry=_build_format_fortran_entry(
                    int_name="fint",
                    real_name="freal",
                    str_name="fstr",
                    datetime_as_int=False,
                ),
            ),
            supports_redefinition=True,
        )

    class DictEntryStyles(enum.Enum):
        """Dict entry style options."""

        DEFAULT = enum.auto()

    class DictFormats(enum.Enum):
        """Dict/map format options."""

        DEFAULT = enum.auto()

    class EmptyDictKey(enum.Enum):
        """Empty dict key options."""

        ALLOW = enum.auto()

    class FloatFormats(
        FloatSpecialsMixin,
        enum.Enum,
        positive_infinity=("ieee_value(0.0_real64, ieee_positive_inf)"),
        negative_infinity=("ieee_value(0.0_real64, ieee_negative_inf)"),
        nan="ieee_value(0.0_real64, ieee_quiet_nan)",
    ):
        """Float format options.

        Every finite literal is emitted with the ``_real64`` kind suffix
        so that values like ``1.7976931348623157e+308`` (which exceed the
        default single-precision real range) parse correctly and so that
        ``3.14`` is not silently rounded to single precision before being
        passed to the ``freal(real(real64))`` constructor declared in
        :attr:`static_body_preamble`.
        """

        REPR = enum.member(value=_suffix_real64(formatter=format_float_repr))
        SCIENTIFIC = enum.member(
            value=_suffix_real64(formatter=format_float_scientific)
        )
        FIXED = enum.member(value=_suffix_real64(formatter=format_float_fixed))

    class IntegerFormats(enum.Enum):
        """Integer format options."""

        DECIMAL = enum.auto()

    class NumericLiteralSuffixes(enum.Enum):
        """Numeric literal suffix options."""

        NONE = enum.auto()

    class NumericSeparators(enum.Enum):
        """Numeric separator options."""

        NONE = enum.auto()

    class NumericStyles(enum.Enum):
        """Numeric literal style options."""

        OVERLOADED = enum.auto()

    class StringFormats(enum.Enum):
        """String format options."""

        DOUBLE = enum.auto()

    class TrailingCommas(enum.Enum):
        """Trailing comma options."""

        NO = TrailingCommaConfig(multiline_trailing_comma=False)

    date_formats = DateFormats
    datetime_formats = DatetimeFormats
    bytes_formats = BytesFormats
    sequence_formats = SequenceFormats
    set_formats = SetFormats
    comment_formats = CommentFormats

    class VariableTypeHints(enum.Enum):
        """Variable type hint options."""

        NEVER = enum.auto()
        SAFE = enum.auto()

    variable_type_hints_formats = VariableTypeHints
    declaration_styles = DeclarationStyles
    dict_entry_styles = DictEntryStyles
    dict_formats = DictFormats
    empty_dict_keys = EmptyDictKey
    float_formats = FloatFormats
    integer_formats = IntegerFormats
    integer_width_strategies = BareIntegerWidthStrategies
    numeric_literal_suffixes = NumericLiteralSuffixes
    numeric_separators = NumericSeparators
    numeric_styles = NumericStyles
    string_formats = StringFormats
    trailing_commas = TrailingCommas

    class StatementTerminatorStyles(enum.Enum):
        """Statement terminator options."""

        SEMICOLON = enum.auto()

    statement_terminator_styles = StatementTerminatorStyles

    class CallStyles(enum.Enum):
        """Fortran call style options."""

        POSITIONAL = PositionalCallStyle(
            arg_separator=", ", parenthesize_each_arg=False
        )

    call_styles = CallStyles

    class Modifiers(enum.Enum):
        """C++/Java/C#-style declaration modifiers: this language has none."""

    modifiers = Modifiers

    class HeterogeneousStrategies(enum.Enum):
        """Heterogeneous-scalar strategy options — this language only
        supports raising.
        """

        ERROR = NO_HETEROGENEOUS_BEHAVIOR

    heterogeneous_strategies = HeterogeneousStrategies

    class JsonTypes(JsonType):
        """Empty: this language has no JSON value-type variants."""

    json_types = JsonTypes

    class BoolFormats(enum.Enum):
        """Empty: this language has no alternative boolean formats."""

    bool_formats = BoolFormats

    class VersionFormats(enum.Enum):
        """Version options for Fortran.

        * ``VersionFormats.V2003`` — target Fortran 2003; the ``int64``
          and ``real64`` kinds are defined locally via
          ``selected_int_kind`` / ``selected_real_kind`` because
          Fortran 2003's ``iso_fortran_env`` has no such named constants.
        * ``VersionFormats.V2008`` — target Fortran 2008; the ``int64``
          and ``real64`` kinds are imported from the intrinsic
          ``iso_fortran_env`` module.
        """

        V2003 = enum.auto()
        V2008 = enum.auto()

    version_formats = VersionFormats

    module_name_case: ClassVar[IdentifierCase] = IdentifierCase.SNAKE

    modifier_combinations: ClassVar[tuple[ModifierCombination, ...]] = ()
    identifier_cases: ClassVar[tuple[IdentifierCase, ...]] = (
        IdentifierCase.SNAKE,
        IdentifierCase.UPPER_SNAKE,
    )
    supported_ref_cases: ClassVar[frozenset[IdentifierCase]] = (
        NON_KEBAB_REF_CASES
    )

    validate_spec_for_data = no_validate_spec_for_data

    @cached_property
    def validate_call_arg(self) -> Callable[[Value], None]:
        """Return call-argument validation for this language."""
        return no_validate_call_arg

    def wrap_in_file(
        self,
        content: str,
        variable_name: str,
        body_preamble: tuple[str, ...],
    ) -> str:
        """Wrap a Fortran variable declaration or call block in a program.

        When *variable_name* is non-empty (variable declaration mode),
        *body_preamble* is prepended before *content* in the program
        body.  When *variable_name* is empty (call mode), *body_preamble*
        holds internal-procedure stubs that go in the ``contains`` section
        after the executable statements in *content*.
        """
        content = _wrap_fortran_source_lines(content)
        if variable_name != "":
            content = prepend_body_preamble(
                content=content,
                body_preamble=body_preamble,
            )
            indented = textwrap.indent(text=content, prefix=self.indent)
            return (
                f"program {self.module_name}\n"
                f"{self.indent}use fval_m\n"
                f"{self.indent}implicit none\n"
                f"{indented}\n"
                f"end program {self.module_name}"
            )
        indented = textwrap.indent(text=content, prefix=self.indent)
        stubs_str = "\n".join(
            _wrap_fortran_source_lines(stub) for stub in body_preamble
        )
        indented_stubs = textwrap.indent(text=stubs_str, prefix=self.indent)
        return (
            f"program {self.module_name}\n"
            f"{self.indent}use fval_m\n"
            f"{self.indent}implicit none\n"
            f"{indented}\n"
            f"contains\n"
            f"{indented_stubs}\n"
            f"end program {self.module_name}"
        )

    def wrap_combined_in_file(
        self,
        declaration: str,
        assignment: str,
        variable_name: str,
        body_preamble: tuple[str, ...],
    ) -> str:
        """Wrap Fortran declaration + assignment in separate
        subroutines.
        """
        declaration = prepend_body_preamble(
            content=declaration,
            body_preamble=body_preamble,
        )
        decl_indented = textwrap.indent(text=declaration, prefix=self.indent)
        has_bound_declarations = declaration.count("type(fval_t) ::") > 1
        assignment_scope = assignment
        if has_bound_declarations:
            assignment_scope = f"{declaration}\n{assignment}"
        assignment_declaration = ""
        if not has_bound_declarations:
            assignment_declaration = (
                f"{self.indent}type(fval_t) :: {variable_name}\n"
            )
        assign_indented = textwrap.indent(
            text=assignment_scope,
            prefix=self.indent,
        )
        return (
            f"subroutine {self.module_name}_declaration()\n"
            f"{self.indent}use fval_m\n"
            f"{self.indent}implicit none\n"
            f"{decl_indented}\n"
            f"end subroutine {self.module_name}_declaration\n"
            "\n"
            f"subroutine {self.module_name}_assignment()\n"
            f"{self.indent}use fval_m\n"
            f"{self.indent}implicit none\n"
            f"{assignment_declaration}"
            f"{assign_indented}\n"
            f"end subroutine {self.module_name}_assignment\n"
            "\n"
            "program main\n"
            f"{self.indent}call {self.module_name}_declaration()\n"
            f"{self.indent}call {self.module_name}_assignment()\n"
            "end program main"
        )

    def wrap_call_variable_in_file(
        self,
        content: str,
        variable_name: str,
        body_preamble: tuple[str, ...],
    ) -> str:
        """Wrap a call-result variable binding in a Fortran program.

        The literal-binding :meth:`wrap_in_file` variable branch places
        *body_preamble* directly in the program body, but a call stub
        (an internal ``function``/``subroutine``) cannot be a
        plain executable statement: it must live in the ``contains``
        section after the executable statements.  *content* already
        carries the ``type(fval_t) :: name`` specification line followed
        by the binding assignment in the order Fortran requires, so this
        delegates to the empty-``variable_name`` (call-mode) branch of
        :meth:`wrap_in_file`, which places *content* in the program body
        and the stubs in ``contains``.
        """
        del variable_name  # the binding text already carries the name
        return self.wrap_in_file(
            content=content,
            variable_name="",
            body_preamble=body_preamble,
        )

    date_format: DateFormats = DateFormats.ISO
    datetime_format: DatetimeFormats = DatetimeFormats.ISO
    bytes_format: BytesFormats = BytesFormats.HEX
    sequence_format: SequenceFormats = SequenceFormats.LIST
    set_format: SetFormats = SetFormats.SET
    variable_type_hints: VariableTypeHints = VariableTypeHints.NEVER
    comment_format: CommentFormats = CommentFormats.EXCLAMATION
    declaration_style: DeclarationStyles = DeclarationStyles.TYPED
    dict_entry_style: DictEntryStyles = DictEntryStyles.DEFAULT
    dict_format: DictFormats = DictFormats.DEFAULT
    float_format: FloatFormats = FloatFormats.REPR
    integer_format: IntegerFormats = IntegerFormats.DECIMAL
    integer_width_strategy: BareIntegerWidthStrategies = (
        BareIntegerWidthStrategies.BARE
    )
    numeric_literal_suffix: NumericLiteralSuffixes = (
        NumericLiteralSuffixes.NONE
    )
    numeric_separator: NumericSeparators = NumericSeparators.NONE
    numeric_style: NumericStyles = NumericStyles.OVERLOADED
    string_format: StringFormats = StringFormats.DOUBLE
    trailing_comma: TrailingCommas = TrailingCommas.NO
    statement_terminator_style: StatementTerminatorStyles = (
        StatementTerminatorStyles.SEMICOLON
    )
    heterogeneous_strategy: HeterogeneousStrategies = (
        HeterogeneousStrategies.ERROR
    )
    # Each ``VersionFormats`` member has a matching ``-std=`` flag in the
    # Fortran lint steps of `.github/workflows/lint.yml` (``V2003`` ->
    # `-std=f2003`, ``V2008`` -> `-std=f2008`); keep the members and
    # those flags in sync.
    language_version: VersionFormats = VersionFormats.V2008
    indent: str = "    "
    null_name: str = "fnull"
    bool_name: str = "fbool"
    int_name: str = "fint"
    real_name: str = "freal"
    str_name: str = "fstr"
    list_name: str = "flist"
    map_name: str = "fmap"
    set_name: str = "fset"
    entry_name: str = "fentry"

    indent_closing_delimiter: ClassVar[bool] = False
    element_separator: ClassVar[str] = ", "
    skip_null_dict_values: ClassVar[bool] = False
    supports_collection_comments: ClassVar[bool] = True
    supports_scalar_before_comments: ClassVar[bool] = False
    supports_scalar_inline_comments: ClassVar[bool] = False
    statement_terminator: ClassVar[str] = ""
    special_float_preamble: ClassVar[tuple[str, ...]] = (
        "  use, intrinsic :: ieee_arithmetic",
    )
    call_style: CallStyles = CallStyles.POSITIONAL

    @cached_property
    def format_integer(self) -> Callable[[int], str]:
        """Format an int value as an int64 Fortran literal."""

        def format_int64(value: int) -> str:
            """Avoid an out-of-range positive operand for INT64_MIN."""
            if value == I64_MIN:
                return "(-9223372036854775807_int64 - 1_int64)"
            return f"{value}_int64"

        return make_overflow_fallback_formatter(
            base=format_int64,
            fallback=raise_for_unrepresentable_int(language_name="Fortran"),
            min_value=I64_MIN,
            max_value=I64_MAX,
        )

    @cached_property
    def data_dependent_preamble(self) -> Callable[[Value], tuple[str, ...]]:
        """Return data-dependent preamble lines."""
        return no_data_preamble

    @cached_property
    def heterogeneous_behavior(self) -> HeterogeneousBehavior:
        """Return the heterogeneous-behavior config."""
        return self.heterogeneous_strategy.value

    @cached_property
    def call_data_dependent_preamble(
        self,
    ) -> Callable[[Value], tuple[str, ...]]:
        """Return data-dependent preamble lines for call rendering."""
        return self.data_dependent_preamble

    @cached_property
    def type_hint_collection_preamble_lines(
        self,
    ) -> Callable[[frozenset[type]], tuple[str, ...]]:
        """Return preamble lines for empty-collection type hints."""
        return no_type_hint_preamble

    @cached_property
    def call_style_config(self) -> CallStyle:
        """Configuration for the chosen call style."""
        return self.call_style.value

    @cached_property
    def format_call_stub(
        self,
    ) -> Callable[
        [Sequence[str], Sequence[str], StubReturn, Sequence[Value]],
        tuple[str, ...],
    ]:
        """Return stub declarations for a call expression."""
        return partial(_fortran_call_stub, indent=self.indent)

    @cached_property
    def format_call_preamble_stub(
        self,
    ) -> Callable[
        [Sequence[str], Sequence[str], StubReturn, Sequence[Value]],
        tuple[str, ...],
    ]:
        """Return file-scope stubs for a call expression."""
        return no_call_stub

    @cached_property
    def format_call_variable_declaration(
        self,
    ) -> Callable[[str, str, Value, frozenset[enum.Enum]], str]:
        """Callable that formats a declaration binding a call result.

        A literal binding wraps the right-hand side in a ``fval_t``
        constructor chosen from the parsed literal's type; a call's
        return type is opaque to the renderer and is always
        ``type(fval_t)`` (the type every generated call stub returns),
        so the call result is bound directly to a plain ``type(fval_t)``
        declaration with no constructor wrapping.
        """
        return _format_fortran_call_declaration

    @cached_property
    def format_call_variable_assignment(
        self,
    ) -> Callable[[str, str, Value], str]:
        """Callable that formats an assignment binding a call result.

        The call-expression counterpart of
        :attr:`format_variable_assignment`; the ``fval_t``-constructor
        wrapping is dropped since the call already yields a
        ``type(fval_t)``.
        """
        return _format_fortran_call_assignment

    @cached_property
    def format_call_target(self) -> Callable[[Sequence[str]], str]:
        """Rewrite a dotted call target into the language's call
        syntax.
        """
        return _fortran_call_target

    @cached_property
    def format_call_arg(self) -> Callable[[Value, str], str]:
        """Wrap a call argument in the appropriate ``fval_t``
        constructor.
        """
        return self._format_entry

    @cached_property
    def format_call_statement(self) -> Callable[[str], str]:
        """Prepend the Fortran ``call`` keyword to each call statement."""
        return _fortran_call_statement

    @cached_property
    def format_call_ref_identifier(
        self,
    ) -> Callable[[str, Value | None], str]:
        """Rewrite a ``{"$ref": "name"}`` identifier into the
        language's call expression syntax.
        """
        return identity_call_ref_identifier

    @cached_property
    def format_call_arg_ref_identifier(
        self,
    ) -> Callable[[str, Value | None], str]:
        """Rewrite a ``{"$ref": "name"}`` identifier in a call-argument
        context.

        Delegates to :attr:`format_call_ref_identifier`.  Override this to
        allow call-argument ``$ref`` values that would otherwise be rejected.
        """
        return self.format_call_ref_identifier

    @cached_property
    def format_call_arg_ref_identifier_consumable(
        self,
    ) -> Callable[[str, Value | None], str]:
        """Format a ``$ref`` the caller authorized as consumable.

        Delegates to :attr:`format_call_arg_ref_identifier`.  Override
        this to opt into a consuming form (e.g. C++ ``std::move``).
        """
        return self.format_call_arg_ref_identifier

    @cached_property
    def consumable_ref_value_inhibits_consuming_form(
        self,
    ) -> Callable[[Value], bool]:
        """Predicate deciding whether a ref's underlying value type
        inhibits the consume form.

        Delegates to :data:`never_inhibits_consuming_form`.  Languages
        whose consume operator rejects certain value types (notably
        the Mojo ``^`` on register-trivial scalars) override this.
        """
        return never_inhibits_consuming_form

    def wrap_calls_with_declarations(
        self,
        declarations: tuple[str, ...],
        calls: str,
        body_preamble: tuple[str, ...],
    ) -> str:
        """Wrap Fortran call stubs and variable declarations alongside
        calls.

        Fortran requires all specification statements (type
        declarations) to precede executable statements (assignments and
        calls).  Each declaration *bare_code* from :func:`literalize`
        is a two-part string: a ``type(fval_t) :: name`` declaration on
        the first line and an assignment on the remaining lines.  This
        method splits them so that all type-declaration lines appear
        before any assignment or call lines, producing a valid program.

        Call stubs are placed in the ``contains`` section via
        :meth:`wrap_in_file`.
        """
        type_decls: list[str] = []
        exec_stmts: list[str] = []
        for bare_code in declarations:
            lines = bare_code.splitlines()
            type_decls.append(lines[0])
            exec_stmts.extend(lines[1:])
        body_parts: list[str] = [*type_decls, *exec_stmts, calls]
        content = "\n".join(body_parts)
        return self.wrap_in_file(
            content=content,
            variable_name="",
            body_preamble=body_preamble,
        )

    @staticmethod
    def sequence_binding_declarations(declarations: tuple[str, ...]) -> str:
        """Order Fortran binding declarations for variable-mode wrapping.

        Each binding's ``bare_code`` is a ``type(fval_t) :: name``
        specification line followed by an assignment.  Fortran requires
        every specification statement to precede every executable
        statement, so the type-declaration lines are gathered first and
        the assignment lines follow, across all bindings including the
        final result binding.
        """
        type_decls: list[str] = []
        exec_stmts: list[str] = []
        for bare_code in declarations:
            lines = bare_code.splitlines()
            type_decls.append(lines[0])
            exec_stmts.extend(lines[1:])
        return "\n".join((*type_decls, *exec_stmts))

    @cached_property
    def _format_entry(self) -> Callable[[Value, str], str]:
        """Shared entry formatter for Fortran values."""
        return _build_format_fortran_entry(
            int_name=self.int_name,
            real_name=self.real_name,
            str_name=self.str_name,
            datetime_as_int=self.datetime_format.value.type_produced is int,
        )

    @cached_property
    def null_literal(self) -> str:
        """Literal representing ``None``."""
        return f"{self.null_name}()"

    @cached_property
    def true_literal(self) -> str:
        """Literal representing ``True``."""
        return f"{self.bool_name}(.true.)"

    @cached_property
    def false_literal(self) -> str:
        """Literal representing ``False``."""
        return f"{self.bool_name}(.false.)"

    @cached_property
    def sequence_format_config(self) -> SequenceFormatConfig:
        """Configuration for the chosen sequence format."""
        fmt = self.sequence_format.value
        return SequenceFormatConfig(
            sequence_open=fixed_open(
                open_str=f"{self.list_name}([fval_t :: ",
            ),
            close="])",
            supports_heterogeneity=fmt.supports_heterogeneity,
            single_element_trailing_comma=(fmt.single_element_trailing_comma),
            single_element_template=fmt.single_element_template,
            supports_trailing_comma=fmt.supports_trailing_comma,
            empty_sequence=fmt.empty_sequence,
            preamble_lines=fmt.preamble_lines,
            format_entry=fmt.format_entry,
            typed_opener_fallback=fmt.typed_opener_fallback,
            uses_typed_literal_for_scalars=(
                fmt.uses_typed_literal_for_scalars
            ),
            requires_uniform_record_shapes=(
                fmt.requires_uniform_record_shapes
            ),
            declared_type=fmt.declared_type,
            narrowed_empty_form=None,
        )

    @cached_property
    def set_format_config(self) -> SetFormatConfig:
        """Configuration for the chosen set format."""
        return SetFormatConfig(
            set_open=fixed_open(
                open_str=f"{self.set_name}([fval_t :: ",
            ),
            close="])",
            empty_set=self.set_format.value.empty_set,
            preamble_lines=self.set_format.value.preamble_lines,
            set_opener_template=self.set_format.value.set_opener_template,
            supports_heterogeneity=self.set_format.value.supports_heterogeneity,
            supports_trailing_comma=True,
        )

    @cached_property
    def sequence_open(self) -> Callable[[list[Value]], str]:
        """Callable that returns the opening delimiter for a sequence."""
        return self.sequence_format_config.sequence_open

    @cached_property
    def dict_format_config(self) -> DictFormatConfig:
        """Configuration for dict formatting."""
        return DictFormatConfig(
            dict_open=fixed_open(
                open_str=f"{self.map_name}([fval_t :: ",
            ),
            close="])",
            format_entry=dict_entry_with_template(
                template=f"{self.entry_name}({{key}}, {{value}})",
                format_value=self._format_entry,
            ),
            empty_dict=None,
            preamble_lines=(),
            narrowed_open=None,
            supports_trailing_comma=True,
            narrowed_empty_form=None,
        )

    @cached_property
    def trailing_comma_config(self) -> TrailingCommaConfig:
        """Configuration for trailing-comma behavior."""
        return self.trailing_comma.value

    @cached_property
    def format_bytes(self) -> Callable[[bytes], str]:
        """Callable that formats a bytes value as a string literal."""
        return self.bytes_format

    @cached_property
    def format_date(self) -> Callable[[datetime.date], str]:
        """Callable that formats a date as a string literal."""
        return self.date_format

    @cached_property
    def format_datetime(self) -> Callable[[datetime.datetime], str]:
        """Callable that formats a datetime as a string literal."""
        return self.datetime_format

    @cached_property
    def format_time(self) -> Callable[[datetime.time], str]:
        """Callable that formats a time as a string literal."""
        return format_time_iso

    @cached_property
    def format_string(self) -> Callable[[str], str]:
        """Callable that formats a string value as a quoted literal."""
        return _format_fortran_string

    @cached_property
    def format_float(self) -> Callable[[float], str]:
        """Callable that formats a float value as a literal."""
        return self.float_format

    @cached_property
    def format_sequence_entry(self) -> Callable[[Value, str], str]:
        """Callable that formats one sequence entry."""
        return self._format_entry

    @cached_property
    def format_set_entry(self) -> Callable[[Value, str], str]:
        """Callable that formats one set entry."""
        return self._format_entry

    @cached_property
    def comment_config(self) -> CommentConfig:
        """Configuration for the language's comment syntax."""
        return self.comment_format.value

    @cached_property
    def ordered_map_format_config(self) -> OrderedMapFormatConfig:
        """Configuration for ordered-map formatting."""
        return OrderedMapFormatConfig(
            ordered_map_open=fixed_open(
                open_str=f"{self.map_name}([fval_t :: ",
            ),
            close="])",
            preamble_lines=(),
        )

    @cached_property
    def format_ordered_map_entry(self) -> Callable[[str, Value, str], str]:
        """Callable that formats one ordered-map entry."""
        return dict_entry_with_template(
            template=f"{self.entry_name}({{key}}, {{value}})",
            format_value=self._format_entry,
        )

    @cached_property
    def format_variable_declaration(
        self,
    ) -> Callable[[str, str, Value, frozenset[enum.Enum]], str]:
        """Callable that formats a new variable declaration."""
        return _build_format_variable_declaration(
            format_entry=self._format_entry,
        )

    @cached_property
    def format_variable_assignment(
        self,
    ) -> Callable[[str, str, Value], str]:
        """Callable that formats an assignment to an existing variable."""
        return _build_format_variable_assignment(
            format_entry=self._format_entry,
        )

    @cached_property
    def static_preamble(self) -> Sequence[str]:
        """Static preamble lines emitted once per file."""
        return ("module fval_m",)

    @cached_property
    def static_body_preamble(self) -> Sequence[str]:
        """Static body-preamble lines emitted once per file.

        Fortran 2008 imports the ``int64`` and ``real64`` kinds from the
        intrinsic ``iso_fortran_env`` module.  Those named constants did
        not exist in Fortran 2003's ``iso_fortran_env``, so the 2003
        target instead defines equivalent kind parameters with
        ``selected_int_kind(18)`` (18 decimal digits selects the same
        8-byte integer kind ``int64`` denotes) and
        ``selected_real_kind(15, 307)`` (15 decimal digits + a 10**307
        range selects the IEEE 754 binary64 kind ``real64`` denotes).
        Fortran requires ``implicit none`` before any data declaration,
        so the 2003 parameters follow it whereas the 2008 ``use``
        precedes it.  Either way the rest of the module, including the
        ``_int64`` and ``_real64`` literal suffixes, refers to the kinds
        by name, so nothing else varies by version.
        """
        if self.language_version is self.version_formats.V2003:
            kind_lines: tuple[str, ...] = (
                "  implicit none",
                "  integer, parameter :: int64 = selected_int_kind(18)",
                "  integer, parameter :: real64 = selected_real_kind(15, 307)",
            )
        else:
            kind_lines = (
                "  use, intrinsic :: iso_fortran_env, only: int64, real64",
                "  implicit none",
            )
        return (
            *kind_lines,
            "  integer, parameter :: tag_null = 0",
            "  integer, parameter :: tag_bool = 1",
            "  integer, parameter :: tag_int = 2",
            "  integer, parameter :: tag_real = 3",
            "  integer, parameter :: tag_str = 4",
            "  integer, parameter :: tag_list = 5",
            "  integer, parameter :: tag_map = 6",
            "  integer, parameter :: tag_set = 7",
            "  integer, parameter :: tag_entry = 8",
            "  type :: fval_t",
            "    integer :: tag = tag_null",
            "    logical :: bv = .false.",
            "    integer(kind=int64) :: iv = 0_int64",
            "    real(kind=real64) :: rv = 0.0_real64",
            "    character(len=:), pointer :: sv => null()",
            "    type(fval_t), pointer :: items(:) => null()",
            "  end type fval_t",
            "contains",
            "\n".join(
                (
                    f"  function {self.null_name}() result(v)",
                    "    type(fval_t) :: v",
                    "    v%tag = tag_null",
                    f"  end function {self.null_name}",
                )
            ),
            "\n".join(
                (
                    f"  function {self.bool_name}(b) result(v)",
                    "    logical, intent(in) :: b",
                    "    type(fval_t) :: v",
                    "    v%tag = tag_bool",
                    "    v%bv = b",
                    f"  end function {self.bool_name}",
                )
            ),
            "\n".join(
                (
                    f"  function {self.int_name}(n) result(v)",
                    "    integer(kind=int64), intent(in) :: n",
                    "    type(fval_t) :: v",
                    "    v%tag = tag_int",
                    "    v%iv = n",
                    f"  end function {self.int_name}",
                )
            ),
            "\n".join(
                (
                    f"  function {self.real_name}(x) result(v)",
                    "    real(kind=real64), intent(in) :: x",
                    "    type(fval_t) :: v",
                    "    v%tag = tag_real",
                    "    v%rv = x",
                    f"  end function {self.real_name}",
                )
            ),
            "\n".join(
                (
                    f"  function {self.str_name}(s) result(v)",
                    "    character(len=*), intent(in) :: s",
                    "    type(fval_t) :: v",
                    "    v%tag = tag_str",
                    "    allocate(character(len=len(s)) :: v%sv)",
                    "    v%sv = s",
                    f"  end function {self.str_name}",
                )
            ),
            "\n".join(
                (
                    f"  function {self.list_name}(a) result(v)",
                    "    type(fval_t), intent(in) :: a(:)",
                    "    type(fval_t) :: v",
                    "    v%tag = tag_list",
                    "    allocate(v%items(size(a)))",
                    "    v%items = a",
                    f"  end function {self.list_name}",
                )
            ),
            "\n".join(
                (
                    f"  function {self.map_name}(a) result(v)",
                    "    type(fval_t), intent(in) :: a(:)",
                    "    type(fval_t) :: v",
                    "    v%tag = tag_map",
                    "    allocate(v%items(size(a)))",
                    "    v%items = a",
                    f"  end function {self.map_name}",
                )
            ),
            "\n".join(
                (
                    f"  function {self.set_name}(a) result(v)",
                    "    type(fval_t), intent(in) :: a(:)",
                    "    type(fval_t) :: v",
                    "    v%tag = tag_set",
                    "    allocate(v%items(size(a)))",
                    "    v%items = a",
                    f"  end function {self.set_name}",
                )
            ),
            "\n".join(
                (
                    f"  function {self.entry_name}(k, u) result(v)",
                    "    character(len=*), intent(in) :: k",
                    "    type(fval_t), intent(in) :: u",
                    "    type(fval_t) :: v",
                    "    v%tag = tag_entry",
                    "    allocate(character(len=len(k)) :: v%sv)",
                    "    v%sv = k",
                    "    allocate(v%items(1))",
                    "    v%items(1) = u",
                    f"  end function {self.entry_name}",
                )
            ),
            "end module fval_m",
        )

    @cached_property
    def scalar_preamble(self) -> dict[type, tuple[str, ...]]:
        """Per-instance scalar preamble (Fortran needs none)."""
        return {}

    @cached_property
    def scalar_body_preamble(self) -> dict[type, tuple[str, ...]]:
        """Per-instance scalar body preamble (Fortran needs none)."""
        return {}

    @cached_property
    def compute_body_preamble(
        self,
    ) -> Callable[[frozenset[type], Value], tuple[str, ...]]:
        """Compute body-preamble lines from the scalar map."""
        return body_preamble_from_scalars(
            scalar_body_preamble=self.scalar_body_preamble,
            format_lines=tuple,
        )
