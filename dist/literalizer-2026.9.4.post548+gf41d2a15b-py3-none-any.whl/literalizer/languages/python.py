"""Python language specification."""

import dataclasses
import datetime
import enum
import functools
import re
from collections.abc import Callable, Sequence
from functools import cached_property
from types import MappingProxyType
from typing import ClassVar, assert_never

from beartype import beartype

from literalizer._comments import EncodingCookieSafeCommentPrefix
from literalizer._formatters.collection_openers import (
    fixed_open,
)
from literalizer._formatters.format_dates import (
    date_ymd_formatter,
    format_date_iso,
    format_datetime_epoch,
)
from literalizer._formatters.format_entries import (
    dict_entry_with_separator,
    format_bytes_base64,
    format_bytes_hex,
    passthrough_sequence_entry,
    passthrough_set_entry,
    tuple_dict_entry,
    variable_declaration_formatter,
    variable_formatter,
)
from literalizer._formatters.format_floats import (
    format_float_fixed,
    format_float_repr,
    format_float_scientific,
)
from literalizer._formatters.format_integers import (
    format_integer_binary,
    format_integer_hex,
    format_integer_octal,
    format_integer_underscore,
)
from literalizer._formatters.format_strings import (
    bidi_escape_replacements,
    has_bidi_formatting_character,
    make_backslash_string_formatter,
)
from literalizer._formatters.record_strategy import (
    RecordDeclarationField,
    RecordFieldType,
    RecordLiteralField,
    RecordRenderer,
    RecordStrategy,
    build_record_strategy,
    identity_field_identifier_key,
)
from literalizer._formatters.type_inference import record_shape_for_dict
from literalizer._language import (
    NO_CALL_PARAMETER_LIMIT,
    NO_HETEROGENEOUS_BEHAVIOR,
    NON_KEBAB_REF_CASES,
    BareIntegerWidthStrategies,
    CallParameterShadowing,
    CallStyle,
    CommentConfig,
    DateFormatConfig,
    DateFormatEnum,
    DatetimeFormatConfig,
    DatetimeFormatEnum,
    DeclarationStyleConfig,
    DictFormatConfig,
    FloatSpecialsMixin,
    HeterogeneousBehavior,
    IdentifierCase,
    JsonType,
    KeywordCallStyle,
    LanguageCls,
    LeadingPreamble,
    ModifierCombination,
    NewVariableNameSyntax,
    OrderedMapFormatConfig,
    PositionalCallStyle,
    RenderedRecordLiteral,
    SequenceFormatConfig,
    SetFormatConfig,
    StubReturn,
    TrailingCommaConfig,
    VariantMetadata,
    body_preamble_from_scalars,
    date_scalar_preamble,
    default_format_call_variable_assignment,
    default_sequence_binding_declarations,
    default_wrap_calls_with_declarations,
    identity_call_arg,
    identity_call_ref_identifier,
    identity_call_statement,
    identity_call_target,
    identity_constructor_target,
    never_inhibits_consuming_form,
    no_call_binding_body_preamble,
    no_call_binding_file_pragmas,
    no_call_stub,
    no_data_preamble,
    no_format_integer_beyond_i64,
    no_format_integer_widened,
    no_validate_call_arg,
    no_validate_spec_for_data,
    wrap_combined_in_file_noop,
    wrap_in_file_noop,
)
from literalizer._preamble import (
    EmptyDict,
    EmptyList,
    EmptyOrderedMap,
    EmptySet,
    HeterogeneousElements,
)
from literalizer._types import OrderedMap, Scalar, Value
from literalizer.exceptions import (
    IncompatibleFormatsError,
    UnrepresentableInputError,
)

_TRAILING_LINE_WHITESPACE = re.compile(pattern=r"[ \t]+(?=\n)")

_BIDI_REPLACEMENTS = bidi_escape_replacements(template="\\u{:04X}")

# Python source cannot contain a literal zero byte.
_format_string_double = make_backslash_string_formatter(
    quote_char='"',
    extra_replacements=[
        ("\0", "\\x00"),
        *_BIDI_REPLACEMENTS,
    ],
)
_format_string_single = make_backslash_string_formatter(
    quote_char="'",
    extra_replacements=[
        ("\0", "\\x00"),
        *_BIDI_REPLACEMENTS,
    ],
)
_format_string_backslash = make_backslash_string_formatter(
    quote_char='"',
    extra_replacements=[*_BIDI_REPLACEMENTS],
)


@beartype
def _format_string_raw(value: str) -> str:
    r"""Format a string as a Python raw string literal.

    Backslashes are kept verbatim. When the value contains no double
    quotes, ``r"…"`` is used. When it contains double quotes,
    ``r'''…'''`` is used so that the quotes need no escaping.

    Falls back to a regular escaped literal when the value contains a
    null byte or a carriage return, ends with an odd number of
    backslashes, or contains both ``"`` and ``'''``.

    A raw literal cannot spell a carriage return: ``\r`` is not an
    escape there, and Python normalizes a literal one while reading
    source, so the value read back would differ from the input
    (issue #3926).
    """
    if (
        "\0" in value
        or "\r" in value
        or has_bidi_formatting_character(value=value)
    ):
        return _format_string_double(value=value)
    stripped = value.rstrip("\\")
    trailing_backslashes = len(value) - len(stripped)
    if trailing_backslashes % 2 == 1:
        return _format_string_backslash(value=value)
    has_newline = "\n" in value
    if '"' not in value and not has_newline:
        return f'r"{value}"'
    if "'''" not in value:
        return f"r'''{value}'''"
    return _format_string_backslash(value=value)


@beartype
def _escape_trailing_whitespace(match: re.Match[str]) -> str:
    r"""Return one ``\x20`` escape per character of the whitespace run
    *match*.
    """
    return r"\x20" * len(match[0])


@beartype
def _format_string_multiline(value: str) -> str:
    r"""Format *value* as an exact Python triple-quoted string.

    The opening line continuation puts the contents on a new source line
    without adding that newline to the runtime value.
    """
    escaped = (
        value.replace("\\", "\\\\")
        .replace("\0", "\\x00")
        .replace("\r", "\\r")
        .replace("\t", "\\t")
        .replace('"', '\\"')
    )
    for character, escape in _BIDI_REPLACEMENTS:
        escaped = escaped.replace(character, escape)
    escaped = _TRAILING_LINE_WHITESPACE.sub(
        repl=_escape_trailing_whitespace,
        string=escaped,
    )
    return f'"""\\\n{escaped}"""'


@beartype
def _format_datetime_python(
    value: datetime.datetime,
    /,
    *,
    utc_tzinfo_expr: str,
) -> str:
    """Format a datetime as a Python ``datetime.datetime(...)`` constructor
    call.
    """
    parts = [
        f"year={value.year}",
        f"month={value.month}",
        f"day={value.day}",
        f"hour={value.hour}",
        f"minute={value.minute}",
        f"second={value.second}",
    ]
    if value.microsecond != 0:
        parts.append(f"microsecond={value.microsecond}")
    if value.tzinfo is not None and (offset := value.utcoffset()) is not None:
        if offset == datetime.timedelta():
            parts.append(f"tzinfo={utc_tzinfo_expr}")
        else:
            total_seconds = int(offset.total_seconds())
            sign = 1
            if total_seconds < 0:
                sign = -1
            abs_seconds = abs(total_seconds)
            hours = sign * (abs_seconds // 3600)
            minutes = sign * ((abs_seconds % 3600) // 60)
            td_parts = [f"hours={hours}"]
            if minutes != 0:
                td_parts.append(f"minutes={minutes}")
            td_args = ", ".join(td_parts)
            parts.append(
                f"tzinfo=datetime.timezone(offset=datetime.timedelta({td_args}))"
            )
    args = ", ".join(parts)
    return f"datetime.datetime({args})"


@beartype
def _format_time_python(value: datetime.time) -> str:
    """Format a time as a Python ``datetime.time(...)`` constructor
    call.
    """
    parts = [
        f"hour={value.hour}",
        f"minute={value.minute}",
        f"second={value.second}",
    ]
    if value.microsecond != 0:
        parts.append(f"microsecond={value.microsecond}")
    args = ", ".join(parts)
    return f"datetime.time({args})"


@beartype
def _format_bytes_python(value: bytes) -> str:
    """Format bytes as a Python ``bytes`` literal."""
    return repr(value)


@beartype
def _needs_type_annotation(
    *,
    data: Value,
    record_eligible: Callable[[Value], bool],
) -> bool:
    """Whether *data* needs a type annotation for type-checkers.

    This is true when *data* is or contains an empty collection,
    because type-checkers cannot infer the element types.

    Under the ``RECORD`` strategy a record-shaped dict renders as a
    fully-annotated ``@dataclasses.dataclass`` instance, so it is
    self-describing and neither needs a helper annotation nor drags an
    enclosing collection into needing one (an empty collection that is
    one of its fields is annotated on the dataclass field instead).
    *record_eligible* identifies such dicts; it is a constant ``False``
    predicate when the strategy is not ``RECORD``.
    """
    match data:
        case dict():
            if record_eligible(data):
                return False
            return len(data) == 0 or any(
                _needs_type_annotation(data=v, record_eligible=record_eligible)
                for v in data.values()
            )
        case set():
            return len(data) == 0
        case list():
            return len(data) == 0 or any(
                _needs_type_annotation(data=e, record_eligible=record_eligible)
                for e in data
            )
        case _:
            return False


@beartype
def _format_variable_declaration(
    *,
    name: str,
    value: str,
    data: Value,
    _modifiers: frozenset[enum.Enum],
    bytes_hint: str,
    date_hint: str,
    datetime_hint: str,
    time_hint: str,
    sequence_hint: str,
    set_hint: str,
    dict_hint: str,
    default_set_element_type: str,
    default_sequence_element_type: str,
    default_dict_value_type: str,
    default_dict_key_type: str,
    join_union: Callable[[list[str]], str],
    record_eligible: Callable[[Value], bool],
) -> str:
    """Format a Python variable declaration.

    For empty collections a type annotation is added so that
    type-checkers can infer the type.  *record_eligible* lets a
    ``RECORD``-strategy record-shaped dict opt out (it is self-typed
    by its generated dataclass); see :func:`_needs_type_annotation`.
    """
    if _needs_type_annotation(data=data, record_eligible=record_eligible):
        return _format_inline_type_hint_declaration(
            name=name,
            value=value,
            data=data,
            _modifiers=_modifiers,
            bytes_hint=bytes_hint,
            date_hint=date_hint,
            datetime_hint=datetime_hint,
            time_hint=time_hint,
            sequence_hint=sequence_hint,
            set_hint=set_hint,
            dict_hint=dict_hint,
            default_set_element_type=default_set_element_type,
            default_sequence_element_type=default_sequence_element_type,
            default_dict_value_type=default_dict_value_type,
            default_dict_key_type=default_dict_key_type,
            join_union=join_union,
        )
    return f"{name} = {value}"


@beartype
def _format_inline_type_hint_declaration(
    *,
    name: str,
    value: str,
    data: Value,
    _modifiers: frozenset[enum.Enum],
    bytes_hint: str,
    date_hint: str,
    datetime_hint: str,
    time_hint: str,
    sequence_hint: str,
    set_hint: str,
    dict_hint: str,
    default_set_element_type: str,
    default_sequence_element_type: str,
    default_dict_value_type: str,
    default_dict_key_type: str,
    join_union: Callable[[list[str]], str],
) -> str:
    """Format a Python variable declaration with an inline type hint."""
    hint = _python_type_hint(
        data=data,
        bytes_hint=bytes_hint,
        date_hint=date_hint,
        datetime_hint=datetime_hint,
        time_hint=time_hint,
        sequence_hint=sequence_hint,
        set_hint=set_hint,
        dict_hint=dict_hint,
        default_set_element_type=default_set_element_type,
        default_sequence_element_type=default_sequence_element_type,
        default_dict_value_type=default_dict_value_type,
        default_dict_key_type=default_dict_key_type,
        join_union=join_union,
    )
    return f"{name}: {hint} = {value}"


@beartype
def _join_union_pipe(types: list[str]) -> str:
    """Join *types* with ``|`` (Python 3.10+ union syntax)."""
    return " | ".join(types)


@beartype
def _join_union_typing(types: list[str]) -> str:
    """Join *types* as ``Union[...]`` (Python 3.8-compatible)."""
    return f"Union[{', '.join(types)}]"


@beartype
def _none_last_sort_key(type_name: str) -> bool:
    """Return a sort key that orders ``None`` after every other type
    name.
    """
    return type_name == "None"


@beartype
def _element_union(
    *, types: list[str], join_union: Callable[[list[str]], str]
) -> str:
    """Remove duplicate *types* and join them into a union."""
    unique: list[str] = sorted(
        dict.fromkeys(types),
        key=_none_last_sort_key,
    )
    match unique:
        case [only]:
            return only
        case _:
            return join_union(unique)


@beartype
def _collection_element_union(
    *,
    elements: list[Value],
    recurse: Callable[..., str],
    sort: bool,
    merge_dicts: bool,
    default_type: str,
    join_union: Callable[[list[str]], str],
) -> str:
    """Return the element union for a collection, or *default_type* if
    empty.

    When *merge_dicts* is ``True``, all dict elements are merged so
    that their values produce a single ``dict[str, …]`` hint.  This
    avoids ``dict[str, X] | dict[str, Y]`` unions that mypy rejects
    because ``dict`` is invariant in its type parameters.
    """
    if len(elements) == 0:
        return default_type
    if merge_dicts:
        elements = _merge_dict_elements(elements=elements)
    types = [recurse(data=e) for e in elements]
    if sort:
        types.sort()
    return _element_union(types=types, join_union=join_union)


@beartype
def _merge_dict_elements(*, elements: list[Value]) -> list[Value]:
    """Pool values from like-typed dicts into single representatives."""
    plain_vals: list[Value] = []
    ordered_vals: list[Value] = []
    non_dict: list[Value] = []
    has_plain = False
    has_ordered = False
    for elem in elements:
        match elem:
            case dict():
                is_ordered = isinstance(elem, OrderedMap)
                target = plain_vals
                if is_ordered:
                    target = ordered_vals
                target.extend(elem.values())
                if is_ordered:
                    has_ordered = True
                else:
                    has_plain = True
            case _:
                non_dict.append(elem)
    merged: list[Value] = list(non_dict)
    if has_plain:
        plain_repr: dict[Scalar, Value] = {
            str(object=i): v for i, v in enumerate(iterable=plain_vals)
        }
        merged.append(plain_repr)
    if has_ordered:
        ordered_repr: dict[Scalar, Value] = {
            str(object=i): v for i, v in enumerate(iterable=ordered_vals)
        }
        merged.append(OrderedMap(ordered_repr))
    return merged


@beartype
def _python_temporal_hint(
    *,
    data: datetime.date | datetime.time,
    date_hint: str,
    datetime_hint: str,
    time_hint: str,
) -> str:
    """Derive a Python type hint for a temporal scalar value."""
    match data:
        case datetime.datetime():
            hint = datetime_hint
        case datetime.date():
            hint = date_hint
        case datetime.time():
            hint = time_hint
        case _ as unreachable:
            assert_never(unreachable)
    return hint


@beartype
def _python_scalar_hint(
    *,
    data: Scalar,
    bytes_hint: str,
    date_hint: str,
    datetime_hint: str,
    time_hint: str,
) -> str:
    """Derive a Python type hint for a scalar value."""
    # Order matters: datetime before date (datetime is a date subclass),
    # bool before int (bool is an int subclass).
    match data:
        case bool():
            hint = "bool"
        case int():
            hint = "int"
        case float():
            hint = "float"
        case str():
            hint = "str"
        case bytes():
            hint = bytes_hint
        case datetime.datetime() | datetime.date() | datetime.time():
            hint = _python_temporal_hint(
                data=data,
                date_hint=date_hint,
                datetime_hint=datetime_hint,
                time_hint=time_hint,
            )
        case None:
            hint = "None"
        case _ as unreachable:
            assert_never(unreachable)
    return hint


@beartype
def _python_type_hint(
    *,
    data: Value,
    bytes_hint: str,
    date_hint: str,
    datetime_hint: str,
    time_hint: str,
    sequence_hint: str,
    set_hint: str,
    dict_hint: str,
    default_set_element_type: str,
    default_sequence_element_type: str,
    default_dict_value_type: str,
    default_dict_key_type: str,
    join_union: Callable[[list[str]], str],
) -> str:
    """Derive a Python type hint from the original data and format
    config.
    """
    recurse = functools.partial(
        _python_type_hint,
        bytes_hint=bytes_hint,
        date_hint=date_hint,
        datetime_hint=datetime_hint,
        time_hint=time_hint,
        sequence_hint=sequence_hint,
        set_hint=set_hint,
        dict_hint=dict_hint,
        default_set_element_type=default_set_element_type,
        default_sequence_element_type=default_sequence_element_type,
        default_dict_value_type=default_dict_value_type,
        default_dict_key_type=default_dict_key_type,
        join_union=join_union,
    )

    match data:
        case dict():
            outer = dict_hint
            if isinstance(data, OrderedMap):
                outer = "OrderedDict"
            key_hint = "str"
            if len(data) == 0:
                key_hint = default_dict_key_type
            val_union = _collection_element_union(
                elements=list(data.values()),
                recurse=recurse,
                sort=False,
                merge_dicts=False,
                default_type=default_dict_value_type,
                join_union=join_union,
            )
            hint = f"{outer}[{key_hint}, {val_union}]"
        case set():
            elem_union = _collection_element_union(
                elements=list(data),
                recurse=recurse,
                sort=True,
                merge_dicts=False,
                default_type=default_set_element_type,
                join_union=join_union,
            )
            hint = f"{set_hint}[{elem_union}]"
        case list():
            elem_union = _collection_element_union(
                elements=data,
                recurse=recurse,
                sort=False,
                merge_dicts=True,
                default_type=default_sequence_element_type,
                join_union=join_union,
            )
            if sequence_hint.casefold() == "tuple":
                hint = f"{sequence_hint}[{elem_union}, ...]"
            else:
                hint = f"{sequence_hint}[{elem_union}]"
        case _:
            hint = _python_scalar_hint(
                data=data,
                bytes_hint=bytes_hint,
                date_hint=date_hint,
                datetime_hint=datetime_hint,
                time_hint=time_hint,
            )
    return hint


@beartype
def _build_type_hint_preamble(
    *,
    always_type_hints: bool,
    use_typing_union: bool,
    default_set_element_type: str,
    default_sequence_element_type: str,
    default_dict_value_type: str,
    default_dict_key_type: str,
) -> Callable[[frozenset[type]], tuple[str, ...]]:
    """Build a callable that returns preamble lines for type hints.

    The returned callable checks which empty collection types are
    present in the data and only emits ``from typing import Any``
    when at least one of them would produce an ``Any`` type hint.
    """
    # Pre-compute which collection types need "Any".
    _any_types: frozenset[type] = frozenset(
        t
        for t, needs in (
            (
                EmptyDict,
                default_dict_value_type == "Any"
                or default_dict_key_type == "Any",
            ),
            (
                EmptyOrderedMap,
                default_dict_value_type == "Any"
                or default_dict_key_type == "Any",
            ),
            (EmptySet, default_set_element_type == "Any"),
            (EmptyList, default_sequence_element_type == "Any"),
        )
        if needs
    )

    def _preamble(
        annotated_collection_types: frozenset[type],
        /,
    ) -> tuple[str, ...]:
        """Return the required ``typing`` imports."""
        imports: set[str] = set()
        if (
            use_typing_union
            and HeterogeneousElements in annotated_collection_types
            and (
                always_type_hints
                or annotated_collection_types
                != frozenset({HeterogeneousElements})
            )
        ):
            imports.add("Union")
        if len(_any_types.intersection(annotated_collection_types)) > 0:
            imports.add("Any")
        if len(imports) == 0:
            return ()
        return (f"from typing import {', '.join(sorted(imports))}",)

    return _preamble


@beartype
def _build_python_call_stub(
    *,
    indent: str,
) -> Callable[
    [Sequence[str], Sequence[str], StubReturn, Sequence[Value]],
    tuple[str, ...],
]:
    """Return a Python call-stub builder bound to ``indent``."""

    def _python_call_stub(
        parts: Sequence[str],
        _params: Sequence[str],
        _stub_return: StubReturn,
        _args: Sequence[Value],
        /,
    ) -> tuple[str, ...]:
        """Return Python stub declarations for a call name."""
        variadic = "*_args: object, **_kwargs: object"
        if len(parts) == 1:
            return (f"def {parts[0]}({variadic}) -> object: ...",)
        root = parts[0]
        method = parts[-1]
        fields = parts[1:-1]
        if len(fields) == 0:
            cls = f"_{IdentifierCase.PASCAL.convert(name=root)}Type"
            return (
                f"class {cls}:",
                f"{indent}def {method}(self, {variadic}) -> object: ...",
                f"{root} = {cls}()",
            )
        lines: list[str] = []
        inner_cls = f"_{IdentifierCase.PASCAL.convert(name=fields[-1])}Type"
        lines.append(f"class {inner_cls}:")
        lines.append(f"{indent}def {method}(self, {variadic}) -> object: ...")
        prev_cls = inner_cls
        for i in range(len(fields) - 2, -1, -1):
            cls = f"_{IdentifierCase.PASCAL.convert(name=fields[i])}Type"
            lines.append(f"class {cls}:")
            lines.append(f"{indent}{fields[i + 1]} = {prev_cls}()")
            prev_cls = cls
        root_cls = f"_{IdentifierCase.PASCAL.convert(name=root)}Type"
        lines.append(f"class {root_cls}:")
        lines.append(f"{indent}{fields[0]} = {prev_cls}()")
        lines.append(f"{root} = {root_cls}()")
        return tuple(lines)

    return _python_call_stub


@beartype
def _build_type_hint_preamble_py38(
    *,
    always_type_hints: bool,
    sequence_typing_name: str,
    set_typing_name: str,
    use_typing_collection_aliases: bool,
    use_typing_union: bool,
    default_set_element_type: str,
    default_sequence_element_type: str,
    default_dict_value_type: str,
    default_dict_key_type: str,
) -> Callable[[frozenset[type]], tuple[str, ...]]:
    """Build the ``type_hint_collection_preamble_lines`` callable for PY38.

    Postponed PY38 annotations can use built-in generic aliases. Eager
    annotations require collection aliases from ``typing``.
    """
    _any_types: frozenset[type] = frozenset(
        t
        for t, needs in (
            (
                EmptyDict,
                default_dict_value_type == "Any"
                or default_dict_key_type == "Any",
            ),
            (
                EmptyOrderedMap,
                default_dict_value_type == "Any"
                or default_dict_key_type == "Any",
            ),
            (EmptySet, default_set_element_type == "Any"),
            (EmptyList, default_sequence_element_type == "Any"),
        )
        if needs
    )

    def _preamble(
        annotated_collection_types: frozenset[type],
        /,
    ) -> tuple[str, ...]:
        """Return ``from typing import ...`` for PY38."""
        imports: set[str] = set()
        if use_typing_collection_aliases:
            if list in annotated_collection_types:
                imports.add(sequence_typing_name)
            if set in annotated_collection_types:
                imports.add(set_typing_name)
            if dict in annotated_collection_types:
                imports.add("Dict")
        if (
            use_typing_union
            and HeterogeneousElements in annotated_collection_types
            and (
                always_type_hints
                or annotated_collection_types
                != frozenset({HeterogeneousElements})
            )
        ):
            imports.add("Union")
        if len(_any_types.intersection(annotated_collection_types)) > 0:
            imports.add("Any")
        if len(imports) == 0:
            return ()
        return (f"from typing import {', '.join(sorted(imports))}",)

    return _preamble


@beartype
def _python_record_field_identifier(
    key: str, /, *, reserved_identifiers: frozenset[str]
) -> str:
    """Return the dataclass field name for a dict *key*.

    Python field identifiers are the dict keys verbatim (no case
    conversion), matching the keyword-argument literal form
    ``Record0(id=1, ...)``.  A keyword has no escaped spelling in
    either the annotation or the keyword argument, so a key that is
    one is refused (issue #3934).
    """
    if key in reserved_identifiers:
        msg = f"Python record field name {key!r} is reserved"
        raise UnrepresentableInputError(msg)
    return key


@beartype
def _python_record_literal(
    name: str,
    fields: Sequence[RecordLiteralField],
    /,
) -> RenderedRecordLiteral:
    """Render a Python ``Name(field=value, ...)`` keyword constructor
    call as structured pieces for the shared compact/multiline layout
    code.
    """
    return RenderedRecordLiteral(
        head=f"{name}(",
        entries=tuple(
            f"{field.identifier}={field.formatted}" for field in fields
        ),
        closer=")",
        compact_pad="",
    )


@beartype
@dataclasses.dataclass(frozen=True, kw_only=True)
class Python(metaclass=LanguageCls):
    """Python language specification.

    Args:
        date_format: How to format :class:`datetime.date` values.

            * ``date_formats.PYTHON`` — ``datetime.date`` constructor call,
              e.g. ``datetime.date(year=2024, month=1, day=15)``.
            * ``date_formats.ISO`` — ISO 8601 quoted string,
              e.g. ``"2024-01-15"``.

        datetime_format: How to format :class:`datetime.datetime` values.

            * ``datetime_formats.PYTHON`` — ``datetime.datetime`` constructor
              call, e.g. ``datetime.datetime(year=2024, month=1,
              day=15, hour=12, minute=30, second=0)``.
            * ``datetime_formats.EPOCH`` — integer Unix epoch seconds,
              e.g. ``1705312200``.

        bytes_format: How to format :class:`bytes` values.

            * ``bytes_formats.HEX`` — lowercase hex string,
              e.g. ``"48656c6c6f"``.
            * ``bytes_formats.PYTHON`` — Python bytes literal,
              e.g. ``b'Hello'``.

        sequence_format: Which Python sequence type to use.

            * ``sequence_formats.TUPLE`` — tuple literal,
              e.g. ``(1, 2, 3)``.
            * ``sequence_formats.LIST`` — list literal,
              e.g. ``[1, 2, 3]``.

        set_format: Which Python set type to use.

            * ``set_formats.SET`` — mutable set literal,
              e.g. ``{1, 2, 3}``.
            * ``set_formats.FROZENSET`` — immutable frozenset,
              e.g. ``frozenset({1, 2, 3})``.

        default_set_element_type: Type name used for empty set type
            hints.  Defaults to ``"Any"``.

        default_sequence_element_type: Type name used for empty
            list/tuple type hints.  Defaults to ``"Any"``.

        default_dict_key_type: Type name used for empty dict key
            type hints.  Defaults to ``"str"``.

        default_dict_value_type: Type name used for empty dict value
            type hints.  Defaults to ``"Any"``.

        variable_type_hints: Whether to add inline type hints to
            variable declarations.

            * ``VariableTypeHints.NEVER`` — bare assignment,
              e.g. ``my_var = {...}``.  Empty collections still
              receive a type annotation so that type-checkers can
              infer the element types,
              e.g. ``my_var: dict[str, Any] = {}``.
            * ``VariableTypeHints.ALWAYS`` — every declaration has
              a type annotation,
              e.g. ``my_var: dict[str, Any] = {...}``.

        annotation_evaluation: When generated annotations are evaluated.

            * ``AnnotationEvaluations.POSTPONED`` — include
              ``from __future__ import annotations`` when annotations
              are emitted (default).
            * ``AnnotationEvaluations.EAGER`` — omit the future import
              and use ordinary runtime annotation evaluation.

        union_format: How to spell union type annotations.

            * ``UnionFormats.AUTO`` — use ``A | B`` with postponed
              annotations and ``typing.Union[A, B]`` with eager
              annotations (default).
            * ``UnionFormats.PIPE`` — always use ``A | B``. This is
              incompatible with eager annotations for the currently
              supported Python 3.8 and 3.9 targets.
            * ``UnionFormats.TYPING`` — always use
              ``typing.Union[A, B]``.

        language_version: The minimum Python version to target.

            Both compatibility variants use built-in ``list``, ``dict``,
            etc. directly as generic aliases when annotations are
            postponed. Eager Python 3.8 annotations use aliases from
            ``typing`` instead.

        heterogeneous_strategy: How to render a record-shaped dict
            (non-empty, string-keyed).

            * ``HeterogeneousStrategies.ERROR`` — render a plain
              ``dict`` (default).  Python's ``dict`` is already
              heterogeneous, so every record-shaped dict is
              representable as one.
            * ``HeterogeneousStrategies.RECORD`` — opt-in
              idiomatic-output strategy: render each record-shaped dict
              as a generated frozen ``@dataclasses.dataclass`` declared
              in the preamble plus a matching
              ``RecordN(field=value, ...)`` literal.  Every dict is
              still representable as a plain ``dict``; this strategy
              only produces the more idiomatic dataclass form.

        record_struct_name_prefix: Prefix for the auto-generated
            ``@dataclasses.dataclass`` names under the ``RECORD``
            strategy (``"Record"`` -> ``Record0``, ``Record1``, ...).
    """

    reserved_module_identifiers: ClassVar[frozenset[str]] = frozenset()
    immutable_variable_modifiers: ClassVar[frozenset[enum.Enum]] = frozenset()
    module_name_shares_variable_scope = False
    reserved_variable_identifier_pattern: ClassVar[re.Pattern[str] | None] = (
        None
    )
    reserved_call_parameter_identifiers: ClassVar[frozenset[str]] = frozenset()
    reserved_call_parameter_identifier_pattern: ClassVar[
        re.Pattern[str] | None
    ] = None
    accepts_type_name_call_target = True
    declares_type_name_call_target = True
    dotted_call_root_shares_entrypoint_namespace = True
    reserved_bare_call_target_identifiers: ClassVar[frozenset[str]] = (
        frozenset()
    )
    reserved_call_target_head_identifiers: ClassVar[frozenset[str]] = (
        frozenset()
    )
    contextual_call_target_identifiers: ClassVar[frozenset[str]] = frozenset()
    call_parameter_shadowing = CallParameterShadowing.ALLOWED
    reserved_call_target_keywords_case_sensitive = True
    module_name_must_start_uppercase = False
    new_variable_name_syntax = NewVariableNameSyntax.ASCII
    max_variable_identifier_length: ClassVar[int | None] = None
    call_target_name_syntax: ClassVar[NewVariableNameSyntax | None] = None
    supports_multiline_dict_layout = True
    pools_map_integer_width = True

    format_integer_widened = no_format_integer_widened
    format_integer_beyond_i64 = no_format_integer_beyond_i64
    format_constructor_target: ClassVar["staticmethod[[str], str]"] = (
        staticmethod(identity_constructor_target)
    )
    format_call_variable_assignment = default_format_call_variable_assignment
    sequence_binding_declarations = default_sequence_binding_declarations
    format_call_binding_body_preamble = no_call_binding_body_preamble
    format_call_binding_file_pragmas = no_call_binding_file_pragmas

    extension = ".py"
    pygments_name = "python"
    stringifies_nested_collections = False
    supports_special_floats = True
    supports_variable_names = True
    wrap_in_file_tolerates_pre_indent: ClassVar[bool] = False
    supports_no_variable_wrap_in_file = True
    wraps_data_dependent_preamble_in_body = False
    dict_supports_heterogeneous_values = True
    supports_dotted_calls = True
    has_free_function_calls = True
    declares_call_parameter_names = True
    reserved_variable_identifiers_case_sensitive: bool = True
    reserved_variable_identifiers: frozenset[str] = frozenset(
        {
            "False",
            "None",
            "True",
            "and",
            "as",
            "assert",
            "async",
            "await",
            "break",
            "case",
            "class",
            "continue",
            "def",
            "del",
            "elif",
            "else",
            "except",
            "finally",
            "for",
            "from",
            "global",
            "if",
            "import",
            "in",
            "is",
            "lambda",
            "match",
            "nonlocal",
            "not",
            "or",
            "pass",
            "raise",
            "return",
            "try",
            "while",
            "with",
            "yield",
        }
    )
    reserved_identifiers: ClassVar[frozenset[str]] = (
        reserved_variable_identifiers
    )
    allows_empty_call_parens = True
    supports_dotted_call_stub = True
    call_returns_expression = True
    supports_json_call_result_binding = False
    supports_zero_parameter_calls = True
    max_call_parameters = NO_CALL_PARAMETER_LIMIT
    supports_inline_multiline_dict_args = True
    supports_standalone_comments_in_wrapped_calls = True
    supports_multi_param_call_wrapper_stub = True
    supports_dict_literal_as_free_expression = True
    supports_module_name = False
    supports_empty_dict_key = False
    supports_call_style = True
    supports_default_dict_key_type = True
    supports_default_dict_value_type = True
    supports_default_sequence_element_type = True
    supports_default_set_element_type = True
    supports_default_ordered_map_value_type = False
    json_type_variant_name_suffix: ClassVar[str | None] = None
    supports_non_ascii_string_literals = True
    supports_multiline_string_literals = True
    supports_empty_sibling_sequence_type_hints = True
    supports_typed_dict_open = False
    language_id: ClassVar[str] = "python"
    variant_metadata: ClassVar[VariantMetadata] = VariantMetadata(
        round_trip_capabilities=frozenset(),
        modifier_sequence_format_overrides={},
        string_literals_escape_null_byte=True,
        supports_ref_elements_in_tuple_strategy=False,
    )
    supports_record_struct_name_prefix = True
    supports_record_shape_names = False
    record_shape_names_emit_declarations = False
    supports_non_string_dict_keys = True
    checks_raw_control_dict_keys_separately = False

    format_call_arg: ClassVar["staticmethod[[Value, str], str]"] = (
        staticmethod(
            identity_call_arg,
        )
    )
    """Callable that rewrites a formatted direct call argument."""

    class DateFormats(DateFormatEnum):
        """Date formatting options for Python."""

        _value_: DateFormatConfig

        PYTHON = DateFormatConfig(
            formatter=date_ymd_formatter(
                template="datetime.date("
                "year={year}, month={month}, day={day})",
            ),
            preamble_lines=("import datetime",),
            type_produced=datetime.date,
        )
        ISO = DateFormatConfig(
            formatter=format_date_iso, type_produced=str, preamble_lines=()
        )

        @property
        def type_hint(self) -> str:
            """The Python type hint for this date format."""
            if self is type(self).PYTHON:
                return "datetime.date"
            return "str"

    class DatetimeFormats(DatetimeFormatEnum):
        """Datetime formatting options for Python."""

        _value_: DatetimeFormatConfig

        PYTHON = DatetimeFormatConfig(
            formatter=functools.partial(
                _format_datetime_python,
                utc_tzinfo_expr="datetime.UTC",
            ),
            preamble_lines=("import datetime",),
            type_produced=datetime.datetime,
        )
        EPOCH = DatetimeFormatConfig(
            formatter=format_datetime_epoch,
            type_produced=int,
            preamble_lines=(),
        )

        @property
        def type_hint(self) -> str:
            """The Python type hint for this datetime format."""
            if self is type(self).PYTHON:
                return "datetime.datetime"
            return "int"

    class BytesFormats(enum.Enum):
        """Bytes formatting options for Python."""

        _value_: Callable[[bytes], str]

        HEX = enum.member(value=format_bytes_hex)
        BASE64 = enum.member(value=format_bytes_base64)
        PYTHON = enum.member(value=_format_bytes_python)

        def __call__(self, data: bytes, /) -> str:
            """Format bytes."""
            return self._value_(data)

        @property
        def type_hint(self) -> str:
            """The Python type hint for this bytes format."""
            if self is type(self).PYTHON:
                return "bytes"
            return "str"

    class SequenceFormats(enum.Enum):
        """Sequence type options for Python."""

        TUPLE = SequenceFormatConfig(
            sequence_open=fixed_open(open_str="("),
            close=")",
            supports_heterogeneity=True,
            single_element_trailing_comma=True,
            single_element_template=None,
            supports_trailing_comma=True,
            empty_sequence=None,
            preamble_lines=(),
            format_entry=passthrough_sequence_entry,
            typed_opener_fallback=None,
            uses_typed_literal_for_scalars=False,
            requires_uniform_record_shapes=False,
            declared_type=None,
            narrowed_empty_form=None,
        )
        LIST = SequenceFormatConfig(
            sequence_open=fixed_open(open_str="["),
            close="]",
            supports_heterogeneity=True,
            single_element_trailing_comma=False,
            single_element_template=None,
            supports_trailing_comma=True,
            empty_sequence=None,
            preamble_lines=(),
            format_entry=passthrough_sequence_entry,
            typed_opener_fallback=None,
            uses_typed_literal_for_scalars=False,
            requires_uniform_record_shapes=False,
            declared_type=None,
            narrowed_empty_form=None,
        )

        @property
        def type_hint(self) -> str:
            """Python type hint name for this sequence format."""
            if self is type(self).TUPLE:
                return "tuple"
            return "list"

    class SetFormats(enum.Enum):
        """Set type options for Python."""

        SET = SetFormatConfig(
            set_open=fixed_open(open_str="{"),
            close="}",
            empty_set="set()",
            preamble_lines=(),
            set_opener_template="",
            supports_heterogeneity=True,
            supports_trailing_comma=True,
        )
        FROZENSET = SetFormatConfig(
            set_open=fixed_open(open_str="frozenset({"),
            close="})",
            empty_set="frozenset()",
            preamble_lines=(),
            set_opener_template="",
            supports_heterogeneity=True,
            supports_trailing_comma=True,
        )

        @property
        def type_hint(self) -> str:
            """Python type hint name for this set format."""
            if self is type(self).FROZENSET:
                return "frozenset"
            return "set"

    class VariableTypeHints(enum.Enum):
        """Variable type hint options for Python."""

        NEVER = enum.auto()
        ALWAYS = enum.auto()
        SAFE = enum.auto()

        def formatter(
            self,
            *,
            bytes_hint: str,
            date_hint: str,
            datetime_hint: str,
            time_hint: str,
            sequence_hint: str,
            set_hint: str,
            dict_hint: str,
            default_set_element_type: str,
            default_sequence_element_type: str,
            default_dict_value_type: str,
            default_dict_key_type: str,
            join_union: Callable[[list[str]], str],
            record_eligible: Callable[[Value], bool],
        ) -> Callable[[str, str, Value, frozenset[enum.Enum]], str]:
            """Return the variable declaration formatter for this hint
            style.

            *record_eligible* flags ``RECORD``-strategy record-shaped
            dicts so a bare assignment is kept for them (the generated
            dataclass already types every field); it is a constant
            ``False`` predicate for other strategies.
            """
            if self is type(self).ALWAYS:

                def _always_formatter(
                    name: str,
                    value: str,
                    data: Value,
                    modifiers: frozenset[enum.Enum],
                ) -> str:
                    """Adapt the inline-hint declaration to the positional
                    formatter interface.
                    """
                    return _format_inline_type_hint_declaration(
                        name=name,
                        value=value,
                        data=data,
                        _modifiers=modifiers,
                        bytes_hint=bytes_hint,
                        date_hint=date_hint,
                        datetime_hint=datetime_hint,
                        time_hint=time_hint,
                        sequence_hint=sequence_hint,
                        set_hint=set_hint,
                        dict_hint=dict_hint,
                        default_set_element_type=default_set_element_type,
                        default_sequence_element_type=(
                            default_sequence_element_type
                        ),
                        default_dict_value_type=default_dict_value_type,
                        default_dict_key_type=default_dict_key_type,
                        join_union=join_union,
                    )

                return _always_formatter

            def _auto_formatter(
                name: str,
                value: str,
                data: Value,
                modifiers: frozenset[enum.Enum],
            ) -> str:
                """Adapt the variable declaration to the positional
                formatter interface.
                """
                return _format_variable_declaration(
                    name=name,
                    value=value,
                    data=data,
                    _modifiers=modifiers,
                    bytes_hint=bytes_hint,
                    date_hint=date_hint,
                    datetime_hint=datetime_hint,
                    time_hint=time_hint,
                    sequence_hint=sequence_hint,
                    set_hint=set_hint,
                    dict_hint=dict_hint,
                    default_set_element_type=default_set_element_type,
                    default_sequence_element_type=(
                        default_sequence_element_type
                    ),
                    default_dict_value_type=default_dict_value_type,
                    default_dict_key_type=default_dict_key_type,
                    join_union=join_union,
                    record_eligible=record_eligible,
                )

            return _auto_formatter

    class CommentFormats(enum.Enum):
        """Comment style options."""

        HASH = CommentConfig(
            prefix=EncodingCookieSafeCommentPrefix(object="#"),
            suffix="",
        )

    class DeclarationStyles(enum.Enum):
        """Declaration style options."""

        ASSIGN = DeclarationStyleConfig(
            formatter=variable_declaration_formatter(
                template="{name} = {value}"
            ),
            supports_redefinition=True,
        )

    class DictEntryStyles(enum.Enum):
        """Dict entry style options."""

        DEFAULT = enum.auto()

    class DictFormats(enum.Enum):
        """Dict/map format options."""

        DEFAULT = enum.auto()

    class EmptyDictKey(enum.Enum):
        """Empty dict key options."""

        ALLOW = enum.auto()

    class FloatFormats(
        FloatSpecialsMixin,
        enum.Enum,
        positive_infinity='float("inf")',
        negative_infinity='float("-inf")',
        nan='float("nan")',
    ):
        """Float format options."""

        REPR = enum.member(value=format_float_repr)
        SCIENTIFIC = enum.member(value=format_float_scientific)
        FIXED = enum.member(value=format_float_fixed)

    class IntegerFormats(enum.Enum):
        """Integer format options."""

        DECIMAL = MappingProxyType(
            mapping={
                "NONE": str,
                "UNDERSCORE": format_integer_underscore,
            }
        )
        HEX = MappingProxyType(
            mapping={
                "NONE": format_integer_hex,
                "UNDERSCORE": format_integer_hex,
            }
        )
        OCTAL = MappingProxyType(
            mapping={
                "NONE": format_integer_octal,
                "UNDERSCORE": format_integer_octal,
            }
        )
        BINARY = MappingProxyType(
            mapping={
                "NONE": format_integer_binary,
                "UNDERSCORE": format_integer_binary,
            }
        )

        def get_formatter(
            self,
            numeric_separator: enum.Enum,
        ) -> Callable[[int], str]:
            """Return the integer formatter for the given separator."""
            formatter: Callable[[int], str] = self.value[
                numeric_separator.name
            ]
            return formatter

    class NumericLiteralSuffixes(enum.Enum):
        """Numeric literal suffix options."""

        NONE = enum.auto()

    class NumericSeparators(enum.Enum):
        """Numeric separator options."""

        NONE = enum.auto()
        UNDERSCORE = enum.auto()

    class NumericStyles(enum.Enum):
        """Numeric literal style options."""

        OVERLOADED = enum.auto()

    class StringFormats(enum.Enum):
        """String format options."""

        _value_: Callable[[str], str]

        DOUBLE = enum.member(value=_format_string_double)
        SINGLE = enum.member(value=_format_string_single)
        RAW = enum.member(value=_format_string_raw)
        MULTILINE = enum.member(value=_format_string_multiline)

        def __call__(self, value: str, /) -> str:
            """Format a string."""
            return self._value_(value)

    class TrailingCommas(enum.Enum):
        """Trailing comma options."""

        YES = TrailingCommaConfig(multiline_trailing_comma=True)
        NO = TrailingCommaConfig(multiline_trailing_comma=False)

    date_formats = DateFormats
    datetime_formats = DatetimeFormats
    bytes_formats = BytesFormats
    sequence_formats = SequenceFormats
    set_formats = SetFormats
    comment_formats = CommentFormats
    variable_type_hints_formats = VariableTypeHints

    class AnnotationEvaluations(enum.Enum):
        """Runtime evaluation behavior for generated annotations."""

        EAGER = enum.auto()
        POSTPONED = enum.auto()

    annotation_evaluations = AnnotationEvaluations

    class UnionFormats(enum.Enum):
        """Syntax choices for generated union annotations."""

        AUTO = enum.auto()
        PIPE = enum.auto()
        TYPING = enum.auto()

    union_formats = UnionFormats
    declaration_styles = DeclarationStyles
    dict_entry_styles = DictEntryStyles
    dict_formats = DictFormats
    empty_dict_keys = EmptyDictKey
    float_formats = FloatFormats
    integer_formats = IntegerFormats
    integer_width_strategies = BareIntegerWidthStrategies
    numeric_literal_suffixes = NumericLiteralSuffixes
    numeric_separators = NumericSeparators
    numeric_styles = NumericStyles
    string_formats = StringFormats
    trailing_commas = TrailingCommas

    class StatementTerminatorStyles(enum.Enum):
        """Statement terminator options."""

        SEMICOLON = enum.auto()

    statement_terminator_styles = StatementTerminatorStyles

    class CallStyles(enum.Enum):
        """Call style options for Python."""

        KEYWORD = KeywordCallStyle(separator="=")
        POSITIONAL = PositionalCallStyle(
            arg_separator=", ", parenthesize_each_arg=False
        )

    call_styles = CallStyles

    class Modifiers(enum.Enum):
        """C++/Java/C#-style declaration modifiers: this language has none."""

    modifiers = Modifiers

    class HeterogeneousStrategies(enum.Enum):
        """Strategy for dicts whose values span more than one Python
        type.

        ``ERROR`` keeps the default behavior.  Python's ``dict`` is
        already heterogeneous, so a record-shaped dict is representable
        as a plain ``dict`` and is rendered that way by default.
        ``RECORD`` is an opt-in *idiomatic-output* strategy: each
        record-shaped dict (non-empty, string-keyed) becomes a
        generated frozen ``@dataclasses.dataclass`` declared in the
        preamble plus a matching ``RecordN(field=value, ...)`` literal.
        Every dict is still representable as a plain ``dict``; this
        strategy only produces the more idiomatic dataclass form.
        """

        ERROR = enum.auto()
        RECORD = enum.auto()

    heterogeneous_strategies = HeterogeneousStrategies

    class JsonTypes(JsonType):
        """Empty: this language has no JSON value-type variants."""

    json_types = JsonTypes

    class BoolFormats(enum.Enum):
        """Empty: this language has no alternative boolean formats."""

    bool_formats = BoolFormats

    class VersionFormats(enum.Enum):
        """Python version to target.

        This selects typing-alias syntax; it is *not* the runtime
        version floor.  The floor under which the default fixtures are
        exercised in CI is governed by ``requires-python`` in
        ``pyproject.toml`` (``>=3.12``), not by this enum.

        * ``VersionFormats.PY38`` — target Python 3.8; uses built-in
          collection generics with postponed annotations and ``typing``
          aliases with eager annotations, and emits ``datetime.timezone.utc``
          for UTC.
        * ``VersionFormats.PY39`` — uses built-in generic aliases
          ``list``, ``dict``, etc. (PEP 585, valid 3.9+).  Note this
          variant also emits ``datetime.UTC``, which requires Python
          3.11+, so its true minimum interpreter is 3.11, not 3.9.
        """

        PY38 = enum.auto()
        PY39 = enum.auto()

    version_formats = VersionFormats

    modifier_combinations: ClassVar[tuple[ModifierCombination, ...]] = ()
    identifier_cases: ClassVar[tuple[IdentifierCase, ...]] = (
        IdentifierCase.SNAKE,
        IdentifierCase.UPPER_SNAKE,
        IdentifierCase.PASCAL,
    )
    supported_ref_cases: ClassVar[frozenset[IdentifierCase]] = (
        NON_KEBAB_REF_CASES
    )

    validate_spec_for_data = no_validate_spec_for_data

    @cached_property
    def validate_call_arg(self) -> Callable[[Value], None]:
        """Return call-argument validation for this language."""
        return no_validate_call_arg

    @cached_property
    def format_call_statement(self) -> Callable[[str], str]:
        """Return call-statement formatting for this language."""
        return identity_call_statement

    wrap_calls_with_declarations = default_wrap_calls_with_declarations

    @staticmethod
    def wrap_in_file(
        content: str,
        variable_name: str,
        body_preamble: tuple[str, ...],
    ) -> str:
        """Wrap Python code in a valid file (no-op)."""
        return wrap_in_file_noop(
            content=content,
            variable_name=variable_name,
            body_preamble=body_preamble,
        )

    @staticmethod
    def wrap_combined_in_file(
        declaration: str,
        assignment: str,
        variable_name: str,
        body_preamble: tuple[str, ...],
    ) -> str:
        """Wrap Python declaration + assignment in a valid file."""
        return wrap_combined_in_file_noop(
            declaration=declaration,
            assignment=assignment,
            variable_name=variable_name,
            body_preamble=body_preamble,
        )

    date_format: DateFormats = DateFormats.PYTHON
    datetime_format: DatetimeFormats = DatetimeFormats.PYTHON
    bytes_format: BytesFormats = BytesFormats.HEX
    sequence_format: SequenceFormats = SequenceFormats.TUPLE
    set_format: SetFormats = SetFormats.SET
    default_set_element_type: str = "Any"
    default_sequence_element_type: str = "Any"
    default_dict_key_type: str = "str"
    default_dict_value_type: str = "Any"
    variable_type_hints: VariableTypeHints = VariableTypeHints.NEVER
    annotation_evaluation: AnnotationEvaluations = (
        AnnotationEvaluations.POSTPONED
    )
    union_format: UnionFormats = UnionFormats.AUTO
    comment_format: CommentFormats = CommentFormats.HASH
    declaration_style: DeclarationStyles = DeclarationStyles.ASSIGN
    dict_entry_style: DictEntryStyles = DictEntryStyles.DEFAULT
    dict_format: DictFormats = DictFormats.DEFAULT
    float_format: FloatFormats = FloatFormats.REPR
    integer_format: IntegerFormats = IntegerFormats.DECIMAL
    integer_width_strategy: BareIntegerWidthStrategies = (
        BareIntegerWidthStrategies.BARE
    )
    numeric_literal_suffix: NumericLiteralSuffixes = (
        NumericLiteralSuffixes.NONE
    )
    numeric_separator: NumericSeparators = NumericSeparators.NONE
    numeric_style: NumericStyles = NumericStyles.OVERLOADED
    string_format: StringFormats = StringFormats.DOUBLE
    trailing_comma: TrailingCommas = TrailingCommas.YES
    statement_terminator_style: StatementTerminatorStyles = (
        StatementTerminatorStyles.SEMICOLON
    )
    call_style: CallStyles = CallStyles.KEYWORD
    heterogeneous_strategy: HeterogeneousStrategies = (
        HeterogeneousStrategies.ERROR
    )
    record_struct_name_prefix: str = "Record"
    language_version: VersionFormats = VersionFormats.PY39
    indent: str = "    "

    def __post_init__(self) -> None:
        """Reject union syntax that the target runtime cannot evaluate."""
        if (
            self.union_format is self.union_formats.PIPE
            and self.annotation_evaluation is self.annotation_evaluations.EAGER
        ):
            msg = (
                "union_format=PIPE is incompatible with eager annotations "
                f"when targeting {self.language_version.name}; use "
                "union_format=AUTO or TYPING, or postponed annotations"
            )
            raise IncompatibleFormatsError(msg)

    null_literal: ClassVar[str] = "None"
    true_literal: ClassVar[str] = "True"
    false_literal: ClassVar[str] = "False"
    indent_closing_delimiter: ClassVar[bool] = False
    element_separator: ClassVar[str] = ", "
    skip_null_dict_values: ClassVar[bool] = False
    supports_collection_comments: ClassVar[bool] = True
    supports_scalar_before_comments: ClassVar[bool] = False
    supports_scalar_inline_comments: ClassVar[bool] = True
    statement_terminator: ClassVar[str] = ""
    static_body_preamble: ClassVar[Sequence[str]] = ()
    special_float_preamble: ClassVar[tuple[str, ...]] = ()

    @cached_property
    def format_sequence_entry(self) -> Callable[[Value, str], str]:
        """Format a sequence entry."""
        return passthrough_sequence_entry

    @cached_property
    def format_set_entry(self) -> Callable[[Value, str], str]:
        """Format a set entry."""
        return passthrough_set_entry

    @cached_property
    def format_variable_assignment(self) -> Callable[[str, str, Value], str]:
        """Format an assignment to an existing variable."""
        return variable_formatter(template="{name} = {value}")

    @cached_property
    def format_call_variable_declaration(
        self,
    ) -> Callable[[str, str, Value, frozenset[enum.Enum]], str]:
        """Callable that formats a declaration binding a call result.

        A literal binding adds an inline ``name: T = ...`` annotation
        for values whose type a checker cannot infer from the literal
        (empty collections, etc.).  A call's return type is opaque to
        the renderer -- the annotation would be derived from the call's
        *argument* data, not its result, and a strict checker rejects
        the mismatch -- so the call result is bound with a plain
        ``name = value`` and the type is left to inference.  Python has
        no declaration modifiers, so the modifier set is ignored.
        """
        return variable_declaration_formatter(template="{name} = {value}")

    def _python_render_declaration(
        self,
        name: str,
        fields: Sequence[RecordDeclarationField],
        /,
    ) -> str:
        """Render a frozen ``@dataclasses.dataclass`` declaration."""
        lines = [
            "@dataclasses.dataclass(frozen=True)",
            f"class {name}:",
        ]
        lines += [
            f"{self.indent}{field.identifier}: {field.type_name}"
            for field in fields
        ]
        return "\n".join(lines)

    @cached_property
    def _record_field_type(self) -> Callable[[RecordFieldType], str]:
        """Return the dataclass field-type resolver for the ``RECORD``
        strategy.

        A field whose value is itself a nested record-shaped dict uses
        that record's generated class name; a field whose value is a
        list of record-shaped dicts (one shared shape) is typed as the
        sequence of that record's class (matching the
        ``(RecordN(...), ...)`` literal the strategy renders, which
        :func:`_python_type_hint` would otherwise infer as a sequence
        of ``dict``); every other value is typed through
        :func:`_python_type_hint`, the same hint function the
        variable-annotation path uses, so the declared type matches the
        rendered literal and honors the configured
        sequence/set/dict/date/datetime formats and the targeted
        Python version.
        """
        sequence_hint, set_hint, dict_hint = self._collection_type_hint_names
        join_union = self._join_union

        def _field_type(request: RecordFieldType, /) -> str:
            """Type a record field from its nested-record name or its
            raw value.
            """
            if request.record_name is not None:
                return request.record_name
            if request.element_record_name is not None:
                if sequence_hint.casefold() == "tuple":
                    return (
                        f"{sequence_hint}[{request.element_record_name}, ...]"
                    )
                return f"{sequence_hint}[{request.element_record_name}]"
            return _python_type_hint(
                data=request.value,
                bytes_hint=self.bytes_format.type_hint,
                date_hint=self.date_format.type_hint,
                datetime_hint=self.datetime_format.type_hint,
                time_hint="datetime.time",
                sequence_hint=sequence_hint,
                set_hint=set_hint,
                dict_hint=dict_hint,
                default_set_element_type=self.default_set_element_type,
                default_sequence_element_type=(
                    self.default_sequence_element_type
                ),
                default_dict_value_type=self.default_dict_value_type,
                default_dict_key_type=self.default_dict_key_type,
                join_union=join_union,
            )

        return _field_type

    @cached_property
    def _record_renderer(self) -> RecordRenderer:
        """Python syntax hooks for the ``RECORD`` strategy."""
        return RecordRenderer(
            name_prefix=self.record_struct_name_prefix,
            # Python does not expose a ``record_shape_names``
            # constructor field (base RECORD only, as for the other
            # non-Rust ports); an empty mapping keeps every shape on
            # the auto ``{prefix}{N}`` names.
            record_shape_names=MappingProxyType(mapping={}),
            field_identifier=functools.partial(
                _python_record_field_identifier,
                reserved_identifiers=self.reserved_variable_identifiers,
            ),
            field_identifier_key=identity_field_identifier_key,
            field_type=self._record_field_type,
            render_declaration=self._python_render_declaration,
            render_literal=_python_record_literal,
            field_type_names_nested_records=False,
            suppress_custom_name_declarations=False,
        )

    @cached_property
    def _record_strategy(self) -> RecordStrategy:
        """Resolve the active strategy to its behavior + preamble."""
        cls = type(self.heterogeneous_strategy)
        if self.heterogeneous_strategy is cls.RECORD:
            return build_record_strategy(
                renderer=self._record_renderer,
                split_conflicting_field_types=False,
                widen_unrecordizable_nested_sibling_maps=False,
                derecordized_map_open=None,
            )
        return RecordStrategy(
            behavior=NO_HETEROGENEOUS_BEHAVIOR,
            preamble=no_data_preamble,
            record_name_for_value=None,
        )

    @cached_property
    def data_dependent_preamble(self) -> Callable[[Value], tuple[str, ...]]:
        """Return data-dependent preamble lines.

        Under ``HeterogeneousStrategies.RECORD`` emits ``import
        dataclasses`` followed by one frozen
        ``@dataclasses.dataclass`` declaration per record shape present
        in the data; otherwise produces no preamble.
        """
        record_preamble = self._record_strategy.preamble

        def _preamble(data: Value, /) -> tuple[str, ...]:
            """Prefix the record declarations with ``import
            dataclasses``.
            """
            blocks = record_preamble(data)
            if len(blocks) == 0:
                return ()
            typing_import: tuple[str, ...]
            if any("Union[" in block for block in blocks):
                typing_import = ("from typing import Union",)
            else:
                typing_import = ()
            return ("import dataclasses", *typing_import, *blocks)

        return _preamble

    @cached_property
    def heterogeneous_behavior(self) -> HeterogeneousBehavior:
        """Return the behavior for the chosen heterogeneous strategy."""
        return self._record_strategy.behavior

    @cached_property
    def format_call_stub(
        self,
    ) -> Callable[
        [Sequence[str], Sequence[str], StubReturn, Sequence[Value]],
        tuple[str, ...],
    ]:
        """Return stub declarations for a call expression."""
        return _build_python_call_stub(indent=self.indent)

    @cached_property
    def format_call_preamble_stub(
        self,
    ) -> Callable[
        [Sequence[str], Sequence[str], StubReturn, Sequence[Value]],
        tuple[str, ...],
    ]:
        """Return file-scope stubs for a call expression."""
        return no_call_stub

    @cached_property
    def format_call_target(self) -> Callable[[Sequence[str]], str]:
        """Rewrite a dotted call target into the language's call
        syntax.
        """
        return identity_call_target

    @cached_property
    def format_call_ref_identifier(
        self,
    ) -> Callable[[str, Value | None], str]:
        """Rewrite a ``{"$ref": "name"}`` identifier into the
        language's call expression syntax.
        """
        return identity_call_ref_identifier

    @cached_property
    def format_call_arg_ref_identifier(
        self,
    ) -> Callable[[str, Value | None], str]:
        """Rewrite a ``{"$ref": "name"}`` identifier in a call-argument
        context.

        Delegates to :attr:`format_call_ref_identifier`.  Override this to
        allow call-argument ``$ref`` values that would otherwise be rejected.
        """
        return self.format_call_ref_identifier

    @cached_property
    def format_call_arg_ref_identifier_consumable(
        self,
    ) -> Callable[[str, Value | None], str]:
        """Format a ``$ref`` the caller authorized as consumable.

        Delegates to :attr:`format_call_arg_ref_identifier`.  Override
        this to opt into a consuming form (e.g. C++ ``std::move``).
        """
        return self.format_call_arg_ref_identifier

    @cached_property
    def consumable_ref_value_inhibits_consuming_form(
        self,
    ) -> Callable[[Value], bool]:
        """Predicate deciding whether a ref's underlying value type
        inhibits the consume form.

        Delegates to :data:`never_inhibits_consuming_form`.  Languages
        whose consume operator rejects certain value types (notably
        the Mojo ``^`` on register-trivial scalars) override this.
        """
        return never_inhibits_consuming_form

    scalar_body_preamble: ClassVar[dict[type, tuple[str, ...]]] = {}

    @cached_property
    def sequence_format_config(self) -> SequenceFormatConfig:
        """Configuration for the chosen sequence format."""
        return self.sequence_format.value

    @cached_property
    def set_format_config(self) -> SetFormatConfig:
        """Configuration for the chosen set format."""
        return self.set_format.value

    @cached_property
    def sequence_open(self) -> Callable[[list[Value]], str]:
        """Callable that returns the opening delimiter for a sequence."""
        return self.sequence_format.value.sequence_open

    @cached_property
    def dict_format_config(self) -> DictFormatConfig:
        """Configuration for dict formatting."""
        return DictFormatConfig(
            dict_open=fixed_open(open_str="{"),
            close="}",
            format_entry=dict_entry_with_separator(
                separator=": ",
                format_value=passthrough_sequence_entry,
            ),
            empty_dict=None,
            preamble_lines=(),
            narrowed_open=None,
            supports_trailing_comma=True,
            narrowed_empty_form=None,
        )

    @cached_property
    def trailing_comma_config(self) -> TrailingCommaConfig:
        """Configuration for trailing-comma behavior."""
        return self.trailing_comma.value

    @cached_property
    def format_bytes(self) -> Callable[[bytes], str]:
        """Callable that formats a bytes value as a string literal."""
        return self.bytes_format

    @cached_property
    def format_date(self) -> Callable[[datetime.date], str]:
        """Callable that formats a date as a string literal."""
        return self.date_format

    @cached_property
    def format_datetime(self) -> Callable[[datetime.datetime], str]:
        """Callable that formats a datetime as a string literal."""
        if (
            self.datetime_format is self.datetime_formats.PYTHON
            and self.language_version is self.version_formats.PY38
        ):
            return functools.partial(
                _format_datetime_python,
                utc_tzinfo_expr="datetime.timezone.utc",
            )
        return self.datetime_format

    @cached_property
    def format_time(self) -> Callable[[datetime.time], str]:
        """Callable that formats a time as a string literal."""
        return _format_time_python

    @cached_property
    def format_string(self) -> Callable[[str], str]:
        """Callable that formats a string value as a quoted literal."""
        return self.string_format

    @cached_property
    def format_float(self) -> Callable[[float], str]:
        """Callable that formats a float value as a literal."""
        return self.float_format

    @cached_property
    def format_integer(self) -> Callable[[int], str]:
        """Callable that formats an int value as a literal."""
        return self.integer_format.get_formatter(
            numeric_separator=self.numeric_separator,
        )

    @cached_property
    def comment_config(self) -> CommentConfig:
        """Configuration for the language's comment syntax."""
        return self.comment_format.value

    static_preamble: ClassVar[Sequence[str]] = ()

    @cached_property
    def leading_preamble(self) -> LeadingPreamble:
        """Emit the PEP 563 future import, but only when the rendered
        code actually contains an annotation.

        ``from __future__ import annotations`` makes annotations lazy so
        generated files stay executable on Python 3.8+, but it serves no
        purpose (and misleads the reader) when nothing is annotated.  An
        annotation is produced in exactly two cases:

        * the ``RECORD`` strategy generated one or more
          ``@dataclasses.dataclass`` blocks for the data (their fields
          are annotated), or
        * an inline variable type hint was produced -- which only
          happens when a new variable is declared and either
          ``variable_type_hints`` is ``ALWAYS`` or the data needs a
          helper annotation (an empty collection; see
          :func:`_needs_type_annotation`).

        The import must be the first statement in the module, so it is
        emitted via :attr:`Language.leading_preamble` rather than the
        data-dependent preamble (which follows other imports).
        """
        if (
            self.annotation_evaluation
            is type(self.annotation_evaluation).EAGER
        ):

            def _no_future_import(
                _data: Value, /, *, has_variable_declaration: bool
            ) -> tuple[str, ...]:
                """Omit the future import for eager annotations."""
                _ = has_variable_declaration
                return ()

            return _no_future_import

        record_preamble = self._record_strategy.preamble
        record_eligible = self._record_eligible_for_annotation
        always = (
            self.variable_type_hints is type(self.variable_type_hints).ALWAYS
        )

        def _leading(
            data: Value, /, *, has_variable_declaration: bool
        ) -> tuple[str, ...]:
            """Return the future import only when annotated."""
            has_record_blocks = bool(record_preamble(data))
            has_inline_hint = has_variable_declaration and (
                always
                or _needs_type_annotation(
                    data=data, record_eligible=record_eligible
                )
            )
            if has_record_blocks or has_inline_hint:
                return ("from __future__ import annotations",)
            return ()

        return _leading

    @cached_property
    def ordered_map_format_config(self) -> OrderedMapFormatConfig:
        """Configuration for ordered-map formatting."""
        return OrderedMapFormatConfig(
            ordered_map_open=fixed_open(open_str="OrderedDict(["),
            close="])",
            preamble_lines=("from collections import OrderedDict",),
        )

    @cached_property
    def format_ordered_map_entry(self) -> Callable[[str, Value, str], str]:
        """Callable that formats one ordered-map entry."""
        return tuple_dict_entry(format_value=passthrough_sequence_entry)

    @cached_property
    def _collection_type_hint_names(self) -> tuple[str, str, str]:
        """Return sequence, set, and dict type-hint names."""
        sequence_hint = self.sequence_format.type_hint
        set_hint = self.set_format.type_hint
        if not self._uses_typing_collection_aliases:
            return sequence_hint, set_hint, "dict"
        mapping = {
            "list": "List",
            "tuple": "Tuple",
            "set": "Set",
            "frozenset": "FrozenSet",
            "dict": "Dict",
        }
        return (
            mapping.get(sequence_hint, sequence_hint),
            mapping.get(set_hint, set_hint),
            mapping["dict"],
        )

    @property
    def _uses_typing_collection_aliases(self) -> bool:
        """Whether eager annotations need Python 3.8 typing aliases."""
        return (
            self.language_version is self.version_formats.PY38
            and self.annotation_evaluation is self.annotation_evaluations.EAGER
        )

    @property
    def _uses_typing_union(self) -> bool:
        """Whether generated unions use ``typing.Union``."""
        return self.union_format is self.union_formats.TYPING or (
            self.union_format is self.union_formats.AUTO
            and self.annotation_evaluation is self.annotation_evaluations.EAGER
        )

    @cached_property
    def _join_union(self) -> Callable[[list[str]], str]:
        """Return the configured union-annotation formatter."""
        if self._uses_typing_union:
            return _join_union_typing
        return _join_union_pipe

    @cached_property
    def _record_eligible_for_annotation(self) -> Callable[[Value], bool]:
        """Predicate marking a value as a ``RECORD``-strategy
        record-shaped dict.

        Such a dict renders as a self-typed
        ``@dataclasses.dataclass`` instance, so the inline
        variable-annotation path treats it as opaque (see
        :func:`_needs_type_annotation`).  For any other strategy the
        predicate is a constant ``False``, leaving the annotation
        behavior unchanged.
        """
        cls = type(self.heterogeneous_strategy)
        if self.heterogeneous_strategy is not cls.RECORD:
            return lambda _data: False

        def _eligible(data: Value, /) -> bool:
            """An ordered map is never record-eligible; a plain
            non-empty string-keyed dict is.
            """
            return (
                isinstance(data, dict)
                and not isinstance(data, OrderedMap)
                and record_shape_for_dict(value=data) is not None
            )

        return _eligible

    @cached_property
    def format_variable_declaration(
        self,
    ) -> Callable[[str, str, Value, frozenset[enum.Enum]], str]:
        """Callable that formats a new variable declaration."""
        sequence_hint, set_hint, dict_hint = self._collection_type_hint_names
        return self.variable_type_hints.formatter(
            bytes_hint=self.bytes_format.type_hint,
            date_hint=self.date_format.type_hint,
            datetime_hint=self.datetime_format.type_hint,
            time_hint="datetime.time",
            sequence_hint=sequence_hint,
            set_hint=set_hint,
            dict_hint=dict_hint,
            default_set_element_type=self.default_set_element_type,
            default_sequence_element_type=self.default_sequence_element_type,
            default_dict_value_type=self.default_dict_value_type,
            default_dict_key_type=self.default_dict_key_type,
            join_union=self._join_union,
            record_eligible=self._record_eligible_for_annotation,
        )

    @cached_property
    def scalar_preamble(self) -> dict[type, tuple[str, ...]]:
        """Per-instance scalar preamble computed from date/datetime format."""
        return date_scalar_preamble(
            date_format=self.date_format,
            datetime_format=self.datetime_format,
            extra={datetime.time: ("import datetime",)},
        )

    @cached_property
    def compute_body_preamble(
        self,
    ) -> Callable[[frozenset[type], Value], tuple[str, ...]]:
        """Compute body-preamble lines from the scalar map."""
        return body_preamble_from_scalars(
            scalar_body_preamble=self.scalar_body_preamble,
            format_lines=tuple,
        )

    @cached_property
    def call_data_dependent_preamble(
        self,
    ) -> Callable[[Value], tuple[str, ...]]:
        """Return data-dependent preamble lines for call rendering."""
        return self.data_dependent_preamble

    @cached_property
    def type_hint_collection_preamble_lines(
        self,
    ) -> Callable[[frozenset[type]], tuple[str, ...]]:
        """Type-hint preamble computed from the configured default
        types.
        """
        if self.language_version is self.version_formats.PY38:
            sequence_hint, set_hint, _ = self._collection_type_hint_names
            return _build_type_hint_preamble_py38(
                always_type_hints=(
                    self.variable_type_hints
                    is self.variable_type_hints_formats.ALWAYS
                ),
                sequence_typing_name=sequence_hint,
                set_typing_name=set_hint,
                use_typing_collection_aliases=(
                    self._uses_typing_collection_aliases
                ),
                use_typing_union=self._uses_typing_union,
                default_set_element_type=self.default_set_element_type,
                default_sequence_element_type=self.default_sequence_element_type,
                default_dict_value_type=self.default_dict_value_type,
                default_dict_key_type=self.default_dict_key_type,
            )
        return _build_type_hint_preamble(
            always_type_hints=(
                self.variable_type_hints
                is self.variable_type_hints_formats.ALWAYS
            ),
            use_typing_union=self._uses_typing_union,
            default_set_element_type=self.default_set_element_type,
            default_sequence_element_type=self.default_sequence_element_type,
            default_dict_value_type=self.default_dict_value_type,
            default_dict_key_type=self.default_dict_key_type,
        )

    @cached_property
    def call_style_config(self) -> CallStyle:
        """Configuration for the chosen call style."""
        config: CallStyle = self.call_style.value
        return config
