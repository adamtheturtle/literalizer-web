"""Java language specification."""

import dataclasses
import datetime
import enum
import functools
import re
from collections.abc import Callable, Mapping, Sequence
from functools import cached_property
from types import MappingProxyType
from typing import ClassVar, Final, assert_never

from beartype import beartype

from literalizer._formatters.collection_openers import (
    TypedOpenerConfig,
    fixed_open,
    typed_collection_open,
)
from literalizer._formatters.format_dates import (
    date_ymd_formatter,
    datetime_epoch_formatter,
    datetime_epoch_seconds,
    format_date_iso,
    format_datetime_epoch,
    format_datetime_iso,
    format_time_local_time_of,
    normalize_datetime_utc,
)
from literalizer._formatters.format_entries import (
    dict_entry_with_template,
    format_bytes_base64,
    format_bytes_hex,
    passthrough_sequence_entry,
    passthrough_set_entry,
)
from literalizer._formatters.format_floats import (
    data_has_special_float,
    format_float_fixed,
    format_float_repr,
    format_float_scientific,
)
from literalizer._formatters.format_integers import (
    I64_MAX,
    I64_MIN,
    data_has_out_of_range_int,
    format_integer_binary,
    format_integer_hex,
    format_integer_octal_c_style,
    format_integer_underscore,
    make_long_suffix_formatter,
    make_overflow_fallback_formatter,
    make_overflow_suffix_formatter,
)
from literalizer._formatters.format_json_value import format_json_value_text
from literalizer._formatters.format_strings import (
    format_string_backslash_nul_octal,
)
from literalizer._formatters.record_strategy import (
    RecordDeclarationField,
    RecordFieldType,
    RecordLiteralField,
    RecordRenderer,
    RecordStrategy,
    build_record_strategy,
    identity_field_identifier_key,
)
from literalizer._formatters.type_inference import (
    DictType,
    ListType,
    RecordShape,
    record_shape_for_dict,
)
from literalizer._language import (
    NO_CALL_PARAMETER_LIMIT,
    NO_HETEROGENEOUS_BEHAVIOR,
    NON_KEBAB_REF_CASES,
    BareIntegerWidthStrategies,
    CallParameterShadowing,
    CallStyle,
    CommentConfig,
    DateFormatConfig,
    DateFormatEnum,
    DatetimeFormatConfig,
    DatetimeFormatEnum,
    DeclarationStyleConfig,
    DictFormatConfig,
    FloatSpecialsMixin,
    HeterogeneousBehavior,
    IdentifierCase,
    JsonType,
    LanguageCls,
    ModifierCombination,
    NewVariableNameSyntax,
    OrderedMapFormatConfig,
    PositionalCallStyle,
    RenderedRecordLiteral,
    RoundTripCapability,
    SequenceFormatConfig,
    SetFormatConfig,
    StubReturn,
    TrailingCommaConfig,
    VariantMetadata,
    body_preamble_from_scalars,
    date_scalar_preamble,
    default_format_call_variable_assignment,
    default_format_call_variable_declaration,
    default_sequence_binding_declarations,
    default_wrap_calls_with_declarations,
    identity_call_arg,
    identity_call_ref_identifier,
    identity_call_statement,
    identity_call_target,
    never_inhibits_consuming_form,
    new_constructor_target,
    no_call_binding_body_preamble,
    no_call_binding_file_pragmas,
    no_call_stub,
    no_data_preamble,
    no_leading_preamble,
    no_type_hint_preamble,
    prepend_body_preamble,
)
from literalizer._types import OrderedMap, Scalar, Value
from literalizer.exceptions import (
    ConflictingVariableModifiersError,
    IncompatibleFormatsError,
    InvalidModuleNameError,
    InvalidRecordNameError,
    NullInCollectionError,
    UnrepresentableInputError,
)

_JAVA_EMITTED_TYPE_NAMES: Final[frozenset[str]] = frozenset(
    {
        # Brought in by the ``import`` lines this back end emits.
        "BigInteger",
        "HashMap",
        "Instant",
        "JsonNode",
        "List",
        "LocalDate",
        "LocalTime",
        "Map",
        "ObjectMapper",
        "Set",
        "TreeSet",
        "ZoneId",
        "ZonedDateTime",
        # Named by rendered types without an import: ``java.lang`` is
        # always in scope.
        "Boolean",
        "Byte",
        "Character",
        "Double",
        "Float",
        "Integer",
        "Long",
        "Number",
        "Object",
        "Short",
        "String",
    }
)
"""Type names rendered Java can reference.

A record named after one of these either shadows the type the same file
uses or clashes with its ``import`` line, so javac rejects the output
(issue #4536).
"""


_PASCAL_CASE_IDENTIFIER = re.compile(pattern=r"^[A-Z][A-Za-z0-9_]*$")


@beartype
def _escape_spaces(match: re.Match[str]) -> str:
    r"""Return one ``\s`` escape per character of the whitespace run
    *match*.
    """
    return r"\s" * len(match[0])


@beartype
def _format_string_multiline(value: str) -> str:
    r"""Format *value* as an exact Java text block."""
    escaped = (
        value.replace("\\", "\\\\")
        .replace("\0", "\\000")
        .replace("\r", "\\r")
        .replace("\t", "\\t")
        .replace('"', '\\"')
    )
    escaped = re.sub(
        pattern=r" +(?=\n)",
        repl=_escape_spaces,
        string=escaped,
    )
    escaped = re.sub(
        pattern=r"(?m)^ +",
        repl=_escape_spaces,
        string=escaped,
    )
    return f'"""\n{escaped}"""'


class _JavaModifiers(enum.Enum):
    """Declaration modifiers supported by Java.

    Each member's value is the Java keyword it renders to.  Declaration
    order matches canonical Java modifier order
    (visibility, storage, finality).

    Exposed as :attr:`Java.Modifiers` / :attr:`Java.modifiers`.
    """

    PUBLIC = "public"
    """Visibility: publicly accessible."""

    PRIVATE = "private"
    """Visibility: private to the enclosing class."""

    PROTECTED = "protected"
    """Visibility: protected (accessible from subclasses)."""

    STATIC = "static"
    """Storage: associated with the enclosing class rather than an
    instance.
    """

    FINAL = "final"
    """Immutability: cannot be reassigned."""


@beartype
def _java_call_stub(
    parts: Sequence[str],
    _params: Sequence[str],
    _stub_return: StubReturn,
    _args: Sequence[Value],
    /,
) -> tuple[str, ...]:
    """Return Java stub declarations for a call name."""
    if len(parts) == 1:
        return (
            f"static Object {parts[0]}(Object... args) {{ return null; }}",
        )
    root = parts[0]
    method = parts[-1]
    fields = parts[1:-1]
    if len(fields) == 0:
        type_name = f"{root.title()}Type_"
        return (
            (
                f"static class {type_name} {{"
                f" Object {method}(Object... args) {{ return null; }} }}"
            ),
            f"static {type_name} {root} = new {type_name}();",
        )
    lines: list[str] = []
    inner_type = f"{fields[-1].title()}Type_"
    lines.append(
        f"static class {inner_type} {{"
        f" Object {method}(Object... args) {{ return null; }} }}"
    )
    prev_type = inner_type
    for i in range(len(fields) - 2, -1, -1):
        curr_type = f"{fields[i].title()}Type_"
        lines.append(
            f"static class {curr_type} {{"
            f" {prev_type} {fields[i + 1]} = new {prev_type}(); }}"
        )
        prev_type = curr_type
    root_type = f"{root.title()}Type_"
    lines.append(
        f"static class {root_type} {{"
        f" {prev_type} {fields[0]} = new {prev_type}(); }}"
    )
    lines.append(f"static {root_type} {root} = new {root_type}();")
    return tuple(lines)


@beartype
def _format_java_biginteger_literal(value: int) -> str:
    """Format a value outside signed 64-bit range as a Java
    ``new BigInteger(...)`` expression.

    Java's ``long`` is signed 64-bit; values outside that range must
    use ``java.math.BigInteger``.
    """
    return f'new BigInteger("{value}")'


@beartype
def _java_biginteger_preamble(data: Value, /) -> tuple[str, ...]:
    """Return ``import java.math.BigInteger;`` if *data* contains a
    very-large integer.
    """
    if data_has_out_of_range_int(data=data):
        return ("import java.math.BigInteger;",)
    return ()


_JAVA_MAX_ZONE_OFFSET = datetime.timedelta(hours=18)
"""The widest offset ``java.time.ZoneOffset`` accepts.

TOML permits an offset up to +-23:59, and Java rejects one past
+-18:00 at run time, so a wider offset is rendered as the equivalent
UTC instant rather than as code that throws (issue #4517).
"""


@beartype
def _within_java_zone_offset(value: datetime.datetime) -> datetime.datetime:
    """Return *value* in a form Java's ``ZoneOffset`` can hold."""
    offset = value.utcoffset()
    if offset is None or abs(offset) <= _JAVA_MAX_ZONE_OFFSET:
        return value
    return normalize_datetime_utc(value=value, language_name="Java")


@beartype
def _format_datetime_java_zoned(value: datetime.datetime) -> str:
    """Format a datetime as a Java ``ZonedDateTime.of(...)`` call."""
    value = _within_java_zone_offset(value=value)
    raw_timezone_name = value.tzname()
    timezone_name = "UTC"
    if raw_timezone_name is not None and raw_timezone_name != "":
        timezone_name = raw_timezone_name
    nanoseconds = value.microsecond * 1000
    return (
        f"ZonedDateTime.of({value.year}, {value.month}, {value.day}, "
        f"{value.hour}, {value.minute}, {value.second}, "
        f'{nanoseconds}, ZoneId.of("{timezone_name}"))'
    )


@beartype
def _format_datetime_java_instant(value: datetime.datetime) -> str:
    """Format a datetime as a Java ``Instant.parse(...)`` call.

    ``Instant.parse`` rejects strings without a timezone offset, so a
    naive datetime (no :attr:`~datetime.datetime.tzinfo`) is rendered
    with a trailing ``Z`` — Python's :meth:`~datetime.datetime.isoformat`
    emits no offset for naive datetimes, which Java reads as invalid.
    Treating naive values as UTC matches the ISO 8601 convention for
    unqualified timestamps.
    """
    value = _within_java_zone_offset(value=value)
    iso = value.isoformat()
    if value.tzinfo is None:
        iso += "Z"
    return f'Instant.parse("{iso}")'


@beartype
def _list_of_open(items: list[Value]) -> str:
    """Return ``List.of(`` after checking for null elements.

    Java's ``List.of()`` throws ``NullPointerException`` on null elements.
    """
    if any(item is None for item in items):
        msg = (
            f"Java's List.of() does not accept null elements"
            f" (got {len(items)} items, including null). "
            "Use sequence_format=ARRAY instead."
        )
        raise NullInCollectionError(msg)
    return "List.of("


@beartype
def _validate_no_null_map_values(data: Value) -> None:
    """Reject null-valued map entries unsupported by ``Map.entry``."""
    match data:
        case dict():
            for value in data.values():
                if value is None:
                    msg = (
                        "Java's Map.entry() does not accept null values; "
                        "remove the null-valued entry"
                    )
                    raise UnrepresentableInputError(msg)
                _validate_no_null_map_values(data=value)
        case list() | set():
            for value in data:
                _validate_no_null_map_values(data=value)
        case _:
            return


@beartype
def _validate_no_null_collection_keys(data: Value) -> None:
    """Reject null keys and set members unsupported by Java factories."""
    match data:
        case dict():
            if None in data:
                msg = "Java's Map.entry() does not accept null keys"
                raise UnrepresentableInputError(msg)
            for value in data.values():
                _validate_no_null_collection_keys(data=value)
        case set():
            if None in data:
                msg = "Java's Set.of() does not accept null elements"
                raise UnrepresentableInputError(msg)
        case list():
            for value in data:
                _validate_no_null_collection_keys(data=value)
        case _:
            return


@beartype
def _walk_java_ordered_map_values(
    *, data: OrderedMap, walk: Callable[[Value], None]
) -> None:
    """Validate direct ordered-map nulls, then walk through its values."""
    for item in data.values():
        if item is None:
            msg = (
                "Java's Map.entry() does not accept null values; "
                "remove the null-valued entry"
            )
            raise UnrepresentableInputError(msg)
        walk(item)


@beartype
def _java_box(type_name: str) -> str:
    """Return the boxed wrapper type for a Java primitive, or the type
    itself for reference types.
    """
    match type_name:
        case "boolean":
            return "Boolean"
        case "int":
            return "Integer"
        case "long":
            return "Long"
        case "double":
            return "Double"
        case _:
            return type_name


@beartype
def _java_common_element_type(
    *,
    elements: list[Value],
    boxed: bool,
    int_type: str,
    date_hint: str,
    datetime_hint: str,
    seq_is_array: bool,
    dict_outer: str,
    set_outer: str,
) -> str:
    """Find the common Java type for a collection's elements.

    Returns ``"Object"`` when elements are empty or have mixed types.
    """
    if len(elements) == 0:
        return "Object"
    recurse = functools.partial(
        _java_type_hint,
        int_type=int_type,
        date_hint=date_hint,
        datetime_hint=datetime_hint,
        seq_is_array=seq_is_array,
        dict_outer=dict_outer,
        set_outer=set_outer,
    )
    types: list[str] = [recurse(data=e) for e in elements]
    unique = set(types)
    if len(unique) == 1:
        result = unique.pop()
        resolved_result_1: str = result
        if boxed:
            resolved_result_1 = _java_box(type_name=result)
        return resolved_result_1
    # int + double → double (widening)
    double_t = "double"
    if unique == {int_type, double_t}:
        resolved_result_2: str = "double"
        if boxed:
            resolved_result_2 = "Double"
        return resolved_result_2
    # int + long → long (integer-width widening for mixed-magnitude
    # int collections, e.g. ``{1, 1099511627776}``)
    if unique == {"int", "long"}:
        resolved_result_3: str = "long"
        if boxed:
            resolved_result_3 = "Long"
        return resolved_result_3
    return "Object"


_JAVA_I32_MIN = -(2**31)
_JAVA_I32_MAX = 2**31 - 1


@beartype
def _java_integer_hint(*, data: int, int_type: str) -> str:
    """Choose the Java integer type covering the value."""
    hint = int_type
    if hint == "int" and not _JAVA_I32_MIN <= data <= _JAVA_I32_MAX:
        hint = "long"
    return hint


@beartype
def _java_scalar_hint(
    *,
    data: Scalar,
    int_type: str,
    date_hint: str,
    datetime_hint: str,
) -> str:
    """Derive the Java annotation for a scalar value."""
    match data:
        case bool():
            hint = "boolean"
        case int():
            hint = _java_integer_hint(data=data, int_type=int_type)
        case float():
            hint = "double"
        case str() | bytes():
            hint = "String"
        case datetime.datetime():
            hint = datetime_hint
        case datetime.date():
            hint = date_hint
        case datetime.time():
            hint = "LocalTime"
        case None:
            hint = "Object"
        case _ as unreachable:
            assert_never(unreachable)
    return hint


@beartype
def _java_type_hint(
    *,
    data: Value,
    int_type: str,
    date_hint: str,
    datetime_hint: str,
    seq_is_array: bool,
    dict_outer: str,
    set_outer: str,
) -> str:
    """Derive a Java type from *data*."""
    common = functools.partial(
        _java_common_element_type,
        int_type=int_type,
        date_hint=date_hint,
        datetime_hint=datetime_hint,
        seq_is_array=seq_is_array,
        dict_outer=dict_outer,
        set_outer=set_outer,
    )
    match data:
        case OrderedMap():
            val_type = common(elements=list(data.values()), boxed=True)
            hint = f"java.util.ArrayList<Map.Entry<String, {val_type}>>"
        case dict():
            val_type = common(elements=list(data.values()), boxed=True)
            hint = f"{dict_outer}<String, {val_type}>"
        case set():
            elem_type = common(elements=list(data), boxed=True)
            hint = f"{set_outer}<{elem_type}>"
        case list() if seq_is_array:
            elem_type = common(elements=data, boxed=False)
            # Java cannot create arrays of generic types, so fall back
            # to Object[] when the element type is generic.
            if "<" in elem_type:
                elem_type = "Object"
            hint = f"{elem_type}[]"
        case list():
            elem_type = common(elements=data, boxed=True)
            hint = f"List<{elem_type}>"
        case _:
            hint = _java_scalar_hint(
                data=data,
                int_type=int_type,
                date_hint=date_hint,
                datetime_hint=datetime_hint,
            )
    return hint


@beartype
def _reject_conflicting_java_modifiers(
    modifiers: frozenset[enum.Enum],
) -> None:
    """Reject modifier combinations that would not compile.

    A field has exactly one visibility, so emitting more than one
    produces source such as ``public private int x``.

    Raises:
        ConflictingVariableModifiersError: If several visibility modifiers
            are given.
    """
    visibility = (
        _JavaModifiers.PUBLIC,
        _JavaModifiers.PRIVATE,
        _JavaModifiers.PROTECTED,
    )
    given = tuple(m.value for m in visibility if m in modifiers)
    if len(given) > 1:
        raise ConflictingVariableModifiersError(
            language_name="Java",
            group_name="visibility",
            keywords=given,
        )


@beartype
def _java_modifier_prefix(modifiers: frozenset[enum.Enum]) -> str:
    """Return the ``public static final `` prefix for a Java
    declaration, including a trailing space when non-empty.

    Values that are not :class:`_JavaModifiers` members are ignored.
    """
    _reject_conflicting_java_modifiers(modifiers=modifiers)
    keywords = [m.value for m in _JavaModifiers if m in modifiers]
    if len(keywords) == 0:
        return ""
    return " ".join(keywords) + " "


@beartype
@dataclasses.dataclass(frozen=True, kw_only=True)
class _JavaTerminatedValue:
    """A Java value split before its trailing line comments."""

    code: str
    trailing: str


@beartype
def _java_split_trailing_line_comments(value: str) -> _JavaTerminatedValue:
    """Keep a statement terminator ahead of trailing ``//`` comments."""
    lines = value.split(sep="\n")
    split_index = next(
        (
            index + 1
            for index, line in reversed(list(enumerate(iterable=lines)))
            if not line.lstrip().startswith("//")
        ),
        0,
    )
    if split_index == len(lines):
        return _JavaTerminatedValue(code=value, trailing="")
    return _JavaTerminatedValue(
        code="\n".join(lines[:split_index]),
        trailing="\n" + "\n".join(lines[split_index:]),
    )


@beartype
def _format_java_var_declaration(
    name: str,
    value: str,
    _data: Value,
    _modifiers: frozenset[enum.Enum],
) -> str:
    """Format a ``var`` declaration."""
    terminated = _java_split_trailing_line_comments(value=value)
    return f"var {name} = {terminated.code};{terminated.trailing}"


@beartype
def _format_java_assignment(
    name: str,
    value: str,
    _data: Value,
) -> str:
    """Format a Java assignment."""
    terminated = _java_split_trailing_line_comments(value=value)
    return f"{name} = {terminated.code};{terminated.trailing}"


@beartype
def _java_inference_widens_unsafely(*, data: Value) -> bool:
    """Return True if Java ``var`` inference for *data* would widen to a
    permissive type (e.g. ``Object[]`` for ``new Object[]{}``).

    Empty collection literals trigger this fallback in
    :func:`_java_common_element_type`, so they are the canonical case
    for which a ``SAFE`` annotation is preferable to inference.
    """
    match data:
        case list() | set() | dict():
            return len(data) == 0
        case _:
            return False


@beartype
def _format_java_typed_declaration(
    *,
    name: str,
    value: str,
    data: Value,
    modifiers: frozenset[enum.Enum],
    int_type: str,
    date_hint: str,
    datetime_hint: str,
    seq_is_array: bool,
    dict_outer: str,
    set_outer: str,
) -> str:
    """Format a Java variable declaration with an explicit type."""
    hint = _java_type_hint(
        data=data,
        int_type=int_type,
        date_hint=date_hint,
        datetime_hint=datetime_hint,
        seq_is_array=seq_is_array,
        dict_outer=dict_outer,
        set_outer=set_outer,
    )
    prefix = _java_modifier_prefix(modifiers=modifiers)
    terminated = _java_split_trailing_line_comments(value=value)
    return f"{prefix}{hint} {name} = {terminated.code};{terminated.trailing}"


@beartype
def _apply_java_object_nil_declaration(
    *,
    name: str,
    value: str,
    data: Value,
    modifiers: frozenset[enum.Enum],
    base_formatter: Callable[[str, str, Value, frozenset[enum.Enum]], str],
    typed_formatter: Callable[[str, str, Value, frozenset[enum.Enum]], str],
) -> str:
    """Format a Java variable declaration, guarding top-level ``null``
    and switching to the typed form whenever modifiers are present.
    """
    if len(modifiers) > 0:
        return typed_formatter(name, value, data, modifiers)
    if data is None:
        terminated = _java_split_trailing_line_comments(value=value)
        return f"Object {name} = {terminated.code};{terminated.trailing}"
    return base_formatter(name, value, data, modifiers)


@beartype
def _object_nil_declaration(
    *,
    base_formatter: Callable[[str, str, Value, frozenset[enum.Enum]], str],
    typed_formatter: Callable[[str, str, Value, frozenset[enum.Enum]], str],
) -> Callable[[str, str, Value, frozenset[enum.Enum]], str]:
    """Wrap *base_formatter* so top-level ``null`` gets a typed form.

    Java cannot infer a type from ``null``, so ``var {name} = null;``
    fails to compile.  Emit ``Object {name} = null;`` when the value is
    ``None``.  Modifiers force the typed form because Java class-field
    syntax (e.g. ``public static final``) cannot be combined with
    ``var``.
    """

    def _format(
        name: str,
        value: str,
        data: Value,
        modifiers: frozenset[enum.Enum],
    ) -> str:
        """Delegate to module-level implementation."""
        return _apply_java_object_nil_declaration(
            name=name,
            value=value,
            data=data,
            modifiers=modifiers,
            base_formatter=base_formatter,
            typed_formatter=typed_formatter,
        )

    return _format


_JACKSON_JSON_NODE_PREAMBLE: tuple[str, ...] = (
    "import com.fasterxml.jackson.databind.JsonNode;",
    "import com.fasterxml.jackson.databind.ObjectMapper;",
)


# Sequence/dict format definitions used while ``json_type`` is active.
# The framework still walks through the data to compute a formatted
# ``value``, but that string is discarded by
# :func:`_format_java_json_declaration` and friends in favor of a fresh
# ``json.dumps`` of the raw data.  These definitions only need to be
# permissive enough that the formatting pass does not error on
# heterogeneous data or nulls inside containers.
_JSON_NODE_SEQUENCE_CONFIG = SequenceFormatConfig(
    sequence_open=fixed_open(open_str="["),
    close="]",
    supports_heterogeneity=True,
    single_element_trailing_comma=False,
    single_element_template=None,
    supports_trailing_comma=True,
    empty_sequence="[]",
    preamble_lines=(),
    format_entry=passthrough_sequence_entry,
    typed_opener_fallback=None,
    uses_typed_literal_for_scalars=False,
    requires_uniform_record_shapes=False,
    declared_type=None,
    narrowed_empty_form=None,
)

_JSON_NODE_SET_CONFIG = SetFormatConfig(
    set_open=fixed_open(open_str="["),
    close="]",
    empty_set="[]",
    preamble_lines=(),
    set_opener_template="",
    supports_heterogeneity=True,
    supports_trailing_comma=True,
)

_JSON_NODE_DICT_CONFIG = DictFormatConfig(
    dict_open=fixed_open(open_str="{"),
    close="}",
    format_entry=dict_entry_with_template(
        template="{key}: {value}",
        format_value=passthrough_sequence_entry,
    ),
    empty_dict="{}",
    preamble_lines=(),
    narrowed_open=None,
    supports_trailing_comma=True,
    narrowed_empty_form=None,
)

_JSON_NODE_ORDERED_MAP_CONFIG = OrderedMapFormatConfig(
    ordered_map_open=fixed_open(open_str="{"),
    close="}",
    preamble_lines=(),
)


@beartype
def _java_read_tree_expression(data: Value) -> str:
    """Render ``new ObjectMapper().readTree("...")`` for *data*."""
    json_text = format_json_value_text(data=data)
    java_literal = format_string_backslash_nul_octal(value=json_text)
    mapper = "new ObjectMapper()"
    if data_has_special_float(data=data):
        mapper = (
            "new ObjectMapper(com.fasterxml.jackson.core.JsonFactory.builder()"
            ".enable(com.fasterxml.jackson.core.json.JsonReadFeature."
            "ALLOW_NON_NUMERIC_NUMBERS).build())"
        )
    return f"{mapper}.readTree({java_literal})"


@beartype
def _format_java_json_declaration(
    name: str,
    _value: str,
    data: Value,
    _modifiers: frozenset[enum.Enum],
) -> str:
    """Format a JsonNode declaration backed by ``readTree``."""
    return f"JsonNode {name} = {_java_read_tree_expression(data=data)};"


@beartype
def _format_java_json_assignment(
    name: str,
    _value: str,
    data: Value,
) -> str:
    """Format a JsonNode assignment backed by ``readTree``."""
    return f"{name} = {_java_read_tree_expression(data=data)};"


@beartype
def _format_java_json_call_arg(raw_value: Value, _formatted: str) -> str:
    """Format a direct call argument as a JsonNode literal."""
    return _java_read_tree_expression(data=raw_value)


@beartype
def _java_record_field_identifier(
    key: str, /, *, reserved_identifiers: frozenset[str]
) -> str:
    """Return the Java record component name for a dict *key*.

    Java record components keep the original key (identity); the
    literal is positional so the name only labels the declaration.
    """
    if key in reserved_identifiers:
        msg = f"Java record field name {key!r} is reserved"
        raise UnrepresentableInputError(msg)
    return key


@beartype
def _java_record_literal(
    name: str,
    fields: Sequence[RecordLiteralField],
    /,
) -> RenderedRecordLiteral:
    """Render a Java ``new Name(value, ...)`` positional record literal
    as structured pieces for the shared compact/multiline layout code.

    Java records are positional, so the field identifiers label only
    the declaration; the literal emits arguments in declaration order
    with no field names.
    """
    return RenderedRecordLiteral(
        head=f"new {name}(",
        entries=tuple(field.formatted for field in fields),
        closer=")",
        compact_pad="",
    )


@beartype
def _java_render_declaration(
    name: str,
    fields: Sequence[RecordDeclarationField],
    /,
) -> str:
    """Render a Java ``record Name(type id, ...) {}`` declaration."""
    components = ", ".join(
        f"{field.type_name} {field.identifier}" for field in fields
    )
    return f"record {name}({components}) {{}}"


@beartype
@dataclasses.dataclass(frozen=True, kw_only=True)
class Java(metaclass=LanguageCls):
    """Java language specification.

    Args:
        date_format: How to format :class:`datetime.date` values.

            * ``date_formats.JAVA`` — ``LocalDate.of(...)`` call,
              e.g. ``LocalDate.of(2024, 1, 15)``.
            * ``date_formats.ISO`` — ISO 8601 quoted string,
              e.g. ``"2024-01-15"``.

        datetime_format: How to format :class:`datetime.datetime` values.

            * ``datetime_formats.INSTANT`` — ``Instant.parse(...)`` call,
              e.g. ``Instant.parse("2024-01-15T12:30:00")``.
            * ``datetime_formats.ZONED`` — ``ZonedDateTime.of(...)`` call,
              e.g. ``ZonedDateTime.of(2024, 1, 15, 12, 30, 0, 0,
              ZoneId.of("UTC"))``.
            * ``datetime_formats.ISO`` — ISO 8601 quoted string,
              e.g. ``"2024-01-15T12:30:00"``.

        sequence_format: How to format sequences.

            * ``sequence_formats.ARRAY`` — Java array literal,
              e.g. ``new Object[]{1, 2, 3}``.
            * ``sequence_formats.LIST`` — ``List.of(...)`` call,
              e.g. ``List.of(1, 2, 3)``.

        json_type: When set to ``json_types.JACKSON_JSON_NODE``, render
            values through Jackson's ``ObjectMapper.readTree(...)`` so the
            output produces a ``com.fasterxml.jackson.databind.JsonNode``
            instead of Java's narrow ``List`` / ``Map`` / array types.

    A rendered literal is one expression, and ``wrap_in_file`` puts it
    in one method, so a large document runs into the 64KB cap the
    virtual machine places on a single method's compiled size: ``javac``
    then reports ``code too large``. The ceiling is on the whole
    document rather than on any one collection -- two 5000-element lists
    overflow where one does not -- and it moves with shape, so there is
    no single element count to quote. Measured with javac 21, a flat
    list stops compiling at about 8200 scalars, two-element nested lists
    at about 6500, and ten-element nested lists at about 11500 (issue
    #4541).

    An unwrapped result carries the same limit, because the caller
    places the expression in a method or an initializer of their own.
    Splitting the document and combining the parts at run time is the
    way past it.
    """

    wrap_in_file_tolerates_pre_indent = True
    module_name_shares_variable_scope = False
    reserved_variable_identifier_pattern: ClassVar[re.Pattern[str] | None] = (
        None
    )
    reserved_call_parameter_identifiers: ClassVar[frozenset[str]] = frozenset()
    reserved_call_parameter_identifier_pattern: ClassVar[
        re.Pattern[str] | None
    ] = None
    accepts_type_name_call_target = True
    declares_type_name_call_target = True
    reserved_bare_call_target_identifiers: ClassVar[frozenset[str]] = (
        frozenset()
    )
    reserved_call_target_head_identifiers: ClassVar[frozenset[str]] = (
        frozenset()
    )
    contextual_call_target_identifiers: ClassVar[frozenset[str]] = frozenset()
    call_parameter_shadowing = CallParameterShadowing.ALLOWED
    reserved_call_target_keywords_case_sensitive = True
    module_name_must_start_uppercase = False
    new_variable_name_syntax = NewVariableNameSyntax.ASCII
    max_variable_identifier_length: ClassVar[int | None] = None
    call_target_name_syntax: ClassVar[NewVariableNameSyntax | None] = None
    supports_multiline_dict_layout = True
    pools_map_integer_width = True

    format_call_variable_declaration = default_format_call_variable_declaration
    format_call_variable_assignment = default_format_call_variable_assignment
    format_constructor_target: ClassVar["staticmethod[[str], str]"] = (
        staticmethod(new_constructor_target)
    )
    sequence_binding_declarations = default_sequence_binding_declarations
    format_call_binding_body_preamble = no_call_binding_body_preamble
    format_call_binding_file_pragmas = no_call_binding_file_pragmas

    module_name: str = "Module"

    leading_preamble = no_leading_preamble
    extension = ".java"
    pygments_name = "java"
    stringifies_nested_collections = False
    supports_special_floats = True
    supports_variable_names = True
    supports_no_variable_wrap_in_file = False
    wraps_data_dependent_preamble_in_body = False
    dict_supports_heterogeneous_values = True
    supports_dotted_calls = True
    has_free_function_calls = True
    declares_call_parameter_names = True
    reserved_variable_identifiers_case_sensitive: bool = True
    reserved_variable_identifiers: frozenset[str] = frozenset(
        {
            "Array",
            "Boolean",
            "Double",
            "Integer",
            "List",
            "Map",
            "String",
            "_",
            "abstract",
            "assert",
            "boolean",
            "break",
            "byte",
            "case",
            "catch",
            "char",
            "class",
            "const",
            "continue",
            "default",
            "do",
            "double",
            "else",
            "enum",
            "extends",
            "false",
            "final",
            "finally",
            "float",
            "for",
            "goto",
            "if",
            "implements",
            "import",
            "instanceof",
            "int",
            "interface",
            "long",
            "native",
            "new",
            "null",
            "package",
            "private",
            "protected",
            "public",
            "return",
            "short",
            "static",
            "strictfp",
            "super",
            "switch",
            "synchronized",
            "this",
            "throw",
            "throws",
            "transient",
            "true",
            "try",
            "void",
            "volatile",
            "while",
        }
    )
    reserved_identifiers: ClassVar[frozenset[str]] = (
        reserved_variable_identifiers
    )
    reserved_module_identifiers: ClassVar[frozenset[str]] = (
        reserved_variable_identifiers
        | {"record", "var", "yield"}
        | frozenset(
            {
                "begin",
                "end",
            }
        )
    )
    allows_empty_call_parens = True
    supports_dotted_call_stub = True
    dotted_call_stub_requires_unique_parts = True
    dotted_call_stub_normalizes_part_case = True
    call_returns_expression = True
    supports_json_call_result_binding = False
    supports_zero_parameter_calls = True
    max_call_parameters = NO_CALL_PARAMETER_LIMIT
    supports_inline_multiline_dict_args = True
    supports_standalone_comments_in_wrapped_calls = True
    supports_multi_param_call_wrapper_stub = True
    supports_dict_literal_as_free_expression = True
    supports_module_name = True
    supports_empty_dict_key = False
    supports_call_style = True
    supports_default_dict_key_type = False
    supports_default_dict_value_type = False
    supports_default_sequence_element_type = False
    supports_default_set_element_type = False
    supports_default_ordered_map_value_type = False
    json_type_variant_name_suffix: ClassVar[str | None] = None
    supports_non_ascii_string_literals = True
    supports_multiline_string_literals = True
    supports_empty_sibling_sequence_type_hints = True
    supports_typed_dict_open = False
    language_id: ClassVar[str] = "java"
    variant_metadata: ClassVar[VariantMetadata] = VariantMetadata(
        round_trip_capabilities=frozenset(
            {
                RoundTripCapability.I64_BOUNDARIES,
                RoundTripCapability.INTERPOLATION_STRINGS,
                RoundTripCapability.EMBEDDED_NUL,
            }
        ),
        modifier_sequence_format_overrides={},
        string_literals_escape_null_byte=True,
        supports_ref_elements_in_tuple_strategy=False,
    )
    supports_record_struct_name_prefix = True
    supports_record_shape_names = True
    record_shape_names_emit_declarations = True
    supports_non_string_dict_keys = True
    checks_raw_control_dict_keys_separately = False

    _opener_config = TypedOpenerConfig(
        str_type="String",
        bool_type="boolean",
        int_type="int",
        float_type="double",
        mixed_numeric_type="double",
        bytes_type="String",
        date_type="LocalDate",
        datetime_type=None,
        time_type="LocalTime",
        list_template="{inner}[]",
        sequence_opener_template="new {type_name}[]{{",
        dict_opener_template="new {type_name}[]{{",
        set_opener_template="Set.of(",
        dict_type_template=None,
        fallback_value_type=None,
        wide_int_type="long",
        beyond_i64_type="BigInteger",
    )

    _opener_config_long = TypedOpenerConfig(
        str_type="String",
        bool_type="boolean",
        int_type="long",
        float_type="double",
        mixed_numeric_type="double",
        bytes_type="String",
        date_type="LocalDate",
        datetime_type=None,
        time_type="LocalTime",
        list_template="{inner}[]",
        sequence_opener_template="new {type_name}[]{{",
        dict_opener_template="new {type_name}[]{{",
        set_opener_template="Set.of(",
        dict_type_template=None,
        fallback_value_type=None,
        wide_int_type=None,
        beyond_i64_type="BigInteger",
    )

    class DateFormats(DateFormatEnum):
        """Date formatting options for Java."""

        _value_: DateFormatConfig

        JAVA = DateFormatConfig(
            formatter=date_ymd_formatter(
                template="LocalDate.of({year}, {month}, {day})",
            ),
            preamble_lines=("import java.time.LocalDate;",),
            type_produced=datetime.date,
        )
        ISO = DateFormatConfig(
            formatter=format_date_iso, type_produced=str, preamble_lines=()
        )

    class DatetimeFormats(DatetimeFormatEnum):
        """Datetime formatting options for Java."""

        _value_: DatetimeFormatConfig

        INSTANT = DatetimeFormatConfig(
            formatter=_format_datetime_java_instant,
            preamble_lines=("import java.time.Instant;",),
            type_produced=datetime.datetime,
        )
        ZONED = DatetimeFormatConfig(
            formatter=_format_datetime_java_zoned,
            preamble_lines=(
                "import java.time.ZoneId;",
                "import java.time.ZonedDateTime;",
            ),
            type_produced=datetime.datetime,
        )
        ISO = DatetimeFormatConfig(
            formatter=format_datetime_iso,
            type_produced=str,
            preamble_lines=(),
        )

        EPOCH = DatetimeFormatConfig(
            formatter=format_datetime_epoch,
            type_produced=int,
            preamble_lines=(),
        )

    class BytesFormats(enum.Enum):
        """Bytes formatting options."""

        _value_: Callable[[bytes], str]

        HEX = enum.member(value=format_bytes_hex)
        BASE64 = enum.member(value=format_bytes_base64)

        def __call__(self, data: bytes, /) -> str:
            """Format bytes."""
            return self._value_(data)

    class SequenceFormats(enum.Enum):
        """Sequence type options for Java."""

        ARRAY = SequenceFormatConfig(
            sequence_open=fixed_open(open_str="new Object[]{"),
            close="}",
            supports_heterogeneity=True,
            single_element_trailing_comma=False,
            single_element_template=None,
            supports_trailing_comma=True,
            empty_sequence=None,
            preamble_lines=(),
            format_entry=passthrough_sequence_entry,
            typed_opener_fallback="new Object[]{",
            uses_typed_literal_for_scalars=False,
            requires_uniform_record_shapes=False,
            declared_type=None,
            narrowed_empty_form=None,
        )
        LIST = SequenceFormatConfig(
            sequence_open=_list_of_open,
            format_entry=passthrough_sequence_entry,
            typed_opener_fallback=None,
            uses_typed_literal_for_scalars=False,
            requires_uniform_record_shapes=False,
            close=")",
            supports_heterogeneity=True,
            single_element_trailing_comma=False,
            single_element_template=None,
            supports_trailing_comma=False,
            empty_sequence="List.of()",
            preamble_lines=("import java.util.List;",),
            declared_type=None,
            narrowed_empty_form=None,
        )

    class SetFormats(enum.Enum):
        """Set type options for Java."""

        SET = SetFormatConfig(
            set_open=fixed_open(open_str="Set.of("),
            close=")",
            empty_set=None,
            preamble_lines=("import java.util.Set;",),
            set_opener_template="",
            supports_heterogeneity=True,
            supports_trailing_comma=False,
        )
        TREE_SET = SetFormatConfig(
            set_open=fixed_open(open_str="new TreeSet<>(Set.of("),
            close="))",
            empty_set="new TreeSet<>()",
            preamble_lines=(
                "import java.util.Set;",
                "import java.util.TreeSet;",
            ),
            set_opener_template="",
            supports_heterogeneity=False,
            supports_trailing_comma=False,
        )

    class CommentFormats(enum.Enum):
        """Comment style options."""

        DOUBLE_SLASH = CommentConfig(
            prefix="//",
            suffix="",
        )
        BLOCK = CommentConfig(
            prefix="/*",
            suffix=" */",
        )

    class DeclarationStyles(enum.Enum):
        """Declaration style options."""

        VAR = DeclarationStyleConfig(
            formatter=_format_java_var_declaration,
            supports_redefinition=True,
        )

    class DictEntryStyles(enum.Enum):
        """Dict entry style options."""

        DEFAULT = enum.auto()

    class DictFormats(enum.Enum):
        """Dict/map format options."""

        MAP_OF_ENTRIES = DictFormatConfig(
            dict_open=fixed_open(open_str="Map.ofEntries("),
            close=")",
            format_entry=dict_entry_with_template(
                template="Map.entry({key}, {value})",
                format_value=passthrough_sequence_entry,
            ),
            empty_dict=None,
            preamble_lines=("import java.util.Map;",),
            narrowed_open=None,
            supports_trailing_comma=False,
            narrowed_empty_form=None,
        )
        HASH_MAP = DictFormatConfig(
            dict_open=fixed_open(open_str="new HashMap<>(Map.ofEntries("),
            close="))",
            format_entry=dict_entry_with_template(
                template="Map.entry({key}, {value})",
                format_value=passthrough_sequence_entry,
            ),
            empty_dict="new HashMap<>()",
            preamble_lines=(
                "import java.util.HashMap;",
                "import java.util.Map;",
            ),
            narrowed_open=None,
            supports_trailing_comma=False,
            narrowed_empty_form=None,
        )

    class EmptyDictKey(enum.Enum):
        """Empty dict key options."""

        ALLOW = enum.auto()

    class FloatFormats(
        FloatSpecialsMixin,
        enum.Enum,
        positive_infinity="Double.POSITIVE_INFINITY",
        negative_infinity="Double.NEGATIVE_INFINITY",
        nan="Double.NaN",
    ):
        """Float format options."""

        REPR = enum.member(value=format_float_repr)
        SCIENTIFIC = enum.member(value=format_float_scientific)
        FIXED = enum.member(value=format_float_fixed)

    class IntegerFormats(enum.Enum):
        """Integer format options."""

        DECIMAL = MappingProxyType(
            mapping={
                "NONE": str,
                "UNDERSCORE": format_integer_underscore,
            }
        )
        HEX = MappingProxyType(
            mapping={
                "NONE": format_integer_hex,
                "UNDERSCORE": format_integer_hex,
            }
        )
        OCTAL = MappingProxyType(
            mapping={
                "NONE": format_integer_octal_c_style,
                "UNDERSCORE": format_integer_octal_c_style,
            }
        )
        BINARY = MappingProxyType(
            mapping={
                "NONE": format_integer_binary,
                "UNDERSCORE": format_integer_binary,
            }
        )

        def get_formatter(
            self,
            numeric_separator: enum.Enum,
        ) -> Callable[[int], str]:
            """Return the integer formatter for the given separator."""
            formatter: Callable[[int], str] = self.value[
                numeric_separator.name
            ]
            return formatter

    class NumericLiteralSuffixes(enum.Enum):
        """Numeric literal suffix options."""

        NONE = enum.auto()
        AUTO = enum.auto()

    class NumericSeparators(enum.Enum):
        """Numeric separator options."""

        NONE = enum.auto()
        UNDERSCORE = enum.auto()

    class NumericStyles(enum.Enum):
        """Numeric literal style options."""

        OVERLOADED = enum.auto()

    class StringFormats(enum.Enum):
        """String format options."""

        _value_: Callable[[str], str]

        DOUBLE = enum.member(value=format_string_backslash_nul_octal)
        MULTILINE = enum.member(value=_format_string_multiline)

        def __call__(self, value: str, /) -> str:
            """Format a string."""
            return self._value_(value)

    class TrailingCommas(enum.Enum):
        """Trailing comma options."""

        YES = TrailingCommaConfig(multiline_trailing_comma=True)
        NO = TrailingCommaConfig(multiline_trailing_comma=False)

    immutable_variable_modifiers: ClassVar[frozenset[enum.Enum]] = frozenset(
        {
            _JavaModifiers.FINAL,
        }
    )
    Modifiers = _JavaModifiers

    date_formats = DateFormats
    datetime_formats = DatetimeFormats
    bytes_formats = BytesFormats
    sequence_formats = SequenceFormats
    set_formats = SetFormats
    comment_formats = CommentFormats
    modifiers = _JavaModifiers

    class HeterogeneousStrategies(enum.Enum):
        """Strategy for dicts whose values span more than one Java type.

        ``ERROR`` keeps Java's strict-typing behavior (mixed-value dicts
        that cannot be represented raise).  ``RECORD`` renders each
        record-shaped dict (non-empty, string-keyed) as a generated
        ``record`` declared in the preamble plus a matching positional
        ``new Record0(...)`` literal, so fields may legitimately mix
        scalars and containers.
        """

        ERROR = enum.auto()
        RECORD = enum.auto()

    heterogeneous_strategies = HeterogeneousStrategies

    class BoolFormats(enum.Enum):
        """Empty: this language has no alternative boolean formats."""

    bool_formats = BoolFormats

    class JsonTypes(JsonType):
        """JSON value type options for Java."""

        JACKSON_JSON_NODE = "com.fasterxml.jackson.databind.JsonNode"
        """Jackson's dynamic JSON value type."""

    json_types = JsonTypes

    class VersionFormats(enum.Enum):
        """Version options for Java.

        * ``VersionFormats.JDK_11``: target Java 11.
        * ``VersionFormats.JDK_16``: target Java 16.

        The ``RECORD`` ``heterogeneous_strategy`` emits ``record``
        declarations, which require Java 16 or newer, so a
        ``RECORD`` spec pins ``language_version`` to ``JDK_16``.
        The ``MULTILINE`` string format likewise pins ``JDK_16`` because it
        emits text blocks, which are unavailable under ``JDK_11``.
        """

        JDK_11 = enum.auto()
        JDK_16 = enum.auto()

    version_formats = VersionFormats

    module_name_case: ClassVar[IdentifierCase] = IdentifierCase.PASCAL
    identifier_cases: ClassVar[tuple[IdentifierCase, ...]] = (
        IdentifierCase.CAMEL,
        IdentifierCase.PASCAL,
        IdentifierCase.UPPER_SNAKE,
    )
    supported_ref_cases: ClassVar[frozenset[IdentifierCase]] = (
        NON_KEBAB_REF_CASES
    )

    modifier_combinations: ClassVar[tuple[ModifierCombination, ...]] = (
        ModifierCombination(
            name="public_static_final",
            modifiers=frozenset(
                {
                    _JavaModifiers.PUBLIC,
                    _JavaModifiers.STATIC,
                    _JavaModifiers.FINAL,
                },
            ),
        ),
    )

    def __post_init__(self) -> None:
        """Pin ``language_version`` to ``JDK_16`` when syntax requires it.

        ``RECORD`` declarations and ``MULTILINE`` text blocks require Java
        16; ``JDK_11`` output would fail to compile. Coercing here keeps the
        version behavior consistent for either format and lets fixtures use
        the effective ``@jdk_16`` tag.
        """
        jdk_16 = type(self.language_version).JDK_16
        requires_jdk_16 = (
            self.heterogeneous_strategy
            is type(self.heterogeneous_strategy).RECORD
            or self.string_format is type(self.string_format).MULTILINE
        )
        if requires_jdk_16 and self.language_version is not jdk_16:
            object.__setattr__(self, "language_version", jdk_16)
        method_name = IdentifierCase.CAMEL.convert(name=self.module_name)
        if method_name in self.reserved_variable_identifiers:
            raise InvalidModuleNameError(
                language_name=type(self).__name__,
                module_name=self.module_name,
            )
        self._validate_record_naming()
        self._validate_json_type_spec()

    def _validate_json_type_spec(self) -> None:
        """Reject ``json_type`` combinations the generator cannot emit.

        ``readTree(...)`` is a checked-exception call wrapped in a
        method whose signature gains ``throws Exception``.  Class-field
        forms (``public static final ...``) have no equivalent place to
        declare that exception without synthesizing a static initializer
        block, so a ``RECORD`` strategy is also unsupported because it
        would mix the JsonNode rendering with auto-generated ``record``
        declarations.  Both are rejected up front instead.
        """
        if not self._json_type_active:
            return
        if self.heterogeneous_strategy is self.heterogeneous_strategies.RECORD:
            msg = (
                "Java json_type renders data through "
                "ObjectMapper.readTree(...) and is incompatible with "
                "heterogeneous_strategy=RECORD, which generates typed "
                "record declarations. Use heterogeneous_strategy=ERROR."
            )
            raise IncompatibleFormatsError(msg)

    def _validate_json_value_keys(self, data: Value, /) -> None:
        """Reject non-string object keys for Jackson ``JsonNode``."""
        match data:
            case OrderedMap() | dict():
                for key, value in data.items():
                    if not isinstance(key, str):
                        msg = (
                            "Java json_type can only represent dict keys "
                            "as JSON object strings, not "
                            f"{type(key).__name__}"
                        )
                        raise UnrepresentableInputError(msg)
                    self._validate_json_value_keys(value)
            case list() | set():
                for item in data:
                    self._validate_json_value_keys(item)
            case _:
                return

    def _validate_record_naming(self) -> None:
        """Validate ``record_shape_names`` for PascalCase identifier
        shape, collisions with the auto-generated ``{prefix}{N}``
        record names, collisions with the wrapper class name, and
        duplicate target names.

        Ported from
        :meth:`literalizer.languages.Rust._validate_record_naming`.
        Java has no ``heterogeneous_value_enum_name`` so that collision
        check does not apply, and Rust's reserved-keyword check is
        unnecessary here: every Java keyword is lowercase, so the
        PascalCase requirement already rejects every one of them.  Java
        records are emitted as top-level types before
        ``class {module_name}`` (default ``Module``, ``Main`` in the
        golden harness), so a custom name must not collide with that
        wrapper class either.
        """
        prefix = self.record_struct_name_prefix
        auto_name_pattern = re.compile(
            pattern=rf"^{re.escape(pattern=prefix)}\d+$",
        )
        seen_names: set[str] = set()
        for keys, name in self.record_shape_names.items():
            if _PASCAL_CASE_IDENTIFIER.match(string=name) is None:
                msg = (
                    f"record_shape_names entry for keys {sorted(keys)!r} "
                    f"maps to {name!r}, which is not a PascalCase Java "
                    f"identifier."
                )
                raise InvalidRecordNameError(msg)
            if name == self.module_name:
                msg = (
                    f"record_shape_names entry for keys {sorted(keys)!r} "
                    f"maps to {name!r}, which collides with the wrapper "
                    f"class name (module_name)."
                )
                raise InvalidRecordNameError(msg)
            if name in _JAVA_EMITTED_TYPE_NAMES:
                msg = (
                    f"record_shape_names entry for keys {sorted(keys)!r} "
                    f"maps to {name!r}, which names a type the generated "
                    f"code itself uses."
                )
                raise InvalidRecordNameError(msg)
            if auto_name_pattern.match(string=name) is not None:
                msg = (
                    f"record_shape_names entry for keys {sorted(keys)!r} "
                    f"maps to {name!r}, which collides with the "
                    f"auto-generated {prefix!r}-prefixed record names."
                )
                raise InvalidRecordNameError(msg)
            if name in seen_names:
                msg = (
                    f"record_shape_names maps multiple key-sets to "
                    f"{name!r}; record names must be unique."
                )
                raise InvalidRecordNameError(msg)
            seen_names.add(name)

    def validate_spec_for_data(self, data: Value) -> None:
        """Raise if the spec cannot produce valid code for *data*.

        Under the ``RECORD`` heterogeneous strategy a list-valued
        record component is typed from the array opener
        (``new <type>[]{``) the value formatter emits, so its declared
        type matches the rendered literal.  Only
        ``sequence_format=ARRAY`` produces that opener; every other
        sequence format (e.g. ``LIST`` -> ``List.of(...)``) carries no
        element type in its opener and is outside the ``RECORD``
        strategy's MVP (cf. the set / non-record-dict boundary in
        #2317), so the combination is rejected here rather than
        emitting a ``record`` declaration that fails to compile.  This
        check is spec-only; *data* is unused.

        When :attr:`json_type` is active, additionally walk *data* to
        reject non-string dict keys, which JSON objects cannot represent.
        """
        if self._json_type_active:
            self._validate_json_value_keys(data)
            return
        _validate_no_null_collection_keys(data=data)
        self.validate_call_arg(data)
        strategies = type(self.heterogeneous_strategy)
        formats = type(self.sequence_format)
        if (
            self.heterogeneous_strategy is strategies.RECORD
            and self.sequence_format is not formats.ARRAY
        ):
            msg = (
                "Java heterogeneous_strategy=RECORD requires "
                "sequence_format=ARRAY: a list-valued record component "
                "is typed from the array opener the value formatter "
                "emits, and other sequence formats (e.g. LIST -> "
                "List.of(...)) carry no element type. "
                "Use sequence_format=ARRAY."
            )
            raise IncompatibleFormatsError(msg)

    @staticmethod
    def _validate_record_null_map_values(
        data: Value,
        *,
        compute_record_shapes: Callable[[Value], Mapping[int, RecordShape]],
        record_name_for_value: Callable[[Value], str | None],
    ) -> None:
        """Reject nulls in maps that the record strategy leaves as
        maps.
        """
        _ = compute_record_shapes(data)

        @beartype
        def _walk(value: Value) -> None:
            """Walk nested values and distinguish records from maps."""
            match value:
                case OrderedMap():
                    _walk_java_ordered_map_values(data=value, walk=_walk)
                case dict():
                    rendered_as_record = (
                        record_name_for_value(value) is not None
                    )
                    for item in value.values():
                        if item is None and not rendered_as_record:
                            msg = (
                                "Java's Map.entry() does not accept null "
                                "values; remove the null-valued entry"
                            )
                            raise UnrepresentableInputError(msg)
                        _walk(value=item)
                case list() | set():
                    for item in value:
                        _walk(value=item)
                case _:
                    return

        _walk(value=data)

    @cached_property
    def validate_call_arg(self) -> Callable[[Value], None]:
        """Return call-argument validation for this language."""
        if self._json_type_active:
            return self._validate_json_value_keys
        strategy = self._record_strategy
        match (
            strategy.behavior.compute_record_shapes,
            strategy.record_name_for_value,
        ):
            case (compute_record_shapes, record_name_for_value) if (
                compute_record_shapes is not None
                and record_name_for_value is not None
            ):
                return functools.partial(
                    self._validate_record_null_map_values,
                    compute_record_shapes=compute_record_shapes,
                    record_name_for_value=record_name_for_value,
                )
            case _:
                return _validate_no_null_map_values

    @cached_property
    def format_call_statement(self) -> Callable[[str], str]:
        """Return call-statement formatting for this language."""
        return identity_call_statement

    wrap_calls_with_declarations = default_wrap_calls_with_declarations

    class VariableTypeHints(enum.Enum):
        """Variable type hint options."""

        NEVER = enum.auto()
        ALWAYS = enum.auto()
        SAFE = enum.auto()

        def formatter(
            self,
            *,
            auto_formatter: Callable[
                [str, str, Value, frozenset[enum.Enum]], str
            ],
            int_type: str,
            date_hint: str,
            datetime_hint: str,
            seq_is_array: bool,
            dict_outer: str,
            set_outer: str,
        ) -> Callable[[str, str, Value, frozenset[enum.Enum]], str]:
            """Return the variable declaration formatter."""

            def typed(
                name: str,
                value: str,
                data: Value,
                modifiers: frozenset[enum.Enum],
            ) -> str:
                """Adapt :func:`_format_java_typed_declaration` to the
                positional formatter interface.
                """
                return _format_java_typed_declaration(
                    name=name,
                    value=value,
                    data=data,
                    modifiers=modifiers,
                    int_type=int_type,
                    date_hint=date_hint,
                    datetime_hint=datetime_hint,
                    seq_is_array=seq_is_array,
                    dict_outer=dict_outer,
                    set_outer=set_outer,
                )

            cls = type(self)
            if self is cls.NEVER:
                return _object_nil_declaration(
                    base_formatter=auto_formatter,
                    typed_formatter=typed,
                )
            if self is cls.SAFE:
                auto_with_nil = _object_nil_declaration(
                    base_formatter=auto_formatter,
                    typed_formatter=typed,
                )

                def _safe_formatter(
                    name: str,
                    value: str,
                    data: Value,
                    modifiers: frozenset[enum.Enum],
                ) -> str:
                    """Annotate when inference would widen unsafely
                    (empty collection).
                    """
                    if _java_inference_widens_unsafely(data=data):
                        return typed(
                            name=name,
                            value=value,
                            data=data,
                            modifiers=modifiers,
                        )
                    return auto_with_nil(name, value, data, modifiers)

                return _safe_formatter
            return typed

    variable_type_hints_formats = VariableTypeHints
    declaration_styles = DeclarationStyles
    dict_entry_styles = DictEntryStyles
    dict_formats = DictFormats
    empty_dict_keys = EmptyDictKey
    float_formats = FloatFormats
    integer_formats = IntegerFormats
    integer_width_strategies = BareIntegerWidthStrategies
    numeric_literal_suffixes = NumericLiteralSuffixes
    numeric_separators = NumericSeparators
    numeric_styles = NumericStyles
    string_formats = StringFormats
    trailing_commas = TrailingCommas

    class StatementTerminatorStyles(enum.Enum):
        """Statement terminator options."""

        SEMICOLON = enum.auto()

    statement_terminator_styles = StatementTerminatorStyles

    class CallStyles(enum.Enum):
        """Java call style options."""

        POSITIONAL = PositionalCallStyle(
            arg_separator=", ", parenthesize_each_arg=False
        )

    call_styles = CallStyles

    dotted_call_root_shares_entrypoint_namespace = False

    @property
    def call_wrapper_entrypoint_name(self) -> str:
        """Return the generated complete-file entry-point name."""
        return IdentifierCase.CAMEL.convert(name=self.module_name)

    def wrap_in_file(
        self,
        content: str,
        variable_name: str,
        body_preamble: tuple[str, ...],
    ) -> str:
        """Wrap a Java declaration in a ``class`` scope named after
        the configured module name.

        When *content* starts with a class-field modifier keyword
        (``public``, ``private``, ``protected``, ``static``) the
        declaration is placed at class-field scope, which is the only
        context where those modifiers are valid.  Otherwise the
        declaration goes inside a ``public static void`` method named
        after the configured module name so that local-only forms like
        ``var x = 42;`` compile.
        """
        del variable_name
        first_token = content.lstrip().partition(" ")[0]
        is_class_field = first_token in {
            "public",
            "private",
            "protected",
            "static",
        }
        # Lines starting with "static " are class-level declarations
        # (call stubs); everything else goes inside the method body.
        class_lines = [
            line for line in body_preamble if line.startswith("static ")
        ]
        method_lines = tuple(
            line for line in body_preamble if not line.startswith("static ")
        )
        class_block = ""
        if len(class_lines) > 0:
            class_block = "\n".join(class_lines) + "\n"
        method_name = IdentifierCase.CAMEL.convert(name=self.module_name)
        if is_class_field:
            field_preamble = "\n".join((*method_lines, ""))
            return (
                f"class {self.module_name} {{\n"
                f"{class_block}{field_preamble}{content}\n}}"
            )
        content = prepend_body_preamble(
            content=content,
            body_preamble=method_lines,
        )
        throws_clause = ""
        if self._json_type_active:
            throws_clause = " throws Exception"
        return (
            f"class {self.module_name} {{\n"
            f"{class_block}"
            f"{self.indent}public static void {method_name}()"
            f"{throws_clause} {{\n"
            f"{content}\n"
            f"{self.indent}}}\n"
            "}"
        )

    def wrap_combined_in_file(
        self,
        declaration: str,
        assignment: str,
        variable_name: str,
        body_preamble: tuple[str, ...],
    ) -> str:
        """Wrap Java declaration + assignment in a static method."""
        return self.wrap_in_file(
            content=declaration + "\n" + assignment,
            variable_name=variable_name,
            body_preamble=body_preamble,
        )

    date_format: DateFormats = DateFormats.JAVA
    datetime_format: DatetimeFormats = DatetimeFormats.INSTANT
    bytes_format: BytesFormats = BytesFormats.HEX
    sequence_format: SequenceFormats = SequenceFormats.ARRAY
    set_format: SetFormats = SetFormats.SET
    variable_type_hints: VariableTypeHints = VariableTypeHints.NEVER
    comment_format: CommentFormats = CommentFormats.DOUBLE_SLASH
    declaration_style: DeclarationStyles = DeclarationStyles.VAR
    dict_entry_style: DictEntryStyles = DictEntryStyles.DEFAULT
    dict_format: DictFormats = DictFormats.MAP_OF_ENTRIES
    float_format: FloatFormats = FloatFormats.REPR
    integer_format: IntegerFormats = IntegerFormats.DECIMAL
    integer_width_strategy: BareIntegerWidthStrategies = (
        BareIntegerWidthStrategies.BARE
    )
    numeric_literal_suffix: NumericLiteralSuffixes = (
        NumericLiteralSuffixes.NONE
    )
    numeric_separator: NumericSeparators = NumericSeparators.NONE
    numeric_style: NumericStyles = NumericStyles.OVERLOADED
    string_format: StringFormats = StringFormats.DOUBLE
    trailing_comma: TrailingCommas = TrailingCommas.NO
    statement_terminator_style: StatementTerminatorStyles = (
        StatementTerminatorStyles.SEMICOLON
    )
    call_style: CallStyles = CallStyles.POSITIONAL
    heterogeneous_strategy: HeterogeneousStrategies = (
        HeterogeneousStrategies.ERROR
    )
    json_type: JsonTypes | None = None
    # The `Lint Java` step in `.github/workflows/lint.yml` compiles each
    # `@jdk_<release>` golden with the `--release` literal matching its
    # `VersionFormats` member (`11` for `JDK_11`, `16` for `JDK_16`).
    # Keep those literals in sync with `VersionFormats` above.
    language_version: VersionFormats = VersionFormats.JDK_11
    record_struct_name_prefix: str = "Record"
    record_shape_names: Mapping[frozenset[str], str] = dataclasses.field(
        default_factory=lambda: MappingProxyType[frozenset[str], str](
            mapping={}
        ),
        hash=False,
    )
    indent: str = "    "

    null_literal: ClassVar[str] = "null"
    true_literal: ClassVar[str] = "true"
    false_literal: ClassVar[str] = "false"
    indent_closing_delimiter: ClassVar[bool] = False
    element_separator: ClassVar[str] = ", "
    skip_null_dict_values: ClassVar[bool] = True
    supports_scalar_before_comments: ClassVar[bool] = False
    supports_scalar_inline_comments: ClassVar[bool] = False
    statement_terminator: ClassVar[str] = ";"
    static_body_preamble: ClassVar[Sequence[str]] = ()
    special_float_preamble: ClassVar[tuple[str, ...]] = ()

    @cached_property
    def supports_collection_comments(self) -> bool:
        """Whether a comment can sit inside the rendered value.

        ``ObjectMapper.readTree`` is handed one JSON document, and
        JSON has no comments, so a comment written inside it would
        be text the parser refuses.  The comments go before the
        declaration instead (issue #4546).
        """
        return not self._json_type_active

    @cached_property
    def _json_type_active(self) -> bool:
        """Return whether Java should render via Jackson JsonNode."""
        return self.json_type is not None

    @cached_property
    def static_preamble(self) -> Sequence[str]:
        """Static preamble lines emitted once per file.

        When :attr:`json_type` is active the Jackson ``JsonNode`` and
        ``ObjectMapper`` imports are emitted here so every fixture has
        them in scope regardless of the rendered data.
        """
        if self._json_type_active:
            return _JACKSON_JSON_NODE_PREAMBLE
        return ()

    @cached_property
    def format_call_arg(self) -> Callable[[Value, str], str]:
        """Callable that rewrites a formatted direct call argument."""
        if self._json_type_active:
            return _format_java_json_call_arg
        return identity_call_arg

    @cached_property
    def format_string(self) -> Callable[[str], str]:
        """Format a string value as a quoted literal."""
        return self.string_format

    @cached_property
    def format_sequence_entry(self) -> Callable[[Value, str], str]:
        """Format a sequence entry."""
        return passthrough_sequence_entry

    @cached_property
    def format_set_entry(self) -> Callable[[Value, str], str]:
        """Format a set entry."""
        return passthrough_set_entry

    @cached_property
    def format_variable_assignment(self) -> Callable[[str, str, Value], str]:
        """Format an assignment to an existing variable."""
        if self._json_type_active:
            return _format_java_json_assignment
        return _format_java_assignment

    @cached_property
    def _java_record_int_type(self) -> str:
        """Java integer type for a record-component scalar."""
        if self._suffix_is_auto:
            return "long"
        return "int"

    def _java_record_datetime_type(self, value: datetime.datetime, /) -> str:
        """Java type for a :class:`datetime.datetime` record component.

        Unlike a top-level variable annotation, a record component must
        match the literal :meth:`format_datetime` emits.  ``ISO``
        renders a quoted string (``String``); ``EPOCH`` renders the
        epoch seconds through :attr:`format_integer`, which appends an
        ``L`` (so the type is ``long``) once the value leaves Java's
        32-bit ``int`` range -- epoch seconds after 2038-01-19 overflow
        it.  The component type therefore reuses the exact plain
        ``int`` record-field formula (``AUTO`` suffix forces ``long``
        for every epoch); it stays value-driven rather than a pure
        ``cached_property``.  Otherwise the type is format-driven
        (``ZonedDateTime`` / ``Instant``).
        """
        produced = self.datetime_format.value.type_produced
        if produced is str:
            return "String"
        if produced is int:
            epoch = datetime_epoch_seconds(value=value)
            int_type = self._java_record_int_type
            in_i32 = _JAVA_I32_MIN <= epoch <= _JAVA_I32_MAX
            if int_type == "int" and not in_i32:
                return "long"
            return int_type
        if self.datetime_format is type(self.datetime_format).ZONED:
            return "ZonedDateTime"
        return "Instant"

    @cached_property
    def _java_record_scalar_resolver(
        self,
    ) -> Callable[[type | ListType | DictType], str | None]:
        """Type-only scalar resolver (the mapping the typed openers are
        built on); returns ``None`` for an unmapped type so callers can
        fall back to the top type.
        """
        return self._opener_config.element_to_type(
            dict_value_to_type=None,
            list_template=None,
            enable_list_type=False,
            date_type=None,
            datetime_type=None,
            enable_dict_type=False,
            dict_key_type="",
        )

    def _java_record_field_type(
        self,
        request: RecordFieldType,
        /,
    ) -> str:
        """Return the Java record-component type for a field.

        Derives the type from the raw value (and any resolved
        nested-record name), mirroring Go's structural port rather than
        re-parsing the formatted literal.  ``int`` magnitude (``int``
        vs ``long``) and the format-dependent ``datetime`` type
        (``Instant`` / ``ZonedDateTime`` / ``String`` / magnitude-aware
        epoch ``int`` or ``long``) are value- and spec-driven, so they
        are resolved explicitly;
        every other scalar (including ``date`` -> ``LocalDate``) goes
        through the shared type-only resolver.

        An ordered-map field is the concrete ``java.util.ArrayList``
        the ordered-map opener constructs.  A list field is typed from
        the array opener ``self.sequence_open`` emits for it (no
        sibling override, so the opener equals the one rendered):
        ``new int[]{`` -> ``int[]``, ``new Object[]{`` -> ``Object[]``.
        Only ``sequence_format=ARRAY`` produces that opener;
        :meth:`validate_spec_for_data` rejects ``RECORD`` with any
        other sequence format up front, so no opener without an
        encoded element type (e.g. ``List.of(``) reaches this branch.

        A record-eligible dict with no ``record_name`` was widened out
        of record inference because its nested sibling maps cannot
        share one shape.  Type that field as ``Map<String, Object>`` so
        the uniform enclosing record survives (#2912).  A
        set or a genuinely non-record dict (empty or non-string-keyed)
        still has no precise component type; per the cross-language
        decision in #2317, Java folds it into the ``Object`` top type.
        """
        if request.record_name is not None and request.record_name != "":
            nested_type = request.record_name
        else:
            nested_type = None
            if request.element_record_name is not None:
                nested_type = f"{request.element_record_name}[]"
        if nested_type is not None:
            return nested_type
        value = request.value
        match value:
            case OrderedMap():
                field_type = "java.util.ArrayList"
            case dict() if record_shape_for_dict(value=value) is not None:
                return "java.util.Map<String, Object>"
            case list():
                opener = self.sequence_open(value)
                field_type = opener.removeprefix("new ").removesuffix("{")
            case _:
                return self._java_record_noncollection_field_type(value)
        return field_type

    def _java_record_noncollection_field_type(self, value: Value, /) -> str:
        """Return a record type for a scalar or unsupported collection."""
        match value:
            case bool():
                return "boolean"
            case int() if not I64_MIN <= value <= I64_MAX:
                return "BigInteger"
            case int():
                int_type = self._java_record_int_type
                in_i32 = _JAVA_I32_MIN <= value <= _JAVA_I32_MAX
                resolved_result_1: str = int_type
                if int_type == "int" and (not in_i32):
                    resolved_result_1 = "long"
                return resolved_result_1
            case datetime.datetime():
                return self._java_record_datetime_type(value)
            case _:
                scalar_type = self._java_record_scalar_resolver(type(value))
                resolved_result_2: str = "Object"
                if scalar_type is not None and scalar_type != "":
                    resolved_result_2 = scalar_type
                return resolved_result_2

    @cached_property
    def _record_renderer(self) -> RecordRenderer:
        """Java syntax hooks for the ``RECORD`` strategy."""
        return RecordRenderer(
            name_prefix=self.record_struct_name_prefix,
            record_shape_names=self.record_shape_names,
            field_identifier=functools.partial(
                _java_record_field_identifier,
                reserved_identifiers=self.reserved_variable_identifiers,
            ),
            field_identifier_key=identity_field_identifier_key,
            field_type=self._java_record_field_type,
            render_declaration=_java_render_declaration,
            render_literal=_java_record_literal,
            field_type_names_nested_records=False,
            suppress_custom_name_declarations=False,
        )

    @cached_property
    def _record_strategy(self) -> RecordStrategy:
        """Resolve the active strategy to its behavior + preamble."""
        cls = type(self.heterogeneous_strategy)
        if self.heterogeneous_strategy is cls.RECORD:
            return build_record_strategy(
                renderer=self._record_renderer,
                split_conflicting_field_types=True,
                widen_unrecordizable_nested_sibling_maps=True,
                derecordized_map_open=None,
            )
        return RecordStrategy(
            behavior=NO_HETEROGENEOUS_BEHAVIOR,
            preamble=no_data_preamble,
            record_name_for_value=None,
        )

    @cached_property
    def data_dependent_preamble(self) -> Callable[[Value], tuple[str, ...]]:
        """Return data-dependent preamble lines.

        Always emits ``import java.math.BigInteger;`` when the data
        needs it; under ``HeterogeneousStrategies.RECORD`` also emits
        one ``record`` declaration per record shape present in the
        data.  When :attr:`json_type` is active, neither the BigInteger
        import nor record declarations apply: integers outside the
        64-bit range ride inside the JSON text, and the data flows
        through a single ``ObjectMapper.readTree`` call instead of typed
        records.
        """
        if self._json_type_active:
            return no_data_preamble
        record_preamble = self._record_strategy.preamble

        @beartype
        def _preamble(data: Value, /) -> tuple[str, ...]:
            """Combine the BigInteger import with record declarations."""
            return _java_biginteger_preamble(data) + record_preamble(data)

        return _preamble

    @cached_property
    def heterogeneous_behavior(self) -> HeterogeneousBehavior:
        """Return the behavior for the chosen heterogeneous strategy."""
        if self._json_type_active:
            return dataclasses.replace(
                NO_HETEROGENEOUS_BEHAVIOR,
                skip_scalar_checks=True,
            )
        return self._record_strategy.behavior

    @cached_property
    def call_data_dependent_preamble(
        self,
    ) -> Callable[[Value], tuple[str, ...]]:
        """Return data-dependent preamble lines for call rendering."""
        return self.data_dependent_preamble

    @cached_property
    def type_hint_collection_preamble_lines(
        self,
    ) -> Callable[[frozenset[type]], tuple[str, ...]]:
        """Return preamble lines for empty-collection type hints."""
        return no_type_hint_preamble

    @cached_property
    def format_call_stub(
        self,
    ) -> Callable[
        [Sequence[str], Sequence[str], StubReturn, Sequence[Value]],
        tuple[str, ...],
    ]:
        """Return stub declarations for a call expression."""
        return _java_call_stub

    @cached_property
    def format_call_preamble_stub(
        self,
    ) -> Callable[
        [Sequence[str], Sequence[str], StubReturn, Sequence[Value]],
        tuple[str, ...],
    ]:
        """Return file-scope stubs for a call expression."""
        return no_call_stub

    @cached_property
    def format_call_target(self) -> Callable[[Sequence[str]], str]:
        """Rewrite a dotted call target into the language's call
        syntax.
        """
        return identity_call_target

    @cached_property
    def format_call_ref_identifier(
        self,
    ) -> Callable[[str, Value | None], str]:
        """Rewrite a ``{"$ref": "name"}`` identifier into the
        language's call expression syntax.
        """
        return identity_call_ref_identifier

    @cached_property
    def format_call_arg_ref_identifier(
        self,
    ) -> Callable[[str, Value | None], str]:
        """Rewrite a ``{"$ref": "name"}`` identifier in a call-argument
        context.

        Delegates to :attr:`format_call_ref_identifier`.  Override this to
        allow call-argument ``$ref`` values that would otherwise be rejected.
        """
        return self.format_call_ref_identifier

    @cached_property
    def format_call_arg_ref_identifier_consumable(
        self,
    ) -> Callable[[str, Value | None], str]:
        """Format a ``$ref`` the caller authorized as consumable.

        Delegates to :attr:`format_call_arg_ref_identifier`.  Override
        this to opt into a consuming form (e.g. C++ ``std::move``).
        """
        return self.format_call_arg_ref_identifier

    @cached_property
    def consumable_ref_value_inhibits_consuming_form(
        self,
    ) -> Callable[[Value], bool]:
        """Predicate deciding whether a ref's underlying value type
        inhibits the consume form.

        Delegates to :data:`never_inhibits_consuming_form`.  Languages
        whose consume operator rejects certain value types (notably
        the Mojo ``^`` on register-trivial scalars) override this.
        """
        return never_inhibits_consuming_form

    @cached_property
    def _suffix_is_auto(self) -> bool:
        """Whether the numeric-literal suffix is AUTO (long suffix)."""
        return (
            self.numeric_literal_suffix
            is type(self.numeric_literal_suffix).AUTO
        )

    @cached_property
    def _java_dict_entry(self) -> Callable[[str, Value, str], str]:
        """Shared dict-entry formatter used by dict and ordered-map."""
        return dict_entry_with_template(
            template="Map.entry({key}, {value})",
            format_value=passthrough_sequence_entry,
        )

    @cached_property
    def sequence_format_config(self) -> SequenceFormatConfig:
        """Configuration for the chosen sequence format."""
        if self._json_type_active:
            return _JSON_NODE_SEQUENCE_CONFIG
        return self.sequence_format.value

    @cached_property
    def set_format_config(self) -> SetFormatConfig:
        """Configuration for the chosen set format."""
        if self._json_type_active:
            return _JSON_NODE_SET_CONFIG
        return self.set_format.value

    @cached_property
    def sequence_open(self) -> Callable[[list[Value]], str]:
        """Callable that returns the opening delimiter for a sequence.

        Under ``HeterogeneousStrategies.RECORD`` a list whose every
        element is rendered as one shared record type opens as
        ``new RecordN[]{`` -- the record literals all share that
        element type, so the array spells it instead of falling back to
        ``new Object[]{``.
        """
        if self._json_type_active:
            return _JSON_NODE_SEQUENCE_CONFIG.sequence_open
        fmt = self.sequence_format.value
        if fmt.typed_opener_fallback is None:
            return fmt.sequence_open
        if self._suffix_is_auto:
            cfg = self._opener_config_long
        else:
            cfg = self._opener_config
        effective_datetime_type: str | None
        effective_datetime_type = "long"
        if self.datetime_format.value.type_produced is not int:
            effective_datetime_type = cfg.type_name(
                py_type=self.datetime_format.value.type_produced,
            )
        openers = cfg.build(
            date_type=cfg.type_name(
                py_type=self.date_format.value.type_produced
            ),
            datetime_type=(effective_datetime_type),
            set_opener_template=None,
            narrow_dict_values=False,
            narrow_list_values=True,
            dict_key_type="",
        )
        base = typed_collection_open(
            type_to_opener=openers.seq,
            fallback=fmt.typed_opener_fallback,
        )
        match self._record_strategy.record_name_for_value:
            case None:
                return base
            case record_name_for_value:
                pass

        def _open(items: list[Value], /) -> str:
            """Use the shared record element type when every item is
            rendered as one record, else the typed array opener.
            """
            names = {record_name_for_value(item) for item in items}
            if len(names) == 1:
                (name,) = names
                if name is not None:
                    return f"new {name}[]{{"
            return base(items)

        return _open

    @cached_property
    def dict_format_config(self) -> DictFormatConfig:
        """Configuration for dict formatting."""
        if self._json_type_active:
            return _JSON_NODE_DICT_CONFIG
        return self.dict_format.value

    @cached_property
    def trailing_comma_config(self) -> TrailingCommaConfig:
        """Configuration for trailing-comma behavior."""
        return self.trailing_comma.value

    @cached_property
    def format_bytes(self) -> Callable[[bytes], str]:
        """Callable that formats a bytes value as a string literal."""
        return self.bytes_format

    @cached_property
    def format_date(self) -> Callable[[datetime.date], str]:
        """Callable that formats a date as a string literal."""
        return self.date_format

    @cached_property
    def format_datetime(self) -> Callable[[datetime.datetime], str]:
        """Callable that formats a datetime as a string literal.

        ``EPOCH`` seconds are routed through :attr:`format_integer` so
        a post-2038 value carries the ``L`` suffix Java requires for an
        integer literal outside 32-bit range: a bare ``4085195400``
        fails to compile as an ``int`` literal even when assigned to a
        ``long``.  In-range epoch seconds format identically to the
        plain integer, so every checked-in golden file stays
        byte-identical.
        """
        base_formatter: Callable[[datetime.datetime], str] = (
            self.datetime_format
        )
        if self.datetime_format is type(self.datetime_format).EPOCH:
            return datetime_epoch_formatter(format_integer=self.format_integer)
        return base_formatter

    @cached_property
    def format_time(self) -> Callable[[datetime.time], str]:
        """Callable that formats a time as a string literal."""
        return format_time_local_time_of

    @cached_property
    def format_float(self) -> Callable[[float], str]:
        """Callable that formats a float value as a literal."""
        return self.float_format

    @cached_property
    def format_integer_widened(self) -> Callable[[int], str]:
        """Always-``L``-suffixed integer formatter for widened
        collections (mixed-magnitude int sets/lists).
        """
        base_int_formatter = self.integer_format.get_formatter(
            numeric_separator=self.numeric_separator,
        )
        return make_overflow_fallback_formatter(
            base=make_long_suffix_formatter(base=base_int_formatter),
            fallback=_format_java_biginteger_literal,
            min_value=I64_MIN,
            max_value=I64_MAX,
        )

    @cached_property
    def format_integer_beyond_i64(self) -> Callable[[int], str]:
        """Always-``BigInteger`` integer formatter for collections that
        exceed signed 64-bit range.
        """
        return _format_java_biginteger_literal

    @cached_property
    def format_integer(self) -> Callable[[int], str]:
        """Callable that formats an int value as a literal."""
        base_int_formatter = self.integer_format.get_formatter(
            numeric_separator=self.numeric_separator,
        )
        suffixed: Callable[[int], str]
        if self._suffix_is_auto:
            suffixed = make_long_suffix_formatter(base=base_int_formatter)
        else:
            suffixed = make_overflow_suffix_formatter(
                base=base_int_formatter,
                min_value=-(2**31),
                max_value=2**31 - 1,
                suffix="L",
            )
        return make_overflow_fallback_formatter(
            base=suffixed,
            fallback=_format_java_biginteger_literal,
            min_value=I64_MIN,
            max_value=I64_MAX,
        )

    @cached_property
    def comment_config(self) -> CommentConfig:
        """Configuration for the language's comment syntax."""
        return self.comment_format.value

    @cached_property
    def ordered_map_format_config(self) -> OrderedMapFormatConfig:
        """Configuration for ordered-map formatting."""
        if self._json_type_active:
            return _JSON_NODE_ORDERED_MAP_CONFIG
        return OrderedMapFormatConfig(
            ordered_map_open=fixed_open(
                open_str=(
                    "new java.util.ArrayList<>(java.util.Arrays.asList("
                ),
            ),
            close="))",
            preamble_lines=("import java.util.Map;",),
        )

    @cached_property
    def format_ordered_map_entry(self) -> Callable[[str, Value, str], str]:
        """Callable that formats one ordered-map entry."""
        return self._java_dict_entry

    @cached_property
    def format_variable_declaration(
        self,
    ) -> Callable[[str, str, Value, frozenset[enum.Enum]], str]:
        """Callable that formats a new variable declaration."""
        if self._json_type_active:
            return _format_java_json_declaration
        datetime_produced = self.datetime_format.value.type_produced
        match datetime_produced:
            case _ if datetime_produced is str:
                datetime_hint = "String"
            case _ if datetime_produced is int:
                datetime_hint = "long"
            case _ if self.datetime_format is type(self.datetime_format).ZONED:
                datetime_hint = "ZonedDateTime"
            case _:
                datetime_hint = "Instant"
        effective_int_type = "int"
        if self._suffix_is_auto:
            effective_int_type = "long"
        effective_date_hint = "LocalDate"
        if self.date_format.value.type_produced is str:
            effective_date_hint = "String"
        effective_dict_outer = "Map"
        if self.dict_format is type(self.dict_format).HASH_MAP:
            effective_dict_outer = "HashMap"
        effective_set_outer = "Set"
        if self.set_format is type(self.set_format).TREE_SET:
            effective_set_outer = "TreeSet"
        return self.variable_type_hints.formatter(
            auto_formatter=self.declaration_style.value.formatter,
            int_type=effective_int_type,
            date_hint=(effective_date_hint),
            datetime_hint=datetime_hint,
            seq_is_array=(
                self.sequence_format is type(self.sequence_format).ARRAY
            ),
            dict_outer=(effective_dict_outer),
            set_outer=(effective_set_outer),
        )

    @cached_property
    def scalar_preamble(self) -> dict[type, tuple[str, ...]]:
        """Per-instance scalar preamble computed from date/datetime format.

        Under :attr:`json_type` every temporal value is folded into the
        JSON text as an ISO-8601 string, so the temporal Java imports
        that the configured ``date_format`` / ``datetime_format`` would
        otherwise add do not apply.
        """
        if self._json_type_active:
            return {}
        return date_scalar_preamble(
            date_format=self.date_format,
            datetime_format=self.datetime_format,
            extra={datetime.time: ("import java.time.LocalTime;",)},
        )

    @cached_property
    def scalar_body_preamble(self) -> dict[type, tuple[str, ...]]:
        """Per-instance scalar body preamble (Java needs none)."""
        return {}

    @cached_property
    def compute_body_preamble(
        self,
    ) -> Callable[[frozenset[type], Value], tuple[str, ...]]:
        """Compute body-preamble lines from the scalar map."""
        return body_preamble_from_scalars(
            scalar_body_preamble=self.scalar_body_preamble,
            format_lines=tuple,
        )

    @cached_property
    def call_style_config(self) -> CallStyle:
        """Configuration for the chosen call style."""
        return self.call_style.value
