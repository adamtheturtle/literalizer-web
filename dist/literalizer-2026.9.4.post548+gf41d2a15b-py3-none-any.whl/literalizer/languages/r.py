"""R language specification."""

import dataclasses
import datetime
import enum
import math
import re
from collections.abc import Callable, Sequence
from functools import cached_property, partial
from typing import ClassVar, override

from beartype import beartype

from literalizer._formatters.collection_openers import (
    fixed_open,
)
from literalizer._formatters.format_dates import (
    date_iso_formatter,
    format_date_iso,
    format_datetime_epoch,
    format_datetime_iso,
    format_time_iso,
    normalize_datetime_utc,
)
from literalizer._formatters.format_entries import (
    dict_entry_with_separator,
    format_bytes_base64,
    format_bytes_hex,
    passthrough_sequence_entry,
    passthrough_set_entry,
    variable_declaration_formatter,
    variable_formatter,
)
from literalizer._formatters.format_floats import (
    format_float_fixed,
    format_float_repr,
    format_float_scientific,
)
from literalizer._formatters.format_integers import format_integer_hex
from literalizer._formatters.format_strings import (
    bidi_escape_replacements,
    make_backslash_string_formatter,
    reject_nul_string_formatter,
)
from literalizer._language import (
    NO_CALL_PARAMETER_LIMIT,
    NO_HETEROGENEOUS_BEHAVIOR,
    NON_KEBAB_REF_CASES,
    BareIntegerWidthStrategies,
    CallParameterShadowing,
    CallStyle,
    CommentConfig,
    DateFormatConfig,
    DateFormatEnum,
    DatetimeFormatConfig,
    DatetimeFormatEnum,
    DeclarationStyleConfig,
    DictFormatConfig,
    FloatSpecialsMixin,
    HeterogeneousBehavior,
    IdentifierCase,
    JsonType,
    KeywordCallStyle,
    LanguageCls,
    ModifierCombination,
    NewVariableNameSyntax,
    OrderedMapFormatConfig,
    PositionalCallStyle,
    SequenceFormatConfig,
    SetFormatConfig,
    StubReturn,
    TrailingCommaConfig,
    VariantMetadata,
    body_preamble_from_scalars,
    default_format_call_variable_assignment,
    default_format_call_variable_declaration,
    default_sequence_binding_declarations,
    default_wrap_calls_with_declarations,
    identity_call_arg,
    identity_call_ref_identifier,
    identity_call_statement,
    identity_call_target,
    identity_constructor_target,
    never_inhibits_consuming_form,
    no_call_binding_body_preamble,
    no_call_binding_file_pragmas,
    no_call_stub,
    no_data_preamble,
    no_format_integer_beyond_i64,
    no_format_integer_widened,
    no_leading_preamble,
    no_type_hint_preamble,
    no_validate_call_arg,
    reject_empty_dicts,
    wrap_combined_in_file_noop,
    wrap_in_file_noop,
)
from literalizer._types import Scalar, Value
from literalizer.exceptions import (
    InvalidDictKeyError,
    UnrepresentableIntegerError,
)

_R_MIN_SAFE_FIXED_MAGNITUDE = 1e-16
_R_MAX_SAFE_FIXED_MAGNITUDE = 1e16


@beartype
def _format_r_float_fixed(value: float) -> str:
    """Avoid fixed spellings that R's decimal parser rounds incorrectly.

    R's ``R_strtod`` is not correctly rounded for the long decimals
    produced outside the conservatively bounded fixed-point range. Keep
    FIXED for ordinary magnitudes and use the round-tripping scientific
    formatter outside that range.
    """
    magnitude = abs(value)
    if (
        0 < magnitude < _R_MIN_SAFE_FIXED_MAGNITUDE
        or magnitude > _R_MAX_SAFE_FIXED_MAGNITUDE
    ):
        return format_float_scientific(value=value)
    return format_float_fixed(value=value)


@beartype
def _format_datetime_r(value: datetime.datetime, /) -> str:
    """Render a datetime with an explicit R parsing format.

    R's default ``as.POSIXct`` formats accept the date prefix of an ISO
    timestamp and silently discard the remaining time.  Use a space-separated
    value and an explicit format; normalize aware values to UTC so ``%z`` is
    portable and preserves the instant.
    """
    aware = value.utcoffset() is not None
    if aware:
        value = normalize_datetime_utc(value=value, language_name="R")
    rendered = value.strftime(format="%Y-%m-%d %H:%M:%S")
    if value.microsecond != 0:
        rendered += f".{value.microsecond:06d}"
    if aware:
        rendered += "+0000"
    offset_format = ""
    if aware:
        offset_format = "%z"
    timezone = ""
    if aware:
        timezone = ', tz = "UTC"'
    return (
        f'as.POSIXct("{rendered}", '
        f'format = "%Y-%m-%d %H:%M:%OS{offset_format}"{timezone})'
    )


@beartype
def _r_call_stub(
    parts: Sequence[str],
    _params: Sequence[str],
    _stub_return: StubReturn,
    _args: Sequence[Value],
    /,
) -> tuple[str, ...]:
    """Return an R stub declaration for a call name.

    R allows ``.`` in identifiers, so a dotted target such as
    ``app.client.fetch`` is a single name and one ``function(...)``
    declaration suffices to make the call evaluate at runtime.
    """
    return (f"{'.'.join(parts)} <- function(...) NULL",)


@beartype
def _format_r_dict_entry_positional(
    raw_key: Scalar,
    formatted_key: str,
    raw_value: Value,
    formatted_value: str,
) -> str:
    """Format an R named list entry.

    R list syntax does not allow zero-length names (``"" = value`` is a
    parse error), so empty-string keys are emitted as positional (unnamed)
    elements.
    """
    del raw_value
    if raw_key == "":
        return formatted_value
    return f"{formatted_key} = {formatted_value}"


@beartype
def _format_r_dict_entry_error(
    raw_key: Scalar,
    formatted_key: str,
    raw_value: Value,
    formatted_value: str,
) -> str:
    """Format an R named list entry, raising on empty-string keys."""
    del raw_value
    if raw_key == "":
        msg = (
            f"R does not support the dict key {formatted_key}. "
            "Use empty_dict_key=R.EmptyDictKey.POSITIONAL to emit them "
            "as unnamed list elements instead."
        )
        raise InvalidDictKeyError(msg)
    return f"{formatted_key} = {formatted_value}"


type _RSourceEntryFormatter = Callable[[Scalar, str, Value, str], str]


@beartype
@dataclasses.dataclass(frozen=True)
class _RDictFormatConfig(DictFormatConfig):
    """R dict config that classifies empty source keys."""

    source_format_entry: _RSourceEntryFormatter

    @override
    def format_entry_from_source(
        self,
        *,
        raw_key: Scalar,
        formatted_key: str,
        raw_value: Value,
        formatted_value: str,
    ) -> str:
        """Format an entry according to the source empty-key policy."""
        return self.source_format_entry(
            raw_key, formatted_key, raw_value, formatted_value
        )


@beartype
@dataclasses.dataclass(frozen=True)
class _ROrderedMapFormatConfig(OrderedMapFormatConfig):
    """R ordered-map config that classifies empty source keys."""

    source_format_entry: _RSourceEntryFormatter

    @override
    def format_entry_from_source(
        self,
        *,
        raw_key: Scalar,
        formatted_key: str,
        raw_value: Value,
        formatted_value: str,
        format_entry: Callable[[str, Value, str], str],
    ) -> str:
        """Format an entry according to the source empty-key policy."""
        del format_entry
        return self.source_format_entry(
            raw_key, formatted_key, raw_value, formatted_value
        )


# The R decimal float parser is several units in the last place out at
# the widest exponent, where one unit is about 2e292, so a value near
# the maximum overflows to ``Inf``.  The hexadecimal form is read
# exactly, so it carries that range (issue #4479).
_R_WIDEST_EXPONENT_MIN = 2.0**1023


@beartype
def _format_r_float(value: float, /, *, base: Callable[[float], str]) -> str:
    """Format a float, spelling the widest exponent in hexadecimal.

    A non-finite value goes to *base*, which spells it with the R
    names ``Inf``/``NaN``.
    """
    if (
        isinstance(value, float)
        and math.isfinite(value)
        and abs(value) >= _R_WIDEST_EXPONENT_MIN
    ):
        return value.hex()
    return base(value)


# An R symbol cannot begin with an underscore, and a bare ``_`` is the
# native pipe placeholder, so neither can name a call argument
# (issue #3952).
_R_LEADING_UNDERSCORE = re.compile(pattern=r"_.*")

# The R parser refuses a raw bidirectional formatting character --
# "formatting not allowed, use escapes instead" -- so each is emitted
# as the ``\uXXXX`` escape it accepts (issue #4478).
_format_string_r = make_backslash_string_formatter(
    quote_char='"',
    extra_replacements=bidi_escape_replacements(template="\\u{:04X}"),
)


@beartype
@dataclasses.dataclass(frozen=True, kw_only=True)
class R(metaclass=LanguageCls):
    """R language specification.

    Dicts are represented as named ``list()`` calls where each entry is
    written as ``"key" = value``.  R's parser rejects zero-length names, so
    by default dict keys that are empty strings raise
    :class:`~literalizer.exceptions.InvalidDictKeyError`.  Positional
    (unnamed) list elements are available as an explicit opt-in.

    Args:
        date_format: How to format :class:`datetime.date` values.

            * ``date_formats.R`` — ``as.Date(...)`` call,
              e.g. ``as.Date("2024-01-15")``.
            * ``date_formats.ISO`` — ISO 8601 quoted string,
              e.g. ``"2024-01-15"``.

        datetime_format: How to format :class:`datetime.datetime` values.

            * ``datetime_formats.R`` — ``as.POSIXct(...)`` call,
              e.g. ``as.POSIXct("2024-01-15T12:30:00")``.
            * ``datetime_formats.ISO`` — ISO 8601 quoted string,
              e.g. ``"2024-01-15T12:30:00"``.

        empty_dict_key: How to handle empty-string dict keys.

            * ``EmptyDictKey.POSITIONAL`` — emit as an unnamed
              positional list element.
            * ``EmptyDictKey.ERROR`` — raise
              :class:`~literalizer.exceptions.InvalidDictKeyError`.
    """

    reserved_module_identifiers: ClassVar[frozenset[str]] = frozenset()
    immutable_variable_modifiers: ClassVar[frozenset[enum.Enum]] = frozenset()
    wrap_in_file_tolerates_pre_indent = True
    module_name_shares_variable_scope = False
    reserved_variable_identifier_pattern: ClassVar[re.Pattern[str] | None] = (
        None
    )
    reserved_call_parameter_identifiers: ClassVar[frozenset[str]] = frozenset()
    accepts_type_name_call_target = True
    declares_type_name_call_target = True
    dotted_call_root_shares_entrypoint_namespace = True
    reserved_bare_call_target_identifiers: ClassVar[frozenset[str]] = (
        frozenset()
    )
    reserved_call_target_head_identifiers: ClassVar[frozenset[str]] = (
        frozenset()
    )
    contextual_call_target_identifiers: ClassVar[frozenset[str]] = frozenset()
    call_parameter_shadowing = CallParameterShadowing.ALLOWED
    reserved_call_target_keywords_case_sensitive = True
    module_name_must_start_uppercase = False
    max_variable_identifier_length: ClassVar[int | None] = None
    call_target_name_syntax: ClassVar[NewVariableNameSyntax | None] = None
    supports_multiline_dict_layout = True
    pools_map_integer_width = True

    format_integer_widened = no_format_integer_widened
    format_integer_beyond_i64 = no_format_integer_beyond_i64
    format_constructor_target: ClassVar["staticmethod[[str], str]"] = (
        staticmethod(identity_constructor_target)
    )
    format_call_variable_declaration = default_format_call_variable_declaration
    format_call_variable_assignment = default_format_call_variable_assignment
    sequence_binding_declarations = default_sequence_binding_declarations
    format_call_binding_body_preamble = no_call_binding_body_preamble
    format_call_binding_file_pragmas = no_call_binding_file_pragmas

    leading_preamble = no_leading_preamble
    extension = ".R"
    pygments_name = "r"
    stringifies_nested_collections = False
    supports_special_floats = True
    supports_variable_names = True
    supports_no_variable_wrap_in_file = True
    wraps_data_dependent_preamble_in_body = False
    dict_supports_heterogeneous_values = True
    supports_dotted_calls = True
    has_free_function_calls = True
    reserved_identifiers: ClassVar[frozenset[str]] = frozenset()
    reserved_call_parameter_identifier_pattern: ClassVar[re.Pattern[str]] = (
        _R_LEADING_UNDERSCORE
    )
    # An R symbol begins with a letter or a dot; a leading underscore
    # is a syntax error wherever it appears, not just in a call
    # argument (issue #4504).
    new_variable_name_syntax: ClassVar[NewVariableNameSyntax] = (
        NewVariableNameSyntax.ASCII_LETTER_START
    )
    declares_call_parameter_names = True
    reserved_variable_identifiers_case_sensitive: bool = True
    reserved_variable_identifiers: frozenset[str] = frozenset(
        {
            "...",
            "FALSE",
            "Inf",
            "NA",
            # The typed ``NA`` constants are parser literals, not
            # names: assigning to one is either an error or, for
            # ``NA_character_``, silently discarded (issue #4507).
            "NA_character_",
            "NA_complex_",
            "NA_integer_",
            "NA_real_",
            "NULL",
            "NaN",
            "TRUE",
            "break",
            "else",
            "for",
            "function",
            "if",
            "in",
            "next",
            "repeat",
            "while",
        }
    )
    allows_empty_call_parens = True
    supports_dotted_call_stub = True
    call_returns_expression = True
    supports_json_call_result_binding = False
    supports_zero_parameter_calls = True
    max_call_parameters = NO_CALL_PARAMETER_LIMIT
    supports_inline_multiline_dict_args = True
    supports_standalone_comments_in_wrapped_calls = True
    supports_multi_param_call_wrapper_stub = True
    supports_dict_literal_as_free_expression = True
    supports_module_name = False
    supports_empty_dict_key = True
    supports_call_style = True
    supports_default_dict_key_type = False
    supports_default_dict_value_type = False
    supports_default_sequence_element_type = False
    supports_default_set_element_type = False
    supports_default_ordered_map_value_type = False
    json_type_variant_name_suffix: ClassVar[str | None] = None
    supports_non_ascii_string_literals = True
    supports_multiline_string_literals = False
    supports_empty_sibling_sequence_type_hints = True
    supports_typed_dict_open = False
    language_id: ClassVar[str] = "r"
    variant_metadata: ClassVar[VariantMetadata] = VariantMetadata(
        round_trip_capabilities=frozenset(),
        modifier_sequence_format_overrides={},
        string_literals_escape_null_byte=False,
        supports_ref_elements_in_tuple_strategy=False,
    )
    supports_record_struct_name_prefix = False
    supports_record_shape_names = False
    record_shape_names_emit_declarations = False
    supports_non_string_dict_keys = False
    checks_raw_control_dict_keys_separately = False

    format_call_arg: ClassVar["staticmethod[[Value, str], str]"] = (
        staticmethod(
            identity_call_arg,
        )
    )
    """Callable that rewrites a formatted direct call argument."""

    class DateFormats(DateFormatEnum):
        """Date formatting options for R."""

        _value_: DateFormatConfig

        R = DateFormatConfig(
            formatter=date_iso_formatter(template='as.Date("{iso}")'),
            preamble_lines=(),
            type_produced=datetime.date,
        )
        ISO = DateFormatConfig(
            formatter=format_date_iso, type_produced=str, preamble_lines=()
        )

    class DatetimeFormats(DatetimeFormatEnum):
        """Datetime formatting options for R."""

        _value_: DatetimeFormatConfig

        R = DatetimeFormatConfig(
            formatter=_format_datetime_r,
            preamble_lines=(),
            type_produced=datetime.datetime,
        )
        ISO = DatetimeFormatConfig(
            formatter=format_datetime_iso,
            type_produced=str,
            preamble_lines=(),
        )

        EPOCH = DatetimeFormatConfig(
            formatter=format_datetime_epoch,
            type_produced=int,
            preamble_lines=(),
        )

    class EmptyDictKey(enum.Enum):
        """How to handle empty-string dict keys in R.

        R's parser rejects zero-length names (``"" = value`` is a parse
        error).
        """

        _value_: _RSourceEntryFormatter

        POSITIONAL = enum.member(value=_format_r_dict_entry_positional)
        ERROR = enum.member(value=_format_r_dict_entry_error)

        def __call__(
            self,
            raw_key: Scalar,
            formatted_key: str,
            raw_value: Value,
            formatted_value: str,
            /,
        ) -> str:
            """Format a dict entry."""
            return self._value_(
                raw_key, formatted_key, raw_value, formatted_value
            )

    class BytesFormats(enum.Enum):
        """Bytes formatting options."""

        _value_: Callable[[bytes], str]

        HEX = enum.member(value=format_bytes_hex)
        BASE64 = enum.member(value=format_bytes_base64)

        def __call__(self, data: bytes, /) -> str:
            """Format bytes."""
            return self._value_(data)

    class SequenceFormats(enum.Enum):
        """Sequence type options for R."""

        LIST = SequenceFormatConfig(
            sequence_open=fixed_open(open_str="list("),
            close=")",
            supports_heterogeneity=True,
            single_element_trailing_comma=False,
            single_element_template=None,
            supports_trailing_comma=False,
            empty_sequence=None,
            preamble_lines=(),
            format_entry=passthrough_sequence_entry,
            typed_opener_fallback=None,
            uses_typed_literal_for_scalars=False,
            requires_uniform_record_shapes=False,
            declared_type=None,
            narrowed_empty_form=None,
        )

    class SetFormats(enum.Enum):
        """Set type options for R."""

        SET = SetFormatConfig(
            set_open=fixed_open(open_str="list("),
            close=")",
            empty_set=None,
            preamble_lines=(),
            set_opener_template="",
            supports_heterogeneity=True,
            supports_trailing_comma=True,
        )

    class CommentFormats(enum.Enum):
        """Comment style options."""

        HASH = CommentConfig(
            prefix="#",
            suffix="",
        )

    class DeclarationStyles(enum.Enum):
        """Declaration style options."""

        ASSIGN = DeclarationStyleConfig(
            formatter=variable_declaration_formatter(
                template="{name} <- {value}"
            ),
            supports_redefinition=True,
        )

    class DictEntryStyles(enum.Enum):
        """Dict entry style options."""

        DEFAULT = enum.auto()

    class DictFormats(enum.Enum):
        """Dict/map format options."""

        DEFAULT = enum.auto()

    class FloatFormats(
        FloatSpecialsMixin,
        enum.Enum,
        positive_infinity="Inf",
        negative_infinity="-Inf",
        nan="NaN",
    ):
        """Float format options."""

        REPR = enum.member(value=format_float_repr)
        SCIENTIFIC = enum.member(value=format_float_scientific)
        FIXED = enum.member(value=_format_r_float_fixed)

    class IntegerFormats(enum.Enum):
        """Integer format options."""

        DECIMAL = enum.member(value=str)
        HEX = enum.member(value=format_integer_hex)

        def __call__(self, value: int, /) -> str:
            """Format an integer."""
            if not -(2**53) <= value <= 2**53:
                msg = (
                    f"R cannot represent integer {value} without external "
                    "arbitrary-precision integer support."
                )
                raise UnrepresentableIntegerError(msg)
            formatter: Callable[[int], str] = self.value
            return formatter(value)

    class NumericLiteralSuffixes(enum.Enum):
        """Numeric literal suffix options."""

        NONE = enum.auto()

    class NumericSeparators(enum.Enum):
        """Numeric separator options."""

        NONE = enum.auto()

    class NumericStyles(enum.Enum):
        """Numeric literal style options."""

        OVERLOADED = enum.auto()

    class StringFormats(enum.Enum):
        """String format options."""

        DOUBLE = enum.auto()

    class TrailingCommas(enum.Enum):
        """Trailing comma options.

        R's ``list()`` rejects empty arguments, so a literal trailing
        comma like ``list(1, 2,)`` parses but raises at runtime; only
        the comma-free form is supported.
        """

        NO = TrailingCommaConfig(multiline_trailing_comma=False)

    date_formats = DateFormats
    datetime_formats = DatetimeFormats
    bytes_formats = BytesFormats
    sequence_formats = SequenceFormats
    set_formats = SetFormats
    comment_formats = CommentFormats

    class VariableTypeHints(enum.Enum):
        """Variable type hint options."""

        NEVER = enum.auto()
        SAFE = enum.auto()

    variable_type_hints_formats = VariableTypeHints
    declaration_styles = DeclarationStyles
    dict_entry_styles = DictEntryStyles
    dict_formats = DictFormats
    empty_dict_keys = EmptyDictKey
    float_formats = FloatFormats
    integer_formats = IntegerFormats
    integer_width_strategies = BareIntegerWidthStrategies
    numeric_literal_suffixes = NumericLiteralSuffixes
    numeric_separators = NumericSeparators
    numeric_styles = NumericStyles
    string_formats = StringFormats
    trailing_commas = TrailingCommas

    class StatementTerminatorStyles(enum.Enum):
        """Statement terminator options."""

        SEMICOLON = enum.auto()

    statement_terminator_styles = StatementTerminatorStyles

    class CallStyles(enum.Enum):
        """R call style options."""

        KEYWORD = KeywordCallStyle(separator=" = ")
        POSITIONAL = PositionalCallStyle(
            arg_separator=", ", parenthesize_each_arg=False
        )

    call_styles = CallStyles

    class Modifiers(enum.Enum):
        """C++/Java/C#-style declaration modifiers: this language has none."""

    modifiers = Modifiers

    class HeterogeneousStrategies(enum.Enum):
        """Heterogeneous-scalar strategy options — this language only
        supports raising.
        """

        ERROR = NO_HETEROGENEOUS_BEHAVIOR

    heterogeneous_strategies = HeterogeneousStrategies

    class JsonTypes(JsonType):
        """Empty: this language has no JSON value-type variants."""

    json_types = JsonTypes

    class BoolFormats(enum.Enum):
        """Empty: this language has no alternative boolean formats."""

    bool_formats = BoolFormats

    class VersionFormats(enum.Enum):
        """Version options for R."""

        V4 = enum.auto()

    version_formats = VersionFormats

    modifier_combinations: ClassVar[tuple[ModifierCombination, ...]] = ()
    identifier_cases: ClassVar[tuple[IdentifierCase, ...]] = (
        IdentifierCase.SNAKE,
        IdentifierCase.CAMEL,
        IdentifierCase.PASCAL,
    )
    supported_ref_cases: ClassVar[frozenset[IdentifierCase]] = (
        NON_KEBAB_REF_CASES
    )

    @staticmethod
    def validate_spec_for_data(data: Value) -> None:
        """Reject inputs containing an empty mapping on R."""
        reject_empty_dicts(data=data, language_name="R")

    @cached_property
    def validate_call_arg(self) -> Callable[[Value], None]:
        """Return call-argument validation for this language."""
        return no_validate_call_arg

    @cached_property
    def format_call_statement(self) -> Callable[[str], str]:
        """Return call-statement formatting for this language."""
        return identity_call_statement

    wrap_calls_with_declarations = default_wrap_calls_with_declarations

    @staticmethod
    def wrap_in_file(
        content: str,
        variable_name: str,
        body_preamble: tuple[str, ...],
    ) -> str:
        """Wrap code in a valid file (no-op)."""
        return wrap_in_file_noop(
            content=content,
            variable_name=variable_name,
            body_preamble=body_preamble,
        )

    @staticmethod
    def wrap_combined_in_file(
        declaration: str,
        assignment: str,
        variable_name: str,
        body_preamble: tuple[str, ...],
    ) -> str:
        """Wrap declaration and assignment in a valid file (no-op)."""
        return wrap_combined_in_file_noop(
            declaration=declaration,
            assignment=assignment,
            variable_name=variable_name,
            body_preamble=body_preamble,
        )

    date_format: DateFormats = DateFormats.R
    datetime_format: DatetimeFormats = DatetimeFormats.R
    empty_dict_key: EmptyDictKey = EmptyDictKey.ERROR
    bytes_format: BytesFormats = BytesFormats.HEX
    sequence_format: SequenceFormats = SequenceFormats.LIST
    set_format: SetFormats = SetFormats.SET
    variable_type_hints: VariableTypeHints = VariableTypeHints.NEVER
    comment_format: CommentFormats = CommentFormats.HASH
    declaration_style: DeclarationStyles = DeclarationStyles.ASSIGN
    dict_entry_style: DictEntryStyles = DictEntryStyles.DEFAULT
    dict_format: DictFormats = DictFormats.DEFAULT
    float_format: FloatFormats = FloatFormats.REPR
    integer_format: IntegerFormats = IntegerFormats.DECIMAL
    integer_width_strategy: BareIntegerWidthStrategies = (
        BareIntegerWidthStrategies.BARE
    )
    numeric_literal_suffix: NumericLiteralSuffixes = (
        NumericLiteralSuffixes.NONE
    )
    numeric_separator: NumericSeparators = NumericSeparators.NONE
    numeric_style: NumericStyles = NumericStyles.OVERLOADED
    string_format: StringFormats = StringFormats.DOUBLE
    trailing_comma: TrailingCommas = TrailingCommas.NO
    statement_terminator_style: StatementTerminatorStyles = (
        StatementTerminatorStyles.SEMICOLON
    )
    call_style: CallStyles = CallStyles.KEYWORD
    heterogeneous_strategy: HeterogeneousStrategies = (
        HeterogeneousStrategies.ERROR
    )
    # Keep in sync with the `r-version` pin passed to
    # `r-lib/actions/setup-r` in the `lint-r` job of
    # `.github/workflows/lint.yml`; `V4` maps to R `4.x`, and that pin
    # (`4.4.0`) must stay `>=` this default.
    language_version: VersionFormats = VersionFormats.V4
    indent: str = "    "

    null_literal: ClassVar[str] = "NULL"
    true_literal: ClassVar[str] = "TRUE"
    false_literal: ClassVar[str] = "FALSE"
    indent_closing_delimiter: ClassVar[bool] = False
    element_separator: ClassVar[str] = ", "
    skip_null_dict_values: ClassVar[bool] = False
    supports_collection_comments: ClassVar[bool] = True
    supports_scalar_before_comments: ClassVar[bool] = True
    supports_scalar_inline_comments: ClassVar[bool] = True
    statement_terminator: ClassVar[str] = ""
    static_preamble: ClassVar[Sequence[str]] = ()
    static_body_preamble: ClassVar[Sequence[str]] = ()
    special_float_preamble: ClassVar[tuple[str, ...]] = ()

    @cached_property
    def format_string(self) -> Callable[[str], str]:
        """Format a string value as a quoted literal."""
        return reject_nul_string_formatter(
            _format_string_r,
            language_name="R",
        )

    @cached_property
    def format_sequence_entry(self) -> Callable[[Value, str], str]:
        """Format a sequence entry."""
        return passthrough_sequence_entry

    @cached_property
    def format_set_entry(self) -> Callable[[Value, str], str]:
        """Format a set entry."""
        return passthrough_set_entry

    @cached_property
    def format_variable_assignment(self) -> Callable[[str, str, Value], str]:
        """Format an assignment to an existing variable."""
        return variable_formatter(template="{name} <- {value}")

    @cached_property
    def data_dependent_preamble(self) -> Callable[[Value], tuple[str, ...]]:
        """Return data-dependent preamble lines."""
        return no_data_preamble

    @cached_property
    def heterogeneous_behavior(self) -> HeterogeneousBehavior:
        """Return the heterogeneous-behavior config."""
        return self.heterogeneous_strategy.value

    @cached_property
    def call_data_dependent_preamble(
        self,
    ) -> Callable[[Value], tuple[str, ...]]:
        """Return data-dependent preamble lines for call rendering."""
        return self.data_dependent_preamble

    @cached_property
    def type_hint_collection_preamble_lines(
        self,
    ) -> Callable[[frozenset[type]], tuple[str, ...]]:
        """Return preamble lines for empty-collection type hints."""
        return no_type_hint_preamble

    @cached_property
    def format_call_stub(
        self,
    ) -> Callable[
        [Sequence[str], Sequence[str], StubReturn, Sequence[Value]],
        tuple[str, ...],
    ]:
        """Return stub declarations for a call expression."""
        return _r_call_stub

    @cached_property
    def format_call_preamble_stub(
        self,
    ) -> Callable[
        [Sequence[str], Sequence[str], StubReturn, Sequence[Value]],
        tuple[str, ...],
    ]:
        """Return file-scope stubs for a call expression."""
        return no_call_stub

    @cached_property
    def format_call_target(self) -> Callable[[Sequence[str]], str]:
        """Rewrite a dotted call target into the language's call
        syntax.
        """
        return identity_call_target

    @cached_property
    def format_call_ref_identifier(
        self,
    ) -> Callable[[str, Value | None], str]:
        """Rewrite a ``{"$ref": "name"}`` identifier into the
        language's call expression syntax.
        """
        return identity_call_ref_identifier

    @cached_property
    def format_call_arg_ref_identifier(
        self,
    ) -> Callable[[str, Value | None], str]:
        """Rewrite a ``{"$ref": "name"}`` identifier in a call-argument
        context.

        Delegates to :attr:`format_call_ref_identifier`.  Override this to
        allow call-argument ``$ref`` values that would otherwise be rejected.
        """
        return self.format_call_ref_identifier

    @cached_property
    def format_call_arg_ref_identifier_consumable(
        self,
    ) -> Callable[[str, Value | None], str]:
        """Format a ``$ref`` the caller authorized as consumable.

        Delegates to :attr:`format_call_arg_ref_identifier`.  Override
        this to opt into a consuming form (e.g. C++ ``std::move``).
        """
        return self.format_call_arg_ref_identifier

    @cached_property
    def consumable_ref_value_inhibits_consuming_form(
        self,
    ) -> Callable[[Value], bool]:
        """Predicate deciding whether a ref's underlying value type
        inhibits the consume form.

        Delegates to :data:`never_inhibits_consuming_form`.  Languages
        whose consume operator rejects certain value types (notably
        the Mojo ``^`` on register-trivial scalars) override this.
        """
        return never_inhibits_consuming_form

    @cached_property
    def sequence_format_config(self) -> SequenceFormatConfig:
        """Configuration for the chosen sequence format."""
        return self.sequence_format.value

    @cached_property
    def set_format_config(self) -> SetFormatConfig:
        """Configuration for the chosen set format."""
        return self.set_format.value

    @cached_property
    def sequence_open(self) -> Callable[[list[Value]], str]:
        """Callable that returns the opening delimiter for a sequence."""
        return self.sequence_format.value.sequence_open

    @cached_property
    def dict_format_config(self) -> DictFormatConfig:
        """Configuration for dict formatting."""
        return _RDictFormatConfig(
            dict_open=fixed_open(open_str="list("),
            close=")",
            format_entry=dict_entry_with_separator(
                separator=" = ", format_value=passthrough_sequence_entry
            ),
            empty_dict=None,
            preamble_lines=(),
            narrowed_open=None,
            supports_trailing_comma=True,
            narrowed_empty_form=None,
            source_format_entry=self.empty_dict_key,
        )

    @cached_property
    def trailing_comma_config(self) -> TrailingCommaConfig:
        """Configuration for trailing-comma behavior."""
        return self.trailing_comma.value

    @cached_property
    def format_bytes(self) -> Callable[[bytes], str]:
        """Callable that formats a bytes value as a string literal."""
        return self.bytes_format

    @cached_property
    def format_date(self) -> Callable[[datetime.date], str]:
        """Callable that formats a date as a string literal."""
        return self.date_format

    @cached_property
    def format_datetime(self) -> Callable[[datetime.datetime], str]:
        """Callable that formats a datetime as a string literal."""
        return self.datetime_format

    @cached_property
    def format_time(self) -> Callable[[datetime.time], str]:
        """Callable that formats a time as a string literal."""
        return format_time_iso

    @cached_property
    def format_float(self) -> Callable[[float], str]:
        """Callable that formats a float value as a literal.

        A value at the widest exponent is spelled in hexadecimal,
        which the R parser reads exactly, because its decimal parser
        is several units in the last place out there and overflows to
        ``Inf`` near the maximum (issue #4479).
        """
        return partial(_format_r_float, base=self.float_format)

    @cached_property
    def format_integer(self) -> Callable[[int], str]:
        """Callable that formats an int value as a literal."""
        return self.integer_format

    @cached_property
    def comment_config(self) -> CommentConfig:
        """Configuration for the language's comment syntax."""
        return self.comment_format.value

    @cached_property
    def ordered_map_format_config(self) -> OrderedMapFormatConfig:
        """Configuration for ordered-map formatting."""
        return _ROrderedMapFormatConfig(
            ordered_map_open=fixed_open(open_str="list("),
            close=")",
            preamble_lines=(),
            source_format_entry=self.empty_dict_key,
        )

    @cached_property
    def format_ordered_map_entry(self) -> Callable[[str, Value, str], str]:
        """Callable that formats one ordered-map entry."""
        return dict_entry_with_separator(
            separator=" = ",
            format_value=passthrough_sequence_entry,
        )

    @cached_property
    def format_variable_declaration(
        self,
    ) -> Callable[[str, str, Value, frozenset[enum.Enum]], str]:
        """Callable that formats a new variable declaration."""
        return self.declaration_style.value.formatter

    @cached_property
    def scalar_preamble(self) -> dict[type, tuple[str, ...]]:
        """Per-instance scalar preamble (R needs none)."""
        return {}

    @cached_property
    def scalar_body_preamble(self) -> dict[type, tuple[str, ...]]:
        """Per-instance scalar body preamble (R needs none)."""
        return {}

    @cached_property
    def compute_body_preamble(
        self,
    ) -> Callable[[frozenset[type], Value], tuple[str, ...]]:
        """Compute body-preamble lines from the scalar map."""
        return body_preamble_from_scalars(
            scalar_body_preamble=self.scalar_body_preamble,
            format_lines=tuple,
        )

    @cached_property
    def call_style_config(self) -> CallStyle:
        """Configuration for the chosen call style."""
        config: CallStyle = self.call_style.value
        return config
