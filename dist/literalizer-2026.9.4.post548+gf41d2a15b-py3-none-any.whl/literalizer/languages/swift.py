"""Swift language specification."""

import dataclasses
import datetime
import enum
import functools
import re
from collections.abc import Callable, Mapping, Sequence
from functools import cached_property
from types import MappingProxyType
from typing import ClassVar, assert_never

from beartype import beartype

from literalizer._comments import NestingCommentSuffix
from literalizer._formatters.collection_openers import fixed_open
from literalizer._formatters.format_dates import (
    format_date_iso,
    format_datetime_epoch,
    format_datetime_iso,
    format_time_iso,
)
from literalizer._formatters.format_entries import (
    dict_entry_with_separator,
    format_bytes_base64,
    format_bytes_hex,
    passthrough_sequence_entry,
    passthrough_set_entry,
    variable_declaration_formatter,
    variable_formatter,
)
from literalizer._formatters.format_factories import (
    dict_format_factory,
    sequence_format_factory,
    set_format_factory,
)
from literalizer._formatters.format_floats import (
    format_float_fixed,
    format_float_repr,
    format_float_scientific,
)
from literalizer._formatters.format_integers import (
    I64_MAX,
    I64_MIN,
    format_integer_binary,
    format_integer_hex,
    format_integer_octal,
    format_integer_underscore,
    make_overflow_fallback_formatter,
    raise_for_unrepresentable_int,
)
from literalizer._formatters.format_strings import (
    format_string_backslash_control,
)
from literalizer._formatters.record_strategy import (
    RecordDeclarationField,
    RecordFieldType,
    RecordLiteralField,
    RecordRenderer,
    RecordStrategy,
    build_record_strategy,
    identity_field_identifier_key,
)
from literalizer._formatters.type_inference import record_shape_for_dict
from literalizer._language import (
    NO_CALL_PARAMETER_LIMIT,
    NO_HETEROGENEOUS_BEHAVIOR,
    NON_KEBAB_REF_CASES,
    BareIntegerWidthStrategies,
    CallParameterShadowing,
    CallStyle,
    CommentConfig,
    DateFormatConfig,
    DateFormatEnum,
    DatetimeFormatConfig,
    DatetimeFormatEnum,
    DeclarationStyleConfig,
    DictFormatBuilder,
    DictFormatConfig,
    FloatSpecialsMixin,
    HeterogeneousBehavior,
    IdentifierCase,
    JsonType,
    KeywordCallStyle,
    LanguageCls,
    ModifierCombination,
    NewVariableNameSyntax,
    OrderedMapFormatConfig,
    RenderedRecordLiteral,
    RoundTripCapability,
    SequenceFormatConfig,
    SetFormatConfig,
    StubReturn,
    TrailingCommaConfig,
    VariantMetadata,
    body_preamble_from_scalars,
    date_scalar_preamble,
    default_format_call_variable_assignment,
    default_sequence_binding_declarations,
    default_wrap_calls_with_declarations,
    identity_call_arg,
    identity_call_ref_identifier,
    identity_call_statement,
    identity_call_target,
    identity_constructor_target,
    never_inhibits_consuming_form,
    no_call_binding_body_preamble,
    no_call_binding_file_pragmas,
    no_call_stub,
    no_data_preamble,
    no_format_integer_beyond_i64,
    no_format_integer_widened,
    no_leading_preamble,
    no_type_hint_preamble,
    no_validate_call_arg,
    wrap_combined_in_file_noop,
    wrap_in_file_noop,
)
from literalizer._types import OrderedMap, Scalar, Value
from literalizer.exceptions import (
    TargetScalarCollisionError,
    UnrepresentableInputError,
)

_CONTROL_CHAR_THRESHOLD = 32
_NESTED_TUPLE_RECORD_DEPTH = 2


@beartype
def _reject_date_midnight_collisions(data: Value) -> None:
    """Reject Swift ``Date`` keys that can denote the same instant."""
    match data:
        case dict() | set():
            values = list(data)
            dates = {
                (scalar.year, scalar.month, scalar.day): scalar
                for scalar in values
                if isinstance(scalar, datetime.date)
                and not isinstance(scalar, datetime.datetime)
            }
            for scalar in values:
                if (
                    isinstance(scalar, datetime.datetime)
                    and scalar.time().replace(tzinfo=None) == datetime.time()
                    and (scalar.year, scalar.month, scalar.day) in dates
                ):
                    raise TargetScalarCollisionError(
                        language_name="Swift",
                        first=dates[(scalar.year, scalar.month, scalar.day)],
                        second=scalar,
                        rendered="the same Date instant",
                    )
            children: list[Value] = []
            if isinstance(data, dict):
                children = list(data.values())
            for child in children:
                _reject_date_midnight_collisions(data=child)
        case list():
            for value in data:
                _reject_date_midnight_collisions(data=value)
        case _:
            return


@beartype
def _format_string_escaped(value: str) -> str:
    r"""Format *value* as an escaped Swift string literal."""
    formatted = format_string_backslash_control(
        value=value,
        control_char_fmt="\\u{{{:x}}}",
        escape_delete=False,
    )
    return formatted.replace("\x7f", "\\u{7f}")


@beartype
def _format_string_multiline(value: str) -> str:
    r"""Format *value* as an exact Swift raw multiline string.

    Swift removes the source line breaks immediately after the opening
    delimiter and before the closing delimiter. Keeping the closer at column
    zero also makes its indentation-removal rule a no-op, so nested rendering
    cannot add indentation to the value.
    """
    has_unsafe_control = any(
        (ord(char) < _CONTROL_CHAR_THRESHOLD or char == "\x7f")
        and char not in "\n\t"
        for char in value
    )
    has_trailing_line_whitespace = any(
        len(line) > 0 and line[-1].isspace() for line in value.split(sep="\n")
    )
    if has_unsafe_control or has_trailing_line_whitespace:
        return _format_string_escaped(value=value)

    hashes = "#"
    while f'"""{hashes}' in value or f"\\{hashes}" in value:
        hashes += "#"
    return f'{hashes}"""\n{value}\n"""{hashes}'


@beartype
def _format_date_swift(value: datetime.date) -> str:
    """Format a date as a Swift ``DateComponents`` expression."""
    return (
        "DateComponents("
        "calendar: Calendar(identifier: .gregorian), "
        "timeZone: TimeZone(secondsFromGMT: 0)!, "
        f"year: {value.year}, month: {value.month}, day: {value.day}"
        ").date!"
    )


@beartype
def _format_datetime_swift(value: datetime.datetime) -> str:
    """Format a datetime as a Swift ``DateComponents`` expression."""
    offset = value.utcoffset()
    if offset is None or offset == datetime.timedelta():
        offset = datetime.timedelta()
    offset_seconds = int(offset.total_seconds())
    parts = (
        "DateComponents("
        "calendar: Calendar(identifier: .gregorian), "
        f"timeZone: TimeZone(secondsFromGMT: {offset_seconds})!, "
        f"year: {value.year}, month: {value.month}, day: {value.day}, "
        f"hour: {value.hour}, minute: {value.minute}, second: {value.second}"
    )
    if value.microsecond != 0:
        nanosecond = value.microsecond * 1000
        parts += f", nanosecond: {nanosecond}"
    return parts + ").date!"


@beartype
def _tuple_sequence_entry(original: Value, entry: str) -> str:
    """Format a tuple sequence entry, casting nil to Any? for Swift."""
    if original is None:
        return "nil as Any?"
    return entry


@beartype
def _swift_param(*, name: str, accepts_nil: bool) -> str:
    """Format a single Swift parameter for a stub signature.

    When *accepts_nil* is ``True`` the parameter type is ``Any?`` with
    a ``nil`` default so a caller may pass ``nil``; otherwise it is
    ``Any`` with a ``0`` default.
    """
    type_and_default = "Any = 0"
    if accepts_nil:
        type_and_default = "Any? = nil"
    if name.startswith("_"):
        return f"_ {name}: {type_and_default}"
    return f"{name}: {type_and_default}"


@beartype
def _swift_args_contain_nil(*, args: Sequence[Value]) -> bool:
    """Return ``True`` when any top-level or per-element call argument is
    ``None``.

    Accepts either the flat per-call argument list or a list of
    per-element call argument lists; both shapes are inspected so a
    ``None`` at any call's slot is detected.
    """
    inner: list[Value] = []
    for arg in args:
        match arg:
            case list():
                inner.extend(arg)
            case _:
                inner.append(arg)
    return any(v is None for v in inner)


@beartype
def _swift_call_stub(
    parts: Sequence[str],
    params: Sequence[str],
    _stub_return: StubReturn,
    args: Sequence[Value],
    /,
) -> tuple[str, ...]:
    """Return Swift stub declarations for a call name."""
    accepts_nil = _swift_args_contain_nil(args=args)
    param_list = ", ".join(
        _swift_param(name=p, accepts_nil=accepts_nil) for p in params
    )
    if len(parts) == 1:
        return (
            f"@discardableResult func {parts[0]}({param_list}) -> Any {{ 0 }}",
        )
    root = parts[0]
    method = parts[-1]
    fields = parts[1:-1]
    method_decl = (
        f"@discardableResult func {method}({param_list}) -> Any {{ 0 }}"
    )
    if len(fields) == 0:
        cls = f"_{root}Type"
        return (
            f"class {cls} {{ {method_decl} }}",
            f"let {root} = {cls}()",
        )
    lines: list[str] = []
    inner_cls = f"_{fields[-1]}Type"
    lines.append(f"class {inner_cls} {{ {method_decl} }}")
    prev_cls = inner_cls
    for i in range(len(fields) - 2, -1, -1):
        cls = f"_{fields[i]}Type"
        lines.append(f"class {cls} {{ var {fields[i + 1]} = {prev_cls}() }}")
        prev_cls = cls
    root_cls = f"_{root}Type"
    lines.append(f"class {root_cls} {{ var {fields[0]} = {prev_cls}() }}")
    lines.append(f"let {root} = {root_cls}()")
    return tuple(lines)


@beartype
def _swift_scalar_hint(
    *,
    data: Scalar,
    date_hint: str,
    datetime_hint: str,
) -> str:
    """Derive the Swift annotation for a scalar value."""
    match data:
        case bool():
            hint = "Bool"
        case int():
            hint = "Int"
        case float():
            hint = "Double"
        case str() | bytes():
            hint = "String"
        case datetime.datetime():
            hint = datetime_hint
        case datetime.date():
            hint = date_hint
        case datetime.time():
            hint = "String"
        case None:
            hint = "Any?"
        case _ as unreachable:
            assert_never(unreachable)
    return hint


@beartype
def _swift_collapse(types: list[str]) -> str:
    """Return a single Swift element type or ``Any`` / ``Any?``
    fallback.
    """
    unique = list(dict.fromkeys(types))
    match unique:
        case [single]:
            return single
        case _ if "Any?" in unique:
            return "Any?"
        case _:
            return "Any"


@beartype
def _swift_dict_hint(
    *,
    val_types: list[str],
    is_empty: bool,
    default_dict_value_type: str,
) -> str:
    """Derive a Swift dictionary type annotation."""
    if is_empty:
        return f"[String: {default_dict_value_type}]"
    return f"[String: {_swift_collapse(types=val_types)}]"


@beartype
def _swift_list_hint(
    *,
    elem_types: list[str],
    is_empty: bool,
    sequence_is_tuple: bool,
    default_sequence_element_type: str,
) -> str:
    """Derive a Swift array/tuple type annotation."""
    if is_empty:
        if sequence_is_tuple:
            return "()"
        return f"[{default_sequence_element_type}]"
    if sequence_is_tuple:
        return f"({', '.join(elem_types)})"
    return f"[{_swift_collapse(types=elem_types)}]"


@beartype
def _swift_type_hint(
    *,
    data: Value,
    date_hint: str,
    datetime_hint: str,
    default_set_element_type: str,
    default_sequence_element_type: str,
    default_dict_value_type: str,
    sequence_is_tuple: bool,
) -> str:
    """Derive a Swift type annotation from *data*."""
    recurse = functools.partial(
        _swift_type_hint,
        date_hint=date_hint,
        datetime_hint=datetime_hint,
        default_set_element_type=default_set_element_type,
        default_sequence_element_type=default_sequence_element_type,
        default_dict_value_type=default_dict_value_type,
        sequence_is_tuple=sequence_is_tuple,
    )
    match data:
        case dict():
            hint = _swift_dict_hint(
                val_types=[recurse(data=v) for v in data.values()],
                is_empty=len(data) == 0,
                default_dict_value_type=default_dict_value_type,
            )
        case set():
            hint = f"Set<{default_set_element_type}>"
        case list():
            hint = _swift_list_hint(
                elem_types=[recurse(data=e) for e in data],
                is_empty=len(data) == 0,
                sequence_is_tuple=sequence_is_tuple,
                default_sequence_element_type=default_sequence_element_type,
            )
        case _:
            hint = _swift_scalar_hint(
                data=data,
                date_hint=date_hint,
                datetime_hint=datetime_hint,
            )
    return hint


@beartype
def _has_record_below_nested_list(*, data: Value, list_depth: int) -> bool:
    """Return whether a record dict occurs below two list levels."""
    match data:
        case OrderedMap():
            return any(
                _has_record_below_nested_list(
                    data=value, list_depth=list_depth
                )
                for value in data.values()
            )
        case dict():
            if (
                list_depth >= _NESTED_TUPLE_RECORD_DEPTH
                and record_shape_for_dict(value=data) is not None
            ):
                return True
            return any(
                _has_record_below_nested_list(
                    data=value, list_depth=list_depth
                )
                for value in data.values()
            )
        case list():
            return any(
                _has_record_below_nested_list(
                    data=item, list_depth=list_depth + 1
                )
                for item in data
            )
        case _:
            return False


@beartype
def _format_swift_typed_declaration(
    *,
    name: str,
    value: str,
    data: Value,
    _modifiers: frozenset[enum.Enum],
    keyword: str,
    date_hint: str,
    datetime_hint: str,
    default_set_element_type: str,
    default_sequence_element_type: str,
    default_dict_value_type: str,
    sequence_is_tuple: bool,
) -> str:
    """Format a Swift variable declaration with a specific type."""
    hint = _swift_type_hint(
        data=data,
        date_hint=date_hint,
        datetime_hint=datetime_hint,
        default_set_element_type=default_set_element_type,
        default_sequence_element_type=default_sequence_element_type,
        default_dict_value_type=default_dict_value_type,
        sequence_is_tuple=sequence_is_tuple,
    )
    return f"{keyword} {name}: {hint} = {value}"


# The ``RECORD`` strategy supports only auto ``Record0``/``Record1``/...
# names (no ``record_shape_names``), so the shared renderer always gets
# an empty custom-name mapping.
_SWIFT_NO_RECORD_SHAPE_NAMES: Mapping[frozenset[str], str] = MappingProxyType[
    frozenset[str], str
](
    mapping={},
)
_SWIFT_ARGUMENT_LABELS_REQUIRING_BACKTICKS = frozenset({"`inout`"})


@beartype
def _swift_record_argument_label(identifier: str, /) -> str:
    """Return a valid initializer label for a record field identifier."""
    if identifier in _SWIFT_ARGUMENT_LABELS_REQUIRING_BACKTICKS:
        return identifier
    return identifier.strip("`")


@beartype
def _swift_record_field_identifier(
    key: str, /, *, reserved_identifiers: frozenset[str]
) -> str:
    """Return the Swift ``struct`` member name for a dict *key*.

    Swift property identifiers preserve the dict keys (no case conversion),
    escaping reserved words with backticks in declarations.
    """
    if key in reserved_identifiers:
        return f"`{key}`"
    return key


@beartype
def _swift_record_literal(
    name: str,
    fields: Sequence[RecordLiteralField],
    /,
) -> RenderedRecordLiteral:
    """Render a Swift ``Name(field: value, ...)`` initializer literal as
    structured pieces for the shared compact/multiline layout code.

    A ``struct`` with stored properties and no explicit initializer gets
    a synthesized initializer taking one argument per stored property,
    each argument named for its property in declaration order; the
    shared strategy iterates the shape's keys in document order for both
    the declaration and the literal, so the orders always agree.
    """
    return RenderedRecordLiteral(
        head=f"{name}(",
        entries=tuple(
            f"{_swift_record_argument_label(field.identifier)}: "
            f"{field.formatted}"
            for field in fields
        ),
        closer=")",
        compact_pad="",
    )


@beartype
def _swift_render_record_declaration(
    name: str,
    fields: Sequence[RecordDeclarationField],
    /,
) -> str:
    """Render a Swift ``struct Name { let field: Type; ... }``.

    Stored ``let`` properties are emitted on one line separated by
    ``;``; the compiler synthesizes the initializer the literal calls.
    """
    members = "; ".join(
        f"let {field.identifier}: {field.type_name}" for field in fields
    )
    return f"struct {name} {{ {members} }}"


@beartype
@dataclasses.dataclass(frozen=True, kw_only=True)
class Swift(metaclass=LanguageCls):
    """Swift language specification."""

    reserved_module_identifiers: ClassVar[frozenset[str]] = frozenset()
    immutable_variable_modifiers: ClassVar[frozenset[enum.Enum]] = frozenset()
    wrap_in_file_tolerates_pre_indent = True
    module_name_shares_variable_scope = False
    reserved_variable_identifier_pattern: ClassVar[re.Pattern[str] | None] = (
        None
    )
    reserved_call_parameter_identifiers: ClassVar[frozenset[str]] = frozenset()
    reserved_call_parameter_identifier_pattern: ClassVar[
        re.Pattern[str] | None
    ] = None
    accepts_type_name_call_target = True
    declares_type_name_call_target = True
    dotted_call_root_shares_entrypoint_namespace = True
    reserved_bare_call_target_identifiers: ClassVar[frozenset[str]] = (
        frozenset()
    )
    reserved_call_target_head_identifiers: ClassVar[frozenset[str]] = (
        frozenset()
    )
    call_parameter_shadowing = CallParameterShadowing.ALLOWED
    reserved_call_target_keywords_case_sensitive = True
    module_name_must_start_uppercase = False
    new_variable_name_syntax = NewVariableNameSyntax.ASCII
    max_variable_identifier_length: ClassVar[int | None] = None
    call_target_name_syntax: ClassVar[NewVariableNameSyntax | None] = None
    supports_multiline_dict_layout = True
    pools_map_integer_width = True

    format_integer_widened = no_format_integer_widened
    format_integer_beyond_i64 = no_format_integer_beyond_i64
    format_constructor_target: ClassVar["staticmethod[[str], str]"] = (
        staticmethod(identity_constructor_target)
    )

    @cached_property
    def format_call_variable_declaration(
        self,
    ) -> Callable[[str, str, Value, frozenset[enum.Enum]], str]:
        """Callable that binds a call result to a new variable.

        The literal-binding formatter annotates from the value being
        rendered, which is right for a literal and wrong for a call: the
        binding holds whatever the stub returns, so the type of the
        input is one Swift then refuses to convert to (issue #4537).
        The declaration style's own formatter writes ``let name = ...``
        and lets Swift infer.
        """
        formatter: Callable[[str, str, Value, frozenset[enum.Enum]], str] = (
            self.declaration_style.value.formatter
        )
        return formatter

    format_call_variable_assignment = default_format_call_variable_assignment
    sequence_binding_declarations = default_sequence_binding_declarations
    format_call_binding_body_preamble = no_call_binding_body_preamble
    format_call_binding_file_pragmas = no_call_binding_file_pragmas

    leading_preamble = no_leading_preamble
    extension = ".swift"
    pygments_name = "swift"
    stringifies_nested_collections = False
    supports_special_floats = True
    supports_variable_names = True
    supports_no_variable_wrap_in_file = False
    wraps_data_dependent_preamble_in_body = False
    dict_supports_heterogeneous_values = True
    supports_dotted_calls = True
    has_free_function_calls = True
    reserved_identifiers: ClassVar[frozenset[str]] = frozenset()
    declares_call_parameter_names = True
    reserved_variable_identifiers_case_sensitive: bool = True
    contextual_call_target_identifiers: ClassVar[frozenset[str]] = frozenset(
        {"self"}
    )
    reserved_variable_identifiers: frozenset[str] = frozenset(
        {
            "Any",
            "Self",
            "as",
            "associatedtype",
            "break",
            "case",
            "catch",
            "class",
            "continue",
            "convenience",
            "default",
            "defer",
            "deinit",
            "didSet",
            "do",
            "else",
            "enum",
            "extension",
            "fallthrough",
            "false",
            "fileprivate",
            "final",
            "for",
            "func",
            "get",
            "guard",
            "if",
            "import",
            "in",
            "indirect",
            "infix",
            "init",
            "inout",
            "internal",
            "is",
            "let",
            "mutating",
            "nil",
            "nonisolated",
            "nonmutating",
            "open",
            "operator",
            "optional",
            "override",
            "postfix",
            "precedencegroup",
            "prefix",
            "private",
            "protocol",
            "public",
            "repeat",
            "required",
            "rethrows",
            "return",
            "self",
            "set",
            "some",
            "static",
            "struct",
            "subscript",
            "super",
            "switch",
            "throw",
            "throws",
            "true",
            "try",
            "typealias",
            "unowned",
            "var",
            "weak",
            "where",
            "while",
            "willSet",
        }
    )
    allows_empty_call_parens = True
    supports_dotted_call_stub = True
    dotted_call_stub_requires_unique_parts = True
    call_returns_expression = True
    supports_json_call_result_binding = False
    supports_zero_parameter_calls = True
    max_call_parameters = NO_CALL_PARAMETER_LIMIT
    supports_inline_multiline_dict_args = True
    supports_standalone_comments_in_wrapped_calls = True
    supports_multi_param_call_wrapper_stub = True
    supports_dict_literal_as_free_expression = True
    supports_module_name = False
    supports_empty_dict_key = False
    supports_call_style = True
    supports_default_dict_key_type = True
    supports_default_dict_value_type = True
    supports_default_sequence_element_type = True
    supports_default_set_element_type = True
    supports_default_ordered_map_value_type = False
    json_type_variant_name_suffix: ClassVar[str | None] = None
    supports_non_ascii_string_literals = True
    supports_multiline_string_literals = True
    supports_empty_sibling_sequence_type_hints = True
    uses_resolved_ref_declaration_data = True
    supports_typed_dict_open = False
    language_id: ClassVar[str] = "swift"
    variant_metadata: ClassVar[VariantMetadata] = VariantMetadata(
        round_trip_capabilities=frozenset(
            {
                RoundTripCapability.I64_BOUNDARIES,
                RoundTripCapability.INTERPOLATION_STRINGS,
                RoundTripCapability.CONTROL_STRINGS,
                RoundTripCapability.EMBEDDED_NUL,
            }
        ),
        modifier_sequence_format_overrides={},
        string_literals_escape_null_byte=True,
        supports_ref_elements_in_tuple_strategy=False,
    )
    supports_record_struct_name_prefix = True
    supports_record_shape_names = False
    record_shape_names_emit_declarations = False
    supports_non_string_dict_keys = True
    checks_raw_control_dict_keys_separately = False

    format_call_arg: ClassVar["staticmethod[[Value, str], str]"] = (
        staticmethod(
            identity_call_arg,
        )
    )
    """Callable that rewrites a formatted direct call argument."""

    class DateFormats(DateFormatEnum):
        """Date format options for Swift."""

        _value_: DateFormatConfig

        SWIFT = DateFormatConfig(
            formatter=_format_date_swift,
            preamble_lines=("import Foundation",),
            type_produced=datetime.date,
        )
        ISO = DateFormatConfig(
            formatter=format_date_iso, type_produced=str, preamble_lines=()
        )

    class DatetimeFormats(DatetimeFormatEnum):
        """Datetime format options for Swift."""

        _value_: DatetimeFormatConfig

        SWIFT = DatetimeFormatConfig(
            formatter=_format_datetime_swift,
            preamble_lines=("import Foundation",),
            type_produced=datetime.datetime,
        )
        ISO = DatetimeFormatConfig(
            formatter=format_datetime_iso,
            type_produced=str,
            preamble_lines=(),
        )

        EPOCH = DatetimeFormatConfig(
            formatter=format_datetime_epoch,
            type_produced=int,
            preamble_lines=(),
        )

    class BytesFormats(enum.Enum):
        """Bytes formatting options."""

        _value_: Callable[[bytes], str]

        HEX = enum.member(value=format_bytes_hex)
        BASE64 = enum.member(value=format_bytes_base64)

        def __call__(self, data: bytes, /) -> str:
            """Format bytes."""
            return self._value_(data)

    class SequenceFormats(enum.Enum):
        """Sequence type options for Swift."""

        _value_: Callable[[str], SequenceFormatConfig]

        ARRAY = enum.member(
            value=sequence_format_factory(
                open_template="[",
                close="]",
                supports_heterogeneity=True,
                single_element_trailing_comma=False,
                single_element_template=None,
                supports_trailing_comma=True,
                empty_template="[{type}]()",
                preamble_lines=(),
                format_entry=passthrough_sequence_entry,
                typed_opener_fallback_template=None,
            )
        )
        TUPLE = enum.member(
            value=sequence_format_factory(
                open_template="(",
                close=")",
                supports_heterogeneity=True,
                single_element_trailing_comma=False,
                single_element_template=None,
                supports_trailing_comma=True,
                empty_template=None,
                preamble_lines=(),
                format_entry=_tuple_sequence_entry,
                typed_opener_fallback_template=None,
            )
        )

        def __call__(self, default_type: str) -> SequenceFormatConfig:
            """Create a sequence format config for the given type."""
            return self._value_(default_type)

    class SetFormats(enum.Enum):
        """Set type options for Swift."""

        _value_: Callable[[str], SetFormatConfig]

        SET = enum.member(
            value=set_format_factory(
                open_template="Set<{type}>([",
                close="])",
                empty_template="Set<{type}>()",
                preamble_lines=(),
                set_opener_template="",
                supports_heterogeneity=True,
                supports_trailing_comma=True,
            )
        )

        def __call__(self, default_type: str) -> SetFormatConfig:
            """Create a set format config for the given type."""
            return self._value_(default_type)

    class CommentFormats(enum.Enum):
        """Comment style options."""

        DOUBLE_SLASH = CommentConfig(
            prefix="//",
            suffix="",
        )
        BLOCK = CommentConfig(
            prefix="/*",
            suffix=NestingCommentSuffix(object=" */"),
        )

    class DeclarationStyles(enum.Enum):
        """Declaration style options."""

        LET = DeclarationStyleConfig(
            formatter=variable_declaration_formatter(
                template="let {name} = {value}"
            ),
            supports_redefinition=False,
        )
        VAR = DeclarationStyleConfig(
            formatter=variable_declaration_formatter(
                template="var {name} = {value}"
            ),
            supports_redefinition=True,
        )

    class DictEntryStyles(enum.Enum):
        """Dict entry style options."""

        DEFAULT = enum.auto()

    class DictFormats(enum.Enum):
        """Dict/map format options."""

        _value_: DictFormatBuilder

        DEFAULT = enum.member(
            value=dict_format_factory(
                open_template="[",
                close="]",
                format_entry=dict_entry_with_separator(
                    separator=": ",
                    format_value=passthrough_sequence_entry,
                ),
                empty_template="[{key_type}: {type}]()",
                preamble_lines=(),
                narrowed_open=None,
                supports_trailing_comma=True,
            )
        )

        def __call__(
            self,
            default_type: str,
            *,
            default_key_type: str = "String",
        ) -> DictFormatConfig:
            """Create a dict format config for the given type."""
            return self._value_(
                default_type=default_type,
                default_key_type=default_key_type,
            )

    class EmptyDictKey(enum.Enum):
        """Empty dict key options."""

        ALLOW = enum.auto()

    class FloatFormats(
        FloatSpecialsMixin,
        enum.Enum,
        positive_infinity="Double.infinity",
        negative_infinity="-Double.infinity",
        nan="Double.nan",
    ):
        """Float format options."""

        REPR = enum.member(value=format_float_repr)
        SCIENTIFIC = enum.member(value=format_float_scientific)
        FIXED = enum.member(value=format_float_fixed)

    class IntegerFormats(enum.Enum):
        """Integer format options."""

        DECIMAL = MappingProxyType(
            mapping={
                "NONE": str,
                "UNDERSCORE": format_integer_underscore,
            }
        )
        HEX = MappingProxyType(
            mapping={
                "NONE": format_integer_hex,
                "UNDERSCORE": format_integer_hex,
            }
        )
        OCTAL = MappingProxyType(
            mapping={
                "NONE": format_integer_octal,
                "UNDERSCORE": format_integer_octal,
            }
        )
        BINARY = MappingProxyType(
            mapping={
                "NONE": format_integer_binary,
                "UNDERSCORE": format_integer_binary,
            }
        )

        def get_formatter(
            self,
            numeric_separator: enum.Enum,
        ) -> Callable[[int], str]:
            """Return the integer formatter for the given separator."""
            formatter: Callable[[int], str] = self.value[
                numeric_separator.name
            ]
            return formatter

    class NumericLiteralSuffixes(enum.Enum):
        """Numeric literal suffix options."""

        NONE = enum.auto()

    class NumericSeparators(enum.Enum):
        """Numeric separator options."""

        NONE = enum.auto()
        UNDERSCORE = enum.auto()

    class NumericStyles(enum.Enum):
        """Numeric literal style options."""

        OVERLOADED = enum.auto()

    class StringFormats(enum.Enum):
        """String format options."""

        _value_: Callable[[str], str]

        DOUBLE = enum.member(value=_format_string_escaped)
        MULTILINE = enum.member(value=_format_string_multiline)

        def __call__(self, value: str, /) -> str:
            """Format a string."""
            return self._value_(value)

    class TrailingCommas(enum.Enum):
        """Trailing comma options."""

        YES = TrailingCommaConfig(multiline_trailing_comma=True)
        NO = TrailingCommaConfig(multiline_trailing_comma=False)

    date_formats = DateFormats
    datetime_formats = DatetimeFormats
    bytes_formats = BytesFormats
    sequence_formats = SequenceFormats
    set_formats = SetFormats
    comment_formats = CommentFormats

    class VariableTypeHints(enum.Enum):
        """Variable type hint options."""

        NEVER = enum.auto()
        ALWAYS = enum.auto()
        SAFE = enum.auto()

        def formatter(
            self,
            *,
            auto_formatter: Callable[
                [str, str, Value, frozenset[enum.Enum]], str
            ],
            keyword: str,
            date_hint: str,
            datetime_hint: str,
            default_set_element_type: str,
            default_sequence_element_type: str,
            default_dict_value_type: str,
            sequence_is_tuple: bool,
        ) -> Callable[[str, str, Value, frozenset[enum.Enum]], str]:
            """Return the variable declaration formatter."""
            if self in {type(self).NEVER, type(self).SAFE}:

                def _inferred_formatter(
                    name: str,
                    value: str,
                    data: Value,
                    modifiers: frozenset[enum.Enum],
                ) -> str:
                    """Annotate only values Swift cannot infer safely."""
                    hint = _swift_type_hint(
                        data=data,
                        date_hint=date_hint,
                        datetime_hint=datetime_hint,
                        default_set_element_type=default_set_element_type,
                        default_sequence_element_type=(
                            default_sequence_element_type
                        ),
                        default_dict_value_type=default_dict_value_type,
                        sequence_is_tuple=sequence_is_tuple,
                    )
                    needs_context = data is None or (
                        bool(data)
                        and (
                            (
                                isinstance(data, OrderedMap)
                                and len({type(item) for item in data.values()})
                                > 1
                            )
                            or "Record0(" not in value
                            or hint == "[Any]"
                        )
                    )
                    if isinstance(data, dict) and any(
                        not isinstance(key, str) for key in data
                    ):
                        hint = "Any"
                    if value == "()":
                        hint = "Any"
                        needs_context = True
                    if "Any" in hint and needs_context:
                        return f"{keyword} {name}: {hint} = {value}"
                    return auto_formatter(name, value, data, modifiers)

                return _inferred_formatter

            def _typed_formatter(
                name: str,
                value: str,
                data: Value,
                modifiers: frozenset[enum.Enum],
            ) -> str:
                """Adapt :func:`_format_swift_typed_declaration` to the
                positional formatter interface.
                """
                return _format_swift_typed_declaration(
                    name=name,
                    value=value,
                    data=data,
                    _modifiers=modifiers,
                    keyword=keyword,
                    date_hint=date_hint,
                    datetime_hint=datetime_hint,
                    default_set_element_type=default_set_element_type,
                    default_sequence_element_type=(
                        default_sequence_element_type
                    ),
                    default_dict_value_type=default_dict_value_type,
                    sequence_is_tuple=sequence_is_tuple,
                )

            return _typed_formatter

    variable_type_hints_formats = VariableTypeHints
    declaration_styles = DeclarationStyles
    dict_entry_styles = DictEntryStyles
    dict_formats = DictFormats
    empty_dict_keys = EmptyDictKey
    float_formats = FloatFormats
    integer_formats = IntegerFormats
    integer_width_strategies = BareIntegerWidthStrategies
    numeric_literal_suffixes = NumericLiteralSuffixes
    numeric_separators = NumericSeparators
    numeric_styles = NumericStyles
    string_formats = StringFormats
    trailing_commas = TrailingCommas

    class StatementTerminatorStyles(enum.Enum):
        """Statement terminator options."""

        SEMICOLON = enum.auto()

    statement_terminator_styles = StatementTerminatorStyles

    class CallStyles(enum.Enum):
        """Swift call style options."""

        KEYWORD = KeywordCallStyle(separator=": ")

    call_styles = CallStyles

    class Modifiers(enum.Enum):
        """C++/Java/C#-style declaration modifiers: this language has none."""

    modifiers = Modifiers

    class HeterogeneousStrategies(enum.Enum):
        """Heterogeneous-scalar strategy options.

        Swift represents heterogeneous collections with ``Any`` by
        default (``ERROR``).  ``RECORD`` instead renders each
        record-shaped dict (non-empty, string-keyed) as a generated
        ``struct`` declared in the preamble plus a matching
        ``Record0(field: value, ...)`` initializer literal, so a
        record-shaped dict that mixes scalars with a container is
        representable as a typed value even though ``Dictionary``
        requires a homogeneous value type.
        """

        ERROR = enum.auto()
        RECORD = enum.auto()

    heterogeneous_strategies = HeterogeneousStrategies

    class JsonTypes(JsonType):
        """Empty: this language has no JSON value-type variants."""

    json_types = JsonTypes

    class BoolFormats(enum.Enum):
        """Empty: this language has no alternative boolean formats."""

    bool_formats = BoolFormats

    class VersionFormats(enum.Enum):
        """Version options for Swift."""

        V5_9 = enum.auto()

    version_formats = VersionFormats

    modifier_combinations: ClassVar[tuple[ModifierCombination, ...]] = ()
    identifier_cases: ClassVar[tuple[IdentifierCase, ...]] = (
        IdentifierCase.CAMEL,
        IdentifierCase.PASCAL,
        IdentifierCase.UPPER_SNAKE,
    )
    supported_ref_cases: ClassVar[frozenset[IdentifierCase]] = (
        NON_KEBAB_REF_CASES
    )

    def validate_spec_for_data(self, data: Value) -> None:
        """Reject target collisions and unsupported tuple record
        fields.
        """
        _reject_date_midnight_collisions(data=data)
        cls = type(self.heterogeneous_strategy)
        if (
            self.heterogeneous_strategy is cls.RECORD
            and self.sequence_format is type(self.sequence_format).TUPLE
            and _has_record_below_nested_list(data=data, list_depth=0)
        ):
            msg = (
                "Swift RECORD tuple fields cannot declare generated record "
                "types nested below multiple tuple levels"
            )
            raise UnrepresentableInputError(msg)

    @cached_property
    def validate_call_arg(self) -> Callable[[Value], None]:
        """Return call-argument validation for this language."""
        return no_validate_call_arg

    @cached_property
    def format_call_statement(self) -> Callable[[str], str]:
        """Return call-statement formatting for this language."""
        return identity_call_statement

    wrap_calls_with_declarations = default_wrap_calls_with_declarations

    @staticmethod
    def wrap_in_file(
        content: str,
        variable_name: str,
        body_preamble: tuple[str, ...],
    ) -> str:
        """Wrap code in a valid file (no-op)."""
        return wrap_in_file_noop(
            content=content,
            variable_name=variable_name,
            body_preamble=body_preamble,
        )

    @staticmethod
    def wrap_combined_in_file(
        declaration: str,
        assignment: str,
        variable_name: str,
        body_preamble: tuple[str, ...],
    ) -> str:
        """Wrap declaration and assignment in a valid file (no-op)."""
        return wrap_combined_in_file_noop(
            declaration=declaration,
            assignment=assignment,
            variable_name=variable_name,
            body_preamble=body_preamble,
        )

    date_format: DateFormats = DateFormats.SWIFT
    datetime_format: DatetimeFormats = DatetimeFormats.SWIFT
    bytes_format: BytesFormats = BytesFormats.HEX
    sequence_format: SequenceFormats = SequenceFormats.ARRAY
    set_format: SetFormats = SetFormats.SET
    default_set_element_type: str = "AnyHashable"
    default_sequence_element_type: str = "Any"
    default_dict_key_type: str = "String"
    default_dict_value_type: str = "Any"
    variable_type_hints: VariableTypeHints = VariableTypeHints.NEVER
    comment_format: CommentFormats = CommentFormats.DOUBLE_SLASH
    declaration_style: DeclarationStyles = DeclarationStyles.LET
    dict_entry_style: DictEntryStyles = DictEntryStyles.DEFAULT
    dict_format: DictFormats = DictFormats.DEFAULT
    float_format: FloatFormats = FloatFormats.REPR
    integer_format: IntegerFormats = IntegerFormats.DECIMAL
    integer_width_strategy: BareIntegerWidthStrategies = (
        BareIntegerWidthStrategies.BARE
    )
    numeric_literal_suffix: NumericLiteralSuffixes = (
        NumericLiteralSuffixes.NONE
    )
    numeric_separator: NumericSeparators = NumericSeparators.NONE
    numeric_style: NumericStyles = NumericStyles.OVERLOADED
    string_format: StringFormats = StringFormats.DOUBLE
    trailing_comma: TrailingCommas = TrailingCommas.YES
    statement_terminator_style: StatementTerminatorStyles = (
        StatementTerminatorStyles.SEMICOLON
    )
    call_style: CallStyles = CallStyles.KEYWORD
    heterogeneous_strategy: HeterogeneousStrategies = (
        HeterogeneousStrategies.ERROR
    )
    record_struct_name_prefix: str = "Record"
    # Keep in sync with the `-swift-version` flag passed to the Swift
    # linter in `.github/workflows/lint.yml` (which only accepts the
    # major language mode, so `V5_9` maps to `-swift-version 5`).
    language_version: VersionFormats = VersionFormats.V5_9
    indent: str = "    "

    null_literal: ClassVar[str] = "nil"
    true_literal: ClassVar[str] = "true"
    false_literal: ClassVar[str] = "false"
    indent_closing_delimiter: ClassVar[bool] = False
    element_separator: ClassVar[str] = ", "
    skip_null_dict_values: ClassVar[bool] = False
    supports_collection_comments: ClassVar[bool] = True
    supports_scalar_before_comments: ClassVar[bool] = False
    supports_scalar_inline_comments: ClassVar[bool] = True
    statement_terminator: ClassVar[str] = ";"
    static_preamble: ClassVar[Sequence[str]] = ()
    static_body_preamble: ClassVar[Sequence[str]] = ()
    special_float_preamble: ClassVar[tuple[str, ...]] = ()

    @cached_property
    def format_string(self) -> Callable[[str], str]:
        """Format a string value as a quoted literal."""
        return self.string_format

    @cached_property
    def format_set_entry(self) -> Callable[[Value, str], str]:
        """Format a set entry."""
        return passthrough_set_entry

    @cached_property
    def format_variable_assignment(self) -> Callable[[str, str, Value], str]:
        """Format an assignment to an existing variable."""
        return variable_formatter(template="{name} = {value}")

    @cached_property
    def _swift_date_hint(self) -> str:
        """Swift type name for the chosen :class:`datetime.date`
        format.
        """
        if self.date_format.value.type_produced is str:
            return "String"
        return "Date"

    @cached_property
    def _swift_datetime_hint(self) -> str:
        """Swift type name for the chosen :class:`datetime.datetime`
        format.
        """
        produced = self.datetime_format.value.type_produced
        if produced is int:
            return "Int"
        if produced is str:
            return "String"
        return "Date"

    def _swift_record_field_type(self, request: RecordFieldType, /) -> str:
        """Return the Swift ``struct`` field type for a record field,
        derived structurally from the raw value.

        A field whose value is itself a nested record-shaped dict uses
        that record's generated name.  A field whose value is a list
        whose every element is a record-shaped dict of one shared shape
        is typed ``[RecordN]`` to match the element type Swift infers
        from the homogeneous array of ``RecordN`` literals.  Every other
        value is typed by the same :func:`_swift_type_hint` machinery
        the typed variable declaration uses.  A record-eligible dict
        with no ``record_name`` was widened out of record inference
        because its nested sibling maps cannot share one shape; type it
        as ``[String: Any?]`` so the uniform enclosing record survives
        (#2916) even when one sibling contains a null.  Using plain
        ``Any`` would make Swift warn while coercing the inferred
        optional dictionary values.  Other dict and set fields fall
        through to the shared resolver.
        """
        if request.record_name is not None:
            return request.record_name
        if request.element_record_name is not None:
            return f"[{request.element_record_name}]"
        if (
            isinstance(request.value, dict)
            and not isinstance(request.value, OrderedMap)
            and record_shape_for_dict(value=request.value) is not None
        ):
            return "[String: Any?]"
        return _swift_type_hint(
            data=request.value,
            date_hint=self._swift_date_hint,
            datetime_hint=self._swift_datetime_hint,
            default_set_element_type=self.default_set_element_type,
            default_sequence_element_type=self.default_sequence_element_type,
            default_dict_value_type=self.default_dict_value_type,
            sequence_is_tuple=(
                self.sequence_format is type(self.sequence_format).TUPLE
            ),
        )

    @cached_property
    def _record_renderer(self) -> RecordRenderer:
        """Swift syntax hooks for the ``RECORD`` strategy."""
        return RecordRenderer(
            name_prefix=self.record_struct_name_prefix,
            record_shape_names=_SWIFT_NO_RECORD_SHAPE_NAMES,
            field_identifier=functools.partial(
                _swift_record_field_identifier,
                reserved_identifiers=self.reserved_variable_identifiers,
            ),
            field_identifier_key=identity_field_identifier_key,
            field_type=self._swift_record_field_type,
            render_declaration=_swift_render_record_declaration,
            render_literal=_swift_record_literal,
            field_type_names_nested_records=False,
            suppress_custom_name_declarations=False,
        )

    @cached_property
    def _record_strategy(self) -> RecordStrategy:
        """Resolve the active strategy to its behavior + preamble."""
        cls = type(self.heterogeneous_strategy)
        if self.heterogeneous_strategy is cls.RECORD:
            return build_record_strategy(
                renderer=self._record_renderer,
                split_conflicting_field_types=True,
                widen_unrecordizable_nested_sibling_maps=True,
                derecordized_map_open=None,
            )
        return RecordStrategy(
            behavior=NO_HETEROGENEOUS_BEHAVIOR,
            preamble=no_data_preamble,
            record_name_for_value=None,
        )

    @cached_property
    def data_dependent_preamble(self) -> Callable[[Value], tuple[str, ...]]:
        """Return data-dependent preamble lines.

        Under ``HeterogeneousStrategies.RECORD`` this emits one
        ``struct`` declaration per record shape present in the data;
        otherwise no data-dependent lines.
        """
        return self._record_strategy.preamble

    @cached_property
    def heterogeneous_behavior(self) -> HeterogeneousBehavior:
        """Return the behavior for the chosen heterogeneous strategy."""
        return self._record_strategy.behavior

    @cached_property
    def call_data_dependent_preamble(
        self,
    ) -> Callable[[Value], tuple[str, ...]]:
        """Return data-dependent preamble lines for call rendering."""
        return self.data_dependent_preamble

    @cached_property
    def type_hint_collection_preamble_lines(
        self,
    ) -> Callable[[frozenset[type]], tuple[str, ...]]:
        """Return preamble lines for empty-collection type hints."""
        return no_type_hint_preamble

    @cached_property
    def format_call_stub(
        self,
    ) -> Callable[
        [Sequence[str], Sequence[str], StubReturn, Sequence[Value]],
        tuple[str, ...],
    ]:
        """Return stub declarations for a call expression."""
        return _swift_call_stub

    @cached_property
    def format_call_preamble_stub(
        self,
    ) -> Callable[
        [Sequence[str], Sequence[str], StubReturn, Sequence[Value]],
        tuple[str, ...],
    ]:
        """Return file-scope stubs for a call expression."""
        return no_call_stub

    @cached_property
    def format_call_target(self) -> Callable[[Sequence[str]], str]:
        """Rewrite a dotted call target into the language's call
        syntax.
        """
        return identity_call_target

    @cached_property
    def format_call_ref_identifier(
        self,
    ) -> Callable[[str, Value | None], str]:
        """Rewrite a ``{"$ref": "name"}`` identifier into the
        language's call expression syntax.
        """
        return identity_call_ref_identifier

    @cached_property
    def format_call_arg_ref_identifier(
        self,
    ) -> Callable[[str, Value | None], str]:
        """Rewrite a ``{"$ref": "name"}`` identifier in a call-argument
        context.

        Delegates to :attr:`format_call_ref_identifier`.  Override this to
        allow call-argument ``$ref`` values that would otherwise be rejected.
        """
        return self.format_call_ref_identifier

    @cached_property
    def format_call_arg_ref_identifier_consumable(
        self,
    ) -> Callable[[str, Value | None], str]:
        """Format a ``$ref`` the caller authorized as consumable.

        Delegates to :attr:`format_call_arg_ref_identifier`.  Override
        this to opt into a consuming form (e.g. C++ ``std::move``).
        """
        return self.format_call_arg_ref_identifier

    @cached_property
    def consumable_ref_value_inhibits_consuming_form(
        self,
    ) -> Callable[[Value], bool]:
        """Predicate deciding whether a ref's underlying value type
        inhibits the consume form.

        Delegates to :data:`never_inhibits_consuming_form`.  Languages
        whose consume operator rejects certain value types (notably
        the Mojo ``^`` on register-trivial scalars) override this.
        """
        return never_inhibits_consuming_form

    scalar_body_preamble: ClassVar[dict[type, tuple[str, ...]]] = {}

    @cached_property
    def sequence_format_config(self) -> SequenceFormatConfig:
        """Configuration for the chosen sequence format."""
        return self.sequence_format(
            default_type=self.default_sequence_element_type,
        )

    @cached_property
    def set_format_config(self) -> SetFormatConfig:
        """Configuration for the chosen set format."""
        return self.set_format(default_type=self.default_set_element_type)

    @cached_property
    def sequence_open(self) -> Callable[[list[Value]], str]:
        """Callable that returns the opening delimiter for a sequence."""
        return self.sequence_format_config.sequence_open

    @cached_property
    def dict_format_config(self) -> DictFormatConfig:
        """Configuration for dict formatting."""
        return self.dict_format(
            default_type=self.default_dict_value_type,
            default_key_type=self.default_dict_key_type,
        )

    @cached_property
    def trailing_comma_config(self) -> TrailingCommaConfig:
        """Configuration for trailing-comma behavior."""
        return self.trailing_comma.value

    @cached_property
    def format_bytes(self) -> Callable[[bytes], str]:
        """Callable that formats a bytes value as a string literal."""
        return self.bytes_format

    @cached_property
    def format_date(self) -> Callable[[datetime.date], str]:
        """Callable that formats a date as a string literal."""
        return self.date_format

    @cached_property
    def format_datetime(self) -> Callable[[datetime.datetime], str]:
        """Callable that formats a datetime as a string literal."""
        return self.datetime_format

    @cached_property
    def format_time(self) -> Callable[[datetime.time], str]:
        """Callable that formats a time as a string literal."""
        return format_time_iso

    @cached_property
    def format_float(self) -> Callable[[float], str]:
        """Callable that formats a float value as a literal."""
        return self.float_format

    @cached_property
    def format_integer(self) -> Callable[[int], str]:
        """Callable that formats an int value as a literal."""
        return make_overflow_fallback_formatter(
            base=self.integer_format.get_formatter(
                numeric_separator=self.numeric_separator,
            ),
            fallback=raise_for_unrepresentable_int(language_name="Swift"),
            min_value=I64_MIN,
            max_value=I64_MAX,
        )

    @cached_property
    def format_sequence_entry(self) -> Callable[[Value, str], str]:
        """Callable that formats a sequence entry."""
        return self.sequence_format_config.format_entry

    @cached_property
    def comment_config(self) -> CommentConfig:
        """Configuration for the language's comment syntax."""
        return self.comment_format.value

    @cached_property
    def ordered_map_format_config(self) -> OrderedMapFormatConfig:
        """Configuration for ordered-map formatting."""
        return OrderedMapFormatConfig(
            ordered_map_open=fixed_open(open_str="["),
            close="]",
            preamble_lines=(),
        )

    @cached_property
    def format_ordered_map_entry(self) -> Callable[[str, Value, str], str]:
        """Callable that formats one ordered-map entry."""
        return dict_entry_with_separator(
            separator=": ",
            format_value=passthrough_sequence_entry,
        )

    @cached_property
    def format_variable_declaration(
        self,
    ) -> Callable[[str, str, Value, frozenset[enum.Enum]], str]:
        """Callable that formats a new variable declaration."""
        return self.variable_type_hints.formatter(
            auto_formatter=self.declaration_style.value.formatter,
            keyword=self.declaration_style.name.lower(),
            date_hint=self._swift_date_hint,
            datetime_hint=self._swift_datetime_hint,
            default_set_element_type=self.default_set_element_type,
            default_sequence_element_type=self.default_sequence_element_type,
            default_dict_value_type=self.default_dict_value_type,
            sequence_is_tuple=(
                self.sequence_format is type(self.sequence_format).TUPLE
            ),
        )

    @cached_property
    def scalar_preamble(self) -> dict[type, tuple[str, ...]]:
        """Per-instance scalar preamble computed from date/datetime format."""
        return date_scalar_preamble(
            date_format=self.date_format,
            datetime_format=self.datetime_format,
            extra=None,
        )

    @cached_property
    def compute_body_preamble(
        self,
    ) -> Callable[[frozenset[type], Value], tuple[str, ...]]:
        """Compute body-preamble lines from the scalar map."""
        return body_preamble_from_scalars(
            scalar_body_preamble=self.scalar_body_preamble,
            format_lines=tuple,
        )

    @cached_property
    def call_style_config(self) -> CallStyle:
        """Configuration for the chosen call style."""
        return self.call_style.value
