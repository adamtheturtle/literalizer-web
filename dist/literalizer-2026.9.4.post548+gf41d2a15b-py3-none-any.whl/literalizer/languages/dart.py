"""Dart language specification."""

import dataclasses
import datetime
import enum
import functools
import re
import textwrap
from collections.abc import Callable, Sequence
from functools import cached_property
from typing import ClassVar, assert_never

from beartype import beartype

from literalizer._formatters.collection_openers import (
    TypedOpenerConfig,
    TypeOpeners,
    fixed_open,
    typed_collection_open,
    typed_dict_open,
)
from literalizer._formatters.format_dates import (
    format_date_iso,
    format_datetime_epoch,
    format_datetime_iso,
    format_time_iso,
)
from literalizer._formatters.format_entries import (
    dict_entry_with_separator,
    format_bytes_base64,
    format_bytes_hex,
    passthrough_sequence_entry,
    passthrough_set_entry,
    variable_declaration_formatter,
    variable_formatter,
)
from literalizer._formatters.format_factories import set_format_factory
from literalizer._formatters.format_floats import (
    format_float_fixed,
    format_float_repr,
    format_float_scientific,
)
from literalizer._formatters.format_integers import (
    I64_MAX,
    I64_MIN,
    format_integer_hex,
    make_overflow_fallback_formatter,
)
from literalizer._formatters.format_strings import (
    bidi_escape_replacements,
    make_backslash_string_formatter,
)
from literalizer._formatters.type_inference import (
    MixedNumeric,
    infer_element_type,
)
from literalizer._language import (
    NO_CALL_PARAMETER_LIMIT,
    NO_HETEROGENEOUS_BEHAVIOR,
    NON_KEBAB_REF_CASES,
    BareIntegerWidthStrategies,
    CallParameterShadowing,
    CallStyle,
    CommentConfig,
    DateFormatConfig,
    DateFormatEnum,
    DatetimeFormatConfig,
    DatetimeFormatEnum,
    DeclarationStyleConfig,
    DictFormatConfig,
    FloatSpecialsMixin,
    HeterogeneousBehavior,
    IdentifierCase,
    JsonType,
    KeywordCallStyle,
    LanguageCls,
    ModifierCombination,
    NewVariableNameSyntax,
    OrderedMapFormatConfig,
    RoundTripCapability,
    SequenceFormatConfig,
    SetFormatConfig,
    StubReturn,
    TrailingCommaConfig,
    VariantMetadata,
    body_preamble_from_scalars,
    default_format_call_variable_assignment,
    default_format_call_variable_declaration,
    default_sequence_binding_declarations,
    default_wrap_calls_with_declarations,
    identity_call_arg,
    identity_call_ref_identifier,
    identity_call_statement,
    identity_call_target,
    identity_constructor_target,
    never_inhibits_consuming_form,
    no_call_binding_body_preamble,
    no_call_binding_file_pragmas,
    no_call_stub,
    no_data_preamble,
    no_format_integer_widened,
    no_leading_preamble,
    no_type_hint_preamble,
    value_contains,
    wrap_in_file_noop,
)
from literalizer._types import Scalar, Value
from literalizer.exceptions import (
    IncompatibleFormatsError,
    UnrepresentableIntegerError,
    WrapCombinedInFileNotSupportedError,
)


@beartype
def _format_date_dart(value: datetime.date) -> str:
    """Format a date as a deterministic UTC ``DateTime``."""
    return f"DateTime.utc({value.year}, {value.month}, {value.day})"


@beartype
def _format_datetime_dart(value: datetime.datetime) -> str:
    """Format a datetime without consulting the runtime time zone."""
    if value.utcoffset() is not None:
        return f'DateTime.parse("{value.isoformat()}")'
    args = (
        f"{value.year}, {value.month}, {value.day}, {value.hour}, "
        f"{value.minute}, {value.second}"
    )
    if value.microsecond != 0:
        milliseconds, microseconds = divmod(value.microsecond, 1000)
        args += f", {milliseconds}, {microseconds}"
    return f"DateTime.utc({args})"


# Dart interpolates ``$`` in both single- and double-quoted strings.
_BIDI_REPLACEMENTS = bidi_escape_replacements(template="\\u{:04X}")
_format_string_single = make_backslash_string_formatter(
    quote_char="'",
    extra_replacements=[
        ("$", "\\$"),
        ("\0", r"\x00"),
        *_BIDI_REPLACEMENTS,
    ],
)
_format_string_double = make_backslash_string_formatter(
    quote_char='"',
    extra_replacements=[
        ("$", "\\$"),
        ("\0", r"\x00"),
        *_BIDI_REPLACEMENTS,
    ],
)
_TRAILING_LINE_WHITESPACE = re.compile(pattern=r"[ \t]+(?=\n)")

# A Dart named parameter cannot be private, so a leading-underscore
# name has no valid named-argument form (issue #3916).
_DART_PRIVATE_NAME = re.compile(pattern=r"_.*")


@beartype
def _escape_trailing_whitespace(match: re.Match[str]) -> str:
    r"""Return one ``\x20`` escape per character of the whitespace run
    *match*.
    """
    return r"\x20" * len(match[0])


@beartype
def _format_string_multiline(value: str) -> str:
    r"""Format *value* as an exact Dart triple-quoted string."""
    first_line, first_newline, _ = value.partition("\n")
    escape_first_newline = (
        bool(first_newline) and first_line.strip(" \t") == ""
    )
    escaped = (
        value.replace("\\", "\\\\")
        .replace("\0", "\\x00")
        .replace("\r", "\\r")
        .replace("\t", "\\t")
        .replace("'", "\\'")
        .replace("$", "\\$")
    )
    for character, escape in _BIDI_REPLACEMENTS:
        escaped = escaped.replace(character, escape)
    escaped = _TRAILING_LINE_WHITESPACE.sub(
        repl=_escape_trailing_whitespace,
        string=escaped,
    )
    # Dart discards a whitespace-only physical line immediately after
    # the opening triple quote, so spell its newline as an escape.
    if escape_first_newline:
        escaped_first_line, _, escaped_rest = escaped.partition("\n")
        escaped = escaped_first_line + r"\n" + escaped_rest
    return f"'''{escaped}'''"


@beartype
def _format_dart_bigint_literal(value: int) -> str:
    """Format a value outside signed 64-bit range as a Dart
    ``BigInt.parse`` expression.

    Dart's compile-time integer literals are limited to signed 64-bit;
    ``BigInt.parse("…")`` yields an arbitrary-precision integer at
    runtime.
    """
    return f'BigInt.parse("{value}")'


@beartype
def _dart_integer_is_exact_double(value: int) -> bool:
    """Return whether Dart can use *value* in a ``double`` context."""
    try:
        return int(float(value)) == value
    except OverflowError:
        return False


@beartype
def _validate_dart_mixed_numeric_data(
    *,
    data: Value,
    sequence_is_tuple: bool,
) -> None:
    """Reject integers that cannot inhabit an inferred ``double``
    container.
    """
    items: list[Value]
    if isinstance(data, dict):
        items = list(data.values())
    elif isinstance(data, list) and not sequence_is_tuple:
        items = list(data)
    else:
        items = []

    if len(items) > 0 and infer_element_type(items=items) is MixedNumeric:
        for item in items:
            if (
                isinstance(item, int)
                and not isinstance(item, bool)
                and not _dart_integer_is_exact_double(value=item)
            ):
                msg = (
                    f"Dart cannot represent integer {item} in a double-typed "
                    "container without loss of precision."
                )
                raise UnrepresentableIntegerError(msg)

    if isinstance(data, dict):
        for child in data.values():
            _validate_dart_mixed_numeric_data(
                data=child,
                sequence_is_tuple=sequence_is_tuple,
            )
    elif isinstance(data, (list, set)):
        for child in data:
            _validate_dart_mixed_numeric_data(
                data=child,
                sequence_is_tuple=sequence_is_tuple,
            )


@beartype
def _dart_scalar_hint(
    *,
    data: Scalar,
    date_hint: str,
    datetime_hint: str,
) -> str:
    """Derive the Dart annotation for a scalar value."""
    match data:
        case bool():
            hint = "bool"
        case int():
            hint = "int"
        case float():
            hint = "double"
        case str() | bytes() | datetime.time():
            hint = "String"
        case datetime.datetime():
            hint = datetime_hint
        case datetime.date():
            hint = date_hint
        case None:
            hint = "Null"
        case _ as unreachable:
            assert_never(unreachable)
    return hint


@beartype
def _dart_unique_or_dynamic(types: list[str]) -> str:
    """Return the sole element of *types* or ``dynamic`` if
    heterogeneous.
    """
    unique = list(dict.fromkeys(types))
    match unique:
        case [single]:
            return single
        case _:
            return "dynamic"


@beartype
def _dart_set_hint(
    *,
    elem_types: list[str],
    is_empty: bool,
    default_set_element_type: str,
) -> str:
    """Derive a Dart Set type annotation."""
    if is_empty:
        return f"Set<{default_set_element_type}>"
    return f"Set<{_dart_unique_or_dynamic(types=elem_types)}>"


@beartype
def _dart_list_hint(
    *,
    elem_types: list[str],
    is_empty: bool,
    sequence_is_tuple: bool,
) -> str:
    """Derive a Dart record type annotation.

    A record's arity is part of its type, so it is built from the
    element hints rather than read off the opener the way the other
    containers are.
    """
    del sequence_is_tuple
    if is_empty:
        return "()"
    return f"({', '.join(elem_types)},)"


@beartype
@dataclasses.dataclass(frozen=True, kw_only=True)
class _DartHintOpeners:
    """The openers a declared type annotation is read back from."""

    dict_open: Callable[[dict[Scalar, Value]], str]
    sequence_open: Callable[[list[Value]], str]


@beartype
def _dart_opener_hint(
    *,
    prefix: str,
    opener: str,
    delimiter: str,
    default_arguments: str,
) -> str:
    """Turn a rendered opener into the type it constructs.

    The declared type and the literal's own type arguments have to be
    one inference or the assignment does not type-check, so the type is
    read back off the opener the renderer picked rather than derived a
    second time (issue #3935).  An opener with no type arguments -- the
    fallback for a value the renderer could not narrow -- names the
    language's default ones.
    """
    arguments = opener.removesuffix(delimiter)
    resolved_arguments = arguments
    if resolved_arguments == "":
        resolved_arguments = f"<{default_arguments}>"
    return f"{prefix}{resolved_arguments}"


@beartype
def _dart_type_hint(
    *,
    data: Value,
    date_hint: str,
    datetime_hint: str,
    default_set_element_type: str,
    default_dict_key_type: str,
    default_dict_value_type: str,
    sequence_is_tuple: bool,
    openers: _DartHintOpeners,
) -> str:
    """Derive a Dart type annotation from *data*."""
    recurse = functools.partial(
        _dart_type_hint,
        date_hint=date_hint,
        datetime_hint=datetime_hint,
        default_set_element_type=default_set_element_type,
        default_dict_key_type=default_dict_key_type,
        default_dict_value_type=default_dict_value_type,
        sequence_is_tuple=sequence_is_tuple,
        openers=openers,
    )
    match data:
        case dict():
            hint = _dart_opener_hint(
                prefix="Map",
                opener=openers.dict_open(data),
                delimiter="{",
                default_arguments=(
                    f"{default_dict_key_type}, {default_dict_value_type}"
                ),
            )
        case set():
            hint = _dart_set_hint(
                elem_types=sorted({recurse(data=e) for e in data}),
                is_empty=len(data) == 0,
                default_set_element_type=default_set_element_type,
            )
        case list() if sequence_is_tuple:
            hint = _dart_list_hint(
                elem_types=[recurse(data=e) for e in data],
                is_empty=len(data) == 0,
                sequence_is_tuple=sequence_is_tuple,
            )
        case list():
            hint = _dart_opener_hint(
                prefix="List",
                opener=openers.sequence_open(data),
                delimiter="[",
                default_arguments="dynamic",
            )
        case _:
            hint = _dart_scalar_hint(
                data=data,
                date_hint=date_hint,
                datetime_hint=datetime_hint,
            )
    return hint


@beartype
def _format_dart_typed_declaration(
    *,
    name: str,
    value: str,
    data: Value,
    _modifiers: frozenset[enum.Enum],
    keyword: str,
    date_hint: str,
    datetime_hint: str,
    default_set_element_type: str,
    default_dict_key_type: str,
    default_dict_value_type: str,
    sequence_is_tuple: bool,
    openers: _DartHintOpeners,
) -> str:
    """Format a Dart variable declaration with an explicit type."""
    hint = _dart_type_hint(
        data=data,
        date_hint=date_hint,
        datetime_hint=datetime_hint,
        default_set_element_type=default_set_element_type,
        default_dict_key_type=default_dict_key_type,
        default_dict_value_type=default_dict_value_type,
        sequence_is_tuple=sequence_is_tuple,
        openers=openers,
    )
    return f"{keyword}{hint} {name} = {value};"


@beartype
def _dart_call_stub(
    parts: Sequence[str],
    params: Sequence[str],
    _stub_return: StubReturn,
    _args: Sequence[Value],
    /,
) -> tuple[str, ...]:
    """Return Dart stub declarations for a call name."""
    # Named parameters can't start with '_' in Dart. When all names
    # start with '_' (e.g. transform stubs like ["_value"]), use required
    # positional syntax so callers can pass the value positionally.
    # An empty named-parameter block {} is invalid Dart, so use positional
    # (empty) syntax when there are no parameters at all.
    match params:
        case []:
            param_list = ""
        case _ if all(p.startswith("_") for p in params):
            param_list = ", ".join(f"dynamic {p}" for p in params)
        case _:
            param_list = "{" + ", ".join(f"dynamic {p}" for p in params) + "}"
    if len(parts) == 1:
        return (f"dynamic {parts[0]}({param_list}) => null;",)
    root = parts[0]
    method = parts[-1]
    fields = parts[1:-1]
    if len(fields) == 0:
        cls = f"_{root.title()}Type"
        return (
            f"class {cls} {{ dynamic {method}({param_list}) => null; }}",
            f"final {root} = {cls}();",
        )
    lines: list[str] = []
    inner_cls = f"_{fields[-1].title()}Type"
    lines.append(
        f"class {inner_cls} {{ dynamic {method}({param_list}) => null; }}"
    )
    prev_cls = inner_cls
    for i in range(len(fields) - 2, -1, -1):
        cls = f"_{fields[i].title()}Type"
        lines.append(
            f"class {cls} {{ final {fields[i + 1]} = {prev_cls}(); }}"
        )
        prev_cls = cls
    root_cls = f"_{root.title()}Type"
    lines.append(f"class {root_cls} {{ final {fields[0]} = {prev_cls}(); }}")
    lines.append(f"final {root} = {root_cls}();")
    return tuple(lines)


@beartype
@dataclasses.dataclass(frozen=True, kw_only=True)
class Dart(metaclass=LanguageCls):
    """Dart language specification.

    Args:
        date_format: How to format :class:`datetime.date` values.

            * ``date_formats.DART`` — ``DateTime.parse(...)`` call,
              e.g. ``DateTime.parse("2024-01-15")``.
            * ``date_formats.ISO`` — ISO 8601 quoted string,
              e.g. ``"2024-01-15"``.

        datetime_format: How to format :class:`datetime.datetime` values.

            * ``datetime_formats.DART`` — ``DateTime.parse(...)`` call,
              e.g. ``DateTime.parse("2024-01-15T12:30:00")``.
            * ``datetime_formats.ISO`` — ISO 8601 quoted string,
              e.g. ``"2024-01-15T12:30:00"``.
    """

    reserved_module_identifiers: ClassVar[frozenset[str]] = frozenset()
    immutable_variable_modifiers: ClassVar[frozenset[enum.Enum]] = frozenset()
    wrap_in_file_tolerates_pre_indent = True
    module_name_shares_variable_scope = False
    reserved_variable_identifier_pattern: ClassVar[re.Pattern[str] | None] = (
        None
    )
    reserved_call_parameter_identifiers: ClassVar[frozenset[str]] = frozenset()
    accepts_type_name_call_target = True
    declares_type_name_call_target = True
    dotted_call_root_shares_entrypoint_namespace = True
    reserved_bare_call_target_identifiers: ClassVar[frozenset[str]] = (
        frozenset()
    )
    reserved_call_target_head_identifiers: ClassVar[frozenset[str]] = (
        frozenset()
    )
    contextual_call_target_identifiers: ClassVar[frozenset[str]] = frozenset()
    call_parameter_shadowing = CallParameterShadowing.ALLOWED
    reserved_call_target_keywords_case_sensitive = True
    module_name_must_start_uppercase = False
    new_variable_name_syntax = NewVariableNameSyntax.ASCII
    max_variable_identifier_length: ClassVar[int | None] = None
    call_target_name_syntax: ClassVar[NewVariableNameSyntax | None] = None
    supports_multiline_dict_layout = True
    pools_map_integer_width = True

    format_integer_widened = no_format_integer_widened
    format_constructor_target: ClassVar["staticmethod[[str], str]"] = (
        staticmethod(identity_constructor_target)
    )
    format_call_variable_declaration = default_format_call_variable_declaration
    format_call_variable_assignment = default_format_call_variable_assignment
    sequence_binding_declarations = default_sequence_binding_declarations
    format_call_binding_body_preamble = no_call_binding_body_preamble
    format_call_binding_file_pragmas = no_call_binding_file_pragmas

    leading_preamble = no_leading_preamble
    extension = ".dart"
    pygments_name = "dart"
    stringifies_nested_collections = False
    supports_special_floats = True
    supports_variable_names = True
    supports_no_variable_wrap_in_file = False
    wraps_data_dependent_preamble_in_body = False
    dict_supports_heterogeneous_values = True
    supports_dotted_calls = True
    has_free_function_calls = True
    reserved_identifiers: ClassVar[frozenset[str]] = frozenset()
    reserved_call_parameter_identifier_pattern: ClassVar[re.Pattern[str]] = (
        _DART_PRIVATE_NAME
    )
    declares_call_parameter_names = True
    reserved_variable_identifiers_case_sensitive: bool = True
    reserved_variable_identifiers: frozenset[str] = frozenset(
        # The keywords, then the type names the backend writes into its
        # annotations and ``main``, the entry point a wrapped file
        # declares.  A top-level declaration taking one of those names
        # shadows it, so the annotations referring to it stop resolving
        # and the file does not analyze (issue #3931).
        {
            "BigInt",
            "DateTime",
            "List",
            "Map",
            "Null",
            "Set",
            "String",
            "as",
            "assert",
            "async",
            "await",
            "bool",
            "break",
            "case",
            "catch",
            "class",
            "const",
            "continue",
            "covariant",
            "default",
            "deferred",
            "do",
            "double",
            "dynamic",
            "else",
            "enum",
            "export",
            "extends",
            "extension",
            "external",
            "factory",
            "false",
            "final",
            "finally",
            "for",
            "function",
            "get",
            "hide",
            "if",
            "implements",
            "import",
            "in",
            "int",
            "interface",
            "is",
            "late",
            "library",
            "main",
            "mixin",
            "new",
            "null",
            "on",
            "operator",
            "part",
            "required",
            "rethrow",
            "return",
            "set",
            "show",
            "static",
            "super",
            "switch",
            "sync",
            "this",
            "throw",
            "true",
            "try",
            "typedef",
            "var",
            "void",
            "while",
            "with",
            "yield",
        }
    )
    allows_empty_call_parens = True
    supports_dotted_call_stub = True
    call_returns_expression = True
    supports_json_call_result_binding = False
    supports_zero_parameter_calls = True
    max_call_parameters = NO_CALL_PARAMETER_LIMIT
    supports_inline_multiline_dict_args = True
    supports_standalone_comments_in_wrapped_calls = True
    supports_multi_param_call_wrapper_stub = True
    supports_dict_literal_as_free_expression = True
    supports_module_name = False
    supports_empty_dict_key = False
    supports_call_style = True
    supports_default_dict_key_type = True
    supports_default_dict_value_type = True
    supports_default_sequence_element_type = False
    supports_default_set_element_type = True
    supports_default_ordered_map_value_type = False
    json_type_variant_name_suffix: ClassVar[str | None] = None
    supports_non_ascii_string_literals = True
    supports_multiline_string_literals = True
    supports_empty_sibling_sequence_type_hints = True
    supports_typed_dict_open = True
    language_id: ClassVar[str] = "dart"
    variant_metadata: ClassVar[VariantMetadata] = VariantMetadata(
        round_trip_capabilities=frozenset(
            {
                RoundTripCapability.I64_BOUNDARIES,
                RoundTripCapability.INTERPOLATION_STRINGS,
                RoundTripCapability.EMBEDDED_NUL,
            }
        ),
        modifier_sequence_format_overrides={},
        string_literals_escape_null_byte=True,
        supports_ref_elements_in_tuple_strategy=False,
    )
    supports_record_struct_name_prefix = False
    supports_record_shape_names = False
    record_shape_names_emit_declarations = False
    supports_non_string_dict_keys = False
    checks_raw_control_dict_keys_separately = False

    format_call_arg: ClassVar["staticmethod[[Value, str], str]"] = (
        staticmethod(
            identity_call_arg,
        )
    )
    """Callable that rewrites a formatted direct call argument."""

    _opener_config = TypedOpenerConfig(
        str_type="String",
        bool_type="bool",
        int_type="int",
        float_type="double",
        mixed_numeric_type="double",
        bytes_type="String",
        date_type="DateTime",
        datetime_type="DateTime",
        time_type="String",
        list_template="List<{inner}>",
        sequence_opener_template="<{type_name}>[",
        dict_opener_template="<{key_type}, {type_name}>{{",
        set_opener_template="<{type_name}>{{",
        dict_type_template="Map<{key_type}, {inner}>",
        fallback_value_type="dynamic",
        wide_int_type=None,
        beyond_i64_type="BigInt",
    )

    class DateFormats(DateFormatEnum):
        """Date formatting options for Dart."""

        _value_: DateFormatConfig

        DART = DateFormatConfig(
            formatter=_format_date_dart,
            preamble_lines=(),
            type_produced=datetime.date,
        )
        ISO = DateFormatConfig(
            formatter=format_date_iso, type_produced=str, preamble_lines=()
        )

    class DatetimeFormats(DatetimeFormatEnum):
        """Datetime formatting options for Dart."""

        _value_: DatetimeFormatConfig

        DART = DatetimeFormatConfig(
            formatter=_format_datetime_dart,
            preamble_lines=(),
            type_produced=datetime.datetime,
        )
        ISO = DatetimeFormatConfig(
            formatter=format_datetime_iso,
            type_produced=str,
            preamble_lines=(),
        )

        EPOCH = DatetimeFormatConfig(
            formatter=format_datetime_epoch,
            type_produced=int,
            preamble_lines=(),
        )

    class BytesFormats(enum.Enum):
        """Bytes formatting options."""

        _value_: Callable[[bytes], str]

        HEX = enum.member(value=format_bytes_hex)
        BASE64 = enum.member(value=format_bytes_base64)

        def __call__(self, data: bytes, /) -> str:
            """Format bytes."""
            return self._value_(data)

    class SequenceFormats(enum.Enum):
        """Sequence type options for Dart."""

        LIST = SequenceFormatConfig(
            sequence_open=fixed_open(open_str="["),
            close="]",
            supports_heterogeneity=True,
            single_element_trailing_comma=False,
            single_element_template=None,
            supports_trailing_comma=True,
            empty_sequence=None,
            preamble_lines=(),
            format_entry=passthrough_sequence_entry,
            typed_opener_fallback="[",
            uses_typed_literal_for_scalars=False,
            requires_uniform_record_shapes=False,
            declared_type=None,
            narrowed_empty_form=None,
        )
        TUPLE = SequenceFormatConfig(
            sequence_open=fixed_open(open_str="("),
            close=")",
            supports_heterogeneity=True,
            single_element_trailing_comma=True,
            single_element_template=None,
            supports_trailing_comma=True,
            empty_sequence="()",
            preamble_lines=(),
            format_entry=passthrough_sequence_entry,
            typed_opener_fallback=None,
            uses_typed_literal_for_scalars=False,
            requires_uniform_record_shapes=False,
            declared_type=None,
            narrowed_empty_form=None,
        )

    class SetFormats(enum.Enum):
        """Set type options for Dart."""

        _value_: Callable[[str], SetFormatConfig]

        SET = enum.member(
            value=set_format_factory(
                open_template="{{",
                close="}}",
                empty_template="<{type}>{{}}",
                preamble_lines=(),
                set_opener_template="",
                supports_heterogeneity=True,
                supports_trailing_comma=True,
            )
        )

        def __call__(self, default_type: str) -> SetFormatConfig:
            """Create a set format config for the given type."""
            return self._value_(default_type)

    class CommentFormats(enum.Enum):
        """Comment style options."""

        DOUBLE_SLASH = CommentConfig(
            prefix="//",
            suffix="",
        )
        BLOCK = CommentConfig(
            prefix="/*",
            suffix=" */",
        )

    class DeclarationStyles(enum.Enum):
        """Declaration style options."""

        FINAL = DeclarationStyleConfig(
            formatter=variable_declaration_formatter(
                template="final {name} = {value};"
            ),
            supports_redefinition=False,
        )
        VAR = DeclarationStyleConfig(
            formatter=variable_declaration_formatter(
                template="var {name} = {value};"
            ),
            supports_redefinition=False,
        )
        CONST = DeclarationStyleConfig(
            formatter=variable_declaration_formatter(
                template="const {name} = {value};"
            ),
            supports_redefinition=False,
        )

    class DictEntryStyles(enum.Enum):
        """Dict entry style options."""

        DEFAULT = enum.auto()

    class DictFormats(enum.Enum):
        """Dict/map format options."""

        DEFAULT = enum.auto()

    class EmptyDictKey(enum.Enum):
        """Empty dict key options."""

        ALLOW = enum.auto()

    class FloatFormats(
        FloatSpecialsMixin,
        enum.Enum,
        positive_infinity="double.infinity",
        negative_infinity="double.negativeInfinity",
        nan="double.nan",
    ):
        """Float format options."""

        REPR = enum.member(value=format_float_repr)
        SCIENTIFIC = enum.member(value=format_float_scientific)
        FIXED = enum.member(value=format_float_fixed)

    class IntegerFormats(enum.Enum):
        """Integer format options."""

        DECIMAL = enum.member(value=str)
        HEX = enum.member(value=format_integer_hex)

        def __call__(self, value: int, /) -> str:
            """Format an integer."""
            formatter: Callable[[int], str] = self.value
            return formatter(value)

    class NumericLiteralSuffixes(enum.Enum):
        """Numeric literal suffix options."""

        NONE = enum.auto()

    class NumericSeparators(enum.Enum):
        """Numeric separator options."""

        NONE = enum.auto()

    class NumericStyles(enum.Enum):
        """Numeric literal style options."""

        OVERLOADED = enum.auto()

    class StringFormats(enum.Enum):
        """String format options."""

        _value_: Callable[[str], str]

        DOUBLE = enum.member(value=_format_string_double)
        SINGLE = enum.member(value=_format_string_single)
        MULTILINE = enum.member(value=_format_string_multiline)

        def __call__(self, value: str, /) -> str:
            """Format a string."""
            return self._value_(value)

    class TrailingCommas(enum.Enum):
        """Trailing comma options."""

        YES = TrailingCommaConfig(multiline_trailing_comma=True)
        NO = TrailingCommaConfig(multiline_trailing_comma=False)

    date_formats = DateFormats
    datetime_formats = DatetimeFormats
    bytes_formats = BytesFormats
    sequence_formats = SequenceFormats
    set_formats = SetFormats
    comment_formats = CommentFormats

    class VariableTypeHints(enum.Enum):
        """Variable type hint options."""

        NEVER = enum.auto()
        ALWAYS = enum.auto()
        SAFE = enum.auto()

        def formatter(
            self,
            *,
            auto_formatter: Callable[
                [str, str, Value, frozenset[enum.Enum]], str
            ],
            keyword: str,
            date_hint: str,
            datetime_hint: str,
            default_set_element_type: str,
            default_dict_key_type: str,
            default_dict_value_type: str,
            sequence_is_tuple: bool,
            openers: "_DartHintOpeners",
        ) -> Callable[[str, str, Value, frozenset[enum.Enum]], str]:
            """Return the variable declaration formatter."""
            if self in {type(self).NEVER, type(self).SAFE}:
                return auto_formatter

            def _typed_formatter(
                name: str,
                value: str,
                data: Value,
                modifiers: frozenset[enum.Enum],
            ) -> str:
                """Adapt :func:`_format_dart_typed_declaration` to the
                positional formatter interface.
                """
                return _format_dart_typed_declaration(
                    name=name,
                    value=value,
                    data=data,
                    _modifiers=modifiers,
                    keyword=keyword,
                    date_hint=date_hint,
                    datetime_hint=datetime_hint,
                    default_set_element_type=default_set_element_type,
                    default_dict_key_type=default_dict_key_type,
                    default_dict_value_type=default_dict_value_type,
                    sequence_is_tuple=sequence_is_tuple,
                    openers=openers,
                )

            return _typed_formatter

    variable_type_hints_formats = VariableTypeHints
    declaration_styles = DeclarationStyles
    dict_entry_styles = DictEntryStyles
    dict_formats = DictFormats
    empty_dict_keys = EmptyDictKey
    float_formats = FloatFormats
    integer_formats = IntegerFormats
    integer_width_strategies = BareIntegerWidthStrategies
    numeric_literal_suffixes = NumericLiteralSuffixes
    numeric_separators = NumericSeparators
    numeric_styles = NumericStyles
    string_formats = StringFormats
    trailing_commas = TrailingCommas

    class StatementTerminatorStyles(enum.Enum):
        """Statement terminator options."""

        SEMICOLON = enum.auto()

    statement_terminator_styles = StatementTerminatorStyles

    class CallStyles(enum.Enum):
        """Dart call style options."""

        NAMED = KeywordCallStyle(separator=": ")

    call_styles = CallStyles

    class Modifiers(enum.Enum):
        """C++/Java/C#-style declaration modifiers: this language has none."""

    modifiers = Modifiers

    class HeterogeneousStrategies(enum.Enum):
        """Heterogeneous-scalar strategy options — this language only
        supports raising.
        """

        ERROR = NO_HETEROGENEOUS_BEHAVIOR

    heterogeneous_strategies = HeterogeneousStrategies

    class JsonTypes(JsonType):
        """Empty: this language has no JSON value-type variants."""

    json_types = JsonTypes

    class BoolFormats(enum.Enum):
        """Empty: this language has no alternative boolean formats."""

    bool_formats = BoolFormats

    class VersionFormats(enum.Enum):
        """Version options for Dart."""

        V3 = enum.auto()

    version_formats = VersionFormats

    modifier_combinations: ClassVar[tuple[ModifierCombination, ...]] = ()
    identifier_cases: ClassVar[tuple[IdentifierCase, ...]] = (
        IdentifierCase.CAMEL,
        IdentifierCase.PASCAL,
        IdentifierCase.UPPER_SNAKE,
    )
    supported_ref_cases: ClassVar[frozenset[IdentifierCase]] = (
        NON_KEBAB_REF_CASES
    )

    def wrap_in_file(
        self,
        content: str,
        variable_name: str,
        body_preamble: tuple[str, ...],
    ) -> str:
        """Wrap code in a valid file."""
        if variable_name != "":
            return wrap_in_file_noop(
                content=content,
                variable_name=variable_name,
                body_preamble=body_preamble,
            )
        # Call mode: top-level expression statements are invalid in Dart.
        # Class/function stubs go at file scope; call expressions and
        # declarations from reference values go inside void main(). Add a
        # top-level my_data sentinel so the CI lint harness can import it.
        indented = textwrap.indent(text=content, prefix=self.indent)
        return "\n".join(
            [
                *body_preamble,
                "final my_data = null;",
                "void main() {",
                indented,
                "}",
            ]
        )

    @property
    def call_wrapper_entrypoint_name(self) -> str:
        """Return the generated complete-file entry-point name."""
        return "main"

    @staticmethod
    def wrap_combined_in_file(
        declaration: str,
        assignment: str,
        variable_name: str,
        body_preamble: tuple[str, ...],
    ) -> str:
        """Unsupported: literalize() rejects BothVariableForms
        upstream.
        """
        del declaration, assignment, variable_name, body_preamble
        raise WrapCombinedInFileNotSupportedError

    date_format: DateFormats = DateFormats.DART
    datetime_format: DatetimeFormats = DatetimeFormats.DART
    bytes_format: BytesFormats = BytesFormats.HEX
    sequence_format: SequenceFormats = SequenceFormats.LIST
    set_format: SetFormats = SetFormats.SET
    default_set_element_type: str = "dynamic"
    default_dict_key_type: str = "String"
    default_dict_value_type: str = "dynamic"
    variable_type_hints: VariableTypeHints = VariableTypeHints.NEVER
    comment_format: CommentFormats = CommentFormats.DOUBLE_SLASH
    declaration_style: DeclarationStyles = DeclarationStyles.FINAL
    dict_entry_style: DictEntryStyles = DictEntryStyles.DEFAULT
    dict_format: DictFormats = DictFormats.DEFAULT
    float_format: FloatFormats = FloatFormats.REPR
    integer_format: IntegerFormats = IntegerFormats.DECIMAL
    integer_width_strategy: BareIntegerWidthStrategies = (
        BareIntegerWidthStrategies.BARE
    )
    numeric_literal_suffix: NumericLiteralSuffixes = (
        NumericLiteralSuffixes.NONE
    )
    numeric_separator: NumericSeparators = NumericSeparators.NONE
    numeric_style: NumericStyles = NumericStyles.OVERLOADED
    string_format: StringFormats = StringFormats.DOUBLE
    trailing_comma: TrailingCommas = TrailingCommas.YES
    statement_terminator_style: StatementTerminatorStyles = (
        StatementTerminatorStyles.SEMICOLON
    )
    call_style: CallStyles = CallStyles.NAMED
    heterogeneous_strategy: HeterogeneousStrategies = (
        HeterogeneousStrategies.ERROR
    )
    # Keep in sync with the `sdk: ^3.0.0` constraint in the generated
    # `pubspec.yaml` in `.github/workflows/lint.yml`. Dart has no
    # `--langversion`-style flag, so that `pubspec.yaml` constraint is
    # the only way to pin the version; `V3` maps to `^3.0.0`.
    language_version: VersionFormats = VersionFormats.V3
    indent: str = "    "

    null_literal: ClassVar[str] = "null"
    true_literal: ClassVar[str] = "true"
    false_literal: ClassVar[str] = "false"
    indent_closing_delimiter: ClassVar[bool] = False
    element_separator: ClassVar[str] = ", "
    skip_null_dict_values: ClassVar[bool] = False
    supports_collection_comments: ClassVar[bool] = True
    supports_scalar_before_comments: ClassVar[bool] = True
    supports_scalar_inline_comments: ClassVar[bool] = False
    statement_terminator: ClassVar[str] = ";"
    static_preamble: ClassVar[Sequence[str]] = ()
    static_body_preamble: ClassVar[Sequence[str]] = ()
    special_float_preamble: ClassVar[tuple[str, ...]] = ()

    wrap_calls_with_declarations = default_wrap_calls_with_declarations

    @cached_property
    def validate_call_arg(self) -> Callable[[Value], None]:
        """Return call-argument validation for this language."""
        sequence_is_tuple = self.sequence_format.name == "TUPLE"

        def validate(data: Value) -> None:
            """Validate one direct call argument."""
            _validate_dart_mixed_numeric_data(
                data=data,
                sequence_is_tuple=sequence_is_tuple,
            )

        return validate

    @cached_property
    def format_call_statement(self) -> Callable[[str], str]:
        """Return call-statement formatting for this language."""
        return identity_call_statement

    def validate_spec_for_data(self, data: Value) -> None:
        """Raise if the spec cannot produce valid code for *data*.

        Dart's ``DART`` date / datetime formats render as
        ``DateTime.parse(...)``, which is a runtime call and not a
        constant expression, so they are incompatible with ``CONST``.
        """
        _validate_dart_mixed_numeric_data(
            data=data,
            sequence_is_tuple=self.sequence_format.name == "TUPLE",
        )
        _decl_cls = type(self.declaration_style)
        if self.declaration_style is not _decl_cls.CONST:
            return
        if value_contains(
            data=data,
            predicate=lambda value: (
                isinstance(value, int)
                and not isinstance(value, bool)
                and not I64_MIN <= value <= I64_MAX
            ),
        ):
            msg = (
                "Dart CONST requires a constant-expression initializer, "
                "but integers outside the signed 64-bit range produce a "
                "BigInt.parse(…) call which is not a constant expression. "
                "Use FINAL instead."
            )
            raise IncompatibleFormatsError(msg)
        _date_cls = type(self.date_format)
        _datetime_cls = type(self.datetime_format)
        # Match pure ``date`` values only — ``datetime`` is a subclass
        # of ``date``, so a plain ``isinstance(v, date)`` check would
        # also fire for datetime values, which belong to the separate
        # ``datetime_format`` check below.
        if self.date_format is _date_cls.DART and value_contains(
            data=data,
            predicate=lambda v: (
                isinstance(v, datetime.date)
                and not isinstance(v, datetime.datetime)
            ),
        ):
            msg = (
                "Dart CONST requires a constant-expression initializer, "
                "but the DART date format produces a DateTime.parse(…) "
                "call which is not a constant expression. "
                "Use ISO instead."
            )
            raise IncompatibleFormatsError(msg)
        if self.datetime_format is _datetime_cls.DART and value_contains(
            data=data,
            predicate=lambda v: isinstance(v, datetime.datetime),
        ):
            msg = (
                "Dart CONST requires a constant-expression initializer, "
                "but the DART datetime format produces a "
                "DateTime.parse(…) call which is not a constant "
                "expression. Use ISO instead."
            )
            raise IncompatibleFormatsError(msg)

    @cached_property
    def format_sequence_entry(self) -> Callable[[Value, str], str]:
        """Format a sequence entry."""
        return passthrough_sequence_entry

    @cached_property
    def format_set_entry(self) -> Callable[[Value, str], str]:
        """Format a set entry."""
        return passthrough_set_entry

    @cached_property
    def format_variable_assignment(self) -> Callable[[str, str, Value], str]:
        """Format an assignment to an existing variable."""
        return variable_formatter(template="{name} = {value};")

    @cached_property
    def format_ordered_map_entry(self) -> Callable[[str, Value, str], str]:
        """Format one ordered-map entry."""
        return dict_entry_with_separator(
            separator=": ", format_value=passthrough_sequence_entry
        )

    @cached_property
    def data_dependent_preamble(self) -> Callable[[Value], tuple[str, ...]]:
        """Return data-dependent preamble lines."""
        return no_data_preamble

    @cached_property
    def heterogeneous_behavior(self) -> HeterogeneousBehavior:
        """Return the heterogeneous-behavior config."""
        return self.heterogeneous_strategy.value

    @cached_property
    def call_data_dependent_preamble(
        self,
    ) -> Callable[[Value], tuple[str, ...]]:
        """Return data-dependent preamble lines for call rendering."""
        return self.data_dependent_preamble

    @cached_property
    def type_hint_collection_preamble_lines(
        self,
    ) -> Callable[[frozenset[type]], tuple[str, ...]]:
        """Return preamble lines for empty-collection type hints."""
        return no_type_hint_preamble

    @cached_property
    def call_style_config(self) -> CallStyle:
        """Configuration for the chosen call style."""
        config: CallStyle = self.call_style.value
        return config

    @cached_property
    def format_call_stub(
        self,
    ) -> Callable[
        [Sequence[str], Sequence[str], StubReturn, Sequence[Value]],
        tuple[str, ...],
    ]:
        """Return stub declarations for a call expression."""
        return _dart_call_stub

    @cached_property
    def format_call_preamble_stub(
        self,
    ) -> Callable[
        [Sequence[str], Sequence[str], StubReturn, Sequence[Value]],
        tuple[str, ...],
    ]:
        """Return file-scope stubs for a call expression."""
        return no_call_stub

    @cached_property
    def format_call_target(self) -> Callable[[Sequence[str]], str]:
        """Rewrite a dotted call target into the language's call
        syntax.
        """
        return identity_call_target

    @cached_property
    def format_call_ref_identifier(
        self,
    ) -> Callable[[str, Value | None], str]:
        """Rewrite a ``{"$ref": "name"}`` identifier into the
        language's call expression syntax.
        """
        return identity_call_ref_identifier

    @cached_property
    def format_call_arg_ref_identifier(
        self,
    ) -> Callable[[str, Value | None], str]:
        """Rewrite a ``{"$ref": "name"}`` identifier in a call-argument
        context.

        Delegates to :attr:`format_call_ref_identifier`.  Override this to
        allow call-argument ``$ref`` values that would otherwise be rejected.
        """
        return self.format_call_ref_identifier

    @cached_property
    def format_call_arg_ref_identifier_consumable(
        self,
    ) -> Callable[[str, Value | None], str]:
        """Format a ``$ref`` the caller authorized as consumable.

        Delegates to :attr:`format_call_arg_ref_identifier`.  Override
        this to opt into a consuming form (e.g. C++ ``std::move``).
        """
        return self.format_call_arg_ref_identifier

    @cached_property
    def consumable_ref_value_inhibits_consuming_form(
        self,
    ) -> Callable[[Value], bool]:
        """Predicate deciding whether a ref's underlying value type
        inhibits the consume form.

        Delegates to :data:`never_inhibits_consuming_form`.  Languages
        whose consume operator rejects certain value types (notably
        the Mojo ``^`` on register-trivial scalars) override this.
        """
        return never_inhibits_consuming_form

    @cached_property
    def _date_tp(self) -> type:
        """Python type produced by the chosen date format."""
        return self.date_format.value.type_produced

    @cached_property
    def _dt_tp(self) -> type:
        """Python type produced by the chosen datetime format."""
        return self.datetime_format.value.type_produced

    @cached_property
    def _openers(self) -> TypeOpeners:
        """Typed openers built from the opener config."""
        cfg = self._opener_config
        return cfg.build(
            date_type=cfg.type_name(py_type=self._date_tp),
            datetime_type=cfg.type_name(py_type=self._dt_tp),
            set_opener_template=None,
            narrow_dict_values=True,
            # A ``TUPLE`` list renders as a Dart record, whose arity is
            # part of its type, so the element type alone cannot name
            # it and a list value keeps the generic one (issue #3925).
            narrow_list_values=(
                self.sequence_format is not type(self.sequence_format).TUPLE
            ),
            dict_key_type=self.default_dict_key_type,
        )

    @cached_property
    def _dart_keyword(self) -> str:
        """Keyword prefix derived from the declaration style."""
        kw = self.declaration_style.name.lower()
        if kw == "var":
            return ""
        return f"{kw} "

    @cached_property
    def sequence_format_config(self) -> SequenceFormatConfig:
        """Configuration for the chosen sequence format."""
        return self.sequence_format.value

    @cached_property
    def set_format_config(self) -> SetFormatConfig:
        """Configuration for the chosen set format."""
        return self.set_format(
            default_type=self.default_set_element_type,
        )

    @cached_property
    def sequence_open(self) -> Callable[[list[Value]], str]:
        """Callable that returns the opening delimiter for a sequence."""
        fmt = self.sequence_format.value
        if fmt.typed_opener_fallback is not None:
            return typed_collection_open(
                type_to_opener=self._openers.seq,
                fallback=fmt.typed_opener_fallback,
            )
        return fmt.sequence_open

    @cached_property
    def dict_format_config(self) -> DictFormatConfig:
        """Configuration for dict formatting."""
        return DictFormatConfig(
            dict_open=typed_dict_open(
                type_to_opener=self._openers.dict,
                fallback=(
                    f"<{self.default_dict_key_type}, "
                    f"{self.default_dict_value_type}>{{"
                ),
            ),
            close="}",
            format_entry=dict_entry_with_separator(
                separator=": ",
                format_value=passthrough_sequence_entry,
            ),
            empty_dict=None,
            preamble_lines=(),
            narrowed_open=None,
            supports_trailing_comma=True,
            narrowed_empty_form=None,
        )

    @cached_property
    def trailing_comma_config(self) -> TrailingCommaConfig:
        """Configuration for trailing-comma behavior."""
        return self.trailing_comma.value

    @cached_property
    def format_bytes(self) -> Callable[[bytes], str]:
        """Callable that formats a bytes value as a string literal."""
        return self.bytes_format

    @cached_property
    def format_date(self) -> Callable[[datetime.date], str]:
        """Callable that formats a date as a string literal."""
        return self.date_format

    @cached_property
    def format_datetime(self) -> Callable[[datetime.datetime], str]:
        """Callable that formats a datetime as a string literal."""
        return self.datetime_format

    @cached_property
    def format_time(self) -> Callable[[datetime.time], str]:
        """Callable that formats a time as a string literal."""
        return format_time_iso

    @cached_property
    def format_string(self) -> Callable[[str], str]:
        """Callable that formats a string value as a quoted literal."""
        return self.string_format

    @cached_property
    def format_float(self) -> Callable[[float], str]:
        """Callable that formats a float value as a literal."""
        return self.float_format

    @cached_property
    def format_integer(self) -> Callable[[int], str]:
        """Callable that formats an int value as a literal."""
        return make_overflow_fallback_formatter(
            base=self.integer_format,
            fallback=_format_dart_bigint_literal,
            min_value=I64_MIN,
            max_value=I64_MAX,
        )

    @cached_property
    def format_integer_beyond_i64(self) -> Callable[[int], str]:
        """Always-``BigInt.parse`` formatter for collections that
        exceed signed 64-bit range.
        """
        return _format_dart_bigint_literal

    @cached_property
    def comment_config(self) -> CommentConfig:
        """Configuration for the language's comment syntax."""
        return self.comment_format.value

    @cached_property
    def ordered_map_format_config(self) -> OrderedMapFormatConfig:
        """Configuration for ordered-map formatting."""
        return OrderedMapFormatConfig(
            ordered_map_open=fixed_open(open_str="{"),
            close="}",
            preamble_lines=(),
        )

    @cached_property
    def format_variable_declaration(
        self,
    ) -> Callable[[str, str, Value, frozenset[enum.Enum]], str]:
        """Callable that formats a new variable declaration."""
        effective_date_hint = "DateTime"
        if self.date_format.value.type_produced is str:
            effective_date_hint = "String"
        if self.datetime_format.value.type_produced is int:
            effective_datetime_hint = "int"
        else:
            effective_datetime_hint = "DateTime"
            if self.datetime_format.value.type_produced is str:
                effective_datetime_hint = "String"
        return self.variable_type_hints.formatter(
            auto_formatter=self.declaration_style.value.formatter,
            keyword=self._dart_keyword,
            date_hint=(effective_date_hint),
            datetime_hint=(effective_datetime_hint),
            default_set_element_type=self.default_set_element_type,
            default_dict_key_type=self.default_dict_key_type,
            default_dict_value_type=self.default_dict_value_type,
            sequence_is_tuple=(
                self.sequence_format is type(self.sequence_format).TUPLE
            ),
            openers=_DartHintOpeners(
                dict_open=self.dict_format_config.dict_open,
                sequence_open=self.sequence_open,
            ),
        )

    @cached_property
    def scalar_preamble(self) -> dict[type, tuple[str, ...]]:
        """Per-instance scalar preamble (Dart needs none)."""
        return {}

    @cached_property
    def scalar_body_preamble(self) -> dict[type, tuple[str, ...]]:
        """Per-instance scalar body preamble (Dart needs none)."""
        return {}

    @cached_property
    def compute_body_preamble(
        self,
    ) -> Callable[[frozenset[type], Value], tuple[str, ...]]:
        """Compute body-preamble lines from the scalar map."""
        return body_preamble_from_scalars(
            scalar_body_preamble=self.scalar_body_preamble,
            format_lines=tuple,
        )
