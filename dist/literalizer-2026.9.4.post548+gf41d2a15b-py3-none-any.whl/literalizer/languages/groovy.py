"""Groovy language specification."""

import dataclasses
import datetime
import enum
import math
import re
from collections.abc import Callable, Sequence
from functools import cached_property
from typing import ClassVar, override

from beartype import beartype

from literalizer._formatters.collection_openers import (
    fixed_open,
)
from literalizer._formatters.format_dates import (
    date_ymd_formatter,
    format_date_iso,
    format_datetime_epoch,
    format_datetime_iso,
    format_time_local_time_of,
)
from literalizer._formatters.format_entries import (
    DictEntryWithSeparator,
    format_bytes_base64,
    format_bytes_hex,
    passthrough_sequence_entry,
    passthrough_set_entry,
    variable_declaration_formatter,
    variable_formatter,
)
from literalizer._formatters.format_factories import set_format_factory
from literalizer._formatters.format_floats import (
    format_float_fixed,
    format_float_repr,
    format_float_scientific,
)
from literalizer._formatters.format_strings import (
    format_string_backslash_dollar_nul_unicode,
)
from literalizer._language import (
    NO_CALL_PARAMETER_LIMIT,
    NO_HETEROGENEOUS_BEHAVIOR,
    NON_KEBAB_REF_CASES,
    BareIntegerWidthStrategies,
    CallParameterShadowing,
    CallStyle,
    CommentConfig,
    DateFormatConfig,
    DateFormatEnum,
    DatetimeFormatConfig,
    DatetimeFormatEnum,
    DeclarationStyleConfig,
    DictFormatConfig,
    FloatSpecialsMixin,
    HeterogeneousBehavior,
    IdentifierCase,
    JsonType,
    KeywordCallStyle,
    LanguageCls,
    ModifierCombination,
    NewVariableNameSyntax,
    OrderedMapFormatConfig,
    PositionalCallStyle,
    RoundTripCapability,
    SequenceFormatConfig,
    SetFormatConfig,
    StubReturn,
    TrailingCommaConfig,
    VariantMetadata,
    body_preamble_from_scalars,
    default_format_call_variable_assignment,
    default_format_call_variable_declaration,
    default_sequence_binding_declarations,
    default_wrap_calls_with_declarations,
    identity_call_arg,
    identity_call_ref_identifier,
    identity_call_statement,
    identity_call_target,
    never_inhibits_consuming_form,
    new_constructor_target,
    no_call_binding_body_preamble,
    no_call_binding_file_pragmas,
    no_call_stub,
    no_data_preamble,
    no_format_integer_beyond_i64,
    no_format_integer_widened,
    no_leading_preamble,
    no_type_hint_preamble,
    no_validate_call_arg,
    no_validate_spec_for_data,
    wrap_combined_in_file_noop,
    wrap_in_file_noop,
)
from literalizer._types import Scalar, Value


@beartype
def _preserve_negative_zero(*, value: float, formatted: str) -> str:
    """Force Groovy to parse negative zero as a ``Double``."""
    if value == 0 and math.copysign(1, value) < 0:
        return f"{formatted}d"
    return formatted


@beartype
def _format_float_repr(value: float) -> str:
    """Format a repr-style float without losing negative zero."""
    return _preserve_negative_zero(
        value=value,
        formatted=format_float_repr(value=value),
    )


@beartype
def _format_float_scientific(value: float) -> str:
    """Format a scientific float without losing negative zero."""
    return _preserve_negative_zero(
        value=value,
        formatted=format_float_scientific(value=value),
    )


@beartype
def _format_float_fixed(value: float) -> str:
    """Format a fixed float without losing negative zero."""
    return _preserve_negative_zero(
        value=value,
        formatted=format_float_fixed(value=value),
    )


_TRAILING_LINE_WHITESPACE = re.compile(pattern=r"[ \t]+(?=\n)")


@beartype
def _groovy_key_is_native_temporal(
    *, raw_key: Scalar, native_dates: bool
) -> bool:
    """Return whether a source key renders as a ``java.time`` call."""
    return isinstance(raw_key, datetime.time) or (
        native_dates
        and isinstance(raw_key, datetime.date)
        and not isinstance(raw_key, datetime.datetime)
    )


@beartype
@dataclasses.dataclass(frozen=True)
class _GroovyDictFormatConfig(DictFormatConfig):
    """Groovy dict config that classifies source temporal keys."""

    native_dates: bool

    @override
    def format_entry_from_source(
        self,
        *,
        raw_key: Scalar,
        formatted_key: str,
        raw_value: Value,
        formatted_value: str,
    ) -> str:
        """Parenthesize native temporal keys so they parse as
        expressions.
        """
        if _groovy_key_is_native_temporal(
            raw_key=raw_key, native_dates=self.native_dates
        ):
            formatted_key = f"({formatted_key})"
        return self.format_entry(formatted_key, raw_value, formatted_value)


@beartype
@dataclasses.dataclass(frozen=True)
class _GroovyOrderedMapFormatConfig(OrderedMapFormatConfig):
    """Groovy ordered-map config that classifies source temporal keys."""

    native_dates: bool

    @override
    def format_entry_from_source(
        self,
        *,
        raw_key: Scalar,
        formatted_key: str,
        raw_value: Value,
        formatted_value: str,
        format_entry: Callable[[str, Value, str], str],
    ) -> str:
        """Parenthesize native temporal keys so they parse as
        expressions.
        """
        if _groovy_key_is_native_temporal(
            raw_key=raw_key, native_dates=self.native_dates
        ):
            formatted_key = f"({formatted_key})"
        return format_entry(formatted_key, raw_value, formatted_value)


@beartype
def _escape_trailing_whitespace(match: re.Match[str]) -> str:
    r"""Return one ``\u0020`` escape per character of the whitespace run
    *match*.
    """
    return r"\u0020" * len(match[0])


@beartype
def _format_string_multiline(value: str) -> str:
    r"""Format *value* as an exact Groovy triple-single-quoted string."""
    escaped = (
        value.replace("\\", "\\\\")
        .replace("\0", "\\u0000")
        .replace("\r", "\\r")
        .replace("\t", "\\t")
        .replace("'", "\\'")
    )
    escaped = _TRAILING_LINE_WHITESPACE.sub(
        repl=_escape_trailing_whitespace,
        string=escaped,
    )
    return f"'''{escaped}'''"


@beartype
def _groovy_call_stub_factory(
    *,
    keyword_style: bool,
) -> Callable[
    [Sequence[str], Sequence[str], StubReturn, Sequence[Value]],
    tuple[str, ...],
]:
    """Return a Groovy stub generator for the given call style.

    Named-argument calls pack every argument into a single
    ``LinkedHashMap`` first parameter, so stubs for ``KEYWORD`` calls
    must declare a single ``Map`` parameter.  ``POSITIONAL`` stubs keep
    the concrete parameter list, which documents the expected argument
    names.
    """

    def _stub(
        parts: Sequence[str],
        params: Sequence[str],
        _stub_return: StubReturn,
        _args: Sequence[Value],
        /,
    ) -> tuple[str, ...]:
        """Return Groovy stub declarations for a call name."""
        param_list = "Map _args"
        if not keyword_style:
            param_list = ", ".join(params)
        if len(parts) == 1:
            return (f"def {parts[0]}({param_list}) {{ null }}",)
        root = parts[0]
        method = parts[-1]
        fields = parts[1:-1]
        if len(fields) == 0:
            cls = f"_{root.title()}Type"
            return (
                f"class {cls} {{ def {method}({param_list}) {{ null }} }}",
                f"def {root} = new {cls}()",
            )
        lines: list[str] = []
        inner_cls = f"_{fields[-1].title()}Type"
        lines.append(
            f"class {inner_cls} {{ def {method}({param_list}) {{ null }} }}"
        )
        prev_cls = inner_cls
        for i in range(len(fields) - 2, -1, -1):
            cls = f"_{fields[i].title()}Type"
            lines.append(
                f"class {cls} {{ def {fields[i + 1]} = new {prev_cls}() }}"
            )
            prev_cls = cls
        root_cls = f"_{root.title()}Type"
        lines.append(
            f"class {root_cls} {{ def {fields[0]} = new {prev_cls}() }}"
        )
        lines.append(f"def {root} = new {root_cls}()")
        return tuple(lines)

    return _stub


@beartype
@dataclasses.dataclass(frozen=True, kw_only=True)
class Groovy(metaclass=LanguageCls):
    """Groovy language specification."""

    reserved_module_identifiers: ClassVar[frozenset[str]] = frozenset()
    immutable_variable_modifiers: ClassVar[frozenset[enum.Enum]] = frozenset()
    wrap_in_file_tolerates_pre_indent = True
    module_name_shares_variable_scope = False
    reserved_variable_identifier_pattern: ClassVar[re.Pattern[str] | None] = (
        None
    )
    reserved_call_parameter_identifiers: ClassVar[frozenset[str]] = frozenset()
    reserved_call_parameter_identifier_pattern: ClassVar[
        re.Pattern[str] | None
    ] = None
    accepts_type_name_call_target = True
    declares_type_name_call_target = True
    dotted_call_root_shares_entrypoint_namespace = True
    reserved_bare_call_target_identifiers: ClassVar[frozenset[str]] = (
        frozenset()
    )
    reserved_call_target_head_identifiers: ClassVar[frozenset[str]] = (
        frozenset()
    )
    contextual_call_target_identifiers: ClassVar[frozenset[str]] = frozenset()
    call_parameter_shadowing = CallParameterShadowing.ALLOWED
    reserved_call_target_keywords_case_sensitive = True
    module_name_must_start_uppercase = False
    new_variable_name_syntax = NewVariableNameSyntax.ASCII
    max_variable_identifier_length: ClassVar[int | None] = None
    call_target_name_syntax: ClassVar[NewVariableNameSyntax | None] = None
    supports_multiline_dict_layout = True
    pools_map_integer_width = True

    format_integer_widened = no_format_integer_widened
    format_integer_beyond_i64 = no_format_integer_beyond_i64
    format_constructor_target: ClassVar["staticmethod[[str], str]"] = (
        staticmethod(new_constructor_target)
    )
    format_call_variable_declaration = default_format_call_variable_declaration
    format_call_variable_assignment = default_format_call_variable_assignment
    sequence_binding_declarations = default_sequence_binding_declarations
    format_call_binding_body_preamble = no_call_binding_body_preamble
    format_call_binding_file_pragmas = no_call_binding_file_pragmas

    leading_preamble = no_leading_preamble
    extension = ".groovy"
    pygments_name = "groovy"
    stringifies_nested_collections = False
    supports_special_floats = True
    supports_variable_names = True
    supports_no_variable_wrap_in_file = True
    wraps_data_dependent_preamble_in_body = False
    dict_supports_heterogeneous_values = True
    supports_dotted_calls = True
    has_free_function_calls = True
    reserved_identifiers: ClassVar[frozenset[str]] = frozenset()
    declares_call_parameter_names = True
    reserved_variable_identifiers_case_sensitive: bool = True
    reserved_variable_identifiers: frozenset[str] = frozenset(
        # The keywords, then the primitive type names: Groovy cannot
        # parse ``def int = ...`` (issue #3944).
        {
            "as",
            "assert",
            "boolean",
            "break",
            "byte",
            "case",
            "catch",
            "char",
            "class",
            "const",
            "continue",
            "def",
            "default",
            "do",
            "double",
            "else",
            "enum",
            "extends",
            "final",
            "finally",
            "float",
            "for",
            "goto",
            "if",
            "implements",
            "import",
            "in",
            "instanceof",
            "int",
            "interface",
            "long",
            "native",
            "new",
            "null",
            "package",
            "private",
            "protected",
            "public",
            "return",
            "short",
            "static",
            "strictfp",
            "super",
            "switch",
            "synchronized",
            "this",
            "throw",
            "throws",
            "trait",
            "transient",
            "try",
            "void",
            "volatile",
            "while",
        }
    )
    allows_empty_call_parens = True
    supports_dotted_call_stub = True
    call_returns_expression = True
    supports_json_call_result_binding = False
    supports_zero_parameter_calls = True
    max_call_parameters = NO_CALL_PARAMETER_LIMIT
    supports_inline_multiline_dict_args = True
    supports_standalone_comments_in_wrapped_calls = True
    supports_multi_param_call_wrapper_stub = False
    supports_dict_literal_as_free_expression = True
    supports_module_name = False
    supports_empty_dict_key = False
    supports_call_style = True
    supports_default_dict_key_type = False
    supports_default_dict_value_type = False
    supports_default_sequence_element_type = False
    supports_default_set_element_type = True
    supports_default_ordered_map_value_type = False
    json_type_variant_name_suffix: ClassVar[str | None] = None
    supports_non_ascii_string_literals = True
    supports_multiline_string_literals = True
    supports_empty_sibling_sequence_type_hints = True
    supports_typed_dict_open = False
    language_id: ClassVar[str] = "groovy"
    variant_metadata: ClassVar[VariantMetadata] = VariantMetadata(
        round_trip_capabilities=frozenset(
            {
                RoundTripCapability.I64_BOUNDARIES,
                RoundTripCapability.INTERPOLATION_STRINGS,
                RoundTripCapability.EMBEDDED_NUL,
            }
        ),
        modifier_sequence_format_overrides={},
        string_literals_escape_null_byte=True,
        supports_ref_elements_in_tuple_strategy=False,
    )
    supports_record_struct_name_prefix = False
    supports_record_shape_names = False
    record_shape_names_emit_declarations = False
    supports_non_string_dict_keys = True
    checks_raw_control_dict_keys_separately = False

    format_call_arg: ClassVar["staticmethod[[Value, str], str]"] = (
        staticmethod(
            identity_call_arg,
        )
    )
    """Callable that rewrites a formatted direct call argument."""

    class DateFormats(DateFormatEnum):
        """Date format options for Groovy."""

        _value_: DateFormatConfig

        ISO = DateFormatConfig(
            formatter=format_date_iso, type_produced=str, preamble_lines=()
        )
        GROOVY = DateFormatConfig(
            formatter=date_ymd_formatter(
                template="java.time.LocalDate.of({year}, {month}, {day})",
            ),
            type_produced=datetime.date,
            preamble_lines=(),
        )

    class DatetimeFormats(DatetimeFormatEnum):
        """Datetime format options for Groovy."""

        _value_: DatetimeFormatConfig

        ISO = DatetimeFormatConfig(
            formatter=format_datetime_iso,
            type_produced=str,
            preamble_lines=(),
        )

        EPOCH = DatetimeFormatConfig(
            formatter=format_datetime_epoch,
            type_produced=int,
            preamble_lines=(),
        )

    class BytesFormats(enum.Enum):
        """Bytes formatting options."""

        _value_: Callable[[bytes], str]

        HEX = enum.member(value=format_bytes_hex)
        BASE64 = enum.member(value=format_bytes_base64)

        def __call__(self, data: bytes, /) -> str:
            """Format bytes."""
            return self._value_(data)

    class SequenceFormats(enum.Enum):
        """Sequence type options for Groovy."""

        LIST = SequenceFormatConfig(
            sequence_open=fixed_open(open_str="["),
            close="]",
            supports_heterogeneity=True,
            single_element_trailing_comma=False,
            single_element_template=None,
            supports_trailing_comma=True,
            empty_sequence=None,
            preamble_lines=(),
            format_entry=passthrough_sequence_entry,
            typed_opener_fallback=None,
            uses_typed_literal_for_scalars=False,
            requires_uniform_record_shapes=False,
            declared_type=None,
            narrowed_empty_form=None,
        )

    class SetFormats(enum.Enum):
        """Set type options for Groovy."""

        _value_: Callable[[str], SetFormatConfig]

        SET = enum.member(
            value=set_format_factory(
                open_template="[",
                close="] as Set<{type}>",
                empty_template="[] as Set<{type}>",
                preamble_lines=(),
                set_opener_template="",
                supports_heterogeneity=True,
                supports_trailing_comma=True,
            )
        )

        def __call__(self, default_type: str) -> SetFormatConfig:
            """Create a set format config for the given type."""
            return self._value_(default_type)

    class CommentFormats(enum.Enum):
        """Comment style options."""

        DOUBLE_SLASH = CommentConfig(
            prefix="//",
            suffix="",
        )
        BLOCK = CommentConfig(
            prefix="/*",
            suffix=" */",
        )

    class DeclarationStyles(enum.Enum):
        """Declaration style options."""

        DEF = DeclarationStyleConfig(
            formatter=variable_declaration_formatter(
                template="def {name} = {value}"
            ),
            supports_redefinition=True,
        )

    class DictEntryStyles(enum.Enum):
        """Dict entry style options."""

        DEFAULT = enum.auto()

    class DictFormats(enum.Enum):
        """Dict/map format options."""

        DEFAULT = enum.auto()

    class EmptyDictKey(enum.Enum):
        """Empty dict key options."""

        ALLOW = enum.auto()

    class FloatFormats(
        FloatSpecialsMixin,
        enum.Enum,
        positive_infinity="Double.POSITIVE_INFINITY",
        negative_infinity="Double.NEGATIVE_INFINITY",
        nan="Double.NaN",
    ):
        """Float format options."""

        REPR = enum.member(value=_format_float_repr)
        SCIENTIFIC = enum.member(value=_format_float_scientific)
        FIXED = enum.member(value=_format_float_fixed)

    class IntegerFormats(enum.Enum):
        """Integer format options."""

        DECIMAL = enum.auto()

    class NumericLiteralSuffixes(enum.Enum):
        """Numeric literal suffix options."""

        NONE = enum.auto()

    class NumericSeparators(enum.Enum):
        """Numeric separator options."""

        NONE = enum.auto()

    class NumericStyles(enum.Enum):
        """Numeric literal style options."""

        OVERLOADED = enum.auto()

    class StringFormats(enum.Enum):
        """String format options."""

        _value_: Callable[[str], str]

        DOUBLE = enum.member(value=format_string_backslash_dollar_nul_unicode)
        MULTILINE = enum.member(value=_format_string_multiline)

        def __call__(self, value: str, /) -> str:
            """Format a string."""
            return self._value_(value)

    class TrailingCommas(enum.Enum):
        """Trailing comma options."""

        YES = TrailingCommaConfig(multiline_trailing_comma=True)
        NO = TrailingCommaConfig(multiline_trailing_comma=False)

    date_formats = DateFormats
    datetime_formats = DatetimeFormats
    bytes_formats = BytesFormats
    sequence_formats = SequenceFormats
    set_formats = SetFormats
    comment_formats = CommentFormats

    class VariableTypeHints(enum.Enum):
        """Variable type hint options."""

        NEVER = enum.auto()
        SAFE = enum.auto()

    variable_type_hints_formats = VariableTypeHints
    declaration_styles = DeclarationStyles
    dict_entry_styles = DictEntryStyles
    dict_formats = DictFormats
    empty_dict_keys = EmptyDictKey
    float_formats = FloatFormats
    integer_formats = IntegerFormats
    integer_width_strategies = BareIntegerWidthStrategies
    numeric_literal_suffixes = NumericLiteralSuffixes
    numeric_separators = NumericSeparators
    numeric_styles = NumericStyles
    string_formats = StringFormats
    trailing_commas = TrailingCommas

    class StatementTerminatorStyles(enum.Enum):
        """Statement terminator options."""

        SEMICOLON = enum.auto()

    statement_terminator_styles = StatementTerminatorStyles

    class CallStyles(enum.Enum):
        """Groovy call style options."""

        KEYWORD = KeywordCallStyle(separator=": ")
        POSITIONAL = PositionalCallStyle(
            arg_separator=", ", parenthesize_each_arg=False
        )

    call_styles = CallStyles

    class Modifiers(enum.Enum):
        """C++/Java/C#-style declaration modifiers: this language has none."""

    modifiers = Modifiers

    class HeterogeneousStrategies(enum.Enum):
        """Heterogeneous-scalar strategy options — this language only
        supports raising.
        """

        ERROR = NO_HETEROGENEOUS_BEHAVIOR

    heterogeneous_strategies = HeterogeneousStrategies

    class JsonTypes(JsonType):
        """Empty: this language has no JSON value-type variants."""

    json_types = JsonTypes

    class BoolFormats(enum.Enum):
        """Empty: this language has no alternative boolean formats."""

    bool_formats = BoolFormats

    class VersionFormats(enum.Enum):
        """Version options for Groovy."""

        V4 = enum.auto()

    version_formats = VersionFormats

    modifier_combinations: ClassVar[tuple[ModifierCombination, ...]] = ()
    identifier_cases: ClassVar[tuple[IdentifierCase, ...]] = (
        IdentifierCase.CAMEL,
        IdentifierCase.PASCAL,
        IdentifierCase.UPPER_SNAKE,
    )
    supported_ref_cases: ClassVar[frozenset[IdentifierCase]] = (
        NON_KEBAB_REF_CASES
    )

    validate_spec_for_data = no_validate_spec_for_data

    @cached_property
    def validate_call_arg(self) -> Callable[[Value], None]:
        """Return call-argument validation for this language."""
        return no_validate_call_arg

    @cached_property
    def format_call_statement(self) -> Callable[[str], str]:
        """Return call-statement formatting for this language."""
        return identity_call_statement

    wrap_calls_with_declarations = default_wrap_calls_with_declarations

    @staticmethod
    def wrap_in_file(
        content: str,
        variable_name: str,
        body_preamble: tuple[str, ...],
    ) -> str:
        """Wrap code in a valid file (no-op)."""
        return wrap_in_file_noop(
            content=content,
            variable_name=variable_name,
            body_preamble=body_preamble,
        )

    @staticmethod
    def wrap_combined_in_file(
        declaration: str,
        assignment: str,
        variable_name: str,
        body_preamble: tuple[str, ...],
    ) -> str:
        """Wrap declaration and assignment in a valid file (no-op)."""
        return wrap_combined_in_file_noop(
            declaration=declaration,
            assignment=assignment,
            variable_name=variable_name,
            body_preamble=body_preamble,
        )

    date_format: DateFormats = DateFormats.GROOVY
    datetime_format: DatetimeFormats = DatetimeFormats.ISO
    bytes_format: BytesFormats = BytesFormats.HEX
    sequence_format: SequenceFormats = SequenceFormats.LIST
    set_format: SetFormats = SetFormats.SET
    default_set_element_type: str = "Object"
    variable_type_hints: VariableTypeHints = VariableTypeHints.NEVER
    comment_format: CommentFormats = CommentFormats.DOUBLE_SLASH
    declaration_style: DeclarationStyles = DeclarationStyles.DEF
    dict_entry_style: DictEntryStyles = DictEntryStyles.DEFAULT
    dict_format: DictFormats = DictFormats.DEFAULT
    float_format: FloatFormats = FloatFormats.REPR
    integer_format: IntegerFormats = IntegerFormats.DECIMAL
    integer_width_strategy: BareIntegerWidthStrategies = (
        BareIntegerWidthStrategies.BARE
    )
    numeric_literal_suffix: NumericLiteralSuffixes = (
        NumericLiteralSuffixes.NONE
    )
    numeric_separator: NumericSeparators = NumericSeparators.NONE
    numeric_style: NumericStyles = NumericStyles.OVERLOADED
    string_format: StringFormats = StringFormats.DOUBLE
    trailing_comma: TrailingCommas = TrailingCommas.YES
    statement_terminator_style: StatementTerminatorStyles = (
        StatementTerminatorStyles.SEMICOLON
    )
    call_style: CallStyles = CallStyles.KEYWORD
    heterogeneous_strategy: HeterogeneousStrategies = (
        HeterogeneousStrategies.ERROR
    )
    # Keep in sync with the Apache Groovy binary distribution downloaded
    # in the ``Install Groovy`` step of ``.github/workflows/lint.yml``.
    # The Ubuntu ``groovy`` apt package is Groovy 2.4.x (``< V4``), so
    # the pinned binary distribution is the only mechanism for
    # installing a Groovy ``>= V4``; ``V4`` maps to the pinned
    # ``4.0.32`` release.
    language_version: VersionFormats = VersionFormats.V4
    indent: str = "    "

    null_literal: ClassVar[str] = "null"
    true_literal: ClassVar[str] = "true"
    false_literal: ClassVar[str] = "false"
    indent_closing_delimiter: ClassVar[bool] = False
    element_separator: ClassVar[str] = ", "
    skip_null_dict_values: ClassVar[bool] = False
    supports_collection_comments: ClassVar[bool] = True
    supports_scalar_before_comments: ClassVar[bool] = True
    supports_scalar_inline_comments: ClassVar[bool] = True
    statement_terminator: ClassVar[str] = ""
    static_preamble: ClassVar[Sequence[str]] = ()
    static_body_preamble: ClassVar[Sequence[str]] = ()
    special_float_preamble: ClassVar[tuple[str, ...]] = ()

    @cached_property
    def format_integer(self) -> Callable[[int], str]:
        """Format an int value as a literal."""
        return str

    @cached_property
    def format_string(self) -> Callable[[str], str]:
        """Format a string value as a quoted literal."""
        return self.string_format

    @cached_property
    def format_sequence_entry(self) -> Callable[[Value, str], str]:
        """Format a sequence entry."""
        return passthrough_sequence_entry

    @cached_property
    def format_set_entry(self) -> Callable[[Value, str], str]:
        """Format a set entry."""
        return passthrough_set_entry

    @cached_property
    def data_dependent_preamble(self) -> Callable[[Value], tuple[str, ...]]:
        """Return data-dependent preamble lines."""
        return no_data_preamble

    @cached_property
    def heterogeneous_behavior(self) -> HeterogeneousBehavior:
        """Return the heterogeneous-behavior config."""
        return self.heterogeneous_strategy.value

    @cached_property
    def call_data_dependent_preamble(
        self,
    ) -> Callable[[Value], tuple[str, ...]]:
        """Return data-dependent preamble lines for call rendering."""
        return self.data_dependent_preamble

    @cached_property
    def type_hint_collection_preamble_lines(
        self,
    ) -> Callable[[frozenset[type]], tuple[str, ...]]:
        """Return preamble lines for empty-collection type hints."""
        return no_type_hint_preamble

    @cached_property
    def format_call_stub(
        self,
    ) -> Callable[
        [Sequence[str], Sequence[str], StubReturn, Sequence[Value]],
        tuple[str, ...],
    ]:
        """Return stub declarations for a call expression."""
        return _groovy_call_stub_factory(
            keyword_style=isinstance(self.call_style.value, KeywordCallStyle),
        )

    @cached_property
    def format_call_preamble_stub(
        self,
    ) -> Callable[
        [Sequence[str], Sequence[str], StubReturn, Sequence[Value]],
        tuple[str, ...],
    ]:
        """Return file-scope stubs for a call expression."""
        return no_call_stub

    @cached_property
    def format_call_target(self) -> Callable[[Sequence[str]], str]:
        """Rewrite a dotted call target into the language's call
        syntax.
        """
        return identity_call_target

    @cached_property
    def format_call_ref_identifier(
        self,
    ) -> Callable[[str, Value | None], str]:
        """Rewrite a ``{"$ref": "name"}`` identifier into the
        language's call expression syntax.
        """
        return identity_call_ref_identifier

    @cached_property
    def format_call_arg_ref_identifier(
        self,
    ) -> Callable[[str, Value | None], str]:
        """Rewrite a ``{"$ref": "name"}`` identifier in a call-argument
        context.

        Delegates to :attr:`format_call_ref_identifier`.  Override this to
        allow call-argument ``$ref`` values that would otherwise be rejected.
        """
        return self.format_call_ref_identifier

    @cached_property
    def format_call_arg_ref_identifier_consumable(
        self,
    ) -> Callable[[str, Value | None], str]:
        """Format a ``$ref`` the caller authorized as consumable.

        Delegates to :attr:`format_call_arg_ref_identifier`.  Override
        this to opt into a consuming form (e.g. C++ ``std::move``).
        """
        return self.format_call_arg_ref_identifier

    @cached_property
    def consumable_ref_value_inhibits_consuming_form(
        self,
    ) -> Callable[[Value], bool]:
        """Predicate deciding whether a ref's underlying value type
        inhibits the consume form.

        Delegates to :data:`never_inhibits_consuming_form`.  Languages
        whose consume operator rejects certain value types (notably
        the Mojo ``^`` on register-trivial scalars) override this.
        """
        return never_inhibits_consuming_form

    @cached_property
    def sequence_format_config(self) -> SequenceFormatConfig:
        """Configuration for the chosen sequence format."""
        return self.sequence_format.value

    @cached_property
    def set_format_config(self) -> SetFormatConfig:
        """Configuration for the chosen set format."""
        return self.set_format(default_type=self.default_set_element_type)

    @cached_property
    def sequence_open(self) -> Callable[[list[Value]], str]:
        """Callable that returns the opening delimiter for a sequence."""
        return self.sequence_format.value.sequence_open

    @cached_property
    def dict_format_config(self) -> DictFormatConfig:
        """Configuration for dict formatting."""
        return _GroovyDictFormatConfig(
            dict_open=fixed_open(open_str="["),
            close="]",
            format_entry=DictEntryWithSeparator(
                separator=": ",
                format_value=passthrough_sequence_entry,
            ),
            empty_dict="[:]",
            preamble_lines=(),
            narrowed_open=None,
            supports_trailing_comma=True,
            narrowed_empty_form=None,
            native_dates=(
                self.date_format.value.type_produced is datetime.date
            ),
        )

    @cached_property
    def trailing_comma_config(self) -> TrailingCommaConfig:
        """Configuration for trailing-comma behavior."""
        return self.trailing_comma.value

    @cached_property
    def format_bytes(self) -> Callable[[bytes], str]:
        """Callable that formats a bytes value as a string literal."""
        return self.bytes_format

    @cached_property
    def format_date(self) -> Callable[[datetime.date], str]:
        """Callable that formats a date as a string literal."""
        return self.date_format

    @cached_property
    def format_datetime(self) -> Callable[[datetime.datetime], str]:
        """Callable that formats a datetime as a string literal."""
        return self.datetime_format

    @cached_property
    def format_time(self) -> Callable[[datetime.time], str]:
        """Callable that formats a time as a string literal."""
        return format_time_local_time_of

    @cached_property
    def format_float(self) -> Callable[[float], str]:
        """Callable that formats a float value as a literal."""
        return self.float_format

    @cached_property
    def comment_config(self) -> CommentConfig:
        """Configuration for the language's comment syntax."""
        return self.comment_format.value

    @cached_property
    def ordered_map_format_config(self) -> OrderedMapFormatConfig:
        """Configuration for ordered-map formatting."""
        return _GroovyOrderedMapFormatConfig(
            ordered_map_open=fixed_open(open_str="["),
            close="]",
            preamble_lines=(),
            native_dates=(
                self.date_format.value.type_produced is datetime.date
            ),
        )

    @cached_property
    def format_ordered_map_entry(self) -> Callable[[str, Value, str], str]:
        """Callable that formats one ordered-map entry."""
        return DictEntryWithSeparator(
            separator=": ",
            format_value=passthrough_sequence_entry,
        )

    @cached_property
    def format_variable_declaration(
        self,
    ) -> Callable[[str, str, Value, frozenset[enum.Enum]], str]:
        """Callable that formats a new variable declaration."""
        return self.declaration_style.value.formatter

    @cached_property
    def format_variable_assignment(
        self,
    ) -> Callable[[str, str, Value], str]:
        """Callable that formats an assignment to an existing variable."""
        return variable_formatter(template="{name} = {value}")

    @cached_property
    def scalar_preamble(self) -> dict[type, tuple[str, ...]]:
        """Per-instance scalar preamble."""
        return {datetime.time: ("import java.time.LocalTime",)}

    @cached_property
    def scalar_body_preamble(self) -> dict[type, tuple[str, ...]]:
        """Per-instance scalar body preamble (Groovy needs none)."""
        return {}

    @cached_property
    def compute_body_preamble(
        self,
    ) -> Callable[[frozenset[type], Value], tuple[str, ...]]:
        """Compute body-preamble lines from the scalar map."""
        return body_preamble_from_scalars(
            scalar_body_preamble=self.scalar_body_preamble,
            format_lines=tuple,
        )

    @cached_property
    def call_style_config(self) -> CallStyle:
        """Configuration for the chosen call style."""
        config: CallStyle = self.call_style.value
        return config
