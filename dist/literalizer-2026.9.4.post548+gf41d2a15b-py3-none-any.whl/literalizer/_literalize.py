"""Core conversion logic: formatting values and entry points."""

import dataclasses
import datetime
import enum
import re
from collections.abc import Callable, Iterable, Mapping, Sequence
from contextlib import suppress
from typing import (
    Final,
    Protocol,
    TypeGuard,
    assert_never,
    overload,
    runtime_checkable,
)

from beartype import BeartypeConf, beartype
from ruamel.yaml.comments import (
    CommentedMap,
    CommentedSeq,
    CommentedSet,
    TaggedScalar,
)
from tomlkit.toml_document import TOMLDocument
from typing_extensions import TypeIs

from literalizer._checks import check_data
from literalizer._comments import (
    CollectionComments,
    ElementComments,
    apply_collection_comments_to_elements,
    extract_toml_comments,
    extract_yaml_comments,
    neutralize_inline_comment,
    prepend_collection_comments,
)
from literalizer._comments_resolve import (
    ResolvedComments,
    resolve_toml_comments,
    resolve_yaml_comments,
)
from literalizer._document_formatting import format_document_fast
from literalizer._formatters.fallbacks import collection_or_default
from literalizer._formatters.type_inference import (
    BeyondI64,
    DictType,
    MixedNumeric,
    WideInt,
    infer_element_type,
    int_widening_tier,
    record_shape_for_dict,
    set_sort_key,
)
from literalizer._language import (
    CallParameterShadowing,
    CallStyle,
    CallSupport,
    CollectionLayout,
    CommandCallStyle,
    DottedCommandCallStyle,
    FileSection,
    IdentifierCase,
    KeywordCallStyle,
    Language,
    LanguageCls,
    ObjectCallStyle,
    PositionalCallStyle,
    PostfixCallStyle,
    PrefixCallStyle,
    StubReturn,
    decode_file_sections,
    is_reserved_identifier,
    validate_call_parameter_names,
    validate_new_variable_name,
)
from literalizer._parsing import (
    InputFormat,
    ParsedInput,
    ParsedToml,
    ParsedYaml,
    parse_input,
    recursion_parse_error,
    reject_excessive_integer_digits,
    unwrap_yaml_scalar,
)
from literalizer._preamble import (
    compute_preamble,
    deduplicate_preamble_entries,
)
from literalizer._types import (
    CallPreambleData,
    OrderedMap,
    Scalar,
    Value,
    ValueInput,
    ValueItemsMap,
)
from literalizer.exceptions import (
    CallsNotSupportedByLanguageError,
    CallsNotSupportedByToolError,
    CommentSourceLengthMismatchError,
    CommentSourceMultilineError,
    CommentSourceNulError,
    DottedCallTargetNotSupportedError,
    ExistingVariableNotSelfContainedError,
    InvalidCallParameterNameError,
    InvalidCallTargetError,
    InvalidValueInputError,
    LiteralizerError,
    ParameterCountMismatchError,
    PerElementNotListError,
    RefNotSelfContainedError,
    RefOutputCollisionError,
    UnrepresentableInputError,
    UnsupportedCallShapeError,
    UnsupportedIdentifierCaseError,
    VariableNameNotSupportedError,
    ZipInputFormatWithoutSourceError,
    ZipSourceWithoutInputFormatError,
    ZipValuesLengthMismatchError,
    ZipValuesWithoutCallTransformError,
)


@runtime_checkable
class _SupportsCallVariableWrapInFile(Protocol):
    """A language with a call-binding-specific ``wrap_in_file``.

    Used when a language's literal-binding file scaffold cannot host a
    call-result binding (e.g. Elm's top-level ``name : Val`` form
    versus a call-mode ``Check.main`` entry point).
    """

    def wrap_call_variable_in_file(
        self,
        content: str,
        variable_name: str,
        body_preamble: tuple[str, ...],
    ) -> str:
        """Wrap a call-result variable binding in a complete file."""
        ...  # pylint: disable=unnecessary-ellipsis


@runtime_checkable
class _HasCallWrapperEntrypoint(Protocol):
    """A language whose complete-file call wrapper declares an
    entry point.
    """

    @property
    def call_wrapper_entrypoint_name(self) -> str:
        """Return the identifier reserved by the generated wrapper."""
        ...  # pylint: disable=unnecessary-ellipsis


@runtime_checkable
class _RequiresUniqueDottedCallParts(Protocol):
    """A language whose dotted-call helpers are named from path
    segments.
    """

    @property
    def dotted_call_stub_requires_unique_parts(self) -> bool:
        """Return whether repeated path segments collide in the
        scaffold.
        """
        ...  # pylint: disable=unnecessary-ellipsis


@runtime_checkable
class _NormalizesDottedCallPartCase(Protocol):
    """A language whose dotted-call helper names fold component case."""

    @property
    def dotted_call_stub_normalizes_part_case(self) -> bool:
        """Return whether helper naming normalizes component case."""
        ...  # pylint: disable=unnecessary-ellipsis


class _DisabledRefKey(str):
    """Identity sentinel distinct from an explicitly enabled empty key."""

    __slots__ = ()


_DISABLED_REF_KEY = _DisabledRefKey()


@beartype
def disabled_ref_key() -> str:
    """Return the internal marker for disabled reference detection."""
    return _DISABLED_REF_KEY


@beartype
@dataclasses.dataclass(frozen=True)
class CallContext:
    """Per-row context passed to a :func:`literalize_call`
    ``call_transform``.

    A ``call_transform`` is invoked once per generated call as
    ``call_transform(context)`` and returns the transformed call
    string.  The context carries the call's positional identity so a
    transform can pair it with data from a parallel source (see
    :func:`literalize_call`'s ``zip_source``).
    """

    call: str
    """The rendered language-native call expression
    (e.g. ``catalog.lookup("Dune", 1965)``).
    """

    index: int
    """Zero-based position of this call among the generated calls."""

    row: Sequence[Value]
    """The input values for this row, in source order.  For
    ``per_element=True`` this is the top-level element at position
    ``index``, as its argument values; for ``per_element=False`` it is
    the whole parsed value wrapped in a single-element sequence.
    """

    zipped: str | None
    """The ``zip_source`` element paired with this call, rendered as a
    language-native literal, or ``None`` when no ``zip_source`` was
    supplied.
    """


@beartype
@dataclasses.dataclass(frozen=True)
class LiteralizeResult:
    """Result of converting data to a native language literal."""

    declaration_code: str
    """The variable declaration or assignment text, without any
    :attr:`body_preamble` or :attr:`pre_declaration_comments` lines.

    Use :attr:`code` for the full formatted text including all prefix
    lines.
    """

    preamble: tuple[str, ...]
    """Lines (imports, package declarations, etc.) that must precede
    the generated code.  Empty when none are needed.
    """

    body_preamble: tuple[str, ...]
    """Type-definition lines (e.g. F#'s ``type Val = …``, Haskell's
    ``data Val = …`` and typeclass instances) that are prepended to
    :attr:`code`.  Empty when none are needed.

    Use :attr:`bare_code` to obtain the literal text *without* these
    lines.
    """

    pre_declaration_comments: tuple[str, ...]
    """Already-formatted comment lines that appear between
    :attr:`body_preamble` and the variable declaration/assignment in
    :attr:`code`.  These come from scalar before-comments when the
    language does not support them inline.

    Included in :attr:`bare_code` but excluded from
    :attr:`declaration_code`.
    """

    types_present: frozenset[type]
    """The set of Python types observed in the source data (e.g.
    ``int``, ``str``, ``list``, ``dict``).  Callers that combine
    multiple ``literalize`` results (for example, a test harness that
    pairs ``$ref`` declarations with a downstream call) can union
    these and re-invoke :attr:`Language.compute_body_preamble` to
    derive a single body preamble that covers every type referenced
    across the combined output.
    """

    contains_standalone_comments: bool
    """Whether the rendered source carried standalone comments (lines
    whose only content is a comment, distinct from inline trailing
    comments).  Set when ``literalize_call`` parses YAML input that
    contains top-level before-element or trailing comments.  Callers
    that wrap the result via :meth:`Language.wrap_calls_with_declarations`
    can consult this together with
    :attr:`Language.supports_standalone_comments_in_wrapped_calls`
    to decide whether wrapping is safe.
    """

    source_data: Value
    """The parsed source value the literal was rendered from.  Most
    callers do not need it.  Callers that combine multiple
    ``literalize`` results and re-invoke
    :attr:`Language.compute_body_preamble` to derive a single body
    preamble surface this so the second call can inspect the actual
    values (e.g. datetime microsecond precision) rather than a
    placeholder.
    """

    sections: tuple[FileSection, ...]
    """For multi-section languages, the rendered output split into its
    file regions; empty for the single-section common case.

    A few languages cannot express a value as one drop-in fragment:
    their output spans more than one region of a source file that a
    wrapping template must place separately.  COBOL under
    ``json_type=CJSON`` is the current example, emitting a
    ``WORKING-STORAGE`` region of declarations and a ``PROCEDURE`` region
    of statements.

    Only populated when ``wrap_in_file=False`` (with ``wrap_in_file=True``
    the language has already composed the regions into a complete file).
    When non-empty, compose these :class:`FileSection` regions into your
    own template; :attr:`code` / :attr:`declaration_code` then hold an
    opaque marker-bracketed payload (the form the language's wrappers
    consume), not usable source.  Empty for almost every language; use
    :attr:`code` then.
    """

    data_dependent_preamble: tuple[str, ...]
    """The entries within :attr:`preamble` that were inferred from the
    rendered data itself.

    Composition helpers use this metadata to replace independently
    inferred declaration and call blocks with one block covering every
    value emitted into the composed file.  Empty when the preamble has
    already been folded into a complete file.
    """

    @property
    def code(self) -> str:
        """The formatted literal text.

        When a language defines ``scalar_body_preamble`` entries (e.g.
        Haskell typeclass instances), those lines are prepended to the
        code so they appear in the correct structural position.
        """
        all_prefix_lines = (
            *self.body_preamble,
            *self.pre_declaration_comments,
        )
        if len(all_prefix_lines) == 0:
            return self.declaration_code
        return "\n".join(all_prefix_lines) + "\n" + self.declaration_code

    @property
    def bare_code(self) -> str:
        """The literal text without :attr:`body_preamble` prepended.

        Identical to :attr:`code` when :attr:`body_preamble` is empty.
        :attr:`pre_declaration_comments` are preserved.
        """
        if len(self.pre_declaration_comments) == 0:
            return self.declaration_code
        return (
            "\n".join(self.pre_declaration_comments)
            + "\n"
            + self.declaration_code
        )


@beartype
@dataclasses.dataclass(frozen=True)
class NewVariable:
    """Wrap output in a new variable declaration."""

    name: str
    modifiers: frozenset[enum.Enum]
    """Declaration modifiers to apply.  Each language exposes its own
    modifier enum as ``Language.Modifiers`` (e.g. ``Java.Modifiers.FINAL``,
    ``CSharp.Modifiers.READONLY``, ``Cpp.Modifiers.STATIC``).  Values
    must be members of the target language's ``Modifiers`` enum.
    """


@beartype
@dataclasses.dataclass(frozen=True)
class ExistingVariable:
    """Wrap output in an assignment to an existing variable.

    The name must be a non-reserved identifier accepted by the target
    language; assignment expressions such as ``obj.field`` are not accepted.
    """

    name: str


@beartype
@dataclasses.dataclass(frozen=True)
class BothVariableForms:
    """Produce both a declaration and an assignment, combined.

    Requires ``wrap_in_file=True`` on :func:`literalize`.
    """

    name: str
    modifiers: frozenset[enum.Enum]
    """Declaration modifiers applied to the declaration half.  See
    :attr:`NewVariable.modifiers`.
    """


VariableForm = NewVariable | ExistingVariable | BothVariableForms


@beartype
def _format_scalar_integer(
    *, value: int, spec: Language, int_formatter: Callable[[int], str] | None
) -> str:
    """Format an integer with the selected collection override."""
    reject_excessive_integer_digits(value=value)
    format_int = int_formatter
    if format_int is None:
        format_int = spec.format_integer
    return format_int(value)


@beartype
def _format_scalar(
    *,
    value: Scalar,
    spec: Language,
    int_formatter: Callable[[int], str] | None,
) -> str:
    """Format a scalar JSON value as a native language literal.

    *int_formatter* overrides ``spec.format_integer`` when given; the
    collection formatter passes a widened formatter (e.g. one that
    always appends an ``L`` suffix) when the surrounding collection's
    inferred element type required widening for some other element.
    """
    match value:
        case None:
            result = spec.null_literal
        case bool():
            result = {True: spec.true_literal, False: spec.false_literal}[
                value
            ]
        case int():
            result = _format_scalar_integer(
                value=value, spec=spec, int_formatter=int_formatter
            )
        case float():
            result = spec.format_float(value)
        case str():
            result = spec.format_string(value)
        case bytes():
            result = spec.format_bytes(value)
        case datetime.datetime():
            result = spec.format_datetime(value)
        case datetime.time():
            result = spec.format_time(value)
        case _:
            result = spec.format_date(value)
    return result


@runtime_checkable
class _MixedNumericIntegerFormatter(Protocol):
    """Optional capability for typed integer literal backends."""

    @property
    def format_integer_in_mixed_numeric_collection(
        self,
    ) -> Callable[[int], str] | None:
        """Return the integer formatter for a float-widened collection."""
        ...  # pylint: disable=unnecessary-ellipsis


@beartype
def _widened_int_formatter(
    *,
    items: list[Value],
    spec: Language,
) -> Callable[[int], str] | None:
    """Return a widened integer formatter for *items* or ``None``.

    Returns ``None`` when *items* do not require widening or when the
    language has no matching widened formatter (it resolves to
    ``None``).  A collection whose integer values exceed signed 64-bit
    range uses :attr:`~Language.format_integer_beyond_i64`; one whose
    integer values only exceed signed 32-bit range uses
    :attr:`~Language.format_integer_widened`.

    Languages without either widened formatter (e.g. Python) return
    immediately so list/map formatting does not pay for a width scan.
    Otherwise :func:`int_widening_tier` selects the tier without full
    element-type inference.
    """
    mixed_numeric = None
    if isinstance(spec, _MixedNumericIntegerFormatter):
        mixed_numeric = spec.format_integer_in_mixed_numeric_collection
    if (
        mixed_numeric is not None
        and infer_element_type(items=items) is MixedNumeric
    ):
        return mixed_numeric
    beyond = spec.format_integer_beyond_i64
    widened = spec.format_integer_widened
    if beyond is None and widened is None:
        return None
    tier = int_widening_tier(items=items)
    if tier is BeyondI64:
        return beyond
    if tier is WideInt:
        return widened
    return None


@beartype
def _map_widened_int_formatter(
    *,
    items: list[Value],
    spec: Language,
) -> Callable[[int], str] | None:
    """Return the pooled integer formatter for a map's values.

    A language whose map value slot is a boxed ``Object`` gives each
    value its own type, so there is nothing to pool and a mixed-width
    document renders each value on its own terms (issue #4488).
    """
    if not spec.pools_map_integer_width:
        return None
    return _widened_int_formatter(items=items, spec=spec)


@beartype
def _sibling_list_groups(data: Value) -> list[list[list[Value]]]:
    """Return direct sibling-list families belonging to *data*."""
    if isinstance(data, dict):
        return [[value for value in data.values() if isinstance(value, list)]]
    if not isinstance(data, list):
        return []
    groups = [[value for value in data if isinstance(value, list)]]
    dicts: list[dict[Scalar, Value]] = [
        value for value in data if isinstance(value, dict)
    ]
    keys = {key for value in dicts for key in value}
    for key in keys:
        group: list[list[Value]] = []
        for value in dicts:
            candidate = value.get(key)
            if isinstance(candidate, list):
                group.append(candidate)
        groups.append(group)
    return groups


@beartype
def _record_list_int_formatter(
    *,
    lists: list[list[Value]],
    spec: Language,
    out: dict[int, Callable[[int], str]],
) -> None:
    """Give compatible sibling lists one pooled integer width."""
    minimum_siblings = 2
    if len(lists) < minimum_siblings:
        return
    formatter = _widened_int_formatter(
        items=[item for values in lists for item in values],
        spec=spec,
    )
    if formatter is not None:
        out.update({id(values): formatter for values in lists})


@beartype
def _accumulate_list_int_formatters(
    *,
    data: Value,
    spec: Language,
    out: dict[int, Callable[[int], str]],
) -> None:
    """Record widened integer formatters below *data*."""
    for group in _sibling_list_groups(data=data):
        _record_list_int_formatter(lists=group, spec=spec, out=out)
    children: Sequence[Value]
    match data:
        case dict():
            children = list(data.values())
        case list() | set():
            children = list(data)
        case _:
            return
    for value in children:
        _accumulate_list_int_formatters(data=value, spec=spec, out=out)


@beartype
def _collect_list_int_formatters(
    *, data: Value, spec: Language
) -> dict[int, Callable[[int], str]]:
    """Return widened integer formatters for sibling inner lists."""
    if (
        spec.format_integer_beyond_i64 is None
        and spec.format_integer_widened is None
    ):
        return {}
    out: dict[int, Callable[[int], str]] = {}
    _accumulate_list_int_formatters(data=data, spec=spec, out=out)
    return out


_SCALAR_TYPES: Final = (
    str,
    int,
    float,
    bool,
    type(None),
    datetime.date,
    datetime.datetime,
    datetime.time,
    bytes,
)


@beartype
@dataclasses.dataclass(frozen=True, slots=True)
class _RenderContext:
    """State shared by recursive formatter calls."""

    spec: Language
    wrap_ids: frozenset[int]
    tuple_list_ids: frozenset[int]
    dict_open_overrides: Mapping[int, str]
    dict_int_formatters: Mapping[int, Callable[[int], str]]
    empty_container_overrides: Mapping[int, str]
    list_int_formatters: Mapping[int, Callable[[int], str]]
    ref_case: IdentifierCase | None
    ref_values: Mapping[str, Value] | None
    expand_refs: bool
    ref_key: str
    collection_layout: CollectionLayout
    multiline_prefix: str
    consumable_ref_names: frozenset[str]
    single_use_ref_names: frozenset[str]
    consume_inhibited_ref_names: frozenset[str]
    yaml_comment_nodes: Mapping[
        int, CommentedSeq | CommentedMap | CommentedSet
    ]
    # Comments for the TOML document root.  Unlike the YAML nodes these
    # are already extracted, because a tomlkit document is addressed by
    # body position rather than by rendered container (issue #4483).
    toml_comments: CollectionComments | None
    comment_root_id: int | None

    def compact(self) -> "_RenderContext":
        """Return this context with compact collection rendering."""
        if self.collection_layout is CollectionLayout.COMPACT:
            return self
        return _RenderContext(
            spec=self.spec,
            wrap_ids=self.wrap_ids,
            tuple_list_ids=self.tuple_list_ids,
            dict_open_overrides=self.dict_open_overrides,
            dict_int_formatters=self.dict_int_formatters,
            empty_container_overrides=self.empty_container_overrides,
            list_int_formatters=self.list_int_formatters,
            ref_case=self.ref_case,
            ref_values=self.ref_values,
            expand_refs=self.expand_refs,
            ref_key=self.ref_key,
            collection_layout=CollectionLayout.COMPACT,
            multiline_prefix=self.multiline_prefix,
            consumable_ref_names=self.consumable_ref_names,
            single_use_ref_names=self.single_use_ref_names,
            consume_inhibited_ref_names=self.consume_inhibited_ref_names,
            yaml_comment_nodes=self.yaml_comment_nodes,
            toml_comments=self.toml_comments,
            comment_root_id=self.comment_root_id,
        )

    def with_multiline(
        self,
        *,
        multiline_prefix: str,
    ) -> "_RenderContext":
        """Return this context with multiline collection rendering."""
        if (
            self.collection_layout is CollectionLayout.MULTILINE
            and self.multiline_prefix == multiline_prefix
        ):
            return self
        return _RenderContext(
            spec=self.spec,
            wrap_ids=self.wrap_ids,
            tuple_list_ids=self.tuple_list_ids,
            dict_open_overrides=self.dict_open_overrides,
            dict_int_formatters=self.dict_int_formatters,
            empty_container_overrides=self.empty_container_overrides,
            list_int_formatters=self.list_int_formatters,
            ref_case=self.ref_case,
            ref_values=self.ref_values,
            expand_refs=self.expand_refs,
            ref_key=self.ref_key,
            collection_layout=CollectionLayout.MULTILINE,
            multiline_prefix=multiline_prefix,
            consumable_ref_names=self.consumable_ref_names,
            single_use_ref_names=self.single_use_ref_names,
            consume_inhibited_ref_names=self.consume_inhibited_ref_names,
            yaml_comment_nodes=self.yaml_comment_nodes,
            toml_comments=self.toml_comments,
            comment_root_id=self.comment_root_id,
        )

    def with_prefix(self, *, multiline_prefix: str) -> "_RenderContext":
        """Return this context with a different multiline prefix."""
        if self.multiline_prefix == multiline_prefix:
            return self
        return _RenderContext(
            spec=self.spec,
            wrap_ids=self.wrap_ids,
            tuple_list_ids=self.tuple_list_ids,
            dict_open_overrides=self.dict_open_overrides,
            dict_int_formatters=self.dict_int_formatters,
            empty_container_overrides=self.empty_container_overrides,
            list_int_formatters=self.list_int_formatters,
            ref_case=self.ref_case,
            ref_values=self.ref_values,
            expand_refs=self.expand_refs,
            ref_key=self.ref_key,
            collection_layout=self.collection_layout,
            multiline_prefix=multiline_prefix,
            consumable_ref_names=self.consumable_ref_names,
            single_use_ref_names=self.single_use_ref_names,
            consume_inhibited_ref_names=self.consume_inhibited_ref_names,
            yaml_comment_nodes=self.yaml_comment_nodes,
            toml_comments=self.toml_comments,
            comment_root_id=self.comment_root_id,
        )


@beartype
def _nested_collection_context(
    *, value: Value, ctx: _RenderContext
) -> _RenderContext:
    """Keep nested collection payload strings layout-independent."""
    if not isinstance(value, (dict, list, set)):
        return ctx
    language_cls = type(ctx.spec)
    if not isinstance(language_cls, LanguageCls):
        msg = "nested collection rendering requires a LanguageCls language"
        raise TypeError(msg)
    if not language_cls.stringifies_nested_collections:
        return ctx
    return ctx.compact()


@beartype
def _maybe_wrap_child(
    *,
    parent_id: int,
    raw_value: Value,
    formatted_value: str,
    ctx: _RenderContext,
) -> str:
    """Wrap *formatted_value* when *parent_id* is in *wrap_ids*.

    Routes scalar children through
    :attr:`~literalizer._language.HeterogeneousBehavior.wrap_scalar`
    and non-scalar children (ref markers, containers) through
    :attr:`~literalizer._language.HeterogeneousBehavior.wrap_non_scalar`.
    A behavior that wraps only scalars can still wrap a container child
    through
    :attr:`~literalizer._language.HeterogeneousBehavior.wrap_empty_container`
    (Rust's ``TAGGED_ENUM``, issue #3028).
    """
    spec = ctx.spec
    behavior = spec.heterogeneous_behavior
    if isinstance(raw_value, _SCALAR_TYPES):
        wrap_scalar = behavior.wrap_scalar
        if wrap_scalar is None or parent_id not in ctx.wrap_ids:
            return formatted_value
        return wrap_scalar(raw_value, formatted_value)
    wrap_non_scalar = behavior.wrap_non_scalar
    if wrap_non_scalar is not None:
        if parent_id not in ctx.wrap_ids:
            return formatted_value
        return wrap_non_scalar(raw_value, formatted_value)
    wrap_empty_container = behavior.wrap_empty_container
    if wrap_empty_container is not None and parent_id in ctx.wrap_ids:
        # Rust uses this hook for list/map variants alongside wrapped
        # scalars; populated descendants are recursively marked so their
        # children match the enum payload type.
        return wrap_empty_container(raw_value, formatted_value)
    return formatted_value


@beartype
def _compute_wrap_ids(*, data: Value, spec: Language) -> frozenset[int]:
    """Return container ids whose scalar children should be wrapped.

    Delegates to the language spec's
    :attr:`~literalizer._language.HeterogeneousBehavior.compute_wrap_ids`.
    """
    return spec.heterogeneous_behavior.compute_wrap_ids(data)


@beartype
def _compute_tuple_list_ids(*, data: Value, spec: Language) -> frozenset[int]:
    """Return the ids of lists to render as fixed-size tuples.

    Delegates to the language spec's
    :attr:`~literalizer._language.HeterogeneousBehavior.compute_tuple_list_ids`,
    returning an empty set for strategies that do not opt into the
    ``TUPLE`` style (the hook is ``None``).
    """
    compute = spec.heterogeneous_behavior.compute_tuple_list_ids
    if compute is not None:
        return compute(data)
    return frozenset[int]()


@beartype
def _empty_container_literal_overrides(
    *, data: Value, spec: Language
) -> Mapping[int, str]:
    """Return language-specific literal replacements for empty
    containers.
    """
    overrides = dict(
        spec.heterogeneous_behavior.empty_container_literal_overrides(data)
    )
    _accumulate_sibling_list_empty_overrides(
        value=data,
        spec=spec,
        out=overrides,
    )
    narrowed_empty_sequence = spec.sequence_format_config.narrowed_empty_form
    if narrowed_empty_sequence is not None:
        _accumulate_cousin_empty_list_overrides(
            value=data,
            narrowed_empty_sequence=narrowed_empty_sequence,
            out=overrides,
        )
    narrowed_empty_dict = spec.dict_format_config.narrowed_empty_form
    if narrowed_empty_dict is not None:
        _accumulate_cousin_empty_dict_overrides(
            value=data,
            narrowed_empty_dict=narrowed_empty_dict,
            out=overrides,
        )
    return overrides


@beartype
def _accumulate_cousin_empty_list_overrides(
    *,
    value: Value,
    narrowed_empty_sequence: Callable[[Sequence[list[Value]]], str],
    out: dict[int, str],
) -> None:
    """Type empty lists at corresponding paths through sibling lists."""
    children: Sequence[Value]
    if isinstance(value, list):
        children = value
    elif isinstance(value, dict):
        children = list(value.values())
    else:
        return
    sibling_lists = [child for child in children if isinstance(child, list)]
    if len(sibling_lists) == len(children) and bool(sibling_lists):
        _accumulate_positional_empty_list_overrides(
            sibling_lists=sibling_lists,
            narrowed_empty_sequence=narrowed_empty_sequence,
            out=out,
        )
    for child in children:
        _accumulate_cousin_empty_list_overrides(
            value=child,
            narrowed_empty_sequence=narrowed_empty_sequence,
            out=out,
        )


@beartype
def _accumulate_positional_empty_list_overrides(
    *,
    sibling_lists: Sequence[list[Value]],
    narrowed_empty_sequence: Callable[[Sequence[list[Value]]], str],
    out: dict[int, str],
) -> None:
    """Walk equal-length sibling lists and type corresponding empties."""
    lengths = {len(sibling) for sibling in sibling_lists}
    if len(lengths) != 1:
        return
    for cousins in zip(*sibling_lists, strict=True):
        lists = [cousin for cousin in cousins if _is_value_list(cousin)]
        if len(lists) != len(cousins):
            continue
        empty_lists = [item for item in lists if len(item) == 0]
        non_empty_lists = [item for item in lists if len(item) > 0]
        if len(empty_lists) > 0 and bool(non_empty_lists):
            replacement = narrowed_empty_sequence(non_empty_lists)
            for empty_list in empty_lists:
                _ = out.setdefault(id(empty_list), replacement)
        if len(non_empty_lists) > 0:
            _accumulate_positional_empty_list_overrides(
                sibling_lists=non_empty_lists,
                narrowed_empty_sequence=narrowed_empty_sequence,
                out=out,
            )


@beartype
def _accumulate_sibling_list_empty_overrides(
    *, value: Value, spec: Language, out: dict[int, str]
) -> None:
    """Type empty lists from homogeneous non-empty list siblings."""
    if isinstance(value, list):
        non_empty = [
            item for item in value if isinstance(item, list) and bool(item)
        ]
        empty = [
            item for item in value if isinstance(item, list) and len(item) == 0
        ]
        sibling_openers = {spec.sequence_open(item) for item in non_empty}
        widened_opener = _compute_sequence_open_override(
            items=non_empty,
            spec=spec,
        )
        sibling_opener = widened_opener
        if len(sibling_openers) == 1:
            sibling_opener = next(iter(sibling_openers))
        if len(empty) > 0 and sibling_opener is not None:
            narrowed = spec.sequence_format_config.narrowed_empty_form
            if narrowed is not None and widened_opener is None:
                replacement = narrowed(non_empty)
            else:
                replacement = (
                    sibling_opener + spec.sequence_format_config.close
                )
            for item in empty:
                _ = out.setdefault(id(item), replacement)
        for child in value:
            _accumulate_sibling_list_empty_overrides(
                value=child, spec=spec, out=out
            )
    elif isinstance(value, dict):
        for child in value.values():
            _accumulate_sibling_list_empty_overrides(
                value=child, spec=spec, out=out
            )


@beartype
def _accumulate_cousin_empty_dict_overrides(
    *,
    value: Value,
    narrowed_empty_dict: Callable[[Sequence[dict[Scalar, Value]]], str],
    out: dict[int, str],
) -> None:
    """Type empty maps from the same field in sibling dictionaries.

    For ``[{"m": {"x": 1}}, {"m": {}}]``, the maps under ``m`` are
    cousins rather than immediate siblings in the rendering walk.  Group
    values by key across sibling dictionaries so the empty cousin can
    borrow the non-empty cousin's inferred value type.
    """
    if isinstance(value, list):
        sibling_dicts = [
            item
            for item in value
            if isinstance(item, dict) and not isinstance(item, OrderedMap)
        ]
        _accumulate_sibling_dict_empty_overrides(
            sibling_dicts=sibling_dicts,
            narrowed_empty_dict=narrowed_empty_dict,
            out=out,
        )
        for child in value:
            _accumulate_cousin_empty_dict_overrides(
                value=child,
                narrowed_empty_dict=narrowed_empty_dict,
                out=out,
            )
    elif isinstance(value, dict):
        for child in value.values():
            _accumulate_cousin_empty_dict_overrides(
                value=child,
                narrowed_empty_dict=narrowed_empty_dict,
                out=out,
            )


@beartype
def _accumulate_sibling_dict_empty_overrides(
    *,
    sibling_dicts: Sequence[dict[Scalar, Value]],
    narrowed_empty_dict: Callable[[Sequence[dict[Scalar, Value]]], str],
    out: dict[int, str],
) -> None:
    """Type empty maps at corresponding paths through sibling dicts."""
    keys = {key for sibling in sibling_dicts for key in sibling}
    for key in keys:
        cousins = [sibling[key] for sibling in sibling_dicts if key in sibling]
        maps = [
            cousin
            for cousin in cousins
            if isinstance(cousin, dict) and not isinstance(cousin, OrderedMap)
        ]
        if len(maps) != len(cousins):
            continue
        empty_maps = [cousin for cousin in maps if len(cousin) == 0]
        non_empty_maps = [cousin for cousin in maps if len(cousin) > 0]
        if len(empty_maps) > 0 and bool(non_empty_maps):
            replacement = narrowed_empty_dict(non_empty_maps)
            for empty_map in empty_maps:
                _ = out.setdefault(id(empty_map), replacement)
        if len(non_empty_maps) > 0:
            _accumulate_sibling_dict_empty_overrides(
                sibling_dicts=non_empty_maps,
                narrowed_empty_dict=narrowed_empty_dict,
                out=out,
            )


@beartype
def _build_dict_entry(
    *,
    raw_key: Scalar,
    key_str: str,
    raw_value: Value,
    formatted_value: str,
    spec: Language,
) -> str:
    """Format a single dict key-value entry using the language spec."""
    config = spec.dict_format_config
    formatted_key = key_str
    if isinstance(raw_key, str):
        formatted_key = config.format_key(
            raw_key=raw_key, formatted_key=key_str
        )
    return config.format_entry_from_source(
        raw_key=raw_key,
        formatted_key=formatted_key,
        raw_value=raw_value,
        formatted_value=formatted_value,
    )


@beartype
def _format_ordered_map_key(
    *, raw_key: Scalar, key_str: str, spec: Language
) -> str:
    """Format an ordered-map key from its raw and rendered forms."""
    if isinstance(raw_key, str):
        return spec.ordered_map_format_config.format_key(
            raw_key=raw_key,
            formatted_key=key_str,
        )
    return key_str


@beartype
def _format_set_value(
    *,
    value: set[Scalar],
    ctx: _RenderContext,
) -> str:
    """Format a set value as a native language literal."""
    spec = ctx.spec
    set_cfg = spec.set_format_config

    if len(value) == 0 and set_cfg.empty_set is not None:
        return set_cfg.empty_set
    sorted_items = sorted(value, key=set_sort_key)
    items_as_values: list[Value] = list(sorted_items)
    parent_id = id(value)
    int_formatter = _widened_int_formatter(items=items_as_values, spec=spec)
    formatted = [
        _format_scalar(value=v, spec=spec, int_formatter=int_formatter)
        for v in sorted_items
    ]
    entries = [
        spec.format_set_entry(
            v,
            _maybe_wrap_child(
                parent_id=parent_id,
                raw_value=v,
                formatted_value=item,
                ctx=ctx,
            ),
        )
        for v, item in zip(sorted_items, formatted, strict=True)
    ]
    joined = spec.element_separator.join(entries)
    return set_cfg.set_open(items_as_values) + joined + set_cfg.close


@beartype
def guard_dict_keys_supported(
    *,
    value: Mapping[Scalar, Value],
    spec: Language,
) -> None:
    """Reject non-string dict keys for languages that cannot represent
    them.
    """
    if spec.supports_non_string_dict_keys:
        return
    for key in value:
        if not isinstance(key, str):
            msg = (
                f"{type(spec).__name__} cannot represent dict key of "
                f"type {type(key).__name__}"
            )
            raise UnrepresentableInputError(msg)


@beartype
def _format_ordered_map_value(
    *,
    value: OrderedMap,
    ctx: _RenderContext,
) -> str:
    """Format an ordered map as a native language literal."""
    spec = ctx.spec
    guard_dict_keys_supported(value=value, spec=spec)
    ordered_map_cfg = spec.ordered_map_format_config

    if _collection_comments(value=value, ctx=ctx) is not None:
        return _format_multiline_collection_value(
            value=value,
            ctx=ctx,
            dict_open_override=None,
            sequence_open_override=None,
        )

    ordered_map_items: list[tuple[Scalar, Value]] = [
        (k, v)
        for k, v in value.items()
        if not (spec.skip_null_dict_values and v is None)
    ]
    if len(ordered_map_items) == 0:
        if ordered_map_cfg.empty_ordered_map is not None:
            return ordered_map_cfg.empty_ordered_map
        if spec.dict_format_config.empty_dict is not None:
            return spec.dict_format_config.empty_dict
    parent_id = id(value)
    sibling_list_values: list[list[Value]] = [
        v for _, v in ordered_map_items if isinstance(v, list)
    ]
    outer_sequence_override = _compute_sequence_open_override(
        items=sibling_list_values,
        spec=spec,
    )
    position_overrides = _compute_sibling_list_position_overrides(
        list_values=sibling_list_values,
        spec=spec,
    )
    map_int_formatter = _map_widened_int_formatter(
        items=[v for _, v in ordered_map_items],
        spec=spec,
    )
    pairs = [
        ordered_map_cfg.format_entry_from_source(
            raw_key=k,
            formatted_key=_format_ordered_map_key(
                raw_key=k,
                key_str=_format_value(
                    value=k,
                    dict_open_override=None,
                    sequence_open_override=None,
                    ctx=ctx.compact(),
                    int_formatter=None,
                ),
                spec=spec,
            ),
            raw_value=v,
            formatted_value=_maybe_wrap_child(
                parent_id=parent_id,
                raw_value=v,
                formatted_value=_format_dict_entry_value(
                    value=v,
                    sibling_list_values=sibling_list_values,
                    outer_sequence_override=outer_sequence_override,
                    position_overrides=position_overrides,
                    ctx=ctx,
                    int_formatter=map_int_formatter,
                ),
                ctx=ctx,
            ),
            format_entry=spec.format_ordered_map_entry,
        )
        for k, v in ordered_map_items
    ]
    joined = spec.element_separator.join(pairs)
    opening = _ordered_map_open_for_ref_inference(data=value, ctx=ctx)
    return opening + joined + ordered_map_cfg.close


@beartype
def _maybe_format_record_literal(
    *,
    value: dict[Scalar, Value],
    ctx: _RenderContext,
) -> str | None:
    """Render *value* as a record-struct literal if eligible.

    Returns ``None`` when the language's heterogeneous behavior is not
    RECORD-enabled or when *value* is not record-shaped (empty,
    non-string keys, or an ordered map).
    """
    spec = ctx.spec
    behavior = spec.heterogeneous_behavior
    render_record_literal = behavior.render_record_literal
    if render_record_literal is None:
        return None
    record_shape = record_shape_for_dict(value=value)
    if record_shape is None:
        return None
    is_multiline = ctx.collection_layout is CollectionLayout.MULTILINE
    body_prefix = ""
    if is_multiline:
        body_prefix = ctx.multiline_prefix + spec.indent
    effective_multiline_prefix = body_prefix
    if not is_multiline:
        effective_multiline_prefix = ctx.multiline_prefix
    field_ctx = ctx.with_prefix(multiline_prefix=effective_multiline_prefix)
    # ``record_shape.keys`` holds *value*'s own keys in insertion order
    # (``record_shape_for_dict`` already guaranteed they are all
    # strings); missing-from-this-dict keys are filled in by the
    # strategy's render callable using whatever unified shape it has
    # cached.
    str_keys = list(record_shape.keys)
    formatted_fields: dict[str, str] = {
        key: _format_value(
            value=value[key],
            dict_open_override=None,
            sequence_open_override=None,
            ctx=field_ctx,
            int_formatter=None,
        )
        for key in str_keys
    }
    rendered = render_record_literal(value, formatted_fields)
    if rendered is None:
        # The strategy widened this record-eligible dict to a plain map
        # (a nested sibling map that cannot share one record shape, issue
        # #2910); fall through to normal map rendering.
        return None
    if not is_multiline:
        joined = ", ".join(rendered.entries)
        return (
            f"{rendered.head}{rendered.compact_pad}{joined}"
            f"{rendered.compact_pad}{rendered.closer}"
        )
    # Respect the language's trailing-comma policy: Go/Rust permit a
    # trailing comma after the last field (config ``True`` -> unchanged),
    # but a Java positional record literal is a constructor call where a
    # trailing comma is a syntax error (config ``False``).
    trailing_comma = spec.trailing_comma_config.multiline_trailing_comma
    sep = spec.element_separator.strip()
    last_idx = len(rendered.entries) - 1
    collected_body: list[str] = []
    for entry_i, entry_entry in enumerate(iterable=rendered.entries):
        effective_sep = ""
        if entry_i < last_idx or trailing_comma:
            effective_sep = sep
        collected_body.append(f"{body_prefix}{entry_entry}{(effective_sep)}")
    body = "\n".join(collected_body)
    return f"{rendered.head}\n{body}\n{ctx.multiline_prefix}{rendered.closer}"


@beartype
def _maybe_format_tuple_literal(
    *,
    value: list[Value],
    ctx: _RenderContext,
) -> str | None:
    """Render *value* as a fixed-size heterogeneous tuple if eligible.

    Returns ``None`` when the language's heterogeneous behavior is not
    TUPLE-enabled or when *value*'s id is not in *tuple_list_ids* (it
    is not a tuple-eligible heterogeneous scalar array, so the normal
    sequence formatter handles it).  Uses the same structured-pieces
    assembler as :func:`_maybe_format_record_literal` so the compact
    and multiline layouts stay identical to record literals.
    """
    spec = ctx.spec
    behavior = spec.heterogeneous_behavior
    render_tuple_literal = behavior.render_tuple_literal
    if render_tuple_literal is None:
        return None
    if id(value) not in ctx.tuple_list_ids:
        return None
    is_multiline = ctx.collection_layout is CollectionLayout.MULTILINE
    body_prefix = ""
    if is_multiline:
        body_prefix = ctx.multiline_prefix + spec.indent
    effective_multiline_prefix_2 = body_prefix
    if not is_multiline:
        effective_multiline_prefix_2 = ctx.multiline_prefix
    element_ctx = ctx.with_prefix(
        multiline_prefix=effective_multiline_prefix_2
    )
    # Tuple-eligible lists are all-scalar (see ``collect_tuple_list_ids``),
    # so every element formats to a single-line literal regardless of
    # the layout; the layout only governs how the elements are joined.
    formatted_elements = [
        _format_value(
            value=element,
            dict_open_override=None,
            sequence_open_override=None,
            ctx=element_ctx,
            int_formatter=None,
        )
        for element in value
    ]
    rendered = render_tuple_literal(value, formatted_elements)
    if not is_multiline:
        joined = ", ".join(rendered.entries)
        return (
            f"{rendered.head}{rendered.compact_pad}{joined}"
            f"{rendered.compact_pad}{rendered.closer}"
        )
    # Rust permits a trailing comma after the last tuple element
    # (config ``True`` -> unchanged); C++'s literal is a
    # ``std::make_tuple(...)`` call where a trailing comma is a syntax
    # error, so it sets ``RenderedTupleLiteral.multiline_trailing_comma``
    # ``False`` even though C++'s braced-collection config is ``True``.
    trailing_comma = (
        spec.trailing_comma_config.multiline_trailing_comma
        and rendered.multiline_trailing_comma
    )
    sep = spec.element_separator.strip()
    last_idx = len(rendered.entries) - 1
    collected_body_2: list[str] = []
    for entry_entry_i, entry_entry_entry in enumerate(
        iterable=rendered.entries
    ):
        effective_sep_2 = ""
        if entry_entry_i < last_idx or trailing_comma:
            effective_sep_2 = sep
        collected_body_2.append(
            f"{body_prefix}{entry_entry_entry}{(effective_sep_2)}"
        )
    body = "\n".join(collected_body_2)
    return f"{rendered.head}\n{body}\n{ctx.multiline_prefix}{rendered.closer}"


@beartype
def _format_dict_value(
    *,
    value: dict[Scalar, Value],
    open_override: str | None,
    ctx: _RenderContext,
) -> str:
    """Format a dict as a native language literal."""
    spec = ctx.spec
    guard_dict_keys_supported(value=value, spec=spec)
    dict_cfg = spec.dict_format_config

    if _collection_comments(value=value, ctx=ctx) is not None:
        return _format_multiline_collection_value(
            value=value,
            ctx=ctx,
            dict_open_override=open_override,
            sequence_open_override=None,
        )

    dict_items: dict[Scalar, Value] = {
        k: v
        for k, v in value.items()
        if not (spec.skip_null_dict_values and v is None)
    }
    if len(dict_items) == 0 and dict_cfg.empty_dict is not None:
        return dict_cfg.empty_dict
    parent_id = id(value)
    # Widen nested sequences that occupy matching positions across
    # sibling list-valued dict entries, so consumers iterating these
    # values (e.g. tuple-style) see a consistent element type at each
    # position instead of one branch narrowed to a concrete type and
    # another collapsed to the fallback.
    sibling_list_values: list[list[Value]] = [
        v for v in dict_items.values() if isinstance(v, list)
    ]
    outer_sequence_override = _compute_sequence_open_override(
        items=sibling_list_values,
        spec=spec,
    )
    position_overrides = _compute_sibling_list_position_overrides(
        list_values=sibling_list_values,
        spec=spec,
    )
    map_int_formatter = ctx.dict_int_formatters.get(id(value))
    if map_int_formatter is None:
        map_int_formatter = _map_widened_int_formatter(
            items=list(dict_items.values()),
            spec=spec,
        )
    pairs = [
        _build_dict_entry(
            raw_key=k,
            key_str=_format_value(
                value=k,
                dict_open_override=None,
                sequence_open_override=None,
                ctx=ctx.compact(),
                int_formatter=None,
            ),
            raw_value=v,
            formatted_value=_maybe_wrap_child(
                parent_id=parent_id,
                raw_value=v,
                formatted_value=_format_dict_entry_value(
                    value=v,
                    sibling_list_values=sibling_list_values,
                    outer_sequence_override=outer_sequence_override,
                    position_overrides=position_overrides,
                    ctx=ctx,
                    int_formatter=map_int_formatter,
                ),
                ctx=ctx,
            ),
            spec=spec,
        )
        for k, v in dict_items.items()
    ]
    joined = spec.element_separator.join(pairs)
    dict_open_for_wrap_ids = spec.heterogeneous_behavior.dict_open_for_wrap_ids
    match open_override:
        case _ if (
            id(value) in ctx.wrap_ids and dict_open_for_wrap_ids is not None
        ):
            opener = dict_open_for_wrap_ids()
        case str():
            opener = open_override
        case _ if id(value) in ctx.dict_open_overrides:
            opener = ctx.dict_open_overrides[id(value)]
        case _:
            opener = _dict_open_for_ref_inference(data=dict_items, ctx=ctx)
    return opener + joined + dict_cfg.close


@beartype
def _format_dict_entry_value(
    *,
    value: Value,
    sibling_list_values: Sequence[list[Value]],
    outer_sequence_override: str | None,
    position_overrides: Sequence[str | None],
    ctx: _RenderContext,
    int_formatter: Callable[[int], str] | None,
) -> str:
    """Format a dict entry's value, threading sequence-opener overrides
    into list-typed values so the outer and inner sequences render with
    types that are consistent across sibling dict entries.

    *outer_sequence_override* is the widened opener for the list itself
    (so sibling list-valued entries share one outer type).
    *position_overrides* supplies per-position openers for the list's
    immediate child lists (so nested sequences at matching positions
    across sibling entries share a widened type).
    *int_formatter* is the map's mixed-magnitude integer widener when
    values inferred :class:`WideInt` or :class:`BeyondI64`.
    """
    child_ctx = _nested_collection_context(value=value, ctx=ctx)
    if isinstance(value, list):
        if len(value) == 0 and outer_sequence_override is None:
            non_empty_siblings = [
                sibling for sibling in sibling_list_values if len(sibling) > 0
            ]
            sibling_openers = {
                ctx.spec.sequence_open(sibling)
                for sibling in non_empty_siblings
            }
            if len(sibling_openers) == 1:
                (sibling_opener,) = sibling_openers
                # Do not borrow an opener whose spelling includes the
                # sequence length (for example ``std::array<T, N>``):
                # doing so would turn an empty list into N default values.
                length_bearing = any(
                    ctx.spec.sequence_open([*sibling, sibling[0]])
                    != sibling_opener
                    for sibling in non_empty_siblings
                )
                if length_bearing:
                    return _format_list_value(
                        value=value,
                        sequence_open_override=None,
                        child_sequence_open_overrides=position_overrides,
                        ctx=child_ctx,
                    )
                narrowed_empty_form = (
                    ctx.spec.sequence_format_config.narrowed_empty_form
                )
                if narrowed_empty_form is not None:
                    return narrowed_empty_form(non_empty_siblings)
                outer_sequence_override = sibling_opener
        tuple_literal = _maybe_format_tuple_literal(
            value=value,
            ctx=child_ctx,
        )
        if tuple_literal is not None:
            return tuple_literal
        return _format_list_value(
            value=value,
            sequence_open_override=outer_sequence_override,
            child_sequence_open_overrides=position_overrides,
            ctx=child_ctx,
        )
    return _format_value(
        value=value,
        dict_open_override=None,
        sequence_open_override=None,
        ctx=child_ctx,
        int_formatter=int_formatter,
    )


@beartype
def _compute_dict_open_override(
    *,
    items: list[Value],
    spec: Language,
    ref_key: str,
) -> str | None:
    """Return a widened dict opener when dicts in a list infer
    different value types, or ``None`` when no widening is needed.

    A reference marker is skipped for the reason
    :func:`_gather_call_slot_values` gives on the call path: the marker
    is rendered as the identifier it names rather than as a map of its
    own, so pooling its ``{ref_key: name}`` shape would widen siblings
    that agree once the reference resolves (issue #4753).
    """
    dict_open = spec.dict_format_config.dict_open
    dicts: list[dict[Scalar, Value]] = [
        item
        for item in items
        if isinstance(item, dict)
        and not isinstance(item, OrderedMap)
        and _extract_call_arg_ref_name(value=item, ref_key=ref_key) is None
    ]
    # Widening compares openers across dicts, so we need at least two
    # to have anything to compare.
    min_dicts_for_widening = 2
    if len(dicts) < min_dicts_for_widening:
        return None

    filtered_dicts = [
        {
            k: v
            for k, v in d.items()
            if not (spec.skip_null_dict_values and v is None)
        }
        for d in dicts
    ]

    openers = {dict_open(d) for d in filtered_dicts}
    if len(openers) <= 1:
        return None

    # Types differ: combine all values to infer the widened type.
    # Use the unfiltered dicts so that ``None`` values contribute
    # "unknown type" to the widening — otherwise a dict that filters
    # to ``{}`` would narrow the widened type to the other dicts'
    # concrete value type, losing the null slot's uncertainty.
    combined: dict[Scalar, Value] = {}
    idx = 0
    for d in dicts:
        for v in d.values():
            combined[f"_k{idx}"] = v
            idx += 1
    return dict_open(combined)


# Single-value dicts whose one value has a different scalar type, used
# to probe whether a language's dict opener *narrows* by value type.  A
# language whose opener ignores the values (dynamic languages emit a
# fixed ``{``) can never produce a mismatch between a map and its
# declared slot, so nested-map widening is irrelevant and the walk is
# skipped entirely.
_DICT_STR_PROBE: dict[Scalar, Value] = {"_probe": "s"}
_DICT_INT_PROBE: dict[Scalar, Value] = {"_probe": 1}
# Two dicts whose values mix disjoint scalar types, used to probe
# whether a narrowing opener collapses to a stable "any"-like fallback
# for mixed values.  When both probes yield the same opener the language
# has a content-independent fallback (e.g. Go's ``map[string]any``,
# Kotlin's ``Any?``); when they differ it builds a content-specific type
# (C++'s ``std::variant``, etc.) with no widened form that accepts every
# sibling, so nested-map widening must be left alone.  Every probe is
# non-empty and string-keyed so the check never depends on an empty-dict
# opener, which some strategies (e.g. D's ``RECORD``) reject.  Mirrors
# :data:`_FALLBACK_PROBE` for sequences.
_DICT_FALLBACK_PROBE_A: dict[Scalar, Value] = {"_probe_a": 1, "_probe_b": "s"}
_DICT_FALLBACK_PROBE_B: dict[Scalar, Value] = {
    "_probe_a": 1.5,
    "_probe_b": False,
}


@beartype
def _dict_widening_applies(*, spec: Language) -> bool:
    """Return whether nested sibling-map widening can help *spec*.

    Widening (#2878) is only relevant, and only produces output that
    compiles, for languages whose dict opener both narrows by value type
    and exposes a single "accepts anything" value type (Go's
    ``map[string]any``, Kotlin's ``Any?``).  Two classes are excluded:

    * Languages whose opener ignores the values (dynamic languages emit
      a fixed ``{``): every map already shares an opener, so no map can
      mismatch its declared slot and the whole walk is skipped.
    * Languages whose opener is content-specific (variant/union typing,
      e.g. C++): they have no widened type that accepts every sibling,
      so widening would only shift the type mismatch; those are handled
      by a dedicated heterogeneous check instead.

    The probes are minimal, non-empty and string-keyed so every
    language's dict opener returns a value for them (an empty-dict
    opener, which some strategies such as D's ``RECORD`` reject, is
    never requested).
    """
    dict_open = spec.dict_format_config.dict_open
    if dict_open(_DICT_STR_PROBE) == dict_open(_DICT_INT_PROBE):
        return False
    return dict_open(_DICT_FALLBACK_PROBE_A) == dict_open(
        _DICT_FALLBACK_PROBE_B
    )


@beartype
def _collect_dict_open_overrides(
    *,
    data: Value,
    spec: Language,
    ref_key: str,
) -> dict[int, str]:
    """Compute widened dict openers for nested sibling map values.

    Sibling dict values that are themselves maps share a single declared
    value type in the enclosing container, but each inner map otherwise
    renders with its own narrowed opener, so a map whose values are
    narrower than the widened slot type does not compile (issue #2878;
    the dict-value analogue of the sibling widening #1471/#1472 applied
    to call arguments and sequence elements).

    Walks *data* and records ``id(map) -> widened opener`` for every
    group of sibling maps that must share a widened type, pooling values
    exactly as
    :func:`~literalizer._formatters.type_inference.infer_element_type`
    does when it derives the container's declared type.  Only languages
    the widening can help (see :func:`_dict_widening_applies`) are
    walked; the returned mapping is empty for every other language, so
    they pay only the constant-cost probe.
    """
    out: dict[int, str] = {}
    if _dict_widening_applies(spec=spec):
        _accumulate_dict_open_overrides(
            data=data,
            spec=spec,
            out=out,
            ref_key=ref_key,
        )
    return out


@beartype
def _collect_dict_int_formatters(
    *, data: Value, spec: Language
) -> Mapping[int, Callable[[int], str]]:
    """Return widened integer formatters for sibling map value slots."""
    out: dict[int, Callable[[int], str]] = {}
    _accumulate_dict_int_formatters(data=data, spec=spec, out=out)
    return out


@beartype
def _accumulate_dict_int_formatters(
    *,
    data: Value,
    spec: Language,
    out: dict[int, Callable[[int], str]],
) -> None:
    """Widen integer leaves consistently across sibling nested maps."""
    match data:
        case OrderedMap():
            children = list(data.values())
        case dict():
            children = list(data.values())
        case list():
            children = list(data)
        case _:
            return
    sibling_maps = [
        child
        for child in children
        if isinstance(child, dict) and not isinstance(child, OrderedMap)
    ]
    min_maps_for_widening = 2
    if len(sibling_maps) >= min_maps_for_widening:
        formatter = _map_widened_int_formatter(
            items=[
                item for sibling in sibling_maps for item in sibling.values()
            ],
            spec=spec,
        )
        if formatter is not None:
            for sibling in sibling_maps:
                _ = out.setdefault(id(sibling), formatter)
    for child in children:
        _accumulate_dict_int_formatters(data=child, spec=spec, out=out)


@beartype
def _accumulate_dict_open_overrides(
    *,
    data: Value,
    spec: Language,
    ref_key: str,
    out: dict[int, str],
) -> None:
    """Record widened openers for sibling maps reachable from *data*.

    The dict values of a plain dict share that dict value slot; a list
    of two or more plain dicts makes those dicts one shared type, so
    their values share a single (deeper) slot pooled across every
    element.  Both are handled by :func:`_widen_sibling_map_values`,
    which descends through nested levels.  The structural recursion here
    reaches every independent slot; :func:`dict.setdefault` in the widen
    helper keeps the widest (outermost) opener for any map claimed at
    more than one level.
    """
    match data:
        case OrderedMap():
            for value in data.values():
                _accumulate_dict_open_overrides(
                    data=value,
                    spec=spec,
                    out=out,
                    ref_key=ref_key,
                )
        case dict():
            _widen_sibling_map_values(
                pool=list(data.values()),
                spec=spec,
                out=out,
                ref_key=ref_key,
            )
            for value in data.values():
                _accumulate_dict_open_overrides(
                    data=value,
                    spec=spec,
                    out=out,
                    ref_key=ref_key,
                )
        case list():
            min_dicts_for_widening = 2
            plain_dict_elements = [
                item
                for item in data
                if isinstance(item, dict) and not isinstance(item, OrderedMap)
            ]
            if len(plain_dict_elements) == len(data) >= min_dicts_for_widening:
                pooled = [
                    value
                    for element in plain_dict_elements
                    for value in element.values()
                ]
                _widen_sibling_map_values(
                    pool=pooled,
                    spec=spec,
                    out=out,
                    ref_key=ref_key,
                )
            for item in data:
                _accumulate_dict_open_overrides(
                    data=item,
                    spec=spec,
                    out=out,
                    ref_key=ref_key,
                )
        case _:
            return


@beartype
def _widen_sibling_map_values(
    *,
    pool: list[Value],
    spec: Language,
    out: dict[int, str],
    ref_key: str,
) -> None:
    """Record the widened opener for the maps in one shared value slot.

    *pool* are the sibling values occupying a single declared value slot.
    When two or more are maps whose inferred openers diverge, every such
    map is recorded with the combined (widened) opener so it renders at
    the slot's declared type, and their own values -- the next shared
    slot -- are pooled and widened in turn, so nesting deeper than one
    level widens too.

    When ``_compute_dict_open_override`` returns ``None`` the recursion
    stops.  That covers two cases, both terminal: fewer than two sibling
    maps here (any nested slot they own is reached instead by the
    structural walk in :func:`_accumulate_dict_open_overrides`), or two
    or more maps that already share an opener -- meaning their inferred
    nested value types are identical, so no nested map anywhere below
    can mismatch its slot.  Stopping there keeps the walk linear in the
    input size instead of re-scanning nested maps once per enclosing
    level.
    """
    maps: list[Value] = [
        item
        for item in pool
        if isinstance(item, dict) and not isinstance(item, OrderedMap)
    ]
    override = _compute_dict_open_override(
        items=maps,
        spec=spec,
        ref_key=ref_key,
    )
    if override is None:
        return
    for map_value in maps:
        _ = out.setdefault(id(map_value), override)
    child_pool = [
        value for m in maps if isinstance(m, dict) for value in m.values()
    ]
    _widen_sibling_map_values(
        pool=child_pool,
        spec=spec,
        out=out,
        ref_key=ref_key,
    )


@beartype
def _gather_call_slot_values(
    *,
    elements: list[Value],
    ref_key: str,
) -> list[list[Value]]:
    """Group non-ref argument values by positional slot across calls.

    Ref markers are filtered out: the marker isn't rendered as a real
    value at the call site, so its shape must not influence
    sibling-aware widening.
    """
    slots: list[list[Value]] = []
    for element in elements:
        arg_values = element
        if not isinstance(arg_values, list):
            arg_values = [element]
        for slot_index, arg_value in enumerate(iterable=arg_values):
            if slot_index >= len(slots):
                slots.append([])
            is_ref = _extract_call_arg_ref_name(
                value=arg_value, ref_key=ref_key
            )
            if is_ref is None:
                slots[slot_index].append(arg_value)
    return slots


@beartype
def _compute_call_slot_overrides(
    *,
    elements: list[Value],
    spec: Language,
    ref_key: str,
) -> list[str | None]:
    """Compute per-slot dict-open overrides across sibling calls.

    For each positional argument slot in per-element calls, gather the
    values at that slot across all elements and compute a widened
    dict opener so that dict arguments at the same slot share a
    common type.  Sibling calls render as independent statements with
    no enclosing sequence, so ``narrowed_open`` does not apply here —
    each dict still needs its own full opener, just widened when
    sibling dicts differ in inferred value type.
    """
    slots = _gather_call_slot_values(elements=elements, ref_key=ref_key)
    return [
        _compute_dict_open_override(
            items=slot_values,
            spec=spec,
            ref_key=ref_key,
        )
        for slot_values in slots
    ]


@beartype
def _compute_call_per_element_wrap_ids(
    *,
    elements: list[Value],
    spec: Language,
    ref_key: str,
) -> frozenset[int]:
    """Compute wrap_ids spanning sibling per-element calls.

    For each positional argument slot, compute wrap_ids on the slot's
    values as if they were siblings inside a single list, then union
    the results.  This mirrors the dict-opener widening done by
    :func:`_compute_call_slot_overrides` so that render-time wrapping
    strategies (e.g. Rust's ``TAGGED_ENUM``) stay consistent across
    sibling calls: a slot whose combined values are heterogeneous
    triggers wrapping in every sibling at that slot, not just the
    ones whose own argument is locally mixed.
    """
    slots = _gather_call_slot_values(elements=elements, ref_key=ref_key)
    return frozenset[int]().union(
        *(
            _compute_wrap_ids(data=slot_values, spec=spec)
            for slot_values in slots
        )
    )


@beartype
def _compute_call_slot_scalar_wrap_ids(
    *,
    elements: list[Value],
    spec: Language,
    ref_key: str,
) -> frozenset[int]:
    """Compute ids of top-level scalar call arguments to wrap.

    For each positional argument slot, gather the values across sibling
    calls and ask the language's
    :class:`~literalizer._language.HeterogeneousBehavior` whether any
    of those values need wrapping due to cross-call type divergence.
    The default behavior returns an empty set for every slot; the Mojo
    language under the ``VARIANT`` strategy returns the value ids of
    divergent top-level scalars so they render wrapped as ``Value(...)``.
    """
    slots = _gather_call_slot_values(elements=elements, ref_key=ref_key)
    return frozenset[int]().union(
        *(
            spec.heterogeneous_behavior.compute_call_slot_wrap_ids(slot_values)
            for slot_values in slots
        )
    )


@beartype
def _compute_sequence_dict_override(
    *,
    items: list[Value],
    sequence_open_override: str | None,
    spec: Language,
    ref_key: str,
) -> str | None:
    """Determine the dict opener override for dicts in a sequence.

    When all items are uniform dicts and the language defines a
    ``narrowed_open``, returns that anonymous opener so the
    sequence type carries the map type instead of each dict.
    Otherwise falls back to the widening logic of
    :func:`_compute_dict_open_override`.

    An anonymous opener elides the element type, which the language
    only reads back from a sequence type that names it.  A parent that
    has widened this sequence to its "accepts anything" opener does not
    name one, so the elision is dropped there (issue #3938).
    """
    narrowed_open = spec.dict_format_config.narrowed_open
    sequence_open = sequence_open_override
    if sequence_open is None:
        sequence_open = spec.sequence_open(items)
    widened = sequence_open == spec.sequence_open([])
    if narrowed_open is not None and not widened:
        element_type = infer_element_type(items=items)
        if isinstance(element_type, DictType):
            return narrowed_open
    return _compute_dict_open_override(
        items=items,
        spec=spec,
        ref_key=ref_key,
    )


@beartype
def _compute_sequence_open_override(
    *,
    items: Sequence[Value],
    spec: Language,
) -> str | None:
    """Return a widened sequence opener when lists in *items* infer
    different element types, or ``None`` when no widening is needed.

    Analogous to :func:`_compute_dict_open_override` but operates on
    nested sequences.  ``items`` are the sibling values at a matching
    position across several sibling containers; only list-typed items
    participate in the widening.  When the element types diverge the
    override widens to the language's fallback opener — the opener
    returned for an empty sequence — so every sibling renders with the
    "accepts anything" type instead of narrowing one branch to its
    concrete element type.

    Languages that use content-specific union typing expose no stable
    fallback opener.  For those, infer one opener from the sibling
    lists together so each literal agrees with the containing type.
    """
    # An empty list has no contents to infer a type from, so its
    # opener is the language's "accepts anything" one.  That says
    # nothing about the slot, and comparing it would widen every
    # sibling to match it, so only the lists that carry a type are
    # compared (issue #3927).
    lists: list[list[Value]] = [
        item for item in items if isinstance(item, list) and bool(item)
    ]
    # Widening compares openers across lists, so we need at least two
    # to have anything to compare.
    min_lists_for_widening = 2
    if len(lists) < min_lists_for_widening:
        return None

    openers = {spec.sequence_open(lst) for lst in lists}
    if len(openers) <= 1:
        return None

    fallback = spec.sequence_open([])
    if fallback != spec.sequence_open(_FALLBACK_PROBE):
        same_length = len({len(sibling) for sibling in lists}) == 1
        has_positional_empty_mix = same_length and any(
            any(_is_value_list(item) and len(item) == 0 for item in position)
            and any(_is_value_list(item) and bool(item) for item in position)
            for position in zip(*lists, strict=True)
        )
        if has_positional_empty_mix:
            normalized_lists = _replace_positional_empty_lists(lists=lists)
            return spec.sequence_open(
                [item for sibling in normalized_lists for item in sibling]
            )
        return None
    return fallback


# Two scalars of incompatible types, used to probe whether a language's
# sequence opener collapses to a stable "any"-like fallback for mixed
# content.  When the opener for this probe equals the opener for an
# empty sequence the language has a true fallback; otherwise it builds
# a content-specific type (variant, union, etc.) that we must leave
# alone to avoid cascading type mismatches.
_FALLBACK_PROBE: list[Value] = [1, "probe"]


@beartype
def _is_value_list(value: Value, /) -> TypeGuard[list[Value]]:
    """Narrow a parsed value to its recursively typed list form."""
    return isinstance(value, list)


@beartype
def _replace_positional_empty_lists(
    *, lists: Sequence[list[Value]]
) -> list[list[Value]]:
    """Replace empty positional cousins with a non-empty type exemplar."""
    normalized = [list(items) for items in lists]
    for position in range(len(normalized[0])):
        cousins = [items[position] for items in normalized]
        exemplar = next(
            (
                cousin
                for cousin in cousins
                if _is_value_list(cousin) and bool(cousin)
            ),
            None,
        )
        if exemplar is None:
            continue
        for items in normalized:
            if _is_value_list(items[position]) and not bool(items[position]):
                items[position] = exemplar
    return normalized


@beartype
def _compute_sibling_list_position_overrides(
    *,
    list_values: list[list[Value]],
    spec: Language,
) -> list[str | None]:
    """Compute per-position sequence-open overrides across sibling lists.

    For each position ``i`` across the given sibling lists, gather the
    items at that position and compute a widened sequence opener so
    that sub-lists sharing the same positional slot across siblings
    render with a common element type.  ``None`` at a given position
    means no widening is needed there.

    Returns an empty list when fewer than two sibling lists are
    provided, since widening requires siblings to compare against.
    """
    min_lists_for_widening = 2
    if len(list_values) < min_lists_for_widening:
        return []
    max_len = max(len(lst) for lst in list_values)
    slots: list[list[Value]] = [[] for _ in range(max_len)]
    for lst in list_values:
        for position, item in enumerate(iterable=lst):
            slots[position].append(item)
    return [
        _compute_sequence_open_override(items=slot_values, spec=spec)
        for slot_values in slots
    ]


@beartype
def _empty_child_sibling_opener(
    *,
    value: list[Value],
    position: int,
    spec: Language,
) -> str | None:
    """Opener to use for an empty inner-list child at *position*.

    Empty inner lists have no contents to infer a type from, so the
    default per-list opener falls back to the language's generic
    "any"-typed sequence (e.g. ``new Object[]{``, ``[]any{``,
    ``Vec::<String>::new()``).  When that empty list sits beside
    non-empty homogeneous list siblings, the rendered literal then
    mixes the narrow sibling type with the generic empty type and is
    rejected by the static type checkers used for Java, Rust, Go, etc.

    Pull a typed opener from a non-empty list sibling when all such
    siblings produce the same opener, so the empty list renders with
    a matching type.  Returns ``None`` when no homogeneous sibling
    opener exists and the default fallback should stand.
    """
    item = value[position]
    if not (isinstance(item, list) and len(item) == 0):
        return None
    non_empty_siblings = [
        other for other in value if isinstance(other, list) and bool(other)
    ]
    if len(non_empty_siblings) == 0:
        return None
    sibling_openers = {spec.sequence_open(o) for o in non_empty_siblings}
    if len(sibling_openers) != 1:
        return None
    return next(iter(sibling_openers))


@beartype
def _format_sequence_child(
    *,
    value: list[Value],
    position: int,
    child: Value,
    dict_open_override: str | None,
    child_sequence_open_overrides: Sequence[str | None],
    ctx: _RenderContext,
    int_formatter: Callable[[int], str] | None,
) -> str:
    """Format a single sequence child with sibling-aware typed empty.

    Empty inner-list children sit beside non-empty homogeneous siblings
    in cases like ``[[1, 2], [], [3, 4]]``.  When the language has a
    bespoke narrowed-empty form (e.g. ``List[Int]()`` for Mojo,
    ``[] of Int32`` for Crystal, ``[] : List Natural`` for Dhall),
    short-circuit to it so the rendered literal type-checks.  Otherwise
    fall through to the regular recursive formatter, which uses
    sibling-derived ``sequence_open_override`` to make the empty list
    render as ``opener + close`` for languages where that is valid
    (Java, Go, Rust, ...).

    *int_formatter* is the parent's mixed-magnitude integer widener when
    the enclosing list inferred :class:`WideInt` or :class:`BeyondI64`;
    nested containers ignore it and compute their own.
    """
    parent_override = None
    if (
        position < len(child_sequence_open_overrides)
        and child_sequence_open_overrides[position] is not None
    ):
        parent_override = child_sequence_open_overrides[position]
    sibling_open = None
    if parent_override is None:
        sibling_open = _empty_child_sibling_opener(
            value=value,
            position=position,
            spec=ctx.spec,
        )
    if (
        parent_override is None
        and isinstance(child, list)
        and len(child) == 0
        and sibling_open is not None
    ):
        narrowed_empty_form = (
            ctx.spec.sequence_format_config.narrowed_empty_form
        )
        if narrowed_empty_form is not None:
            non_empty_siblings = [
                other
                for other in value
                if isinstance(other, list) and bool(other)
            ]
            return narrowed_empty_form(non_empty_siblings)
    if (
        parent_override is None
        and isinstance(child, dict)
        and not isinstance(child, OrderedMap)
        and len(child) == 0
    ):
        narrowed_empty_dict = ctx.spec.dict_format_config.narrowed_empty_form
        if narrowed_empty_dict is not None:
            non_empty_map_siblings = [
                other
                for other in value
                if isinstance(other, dict)
                and (not isinstance(other, OrderedMap))
                and bool(other)
            ]
            if len(non_empty_map_siblings) > 0:
                return narrowed_empty_dict(non_empty_map_siblings)
    child_ctx = _nested_collection_context(value=child, ctx=ctx)
    effective_sequence_open_override = sibling_open
    if parent_override is not None:
        effective_sequence_open_override = parent_override
    return _format_value(
        value=child,
        dict_open_override=dict_open_override,
        sequence_open_override=(effective_sequence_open_override),
        ctx=child_ctx,
        int_formatter=int_formatter,
    )


@beartype
def _format_list_value(
    *,
    value: list[Value],
    sequence_open_override: str | None,
    child_sequence_open_overrides: Sequence[str | None],
    ctx: _RenderContext,
) -> str:
    """Format a list as a native language literal.

    *sequence_open_override* overrides the opener for this list itself
    (used when a parent has widened nested sequence types across
    sibling positions).

    *child_sequence_open_overrides* supplies per-position sequence
    openers for child lists, so nested sequences at matching positions
    across sibling containers can share a widened type.
    """
    spec = ctx.spec
    sequence_cfg = spec.sequence_format_config

    if _collection_comments(value=value, ctx=ctx) is not None:
        return _format_multiline_collection_value(
            value=value,
            ctx=ctx,
            dict_open_override=None,
            sequence_open_override=sequence_open_override,
        )

    # When a parent has widened this position's opener, skip the
    # default ``empty_sequence`` literal so the empty list still
    # renders with the widened opener and stays type-consistent with
    # its non-empty siblings.  However, if this list is in wrap_ids,
    # it must use the typed empty literal (e.g. ``[]TYPE{}``) regardless
    # of any sibling opener, so that the element type is preserved.
    if (
        len(value) == 0
        and sequence_cfg.empty_sequence is not None
        and (sequence_open_override is None or id(value) in ctx.wrap_ids)
    ):
        return sequence_cfg.empty_sequence
    if ctx.collection_layout is CollectionLayout.MULTILINE and bool(value):
        return _format_multiline_collection_value(
            value=value,
            dict_open_override=None,
            sequence_open_override=sequence_open_override,
            ctx=ctx,
        )
    inferred_value = _opener_inference_value(data=value, ctx=ctx)
    effective_items = inferred_value
    dict_open_override = _compute_sequence_dict_override(
        items=effective_items,
        sequence_open_override=sequence_open_override,
        spec=spec,
        ref_key=ctx.ref_key,
    )
    parent_id = id(value)
    int_formatter = ctx.list_int_formatters.get(id(value))
    if int_formatter is None:
        int_formatter = _widened_int_formatter(items=value, spec=spec)
    items = [
        spec.format_sequence_entry(
            v,
            _maybe_wrap_child(
                parent_id=parent_id,
                raw_value=v,
                formatted_value=_format_sequence_child(
                    value=value,
                    position=position,
                    child=v,
                    dict_open_override=dict_open_override,
                    child_sequence_open_overrides=(
                        child_sequence_open_overrides
                    ),
                    ctx=ctx,
                    int_formatter=int_formatter,
                ),
                ctx=ctx,
            ),
        )
        for position, v in enumerate(iterable=value)
    ]
    # Drop items that render to the empty string before joining, so a
    # nested empty sub-list inside a non-empty list (possible in
    # languages like Forth whose empty-sequence opener and close are
    # both empty) does not leave a dangling separator in the output.
    non_empty_items = [item for item in items if item != ""]
    joined = spec.element_separator.join(non_empty_items)
    # Some languages (e.g. Python) require a trailing comma on
    # single-element sequences to avoid syntactic ambiguity.  The
    # decision uses the original element count so filtered-away empty
    # sub-lists do not flip a multi-element list into the trailing-
    # comma branch.
    if len(items) == 1 and sequence_cfg.single_element_trailing_comma:
        joined += spec.element_separator.strip()
    if (
        len(items) == 1
        and sequence_cfg.single_element_template is not None
        and sequence_open_override is None
    ):
        return sequence_cfg.single_element_template.format(items=joined)
    match sequence_open_override:
        case str():
            opener = sequence_open_override
        case _:
            opener = _sequence_open_for_ref_inference(data=value, ctx=ctx)
    return f"{opener}{joined}{sequence_cfg.close}"


@beartype
def _layout_context(*, value: Value, ctx: _RenderContext) -> _RenderContext:
    """Return the context a value's own layout is rendered with.

    TOML forbids a multi-line inline table, so a language that says so
    renders a mapping -- and everything under it -- on one line even
    when the caller asked for the multiline layout (issue #4538).
    """
    if not isinstance(value, (dict, OrderedMap)):
        return ctx
    if ctx.spec.supports_multiline_dict_layout:
        return ctx
    return ctx.compact()


@beartype
def _format_ref_value(*, raw_ref_name: str, ctx: _RenderContext) -> str:
    """Format a reference marker found in a nested value."""
    ref_name = _validated_ref_name(
        raw_ref_name=raw_ref_name,
        ref_case=ctx.ref_case,
        language=ctx.spec,
    )
    ref_value = None
    if ctx.ref_values is not None:
        ref_value = ctx.ref_values.get(raw_ref_name)
    if not ctx.expand_refs:
        return ctx.spec.format_call_ref_identifier(ref_name, ref_value)
    return _format_call_arg_ref_identifier(
        raw_ref_name=raw_ref_name,
        ref_name=ref_name,
        ref_value=ref_value,
        language=ctx.spec,
        consumable_ref_names=ctx.consumable_ref_names,
        single_use_ref_names=ctx.single_use_ref_names,
        consume_inhibited_ref_names=ctx.consume_inhibited_ref_names,
    )


@beartype
def _format_compact_collection_value(
    *,
    value: list[Value] | dict[Scalar, Value] | set[Scalar],
    dict_open_override: str | None,
    sequence_open_override: str | None,
    ctx: _RenderContext,
) -> str:
    """Format a collection using its compact layout."""
    match value:
        case OrderedMap():
            return _format_ordered_map_value(value=value, ctx=ctx)
        case dict():
            return _format_dict_value(
                value=value,
                open_override=dict_open_override,
                ctx=ctx,
            )
        case set():
            return _format_set_value(value=value, ctx=ctx)
        case _:
            return _format_list_value(
                value=value,
                sequence_open_override=sequence_open_override,
                child_sequence_open_overrides=(),
                ctx=ctx,
            )


@beartype
def _format_value(
    *,
    value: Value,
    dict_open_override: str | None,
    sequence_open_override: str | None,
    ctx: _RenderContext,
    int_formatter: Callable[[int], str] | None,
) -> str:
    """Format any JSON value as a native language literal.

    Handles scalars, lists (recursively), dicts, and sets.

    When *dict_open_override* is set, dict values use it as the opening
    delimiter instead of inferring the type from their own values.
    This is used to widen map value types when dicts with differing
    inferred types appear in the same sequence.

    When *sequence_open_override* is set, list values use it as the
    opening delimiter instead of inferring their element type.  This
    widens nested sequence types at matching positions across sibling
    containers.

    The render context carries the language spec, ref policy, layout,
    indentation prefix, and the set of container ids whose scalar
    children should be wrapped by the spec's
    :attr:`~literalizer._language.HeterogeneousBehavior.wrap_scalar`
    hook.

    ``{"$ref": "name"}`` markers anywhere in the value tree are rendered
    as bare identifiers.  ``literalize`` uses
    :attr:`~literalizer._language.Language.format_call_ref_identifier`;
    ``literalize_call`` sets the context's ``expand_refs`` so nested
    argument refs use the regular or consumable call-argument ref
    formatter according to the call's ownership policy.
    When the context's ``ref_case`` is set, the identifier name is
    converted to that case first.
    """
    ctx = _layout_context(value=value, ctx=ctx)
    spec = ctx.spec
    if ctx.ref_key is not _DISABLED_REF_KEY and isinstance(value, dict):
        raw_ref_name = _extract_call_arg_ref_name(
            value=value, ref_key=ctx.ref_key
        )
        if raw_ref_name is not None:
            return _format_ref_value(
                raw_ref_name=raw_ref_name,
                ctx=ctx,
            )
    empty_override = ctx.empty_container_overrides.get(id(value))
    if empty_override is not None:
        return empty_override
    if isinstance(value, dict) and not isinstance(value, OrderedMap):
        record_literal = _maybe_format_record_literal(
            value=value,
            ctx=ctx,
        )
        if record_literal is not None:
            return record_literal
    if isinstance(value, list):
        tuple_literal = _maybe_format_tuple_literal(
            value=value,
            ctx=ctx,
        )
        if tuple_literal is not None:
            return tuple_literal
    if (
        ctx.collection_layout is CollectionLayout.MULTILINE
        and isinstance(value, (dict, list, set, OrderedMap))
        and bool(value)
    ):
        return _format_multiline_collection_value(
            value=value,
            dict_open_override=dict_open_override,
            sequence_open_override=sequence_open_override,
            ctx=ctx,
        )
    if isinstance(value, (list, dict, set)):
        result = _format_compact_collection_value(
            value=value,
            dict_open_override=dict_open_override,
            sequence_open_override=sequence_open_override,
            ctx=ctx,
        )
    else:
        result = _format_scalar(
            value=value, spec=spec, int_formatter=int_formatter
        )
    return result


@beartype
def _wrap_body(
    *,
    body: str,
    is_ordered_map: bool,
    data: list[Value] | dict[Scalar, Value] | set[Scalar],
    spec: Language,
    line_prefix: str,
    dict_open_override: str | None,
) -> str:
    """Wrap ``body`` in the language's open/close delimiters."""
    ci = ""
    if spec.indent_closing_delimiter:
        ci = spec.indent
    close_prefix = f"{line_prefix}{ci}"
    match data:
        case dict() if is_ordered_map:
            ordered_map_cfg = spec.ordered_map_format_config
            open_str = ordered_map_cfg.ordered_map_open(data)
            opening = f"{line_prefix}{open_str}"
            closing = f"{close_prefix}{ordered_map_cfg.close}"
        case dict() if dict_open_override is not None:
            dict_cfg = spec.dict_format_config
            opening = f"{line_prefix}{dict_open_override}"
            closing = f"{close_prefix}{dict_cfg.close}"
        case dict():
            dict_cfg = spec.dict_format_config
            opening = f"{line_prefix}{dict_cfg.dict_open(data)}"
            closing = f"{close_prefix}{dict_cfg.close}"
        case set():
            sorted_set: list[Value] = sorted(
                data,
                key=set_sort_key,
            )
            set_cfg = spec.set_format_config
            opening = f"{line_prefix}{set_cfg.set_open(sorted_set)}"
            closing = f"{close_prefix}{set_cfg.close}"
        case _:
            sequence_cfg = spec.sequence_format_config
            template = sequence_cfg.single_element_template
            if template is not None and len(data) == 1:
                open_str, _, close_str = template.partition("{items}")
            else:
                open_str = spec.sequence_open(data)
                close_str = sequence_cfg.close
            opening = f"{line_prefix}{open_str}"
            closing = f"{close_prefix}{close_str}"
    return f"{opening.rstrip()}\n{body}\n{closing}"


@beartype
def _strip_direct_refs_for_opener(
    *, value: list[Value] | dict[Scalar, Value], ref_key: str
) -> list[Value] | dict[Scalar, Value]:
    """Remove direct ref-marker children before opener inference."""
    if isinstance(value, list):
        return [
            child
            for child in value
            if _extract_call_arg_ref_name(value=child, ref_key=ref_key) is None
        ]
    return {
        key: child
        for key, child in value.items()
        if _extract_call_arg_ref_name(value=child, ref_key=ref_key) is None
    }


@beartype
def _substitute_known_refs(
    *,
    value: Value,
    ref_values: Mapping[str, Value],
    ref_key: str,
) -> Value:
    """Return *value* with each marker whose value is known replaced.

    A marker whose value was not supplied stays as it is: there is no
    type to read from it, and dropping it would leave the container it
    sits in with nothing to take a type from (issue #4567).
    """
    ref_name = _extract_call_arg_ref_name(value=value, ref_key=ref_key)
    if ref_name is not None:
        return ref_values.get(ref_name, value)
    match value:
        case dict() | list():
            return _substitute_known_refs_in_container(
                data=value,
                ref_values=ref_values,
                ref_key=ref_key,
            )
        case _:
            return value


@overload
def _opener_inference_value(
    *, data: list[Value], ctx: _RenderContext
) -> list[Value]: ...


@overload
def _opener_inference_value(
    *, data: dict[Scalar, Value], ctx: _RenderContext
) -> Value: ...


@beartype
def _opener_inference_value(
    *,
    data: dict[Scalar, Value] | list[Value],
    ctx: _RenderContext,
) -> Value:
    """Return what a container's opener reads its type from.

    A marker stands for a value declared elsewhere, so the container
    around it takes the type that reference holds rather than the
    marker's own ``{str: str}`` shape (issue #4567).
    """
    if ctx.ref_key is _DISABLED_REF_KEY:
        return data
    effective_ref_values_5: Mapping[str, Value]
    if ctx.expand_refs:
        ref_values = ctx.ref_values
        effective_ref_values_5 = reference_values_or_empty(values=ref_values)
        return _strip_direct_refs_for_opener(
            value=_substitute_known_refs_in_container(
                data=data,
                ref_values=(effective_ref_values_5),
                ref_key=ctx.ref_key,
            ),
            ref_key=ctx.ref_key,
        )
    return _resolve_refs_for_inference(
        value=data,
        ref_values=ctx.ref_values,
        ref_key=ctx.ref_key,
    )


@beartype
def _substitute_known_refs_in_container(
    *,
    data: dict[Scalar, Value] | list[Value],
    ref_values: Mapping[str, Value],
    ref_key: str,
) -> dict[Scalar, Value] | list[Value]:
    """Return a container with each known marker inside it replaced."""
    if isinstance(data, list):
        return [
            _substitute_known_refs(
                value=item,
                ref_values=ref_values,
                ref_key=ref_key,
            )
            for item in data
        ]
    # An ordered map is a dict subclass whose tag decides how it is
    # written, so the rebuilt container keeps whichever it is.
    return type(data)(
        {
            key: _substitute_known_refs(
                value=item,
                ref_values=ref_values,
                ref_key=ref_key,
            )
            for key, item in data.items()
        }
    )


@beartype
def _ordered_map_open_for_ref_inference(
    *, data: dict[Scalar, Value], ctx: _RenderContext
) -> str:
    """Return the ordered-map opener using resolved refs when needed."""
    inferred = _opener_inference_value(data=data, ctx=ctx)
    effective_inferred = data
    if isinstance(inferred, dict) and bool(inferred):
        effective_inferred = inferred
    return ctx.spec.ordered_map_format_config.ordered_map_open(
        effective_inferred
    )


@beartype
def _dict_open_for_ref_inference(
    *, data: dict[Scalar, Value], ctx: _RenderContext
) -> str:
    """Return the dictionary opener using resolved refs when needed."""
    inferred = _opener_inference_value(data=data, ctx=ctx)
    effective_inferred_2 = data
    if isinstance(inferred, dict) and bool(inferred):
        effective_inferred_2 = inferred
    return ctx.spec.dict_format_config.dict_open(effective_inferred_2)


@beartype
def _sequence_open_for_ref_inference(
    *, data: list[Value], ctx: _RenderContext
) -> str:
    """Return the sequence opener using resolved refs when needed."""
    inferred = _opener_inference_value(data=data, ctx=ctx)
    effective_inferred_3 = data
    if len(inferred) > 0:
        effective_inferred_3 = inferred
    return ctx.spec.sequence_open(effective_inferred_3)


@beartype
def _single_element_sequence_delimiters(
    *,
    data: dict[Scalar, Value] | set[Scalar] | list[Value],
    sequence_open_override: str | None,
    ctx: _RenderContext,
) -> tuple[str, str] | None:
    """Return the delimiters a one-element sequence takes, if any.

    The template a language declares for that length is one string
    around its element; a multiline layout needs the two halves apart
    so the element can sit on its own line (issue #3928).
    """
    template = ctx.spec.sequence_format_config.single_element_template
    if (
        template is None
        or sequence_open_override is not None
        or not isinstance(data, list)
        or len(data) != 1
    ):
        return None
    opening, _, close = template.partition("{items}")
    return (opening, close)


@beartype
def _collection_open_for_multiline_value(
    *,
    data: dict[Scalar, Value] | set[Scalar] | list[Value],
    is_ordered_map: bool,
    dict_open_override: str | None,
    sequence_open_override: str | None,
    ctx: _RenderContext,
) -> str:
    """Return an opener without a leading prefix.

    Used for a nested multiline collection.
    """
    spec = ctx.spec
    dict_open_for_wrap_ids = spec.heterogeneous_behavior.dict_open_for_wrap_ids
    match data:
        case dict() if is_ordered_map:
            opener = _ordered_map_open_for_ref_inference(data=data, ctx=ctx)
        case dict() if (
            id(data) in ctx.wrap_ids and dict_open_for_wrap_ids is not None
        ):
            opener = dict_open_for_wrap_ids()
        case dict() if dict_open_override is not None:
            opener = dict_open_override
        case dict() if id(data) in ctx.dict_open_overrides:
            opener = ctx.dict_open_overrides[id(data)]
        case dict():
            opener = _dict_open_for_ref_inference(data=data, ctx=ctx)
        case set():
            sorted_set: list[Value] = sorted(
                data,
                key=set_sort_key,
            )
            opener = spec.set_format_config.set_open(sorted_set)
        case _ if sequence_open_override is not None:
            opener = sequence_open_override
        case _:
            delimiters = _single_element_sequence_delimiters(
                data=data,
                sequence_open_override=sequence_open_override,
                ctx=ctx,
            )
            if delimiters is not None:
                opener = delimiters[0]
            else:
                opener = _sequence_open_for_ref_inference(data=data, ctx=ctx)
    return opener


@beartype
def _format_multiline_collection_value(
    *,
    value: dict[Scalar, Value] | set[Scalar] | list[Value],
    ctx: _RenderContext,
    dict_open_override: str | None,
    sequence_open_override: str | None,
) -> str:
    """Format a nested collection whose first delimiter has no leading
    prefix.

    The caller adds its own entry prefix to the first line. Continuation
    lines and the closing delimiter are prefixed here so nested layouts align
    under that entry.
    """
    spec = ctx.spec
    is_ordered_map = isinstance(value, OrderedMap)
    trailing_comma = spec.trailing_comma_config.multiline_trailing_comma
    body_prefix = ctx.multiline_prefix + spec.indent
    lines = _format_collection_lines(
        data=value,
        body_prefix=body_prefix,
        trailing_comma=trailing_comma,
        is_ordered_map=is_ordered_map,
        collection_layout=CollectionLayout.MULTILINE,
        sequence_open_override=sequence_open_override,
        ctx=ctx,
    )
    body = "\n".join(lines)
    opening = _collection_open_for_multiline_value(
        data=value,
        is_ordered_map=is_ordered_map,
        dict_open_override=dict_open_override,
        sequence_open_override=sequence_open_override,
        ctx=ctx,
    ).rstrip()
    closing_indent = ""
    if spec.indent_closing_delimiter:
        closing_indent = spec.indent
    close_prefix = ctx.multiline_prefix + closing_indent
    match value:
        case dict() if is_ordered_map:
            close = spec.ordered_map_format_config.close
        case dict():
            close = spec.dict_format_config.close
        case set():
            close = spec.set_format_config.close
        case _:
            delimiters = _single_element_sequence_delimiters(
                data=value,
                sequence_open_override=sequence_open_override,
                ctx=ctx,
            )
            if delimiters is not None:
                close = delimiters[1]
            else:
                close = spec.sequence_format_config.close
    return f"{opening}\n{body}\n{close_prefix}{close}"


@beartype
def _collection_comments(
    *,
    value: Value,
    ctx: _RenderContext,
) -> CollectionComments | None:
    """Return the source comments for a collection, when present.

    Applying comments here, while the renderer still knows where each
    element begins, is what keeps a comment on the element after a
    multiline one from landing inside that one (issue #4483).
    """
    if not ctx.spec.supports_collection_comments:
        return None
    comments = _source_collection_comments(value=value, ctx=ctx)
    if comments is None:
        return None
    if bool(comments.trailing) or any(
        bool(element.before) or bool(element.inline)
        for element in comments.elements
    ):
        return comments
    return None


@beartype
def _source_collection_comments(
    *,
    value: Value,
    ctx: _RenderContext,
) -> CollectionComments | None:
    """Return the extracted comments for a collection, when present."""
    if ctx.toml_comments is not None:
        if id(value) != ctx.comment_root_id:
            return None
        return ctx.toml_comments
    raw_value = ctx.yaml_comment_nodes.get(id(value))
    if raw_value is None:
        return None
    return extract_yaml_comments(
        ruamel_data=raw_value,
        nested=id(value) != ctx.comment_root_id,
        hoist_nested_inline=False,
    )


@beartype
def rstrip_lines(text: str) -> str:
    r"""Remove trailing indentation whitespace from each line.

    Only spaces and tabs are stripped.  A bare ``rstrip`` also removes
    a carriage return, and a ``\r\n`` inside a string value the target
    language embeds literally ends a line here, so the value silently
    lost its carriage return (issue #4514).
    """
    return "\n".join(line.rstrip(" \t") for line in text.split(sep="\n"))


@beartype
def _append_entries(
    *,
    formatted_entries: Sequence[str],
    lines: list[str],
    body_prefix: str,
    trailing_comma: bool,
    spec: Language,
    collection_comments: CollectionComments | None,
) -> None:
    """Append formatted entries with separators to *lines*."""
    last_idx = len(formatted_entries) - 1
    rendered_elements: list[str] = []
    for i, entry in enumerate(iterable=formatted_entries):
        add_sep = i < last_idx or trailing_comma
        sep = ""
        if add_sep:
            sep = spec.element_separator.strip()
        rendered_elements.append(
            f"{body_prefix}{rstrip_lines(text=entry)}{sep}"
        )
    if collection_comments is None:
        lines.extend(rendered_elements)
        return
    comment_cfg = spec.comment_config
    commented = apply_collection_comments_to_elements(
        rendered_elements=rendered_elements,
        collection_comments=collection_comments,
        comment_prefix=comment_cfg.prefix,
        comment_suffix=comment_cfg.suffix,
        line_prefix=body_prefix,
    )
    lines.extend(commented.split(sep="\n"))


@beartype
def _filter_collection_comments(
    *,
    collection_comments: CollectionComments,
    keep: Sequence[bool],
    redistribute: bool,
) -> CollectionComments:
    """Keep comment slots corresponding to rendered collection entries.

    A length mismatch is an internal alignment error and intentionally
    raises rather than silently assigning comments to different values.
    """
    if not redistribute:
        return CollectionComments(
            elements=tuple(
                element
                for element, keep_element in zip(
                    collection_comments.elements, keep, strict=True
                )
                if keep_element
            ),
            trailing=collection_comments.trailing,
        )

    pending: list[str] = []
    elements: list[ElementComments] = []
    for element, keep_element in zip(
        collection_comments.elements, keep, strict=True
    ):
        if not keep_element:
            pending.extend(element.before)
            if element.inline != "":
                pending.append(element.inline)
            continue
        elements.append(
            dataclasses.replace(
                element,
                before=(*pending, *element.before),
            )
        )
        pending = []
    return CollectionComments(
        elements=tuple(elements),
        trailing=(*pending, *collection_comments.trailing),
    )


@beartype
def _format_dict_lines(
    *,
    dict_data: dict[Scalar, Value],
    data: Value,
    spec: Language,
    ctx: _RenderContext,
    line_ctx: _RenderContext,
    parent_id: int,
    collection_comments: CollectionComments | None,
    is_ordered_map: bool,
    trailing_comma: bool,
    body_prefix: str,
    lines: list[str],
) -> list[str]:
    """Format dictionary entries and their collection comments."""
    guard_dict_keys_supported(value=dict_data, spec=spec)
    keep_entries = [
        not (spec.skip_null_dict_values and value is None)
        for value in dict_data.values()
    ]
    entries = [
        (k, v)
        for (k, v), keep_entry in zip(
            dict_data.items(), keep_entries, strict=True
        )
        if keep_entry
    ]
    if collection_comments is not None:
        collection_comments = _filter_collection_comments(
            collection_comments=collection_comments,
            keep=keep_entries,
            redistribute=id(data) == ctx.comment_root_id,
        )
    sibling_list_values: list[list[Value]] = [
        v for _, v in entries if isinstance(v, list)
    ]
    outer_sequence_override = _compute_sequence_open_override(
        items=sibling_list_values,
        spec=spec,
    )
    position_overrides = _compute_sibling_list_position_overrides(
        list_values=sibling_list_values,
        spec=spec,
    )
    map_int_formatter = ctx.dict_int_formatters.get(id(dict_data))
    if map_int_formatter is None:
        map_int_formatter = _map_widened_int_formatter(
            items=[v for _, v in entries],
            spec=spec,
        )
    formatted_entries: list[str] = []
    for k, v in entries:
        formatted_key: str = _format_value(
            value=k,
            dict_open_override=None,
            sequence_open_override=None,
            ctx=line_ctx.compact(),
            int_formatter=None,
        )
        formatted_val = _maybe_wrap_child(
            parent_id=parent_id,
            raw_value=v,
            formatted_value=_format_dict_entry_value(
                value=v,
                sibling_list_values=sibling_list_values,
                outer_sequence_override=outer_sequence_override,
                position_overrides=position_overrides,
                ctx=line_ctx,
                int_formatter=map_int_formatter,
            ),
            ctx=ctx,
        )
        if is_ordered_map:
            entry = spec.ordered_map_format_config.format_entry_from_source(
                raw_key=k,
                formatted_key=_format_ordered_map_key(
                    raw_key=k,
                    key_str=formatted_key,
                    spec=spec,
                ),
                raw_value=v,
                formatted_value=formatted_val,
                format_entry=spec.format_ordered_map_entry,
            )
        else:
            entry = _build_dict_entry(
                raw_key=k,
                key_str=formatted_key,
                raw_value=v,
                formatted_value=formatted_val,
                spec=spec,
            )
        formatted_entries.append(entry)
    dict_trailing = (
        trailing_comma and spec.dict_format_config.supports_trailing_comma
    )
    _append_entries(
        formatted_entries=formatted_entries,
        lines=lines,
        body_prefix=body_prefix,
        trailing_comma=dict_trailing,
        spec=spec,
        collection_comments=collection_comments,
    )
    return lines


@beartype
def _format_collection_lines(
    *,
    data: dict[Scalar, Value] | set[Scalar] | list[Value],
    body_prefix: str,
    trailing_comma: bool,
    is_ordered_map: bool,
    collection_layout: CollectionLayout,
    sequence_open_override: str | None,
    ctx: _RenderContext,
) -> list[str]:
    """Format collection elements as indented lines."""
    spec = ctx.spec
    del collection_layout
    line_ctx = ctx.with_prefix(multiline_prefix=body_prefix)
    lines: list[str] = []
    parent_id = id(data)
    collection_comments = _collection_comments(
        value=data,
        ctx=ctx,
    )
    match data:
        case dict() as dict_data:
            lines = _format_dict_lines(
                dict_data=dict_data,
                data=data,
                spec=spec,
                ctx=ctx,
                line_ctx=line_ctx,
                parent_id=parent_id,
                collection_comments=collection_comments,
                is_ordered_map=is_ordered_map,
                trailing_comma=trailing_comma,
                body_prefix=body_prefix,
                lines=lines,
            )
        case set() as set_data:
            sorted_items = sorted(
                set_data,
                key=set_sort_key,
            )
            set_parent_id = id(set_data)
            set_int_formatter = _widened_int_formatter(
                items=list(sorted_items),
                spec=spec,
            )
            formatted_entries = [
                spec.format_set_entry(
                    item,
                    _maybe_wrap_child(
                        parent_id=set_parent_id,
                        raw_value=item,
                        formatted_value=_format_value(
                            value=item,
                            dict_open_override=None,
                            sequence_open_override=None,
                            ctx=line_ctx,
                            int_formatter=set_int_formatter,
                        ),
                        ctx=ctx,
                    ),
                )
                for item in sorted_items
            ]
            set_trailing = (
                trailing_comma
                and spec.set_format_config.supports_trailing_comma
            )
            _append_entries(
                formatted_entries=formatted_entries,
                lines=lines,
                body_prefix=body_prefix,
                trailing_comma=set_trailing,
                spec=spec,
                collection_comments=collection_comments,
            )
        case list() as list_data:
            seq_trailing = (
                trailing_comma
                and spec.sequence_format_config.supports_trailing_comma
            )
            inferred_list_data = _opener_inference_value(
                data=list_data, ctx=ctx
            )
            effective_items_2 = inferred_list_data
            dict_open_override = _compute_sequence_dict_override(
                items=(effective_items_2),
                sequence_open_override=sequence_open_override,
                spec=spec,
                ref_key=ctx.ref_key,
            )
            list_int_formatter = ctx.list_int_formatters.get(id(list_data))
            if list_int_formatter is None:
                list_int_formatter = _widened_int_formatter(
                    items=list_data, spec=spec
                )
            formatted_entries = [
                spec.format_sequence_entry(
                    element,
                    _maybe_wrap_child(
                        parent_id=parent_id,
                        raw_value=element,
                        formatted_value=_format_sequence_child(
                            value=list_data,
                            position=position,
                            child=element,
                            dict_open_override=dict_open_override,
                            child_sequence_open_overrides=(),
                            ctx=line_ctx,
                            int_formatter=list_int_formatter,
                        ),
                        ctx=ctx,
                    ),
                )
                for position, element in enumerate(iterable=list_data)
            ]
            # Drop entries that render to the empty string so a nested
            # empty sub-list (possible in languages like Forth whose
            # empty-sequence opener and close are both empty) does not
            # leave a dangling indented blank line in the output.
            keep_entries = [bool(entry) for entry in formatted_entries]
            formatted_entries = [
                entry
                for entry, keep_entry in zip(
                    formatted_entries, keep_entries, strict=True
                )
                if keep_entry
            ]
            if collection_comments is not None:
                collection_comments = _filter_collection_comments(
                    collection_comments=collection_comments,
                    keep=keep_entries,
                    redistribute=id(data) == ctx.comment_root_id,
                )
            _append_entries(
                formatted_entries=formatted_entries,
                lines=lines,
                body_prefix=body_prefix,
                trailing_comma=seq_trailing,
                spec=spec,
                collection_comments=collection_comments,
            )
        case _ as unreachable:
            assert_never(unreachable)
    if isinstance(data, dict):
        lines = spec.dict_format_config.postprocess_entries(lines)
    return lines


@beartype
def _normalized_mapping_objects(
    *, mapping: Mapping[object, object]
) -> dict[object, object]:
    """Index mapping values by their public-boundary key once."""
    collected_entries: dict[object, object] = {}
    for entry_raw_key, entry_value in mapping.items():
        unwrapped_key = entry_raw_key
        if isinstance(unwrapped_key, TaggedScalar):
            unwrapped_key = unwrap_yaml_scalar(value=unwrapped_key)
        collected_entries[unwrapped_key] = entry_value
    return collected_entries


@beartype
def _sequence_object_at(*, sequence: Sequence[object], index: int) -> object:
    """Return a sequence value with its public boundary type preserved."""
    return sequence[index]


@beartype
def _collect_yaml_comment_nodes(
    *,
    value: Value,
    raw_value: object,
    out: dict[int, CommentedSeq | CommentedMap | CommentedSet],
) -> None:
    """Map rendered container identities to their ruamel YAML nodes."""
    if isinstance(raw_value, CommentedMap) and isinstance(value, dict):
        out[id(value)] = raw_value
        normalized_raw_map = _normalized_mapping_objects(mapping=raw_value)
        for key, child in value.items():
            _collect_yaml_comment_nodes(
                value=child,
                raw_value=normalized_raw_map[key],
                out=out,
            )
        return
    if isinstance(raw_value, CommentedSeq) and isinstance(value, list):
        out[id(value)] = raw_value
        typed_raw_sequence: Sequence[object] = raw_value
        for index, child in enumerate(iterable=value):
            _collect_yaml_comment_nodes(
                value=child,
                raw_value=_sequence_object_at(
                    sequence=typed_raw_sequence, index=index
                ),
                out=out,
            )
        return
    if isinstance(raw_value, CommentedSet) and isinstance(value, set):
        out[id(value)] = raw_value


@beartype
def _source_list_children_for_inference(
    *,
    source: list[Value],
    ref_values: Mapping[str, Value] | None,
    ref_key: str,
) -> list[Value]:
    """Return source children retained during reference inference."""
    children: list[Value] = []
    for child in source:
        if ref_values is not None and len(ref_values) > 0:
            include = _resolve_ref_for_preamble(
                value=child,
                ref_values=ref_values,
                ref_key=ref_key,
            ).include
        else:
            include = (
                _extract_call_arg_ref_name(value=child, ref_key=ref_key)
                is None
            )
        children.extend({True: (child,), False: ()}[include])
    return children


@beartype
def _inference_to_source_container_ids(
    *,
    source: Value,
    inferred: Value,
    ref_values: Mapping[str, Value] | None,
    ref_key: str,
) -> dict[int, int]:
    """Map inferred container ids back to corresponding source ids."""
    id_map: dict[int, int] = {}

    def _visit(*, source_item: Value, inferred_item: Value) -> None:
        """Record corresponding containers and traverse their peers."""
        if not isinstance(source_item, (dict, list, set)) or not isinstance(
            inferred_item, (dict, list, set)
        ):
            return
        id_map[id(inferred_item)] = id(source_item)
        if isinstance(source_item, list) and isinstance(inferred_item, list):
            source_children = _source_list_children_for_inference(
                source=source_item,
                ref_values=ref_values,
                ref_key=ref_key,
            )
            for source_child, inferred_child in zip(
                source_children, inferred_item, strict=False
            ):
                _visit(
                    source_item=source_child,
                    inferred_item=inferred_child,
                )
        elif isinstance(source_item, dict) and isinstance(inferred_item, dict):
            for key in source_item.keys() & inferred_item.keys():
                _visit(
                    source_item=source_item[key],
                    inferred_item=inferred_item[key],
                )

    _visit(source_item=source, inferred_item=inferred)
    return id_map


@beartype
def _source_container_ids(
    *, inferred_ids: frozenset[int], id_map: Mapping[int, int]
) -> frozenset[int]:
    """Translate inferred container ids to ids used while rendering."""
    return frozenset(
        id_map[inferred_id]
        for inferred_id in inferred_ids
        if inferred_id in id_map
    )


@beartype
def _source_container_id_mapping[T](
    *, inferred_mapping: Mapping[int, T], id_map: Mapping[int, int]
) -> dict[int, T]:
    """Translate an inferred id-keyed mapping for source rendering."""
    return {
        id_map[inferred_id]: value
        for inferred_id, value in inferred_mapping.items()
        if inferred_id in id_map
    }


@beartype
def _empty_source_container_ids(value: Value, /) -> frozenset[int]:
    """Return identities of containers that are empty in source data."""
    ids: set[int] = set()

    def _visit(item: Value, /) -> None:
        """Collect empty containers and traverse populated peers."""
        if isinstance(item, (dict, list, set)) and len(item) == 0:
            ids.add(id(item))
        if isinstance(item, dict):
            for child in item.values():
                _visit(child)
        elif isinstance(item, list):
            for child in item:
                _visit(child)

    _visit(value)
    return frozenset(ids)


@beartype
@dataclasses.dataclass(frozen=True, slots=True)
class _RecordContextFormatting:
    """Formatting metadata inferred from composition-wide record data."""

    wrap_ids: frozenset[int]
    tuple_list_ids: frozenset[int]
    dict_open_overrides: Mapping[int, str]
    dict_int_formatters: Mapping[int, Callable[[int], str]]
    empty_overrides: Mapping[int, str]
    list_int_formatters: Mapping[int, Callable[[int], str]]


@beartype
def _record_context_formatting(
    *,
    data: Value,
    language: Language,
    ref_key: str,
) -> _RecordContextFormatting:
    """Infer formatting metadata shared by composed declarations."""
    wrap_ids = _compute_wrap_ids(data=data, spec=language)
    tuple_list_ids = _compute_tuple_list_ids(data=data, spec=language)
    dict_open_overrides: dict[int, str] = {}
    # A bound map is emitted as a separate declaration, so it needs the exact
    # widened opener of the container that consumes it even for variant-based
    # languages without a universal map fallback.
    _accumulate_dict_open_overrides(
        data=data,
        spec=language,
        out=dict_open_overrides,
        ref_key=ref_key,
    )
    if isinstance(data, list):
        children = list(data)
    elif isinstance(data, dict):
        children = list(data.values())
    else:
        children = list[Value]()
    direct_dict_override = _compute_dict_open_override(
        items=children,
        spec=language,
        ref_key=ref_key,
    )
    if direct_dict_override is not None:
        plain_dict_children = [
            child
            for child in children
            if isinstance(child, dict) and not isinstance(child, OrderedMap)
        ]
        for child in plain_dict_children:
            _ = dict_open_overrides.setdefault(
                id(child),
                direct_dict_override,
            )
    formatting = _RecordContextFormatting(
        wrap_ids=wrap_ids,
        tuple_list_ids=tuple_list_ids,
        dict_open_overrides=dict_open_overrides,
        dict_int_formatters=_collect_dict_int_formatters(
            data=data,
            spec=language,
        ),
        empty_overrides=_empty_container_literal_overrides(
            data=data,
            spec=language,
        ),
        list_int_formatters=_collect_list_int_formatters(
            data=data,
            spec=language,
        ),
    )
    check_data(data=data, spec=language)
    return formatting


@beartype
def _build_render_context(
    *,
    data: Value,
    inference_data: Value,
    language: Language,
    ref_case: IdentifierCase | None,
    ref_values: Mapping[str, Value] | None,
    ref_key: str,
    collection_layout: CollectionLayout,
    line_prefix: str,
    raw_yaml_data: object | None,
    toml_comment_doc: TOMLDocument | None,
    record_context_data: Value | None,
) -> _RenderContext:
    """Build the metadata used by recursive value rendering."""
    yaml_comment_nodes: dict[
        int, CommentedSeq | CommentedMap | CommentedSet
    ] = {}
    if raw_yaml_data is not None:
        _collect_yaml_comment_nodes(
            value=data,
            raw_value=raw_yaml_data,
            out=yaml_comment_nodes,
        )
    toml_comments = None
    if toml_comment_doc is not None:
        toml_comments = extract_toml_comments(toml_doc=toml_comment_doc)

    inference_id_map = _inference_to_source_container_ids(
        source=data,
        inferred=inference_data,
        ref_values=ref_values,
        ref_key=ref_key,
    )
    alias_record_ids = language.heterogeneous_behavior.alias_record_ids
    if alias_record_ids is not None:
        alias_record_ids(inference_id_map)
    wrap_ids = _source_container_ids(
        inferred_ids=_compute_wrap_ids(data=inference_data, spec=language),
        id_map=inference_id_map,
    )
    if record_context_data is not None:
        # Computing the declaration-local wrap IDs above may update a
        # language's type-inference cache. Restore the composition-wide record
        # context before any opener or field type reads that cache.
        check_data(data=record_context_data, spec=language)
    tuple_list_ids = _source_container_ids(
        inferred_ids=_compute_tuple_list_ids(
            data=inference_data,
            spec=language,
        ),
        id_map=inference_id_map,
    )
    inferred_empty_overrides = _source_container_id_mapping(
        inferred_mapping=_empty_container_literal_overrides(
            data=inference_data,
            spec=language,
        ),
        id_map=inference_id_map,
    )
    context = _RecordContextFormatting(
        wrap_ids=frozenset[int](),
        tuple_list_ids=frozenset[int](),
        dict_open_overrides={},
        dict_int_formatters={},
        empty_overrides={},
        list_int_formatters={},
    )
    if record_context_data is not None:
        context = _record_context_formatting(
            data=record_context_data,
            language=language,
            ref_key=ref_key,
        )
    effective_comment_root_id = None
    if len(yaml_comment_nodes) > 0 or bool(toml_comments):
        effective_comment_root_id = id(data)
    source_empty_ids = _empty_source_container_ids(data)
    return _RenderContext(
        spec=language,
        wrap_ids=wrap_ids | context.wrap_ids,
        tuple_list_ids=tuple_list_ids | context.tuple_list_ids,
        dict_open_overrides={
            **_source_container_id_mapping(
                inferred_mapping=_collect_dict_open_overrides(
                    data=inference_data,
                    spec=language,
                    ref_key=ref_key,
                ),
                id_map=inference_id_map,
            ),
            **context.dict_open_overrides,
        },
        dict_int_formatters={
            **_source_container_id_mapping(
                inferred_mapping=_collect_dict_int_formatters(
                    data=inference_data,
                    spec=language,
                ),
                id_map=inference_id_map,
            ),
            **context.dict_int_formatters,
        },
        empty_container_overrides={
            container_id: literal
            for container_id, literal in {
                **inferred_empty_overrides,
                **context.empty_overrides,
            }.items()
            if container_id in source_empty_ids
        },
        list_int_formatters={
            **_collect_list_int_formatters(data=data, spec=language),
            **context.list_int_formatters,
        },
        ref_case=ref_case,
        ref_values=ref_values,
        expand_refs=False,
        ref_key=ref_key,
        collection_layout=collection_layout,
        multiline_prefix=line_prefix,
        consumable_ref_names=frozenset(),
        single_use_ref_names=frozenset(),
        consume_inhibited_ref_names=frozenset(),
        yaml_comment_nodes=yaml_comment_nodes,
        toml_comments=toml_comments,
        comment_root_id=effective_comment_root_id,
    )


@beartype
def _format_root_collection_override(
    *,
    data: dict[Scalar, Value] | list[Value] | set[Scalar] | OrderedMap,
    language: Language,
    line_prefix: str,
    include_delimiters: bool,
    ctx: _RenderContext,
) -> str | None:
    """Render a root collection that bypasses line-by-line layout."""
    if len(data) == 0 and include_delimiters:
        formatted = _format_value(
            value=data,
            dict_open_override=None,
            sequence_open_override=None,
            ctx=ctx,
            int_formatter=None,
        )
        return f"{line_prefix}{formatted}"
    if (
        isinstance(data, dict)
        and include_delimiters
        and language.skip_null_dict_values
        and all(value is None for value in data.values())
    ):
        empty_value: OrderedMap | dict[Scalar, Value] = {}
        if isinstance(data, OrderedMap):
            empty_value = OrderedMap()
        formatted = _format_value(
            value=empty_value,
            dict_open_override=None,
            sequence_open_override=None,
            ctx=ctx,
            int_formatter=None,
        )
        return f"{line_prefix}{formatted}"
    if (
        include_delimiters
        and isinstance(data, dict)
        and not isinstance(data, OrderedMap)
    ):
        record_literal = _maybe_format_record_literal(
            value=data,
            ctx=ctx.with_multiline(multiline_prefix=line_prefix),
        )
        if record_literal is not None:
            return f"{line_prefix}{record_literal}"
    if include_delimiters and isinstance(data, list):
        tuple_literal = _maybe_format_tuple_literal(
            value=data,
            ctx=ctx.with_multiline(multiline_prefix=line_prefix),
        )
        if tuple_literal is not None:
            return f"{line_prefix}{tuple_literal}"
    return None


@beartype
def _format_root_collection(
    *,
    data: dict[Scalar, Value] | list[Value] | set[Scalar] | OrderedMap,
    inference_data: Value,
    language: Language,
    line_prefix: str,
    include_delimiters: bool,
    collection_layout: CollectionLayout,
    ctx: _RenderContext,
) -> str:
    """Render one root collection with its requested delimiters."""
    override = _format_root_collection_override(
        data=data,
        language=language,
        line_prefix=line_prefix,
        include_delimiters=include_delimiters,
        ctx=ctx,
    )
    if override is not None:
        return override
    body_prefix = line_prefix
    if include_delimiters:
        body_prefix = line_prefix + language.indent
    is_ordered_map = isinstance(data, OrderedMap)
    lines = _format_collection_lines(
        data=data,
        body_prefix=body_prefix,
        trailing_comma=(
            language.trailing_comma_config.multiline_trailing_comma
        ),
        is_ordered_map=is_ordered_map,
        collection_layout=collection_layout,
        sequence_open_override=None,
        ctx=ctx,
    )
    body = "\n".join(lines)
    if not include_delimiters or body == "":
        return body
    effective_data = collection_or_default(value=inference_data, default=data)
    return _wrap_body(
        body=body,
        is_ordered_map=is_ordered_map,
        data=effective_data,
        spec=language,
        line_prefix=line_prefix,
        dict_open_override=ctx.dict_open_overrides.get(id(data)),
    )


@beartype(conf=BeartypeConf(is_pep484_tower=True))
def _literalize_impl(
    *,
    data: Value,
    language: Language,
    line_prefix: str,
    include_delimiters: bool,
    ref_case: IdentifierCase | None,
    ref_values: Mapping[str, Value] | None,
    ref_key: str,
    collection_layout: CollectionLayout,
    raw_yaml_data: object | None,
    toml_comment_doc: TOMLDocument | None,
    validate_data: bool,
    record_context_data: Value | None,
) -> str:
    r"""Convert data to native language literal text.

    Each element (or key-value pair) is formatted as a native literal
    for the given language with a trailing comma and the language's
    indent.

    Args:
        data: A scalar, sequence, or mapping.  Scalars (strings,
            numbers, booleans, ``None``, :class:`datetime.date`,
            :class:`datetime.datetime`) are formatted as a single
            literal value.  Sequences may contain scalars, sequences,
            or mappings with nesting to arbitrary depth.  Mappings are
            formatted as one key-value pair per line using the
            language's dict separator.
        language: A :class:`Language` instance describing how to format
            literals.  Use one of the built-in constants
            (e.g. :data:`PYTHON`, :data:`GO`) or provide your own.
        line_prefix: String to prepend to every output line
            (e.g. ``"        "`` for 8-space margin, or ``"\t\t"``
            for 2-tab margin).  Positions the generated block at
            the right column in surrounding source code.
        include_delimiters: If True, include the collection delimiters
            (``[`` … ``]`` for arrays, ``{`` … ``}`` for dicts).
            Ignored for scalar values.
        ref_case: When set, ref identifiers are converted to this case
            before rendering.
        ref_values: Optional mapping from ref identifier to the value
            declared elsewhere for that ref.  Forwarded to the
            language's ``format_call_ref_identifier`` /
            ``format_call_arg_ref_identifier`` hooks so type-sensitive
            languages can pick the right form.
        ref_key: The key used to identify ref markers in the input.
        collection_layout: Controls layout for collections nested
            inside other collections.
        raw_yaml_data: The comment-preserving ruamel node corresponding
            to *data*, or ``None`` for non-YAML/comment-free input.
        toml_comment_doc: The comment-preserving tomlkit document
            corresponding to *data*, or ``None`` for non-TOML input.
        validate_data: Whether to run the data checks before rendering.
            Bound-ref declarations set this false after validating their
            shared record-shape context.
        record_context_data: Composition-wide data used to restore shared
            inference caches after calculating declaration-local wrap IDs.
    """
    _validate_ref_case_is_injective(
        value=data,
        ref_key=ref_key,
        ref_case=ref_case,
    )
    if ref_key is not _DISABLED_REF_KEY and isinstance(data, dict):
        raw_ref_name = _extract_call_arg_ref_name(value=data, ref_key=ref_key)
        if raw_ref_name is not None:
            ref_name = _validated_ref_name(
                raw_ref_name=raw_ref_name,
                ref_case=ref_case,
                language=language,
            )
            ref_value = None
            if ref_values is not None:
                ref_value = ref_values.get(raw_ref_name)
            identifier = language.format_call_ref_identifier(
                ref_name, ref_value
            )
            return f"{line_prefix}{identifier}"

    inference_data = _resolve_refs_for_inference(
        value=data,
        ref_values=ref_values,
        ref_key=ref_key,
    )
    if validate_data:
        check_data(data=inference_data, spec=language)

    if (
        ref_key is _DISABLED_REF_KEY
        and raw_yaml_data is None
        and toml_comment_doc is None
    ):
        fast_result = format_document_fast(
            language,
            data=data,
            line_prefix=line_prefix,
            include_delimiters=include_delimiters,
            collection_layout=collection_layout,
        )
        if fast_result is not None:
            return fast_result

    ctx = _build_render_context(
        data=data,
        inference_data=inference_data,
        language=language,
        ref_case=ref_case,
        ref_values=ref_values,
        ref_key=ref_key,
        collection_layout=collection_layout,
        line_prefix=line_prefix,
        raw_yaml_data=raw_yaml_data,
        toml_comment_doc=toml_comment_doc,
        record_context_data=record_context_data,
    )

    if isinstance(data, _SCALAR_TYPES):
        formatted_scalar = _format_scalar(
            value=data,
            spec=language,
            int_formatter=None,
        )
        return f"{line_prefix}{formatted_scalar}"
    return _format_root_collection(
        data=data,
        inference_data=inference_data,
        language=language,
        line_prefix=line_prefix,
        include_delimiters=include_delimiters,
        collection_layout=collection_layout,
        ctx=ctx,
    )


@beartype
def _literalize_child_path(
    *,
    data: Value,
    error_type: type[LiteralizerError],
    language: Language,
    ref_case: IdentifierCase | None,
    ref_values: Mapping[str, Value] | None,
    ref_key: str,
    collection_layout: CollectionLayout,
) -> tuple[str | int, ...]:
    """Locate a renderer error by probing children with the same
    options.
    """
    children: list[tuple[str | int, Value]]
    match data:
        case dict():
            collected_children: list[tuple[str | int, Value]] = []
            for entry_entry_key, entry_entry_entry_value in data.items():
                effective_entry_entry_key = entry_entry_key
                if not (
                    isinstance(effective_entry_entry_key, (str, int))
                    and (not isinstance(effective_entry_entry_key, bool))
                ):
                    effective_entry_entry_key = repr(entry_entry_key)
                collected_children.append(
                    (effective_entry_entry_key, entry_entry_entry_value)
                )
            children = collected_children
        case list():
            children = list(enumerate(iterable=data))
        case _:
            return ()
    for component, child in children:
        with suppress(LiteralizerError):
            try:
                _ = _literalize_impl(
                    data=child,
                    language=language,
                    line_prefix="",
                    include_delimiters=True,
                    ref_case=ref_case,
                    ref_values=ref_values,
                    ref_key=ref_key,
                    collection_layout=collection_layout,
                    raw_yaml_data=None,
                    toml_comment_doc=None,
                    validate_data=True,
                    record_context_data=None,
                )
            except error_type:
                return (
                    component,
                    *_literalize_child_path(
                        data=child,
                        error_type=error_type,
                        language=language,
                        ref_case=ref_case,
                        ref_values=ref_values,
                        ref_key=ref_key,
                        collection_layout=collection_layout,
                    ),
                )
    return ()


@beartype(conf=BeartypeConf(is_pep484_tower=True))
def _literalize(
    *,
    data: Value,
    language: Language,
    line_prefix: str,
    include_delimiters: bool,
    ref_case: IdentifierCase | None,
    ref_values: Mapping[str, Value] | None,
    ref_key: str,
    collection_layout: CollectionLayout,
    raw_yaml_data: object | None,
    toml_comment_doc: TOMLDocument | None,
    validate_data: bool,
    record_context_data: Value | None,
) -> str:
    """Render data and attach a path to value-specific renderer errors."""
    try:
        return _literalize_impl(
            data=data,
            language=language,
            line_prefix=line_prefix,
            include_delimiters=include_delimiters,
            ref_case=ref_case,
            ref_values=ref_values,
            ref_key=ref_key,
            collection_layout=collection_layout,
            raw_yaml_data=raw_yaml_data,
            toml_comment_doc=toml_comment_doc,
            validate_data=validate_data,
            record_context_data=record_context_data,
        )
    except LiteralizerError as exc:
        if exc.path is None:
            exc.path = _literalize_child_path(
                data=data,
                error_type=type(exc),
                language=language,
                ref_case=ref_case,
                ref_values=ref_values,
                ref_key=ref_key,
                collection_layout=collection_layout,
            )
        raise


@beartype
def _apply_variable_wrapper(
    *,
    result: str,
    language: Language,
    data: Value,
    variable_form: NewVariable | ExistingVariable | None,
    line_prefix: str,
    is_call_binding: bool,
) -> str:
    """Optionally wrap *result* in a variable declaration or
    assignment.

    *result* arrives with *line_prefix* already prepended to every
    line.  When wrapping in a variable form the leading prefix on the
    first line is stripped so the value sits flush against the
    declaration's ``=``, then re-prepended once to the entire wrapped
    output.  This keeps every line uniformly indented instead of
    doubly-indenting continuation lines.

    When *is_call_binding* is ``True`` the right-hand side is a call
    expression, not a literal value.  Languages whose literal-binding
    templates inject a value-type-derived tag (Haskell's ``x :: Val``
    annotation, F#'s ``x: Val = FInt ...``, the OCaml
    ``let x : val_t = OInt ...`` binding, Elm's ``x : Val``, etc.) can
    opt in to call-specific formatters via
    ``format_call_variable_declaration`` (for :class:`NewVariable`) and
    ``format_call_variable_assignment`` (for :class:`ExistingVariable`);
    languages that do not define them fall back to their literal-binding
    formatter unchanged.
    """
    if variable_form is None:
        return result

    if line_prefix != "" and result.startswith(line_prefix):
        value = result[len(line_prefix) :]
    else:
        value = result

    match variable_form:
        case NewVariable(name=name, modifiers=modifiers):
            if is_call_binding:
                declaration_formatter = (
                    language.format_call_variable_declaration
                )
            else:
                declaration_formatter = language.format_variable_declaration
            validate_new_variable_name(
                language=language,
                name=name,
                name_source="NewVariable",
            )
            wrapped = declaration_formatter(
                name,
                value,
                data,
                modifiers,
            )
        case _:
            if is_call_binding:
                assignment_formatter = language.format_call_variable_assignment
            else:
                assignment_formatter = language.format_variable_assignment
            validate_new_variable_name(
                language=language,
                name=variable_form.name,
                name_source="ExistingVariable",
            )
            wrapped = assignment_formatter(
                variable_form.name,
                value,
                data,
            )

    return line_prefix + wrapped


@beartype
@dataclasses.dataclass(frozen=True)
class _PreFormState:
    """Variable-form-independent results of
    :func:`literalize_pre_form`.

    ``data`` is the parsed input with ``$ref`` markers left intact so
    the renderer can emit them as bare identifiers.  ``data_for_preamble``
    is the same tree with each ref marker resolved against the caller's
    ``ref_values`` (or stripped when the value is not supplied), so
    preamble inference sees the types actually flowing through the
    rendered code -- not the marker's ``{str: str}`` shape.

    ``data_for_declaration`` resolves known markers while retaining unknown
    ones, so annotations describe the values behind emitted identifiers.
    """

    data: Value
    data_for_preamble: Value
    data_for_declaration: Value
    result: str
    resolved: ResolvedComments | None
    line_prefix: str
    active_ref_key: str
    """The ref key the render actually used, or the disabled sentinel."""
    ref_case: IdentifierCase | None
    """The case a ref identifier was converted to, if any."""


@runtime_checkable
class _ResolvedRefDeclarationLanguage(Protocol):
    """A language opting into resolved-reference declaration hints."""

    uses_resolved_ref_declaration_data: bool


@beartype
def _declaration_data(*, pre_form: _PreFormState, language: Language) -> Value:
    """Return the source tree a language uses for declaration hints."""
    uses_resolved = (
        isinstance(language, _ResolvedRefDeclarationLanguage)
        and language.uses_resolved_ref_declaration_data
    )
    if uses_resolved:
        return pre_form.data_for_declaration
    return pre_form.data


@beartype
def _literalize_pre_form_impl(
    *,
    source: str,
    input_format: InputFormat,
    language: Language,
    pre_indent_level: int,
    include_delimiters: bool,
    ref_case: IdentifierCase | None,
    ref_values: Mapping[str, Value] | None,
    ref_key: str,
    record_null_substitutions: Mapping[str, Value] | None,
    collection_layout: CollectionLayout,
) -> _PreFormState:
    """Run the variable-form-independent phase of :func:`literalize`.

    Parses the source, formats the literal, and resolves YAML/TOML
    comments.
    """
    line_prefix = language.indent * pre_indent_level
    parsed = parse_input(source=source, input_format=input_format)
    data = _substitute_record_nulls(
        data=parsed.data,
        substitutions=record_null_substitutions,
    )
    active_ref_key = _active_literalize_ref_key(
        source=source,
        data=data,
        ref_key=ref_key,
    )

    language.validate_spec_for_data(data=data)

    effective_raw_yaml_data = None
    if isinstance(parsed, ParsedYaml) and parsed.needs_comment_resolve:
        effective_raw_yaml_data = parsed.raw_data
    effective_toml_comment_doc = None
    if isinstance(parsed, ParsedToml):
        effective_toml_comment_doc = parsed.toml_doc
    result = _literalize(
        data=data,
        language=language,
        line_prefix=line_prefix,
        include_delimiters=include_delimiters,
        ref_case=ref_case,
        ref_values=ref_values,
        ref_key=active_ref_key,
        collection_layout=collection_layout,
        raw_yaml_data=(effective_raw_yaml_data),
        toml_comment_doc=(effective_toml_comment_doc),
        record_context_data=None,
        validate_data=True,
    )

    comment_line_prefix = line_prefix
    if include_delimiters:
        comment_line_prefix = line_prefix + language.indent

    resolved: ResolvedComments | None = None
    match parsed:
        case ParsedYaml() if parsed.needs_comment_resolve:
            comment_cfg = language.comment_config
            cp = comment_cfg.prefix
            cs = comment_cfg.suffix
            resolved = resolve_yaml_comments(
                yaml_string=source,
                raw_data=parsed.raw_data,
                base=result,
                language=language,
                comment_prefix=cp,
                comment_suffix=cs,
                comment_line_prefix=comment_line_prefix,
                line_prefix=line_prefix,
            )
            result = resolved.result
        case ParsedToml():
            comment_cfg = language.comment_config
            resolved = resolve_toml_comments(
                toml_doc=parsed.toml_doc,
                base=result,
                language=language,
                comment_prefix=comment_cfg.prefix,
                comment_suffix=comment_cfg.suffix,
                comment_line_prefix=comment_line_prefix,
            )
            result = resolved.result
        case _:
            pass

    data_for_preamble: Value = data
    data_for_declaration: Value = data
    effective_ref_values_3: Mapping[str, Value]
    effective_ref_values_4: Mapping[str, Value]
    if active_ref_key is not disabled_ref_key():
        effective_ref_values_3 = reference_values_or_empty(values=ref_values)
        data_for_declaration = _substitute_known_refs(
            value=data,
            ref_values=(effective_ref_values_3),
            ref_key=active_ref_key,
        )
        # A marker with no value supplied is stripped rather than left
        # in place, so preamble inference never sees the marker's own
        # ``{str: str}`` shape and an unrelated ``ref_values`` entry
        # cannot change the preamble of identical code (issue #4480).
        effective_ref_values_4 = reference_values_or_empty(values=ref_values)
        resolution = _resolve_ref_for_preamble(
            value=data,
            ref_values=(effective_ref_values_4),
            ref_key=active_ref_key,
        )
        data_for_preamble = resolution.inference_value()

    return _PreFormState(
        data=data,
        data_for_preamble=data_for_preamble,
        data_for_declaration=data_for_declaration,
        result=result,
        resolved=resolved,
        line_prefix=line_prefix,
        active_ref_key=active_ref_key,
        ref_case=ref_case,
    )


@beartype
def literalize_pre_form(
    *,
    source: str,
    input_format: InputFormat,
    language: Language,
    pre_indent_level: int,
    include_delimiters: bool,
    ref_case: IdentifierCase | None,
    ref_values: Mapping[str, Value] | None,
    ref_key: str,
    record_null_substitutions: Mapping[str, Value] | None,
    collection_layout: CollectionLayout,
    wrap_in_file: bool,
    bound_ref_names: frozenset[str],
) -> _PreFormState:
    """Run pre-form rendering with typed recursion failures."""
    try:
        pre_form = _literalize_pre_form_impl(
            source=source,
            input_format=input_format,
            language=language,
            pre_indent_level=pre_indent_level,
            include_delimiters=include_delimiters,
            ref_case=ref_case,
            ref_values=ref_values,
            ref_key=ref_key,
            record_null_substitutions=record_null_substitutions,
            collection_layout=collection_layout,
        )
    except RecursionError as exc:
        raise recursion_parse_error(input_format=input_format) from exc
    reject_unbound_refs_in_file(
        data=pre_form.data,
        ref_key=ref_key,
        ref_case=ref_case,
        bound_ref_names=bound_ref_names,
        language=language,
        wrap_in_file=wrap_in_file,
    )
    return pre_form


@beartype
def _substitute_record_nulls(
    *,
    data: Value,
    substitutions: Mapping[str, Value] | None,
) -> Value:
    """Replace configured null-valued record fields before rendering.

    Replacements are copied for every matching field so configured containers
    cannot alias between parsed records. Ordered maps remain positional maps
    and are never considered records.
    """
    if substitutions is None or len(substitutions) == 0:
        return data
    if isinstance(data, list):
        return [
            _substitute_record_nulls(data=item, substitutions=substitutions)
            for item in data
        ]
    collected_entries_2: dict[Scalar, Value]
    if isinstance(data, dict):
        if isinstance(data, OrderedMap):
            return OrderedMap(
                {
                    key: _substitute_record_nulls(
                        data=item, substitutions=substitutions
                    )
                    for key, item in data.items()
                }
            )
        is_record = record_shape_for_dict(value=data) is not None
        collected_entries_2 = {}
        for entry_key, entry_item in data.items():
            if (
                is_record
                and isinstance(entry_key, str)
                and (entry_item is None)
                and (entry_key in substitutions)
            ):
                collected_entries_2[entry_key] = materialize_value_input(
                    value=substitutions[entry_key],
                    argument_name="record_null_substitutions",
                )
            else:
                collected_entries_2[entry_key] = _substitute_record_nulls(
                    data=entry_item, substitutions=substitutions
                )
        return collected_entries_2
    return data


@beartype
@dataclasses.dataclass(frozen=True)
class _ScopedWrapPreamble:
    """Preamble entries split by wrap-mode placement."""

    file_scope: tuple[str, ...]
    """Entries prepended to the wrapped file at file scope."""

    body: tuple[str, ...]
    """Entries placed inside the wrapped body, ahead of the body
    preamble.
    """


@beartype
def _scope_preamble_for_wrap(
    *,
    language: Language,
    preamble: tuple[str, ...],
    data_dependent_entries: tuple[str, ...],
) -> _ScopedWrapPreamble:
    """Split *preamble* by wrap-mode placement.

    Languages that set
    :attr:`~literalizer._language.LanguageCls.wraps_data_dependent_preamble_in_body`
    need their data-dependent preamble entries (Scala's generated
    ``case class`` declarations) inside the wrapped body rather than at
    file scope; everything stays at file scope for the rest.
    """
    language_cls = type(language)
    if not isinstance(language_cls, LanguageCls):
        msg = "preamble scoping requires a LanguageCls language"
        raise TypeError(msg)
    if not language_cls.wraps_data_dependent_preamble_in_body:
        return _ScopedWrapPreamble(file_scope=preamble, body=())
    body_entries = set(data_dependent_entries)
    return _ScopedWrapPreamble(
        file_scope=tuple(
            entry for entry in preamble if entry not in body_entries
        ),
        body=tuple(entry for entry in preamble if entry in body_entries),
    )


@beartype
def _validate_ref_output_name(
    *,
    language: Language,
    pre_form: _PreFormState,
    variable_form: NewVariable | ExistingVariable | None,
) -> None:
    """Reject a ref emitted as the name the output binding declares.

    A ref is rendered as a bare identifier, so one converging on the
    declared name -- directly or through ``ref_case`` conversion --
    reads that binding rather than anything the caller meant
    (issue #4506).  An ``ExistingVariable`` is exempt: the name it
    assigns to is already bound, so reading it is a legitimate shape.
    """
    if (
        not isinstance(variable_form, NewVariable)
        or pre_form.active_ref_key is _DISABLED_REF_KEY
    ):
        return
    ref_case = pre_form.ref_case
    # Compared with the language's own case sensitivity, as the bound
    # ref check is: an Ada or Fortran ref differing only in case is the
    # same identifier (issue #4506).
    collected_identifiers: list[str] = []
    for entry_entry_entry_name in _call_arg_ref_names_in_value(
        value=pre_form.data, ref_key=pre_form.active_ref_key
    ):
        effective_ref_case = entry_entry_entry_name
        if ref_case is not None:
            effective_ref_case = ref_case.convert(name=entry_entry_entry_name)
        collected_identifiers.append(effective_ref_case)
    identifiers = frozenset(collected_identifiers)
    if is_reserved_identifier(
        case_sensitive=(language.reserved_variable_identifiers_case_sensitive),
        name=variable_form.name,
        reserved_identifiers=identifiers,
    ):
        raise RefOutputCollisionError(name=variable_form.name)


@beartype
def _declaration_spellings(
    *,
    language: Language,
    render: Callable[[Language], str],
) -> set[str]:
    """Return the declaration text each declaration style would give.

    An assignment declares the name it binds when it reads as one of
    these: F# ``let mutable v = ...`` and ``let v = ...`` are different
    styles of the same declaration, and the second is what the
    assignment form emits, so it stands on its own (issue #4465).
    """
    styles = language.declaration_styles
    spellings: set[str] = set()
    for style in styles:
        try:
            styled = dataclasses.replace(language, declaration_style=style)
        except LiteralizerError:
            # A style the rest of the spec rules out spells nothing.
            continue
        spellings.add(render(styled))
    return spellings


@beartype
def reject_undeclared_assignment(
    *,
    pre_form: _PreFormState,
    language: Language,
    variable_form: NewVariable | ExistingVariable | None,
) -> None:
    """Reject an assignment a complete file would leave undeclared.

    An assignment that reads as one of the language's declarations
    introduces the name itself, so a whole file containing it compiles.
    Where it reads as none of them, the file names something it never
    declares (issue #4465).
    """
    if not isinstance(variable_form, ExistingVariable):
        return
    assignment = _apply_variable_wrapper(
        result=pre_form.result,
        language=language,
        data=_declaration_data(pre_form=pre_form, language=language),
        variable_form=variable_form,
        line_prefix=pre_form.line_prefix,
        is_call_binding=False,
    )

    def _render(styled: Language) -> str:
        """Return the declaration *styled* would emit for this value."""
        return _apply_variable_wrapper(
            result=pre_form.result,
            language=styled,
            data=_declaration_data(pre_form=pre_form, language=styled),
            variable_form=NewVariable(
                name=variable_form.name,
                modifiers=frozenset(),
            ),
            line_prefix=pre_form.line_prefix,
            is_call_binding=False,
        )

    if assignment not in _declaration_spellings(
        language=language,
        render=_render,
    ):
        raise ExistingVariableNotSelfContainedError(
            language_name=type(language).__name__
        )


@beartype
def literalize_apply_form(
    *,
    pre_form: _PreFormState,
    language: Language,
    variable_form: NewVariable | ExistingVariable | None,
    wrap_in_file: bool,
) -> LiteralizeResult:
    """Apply variable-form-specific wrapping on top of a pre-form pass.

    Performs variable wrapping, handles any pending collection
    comments, computes the preamble, and optionally wraps the output
    in a complete file.
    """
    _validate_ref_output_name(
        language=language,
        pre_form=pre_form,
        variable_form=variable_form,
    )
    if wrap_in_file:
        reject_undeclared_assignment(
            pre_form=pre_form,
            language=language,
            variable_form=variable_form,
        )

    result = _apply_variable_wrapper(
        result=pre_form.result,
        language=language,
        data=_declaration_data(pre_form=pre_form, language=language),
        variable_form=variable_form,
        line_prefix=pre_form.line_prefix,
        is_call_binding=False,
    )

    resolved = pre_form.resolved
    if resolved is not None and resolved.pending is not None:
        comment_cfg = language.comment_config
        result = prepend_collection_comments(
            collection_comments=resolved.pending,
            base=result,
            comment_prefix=comment_cfg.prefix,
            comment_suffix=comment_cfg.suffix,
            line_prefix=pre_form.line_prefix,
        )

    variable_name = None
    if variable_form is not None:
        variable_name = variable_form.name
    is_declaration = isinstance(variable_form, NewVariable)
    computed = compute_preamble(
        data=pre_form.data_for_preamble,
        language=language,
        has_variable_declaration=variable_name is not None and is_declaration,
    )
    data_dependent_preamble = language.data_dependent_preamble(
        pre_form.data_for_preamble
    )
    preamble = deduplicate_preamble_entries(
        entries=(
            computed.leading
            + tuple(language.static_preamble)
            + computed.header
            + data_dependent_preamble
        )
    )

    pre_decl: tuple[str, ...] = ()
    if resolved is not None:
        pre_decl = resolved.pending_scalar_before

    if wrap_in_file:
        content = result
        if len(pre_decl) > 0:
            content = "\n".join(pre_decl) + "\n" + content
        scoped = _scope_preamble_for_wrap(
            language=language,
            preamble=preamble,
            data_dependent_entries=data_dependent_preamble,
        )
        effective_variable_name = ""
        if variable_name is not None and variable_name != "":
            effective_variable_name = variable_name
        wrapped = language.wrap_in_file(
            content=content,
            variable_name=(effective_variable_name),
            body_preamble=scoped.body + computed.body,
        )
        if len(scoped.file_scope) > 0:
            wrapped = "\n".join(scoped.file_scope) + "\n" + wrapped
        return LiteralizeResult(
            declaration_code=wrapped,
            preamble=(),
            body_preamble=(),
            types_present=computed.types_present,
            source_data=pre_form.data_for_preamble,
            pre_declaration_comments=(),
            contains_standalone_comments=False,
            sections=(),
            data_dependent_preamble=(),
        )

    return LiteralizeResult(
        declaration_code=result,
        preamble=preamble,
        body_preamble=computed.body,
        pre_declaration_comments=pre_decl,
        types_present=computed.types_present,
        source_data=pre_form.data_for_preamble,
        sections=decode_file_sections(result),
        contains_standalone_comments=False,
        data_dependent_preamble=data_dependent_preamble,
    )


@beartype
def literalize_both_forms(
    *,
    source: str,
    input_format: InputFormat,
    language: Language,
    pre_indent_level: int,
    include_delimiters: bool,
    variable_form: BothVariableForms,
    ref_case: IdentifierCase | None,
    ref_values: Mapping[str, Value] | None,
    explicit_ref_values: Mapping[str, Value] | None,
    bound_refs: Mapping[str, Value],
    ref_key: str,
    record_null_substitutions: Mapping[str, Value] | None,
    collection_layout: CollectionLayout,
) -> LiteralizeResult:
    """Produce combined declaration + assignment output."""
    if len(bound_refs) > 0:
        return literalize_bound_refs(
            source=source,
            input_format=input_format,
            language=language,
            pre_indent_level=pre_indent_level,
            include_delimiters=include_delimiters,
            variable_form=variable_form,
            ref_case=ref_case,
            explicit_ref_values=explicit_ref_values,
            bound_refs=bound_refs,
            ref_key=ref_key,
            record_null_substitutions=record_null_substitutions,
            collection_layout=collection_layout,
        )
    pre_form = literalize_pre_form(
        source=source,
        input_format=input_format,
        language=language,
        pre_indent_level=pre_indent_level,
        include_delimiters=include_delimiters,
        ref_case=ref_case,
        ref_values=ref_values,
        ref_key=ref_key,
        record_null_substitutions=record_null_substitutions,
        collection_layout=collection_layout,
        wrap_in_file=True,
        bound_ref_names=frozenset(bound_refs),
    )
    declaration = literalize_apply_form(
        pre_form=pre_form,
        language=language,
        variable_form=NewVariable(
            name=variable_form.name,
            modifiers=variable_form.modifiers,
        ),
        wrap_in_file=False,
    )
    assignment = literalize_apply_form(
        pre_form=pre_form,
        language=language,
        variable_form=ExistingVariable(name=variable_form.name),
        wrap_in_file=False,
    )
    scoped = _scope_preamble_for_wrap(
        language=language,
        preamble=declaration.preamble,
        data_dependent_entries=declaration.data_dependent_preamble,
    )
    decl_preamble = (
        *scoped.body,
        *declaration.body_preamble,
        *declaration.pre_declaration_comments,
    )
    wrapped = language.wrap_combined_in_file(
        declaration=declaration.declaration_code,
        assignment=assignment.bare_code,
        variable_name=variable_form.name,
        body_preamble=decl_preamble,
    )
    if len(scoped.file_scope) > 0:
        wrapped = "\n".join(scoped.file_scope) + "\n" + wrapped
    return LiteralizeResult(
        declaration_code=wrapped,
        preamble=(),
        body_preamble=(),
        types_present=declaration.types_present,
        source_data=declaration.source_data,
        pre_declaration_comments=(),
        contains_standalone_comments=False,
        sections=(),
        data_dependent_preamble=(),
    )


@beartype
@dataclasses.dataclass(frozen=True)
class _BoundRefComposition:
    """Per-ref declaration results paired with the main binding."""

    declarations: tuple[LiteralizeResult, ...]
    main_result: LiteralizeResult
    assignment_result: LiteralizeResult | None
    main_variable_name: str


@beartype
def _contextual_bound_ref_values(
    *,
    source: Value,
    resolved: Value,
    bound_refs: Mapping[str, Value],
    ref_key: str,
) -> dict[str, Value]:
    """Widen scalar ref bindings to the numeric type their use
    requires.
    """
    contextual: dict[str, Value] = dict(bound_refs)

    def _visit(*, raw: Value, inferred: Value) -> None:
        """Find markers whose resolved siblings require float bindings."""
        raw_children: Iterable[Value]
        inferred_children: Iterable[Value]
        child_pairs: Iterable[tuple[Value, Value]]
        if isinstance(raw, list) and isinstance(inferred, list):
            raw_children = raw
            inferred_children = inferred
            child_pairs = zip(raw, inferred, strict=False)
        elif isinstance(raw, dict) and isinstance(inferred, dict):
            raw_children = raw.values()
            inferred_children = inferred.values()
            child_pairs = (
                (raw[key], inferred[key])
                for key in raw.keys() & inferred.keys()
            )
        else:
            return

        if any(isinstance(item, float) for item in inferred_children):
            for child in raw_children:
                name = _extract_call_arg_ref_name(value=child, ref_key=ref_key)
                if name is not None:
                    # ``literalize_bound_refs`` rejects undeclared references
                    # before collecting contexts, so every marker is present.
                    value = contextual[name]
                    if isinstance(value, int) and not isinstance(value, bool):
                        contextual[name] = float(value)
        for raw_child, inferred_child in child_pairs:
            if (
                _extract_call_arg_ref_name(value=raw_child, ref_key=ref_key)
                is None
            ):
                _visit(raw=raw_child, inferred=inferred_child)

    _visit(raw=source, inferred=resolved)
    return contextual


@beartype
def _copy_parent_mapping(*, value: dict[Scalar, Value]) -> dict[Scalar, Value]:
    """Copy a reference's parent while preserving ordered-map
    semantics.
    """
    if isinstance(value, OrderedMap):
        return OrderedMap(value)
    return dict(value)


@beartype
def _bound_ref_parent_contexts(
    *,
    source: Value,
    resolved: Value,
    bound_refs: Mapping[str, Value],
    ref_key: str,
) -> dict[str, Value]:
    """Return each bound ref inside the resolved container that uses
    it.
    """
    contexts: dict[str, Value] = {}

    def _visit(*, raw: Value, inferred: Value) -> None:
        """Pair each marker with a resolved copy of its parent."""
        if isinstance(raw, list) and isinstance(inferred, list):
            for index, (raw_child, inferred_child) in enumerate(
                iterable=zip(raw, inferred, strict=False)
            ):
                name = _extract_call_arg_ref_name(
                    value=raw_child, ref_key=ref_key
                )
                if name is None:
                    _visit(raw=raw_child, inferred=inferred_child)
                    continue
                list_parent = list(inferred)
                list_parent[index] = bound_refs[name]
                _ = contexts.setdefault(name, list_parent)
        elif isinstance(raw, dict) and isinstance(inferred, dict):
            for key in raw.keys() & inferred.keys():
                raw_child = raw[key]
                name = _extract_call_arg_ref_name(
                    value=raw_child, ref_key=ref_key
                )
                if name is None:
                    _visit(raw=raw_child, inferred=inferred[key])
                    continue
                dict_parent = _copy_parent_mapping(value=inferred)
                dict_parent[key] = bound_refs[name]
                _ = contexts.setdefault(name, dict_parent)

    _visit(raw=source, inferred=resolved)
    return contexts


@beartype
def literalize_bound_refs(
    *,
    source: str,
    input_format: InputFormat,
    language: Language,
    pre_indent_level: int,
    include_delimiters: bool,
    variable_form: NewVariable | ExistingVariable | BothVariableForms,
    ref_case: IdentifierCase | None,
    explicit_ref_values: Mapping[str, Value] | None,
    bound_refs: Mapping[str, Value],
    ref_key: str,
    record_null_substitutions: Mapping[str, Value] | None,
    collection_layout: CollectionLayout,
) -> LiteralizeResult:
    """Emit a binding for each supplied ref before its first use.

    Renders one per-ref declaration (via :func:`literalize` with no
    ``bound_refs`` and no file wrapping) for every name in *bound_refs*,
    in *bound_refs* iteration order, then renders the main binding with
    the bound values folded into ``ref_values``.  Callers supply
    ``bound_refs`` already ordered by the ref's first use in *source*
    (and containing only refs that appear there), so the bindings are
    emitted before their first use.  The pieces are composed by
    sequencing every binding's declaration text per language (Nix
    nested ``let``, Fortran two-phase) and wrapping the result in
    variable mode so the language's binding epilogue (Go ``_ = name``,
    Haskell ``seq name``) is preserved.
    """
    ordered_names = list(bound_refs)
    effective_ref_values: dict[str, Value] = {
        name: bound_refs[name] for name in ordered_names
    }
    effective_explicit_ref_values: Mapping[str, Value]
    effective_explicit_ref_values = reference_values_or_empty(
        values=explicit_ref_values
    )
    effective_ref_values.update(effective_explicit_ref_values)
    effective_ref_values_2 = nonempty_mapping(values=effective_ref_values)
    pre_form = literalize_pre_form(
        source=source,
        input_format=input_format,
        language=language,
        pre_indent_level=pre_indent_level,
        include_delimiters=include_delimiters,
        ref_case=ref_case,
        ref_values=(effective_ref_values_2),
        ref_key=ref_key,
        record_null_substitutions=record_null_substitutions,
        collection_layout=collection_layout,
        wrap_in_file=True,
        bound_ref_names=frozenset(bound_refs),
    )
    declaration_form = variable_form
    if isinstance(declaration_form, BothVariableForms):
        declaration_form = NewVariable(
            name=declaration_form.name,
            modifiers=declaration_form.modifiers,
        )
    # This route is reached only for a wrapped file, and the wrapping
    # happens in the composer below, so the self-containment guard runs
    # here rather than through ``literalize_apply_form`` (issue #4465).
    reject_undeclared_assignment(
        pre_form=pre_form,
        language=language,
        variable_form=declaration_form,
    )
    main_result = literalize_apply_form(
        pre_form=pre_form,
        language=language,
        variable_form=declaration_form,
        wrap_in_file=False,
    )
    assignment_result = None
    if isinstance(variable_form, BothVariableForms):
        assignment_result = literalize_apply_form(
            pre_form=pre_form,
            language=language,
            variable_form=ExistingVariable(name=variable_form.name),
            wrap_in_file=False,
        )
    contextual_bound_refs = _contextual_bound_ref_values(
        source=pre_form.data,
        resolved=pre_form.data_for_preamble,
        bound_refs=bound_refs,
        ref_key=ref_key,
    )
    bound_ref_contexts = _bound_ref_parent_contexts(
        source=pre_form.data,
        resolved=pre_form.data_for_preamble,
        bound_refs=contextual_bound_refs,
        ref_key=ref_key,
    )
    decl_results: list[LiteralizeResult] = []
    for name in ordered_names:
        bound_value = contextual_bound_refs[name]
        language.validate_spec_for_data(data=bound_value)
        converted_name = name
        if ref_case is not None:
            converted_name = ref_case.convert(name=name)
        decl_results.append(
            _literalize_value_binding(
                value=bound_value,
                language=language,
                variable_form=NewVariable(
                    name=converted_name, modifiers=frozenset()
                ),
                collection_layout=collection_layout,
                record_context_data=bound_ref_contexts.get(
                    name, pre_form.data_for_preamble
                ),
                line_prefix=pre_form.line_prefix,
            )
        )
    composition = _BoundRefComposition(
        declarations=tuple(decl_results),
        main_result=main_result,
        assignment_result=assignment_result,
        main_variable_name=variable_form.name,
    )
    return _compose_bound_refs(
        language=language,
        composition=composition,
    )


@beartype
def _literalize_value_binding(
    *,
    value: Value,
    language: Language,
    variable_form: NewVariable,
    collection_layout: CollectionLayout,
    record_context_data: Value | None,
    line_prefix: str,
) -> LiteralizeResult:
    """Render *value* as a variable binding without file wrapping.

    Mirrors the ``literalize`` declaration path for an already-parsed
    value (a bound ref's materialized value), so it carries no source
    comments and needs no parsing.  *line_prefix* is the caller's
    margin, so a declaration sits at the same indentation as the
    binding it precedes (issue #4464).
    """
    result_text = _literalize(
        data=value,
        language=language,
        line_prefix=line_prefix,
        include_delimiters=True,
        ref_case=None,
        ref_values=None,
        ref_key=_DISABLED_REF_KEY,
        collection_layout=collection_layout,
        raw_yaml_data=None,
        toml_comment_doc=None,
        validate_data=record_context_data is None,
        record_context_data=record_context_data,
    )
    wrapped = _apply_variable_wrapper(
        result=result_text,
        language=language,
        data=value,
        variable_form=variable_form,
        line_prefix=line_prefix,
        is_call_binding=False,
    )
    computed = compute_preamble(
        data=value,
        language=language,
        has_variable_declaration=True,
    )
    data_dependent_preamble = language.data_dependent_preamble(value)
    preamble = deduplicate_preamble_entries(
        entries=(
            computed.leading
            + tuple(language.static_preamble)
            + computed.header
            + data_dependent_preamble
        )
    )
    return LiteralizeResult(
        declaration_code=wrapped,
        preamble=preamble,
        body_preamble=computed.body,
        types_present=computed.types_present,
        source_data=value,
        pre_declaration_comments=(),
        contains_standalone_comments=False,
        sections=(),
        data_dependent_preamble=data_dependent_preamble,
    )


@beartype
def _compose_bound_refs(
    *,
    language: Language,
    composition: _BoundRefComposition,
) -> LiteralizeResult:
    """Compose per-ref declarations and the main binding into a file.

    Recomputes the body preamble across the union of types observed in
    every declaration and the main binding, sequences every binding's
    declaration text (the last entry is the main binding), then wraps
    the sequenced content in variable mode through
    :meth:`Language.wrap_in_file` so the language's variable-binding
    epilogue (e.g. Go's ``_ = name`` or Haskell's ``seq name``) is
    emitted exactly as for a single-binding ``wrap_in_file=True`` call.

    Declaration sequencing defaults to a plain newline join, which is
    correct for every language whose bindings can simply precede one
    another at statement scope.  Languages that need declaration-level
    reordering (the Fortran rule that specification statements precede
    executable statements) or structural nesting (the Nix chained
    ``let``) override :meth:`Language.sequence_binding_declarations`.
    Preamble lines are deduplicated in first-seen order.
    """
    decl_results = composition.declarations
    main_result = composition.main_result
    empty_types = frozenset[type]()
    union_types = empty_types.union(
        *(d.types_present for d in decl_results),
        main_result.types_present,
    )
    combined_source_data: list[Value] = [
        *(d.source_data for d in decl_results),
        main_result.source_data,
    ]
    unified_body_preamble = language.compute_body_preamble(
        union_types, combined_source_data
    )
    binding_bare_codes = (
        *(d.bare_code for d in decl_results),
        main_result.bare_code,
    )
    sequenced_content = language.sequence_binding_declarations(
        declarations=binding_bare_codes
    )
    # Each declaration emitted its data-dependent block (e.g. Gleam's
    # ``pub type GVal {...}``) from *its own* data alone, so the
    # per-declaration blocks disagree on which constructors they
    # declare.  The main binding was rendered with every bound ref
    # resolved into its data, so ``main_result.preamble`` already
    # carries one block computed over that full union (declarations
    # *and* the main binding); it is the single canonical copy.  Unlike
    # the call composer there is no divergent form to reconcile: every
    # binding renders its data-dependent construct through
    # :meth:`Language.data_dependent_preamble`, which is a pure function
    # of the value, so the exact strings a declaration appended to its
    # ``preamble`` are reproducible by re-invoking it on that
    # declaration's ``source_data``.  Drop those reproduced
    # per-declaration blocks and let first-seen duplicate removal
    # collapse the shared single-line entries (imports, package lines).
    # Keep a declaration-local data entry only when recomputing over the
    # entire composition reproduces it.  This retains shared imports while
    # dropping one-line and multi-line declarations whose generated names
    # or field types conflict with the main binding's canonical preamble.
    unified_data_dependent_preamble = language.data_dependent_preamble(
        combined_source_data
    )
    unified_data_dependent_entries = set(unified_data_dependent_preamble)
    declaration_preamble = tuple(
        entry
        for d in decl_results
        for entry in d.preamble
        if entry not in d.data_dependent_preamble
        or entry in unified_data_dependent_entries
    )
    all_preamble = deduplicate_preamble_entries(
        entries=declaration_preamble + main_result.preamble
    )
    scoped = _scope_preamble_for_wrap(
        language=language,
        preamble=all_preamble,
        data_dependent_entries=deduplicate_preamble_entries(
            entries=(
                main_result.data_dependent_preamble
                + unified_data_dependent_preamble
            )
        ),
    )
    body_preamble = scoped.body + unified_body_preamble
    if composition.assignment_result is None:
        wrapped = language.wrap_in_file(
            content=sequenced_content,
            variable_name=composition.main_variable_name,
            body_preamble=body_preamble,
        )
    else:
        wrapped = language.wrap_combined_in_file(
            declaration=sequenced_content,
            assignment=composition.assignment_result.bare_code,
            variable_name=composition.main_variable_name,
            body_preamble=body_preamble,
        )
    if len(scoped.file_scope) > 0:
        wrapped = "\n".join(scoped.file_scope) + "\n" + wrapped
    return LiteralizeResult(
        declaration_code=wrapped,
        preamble=(),
        body_preamble=(),
        types_present=union_types,
        source_data=main_result.source_data,
        pre_declaration_comments=(),
        contains_standalone_comments=False,
        sections=(),
        data_dependent_preamble=(),
    )


@beartype
def _active_literalize_ref_key(
    *,
    source: str,
    data: Value,
    ref_key: str,
) -> str:
    """Return *ref_key* when literalize should check for ref markers."""
    if (ref_key == "$ref" and "$" in source) or (
        ref_key != "$ref" and ref_key in source
    ):
        return ref_key
    if "\\" in source and _contains_ref_marker(
        value=data,
        ref_key=ref_key,
    ):
        return ref_key
    return _DISABLED_REF_KEY


@beartype
def _extract_call_arg_ref_name(*, value: Value, ref_key: str) -> str | None:
    """Return the identifier name for a ``{ref_key: "name"}`` marker.

    Returns ``None`` when *value* is not a variable-reference marker.
    In :func:`literalize_call` such markers render as the bare
    identifier instead of being formatted as a literal value.
    """
    if (
        ref_key is _DISABLED_REF_KEY
        or not isinstance(value, dict)
        or len(value) != 1
    ):
        return None
    ref_value = value.get(ref_key)
    if not isinstance(ref_value, str):
        return None
    return ref_value


@beartype
def _validated_ref_name(
    *,
    raw_ref_name: str,
    ref_case: IdentifierCase | None,
    language: Language,
) -> str:
    """Convert and validate a ref name before emitting source code."""
    ref_name = raw_ref_name
    if ref_case is not None:
        ref_name = ref_case.convert(name=raw_ref_name)
    validate_new_variable_name(
        language=language,
        name=ref_name,
        name_source="reference",
    )
    return ref_name


@beartype
def _contains_ref_marker(*, value: Value, ref_key: str) -> bool:
    """Return whether *value* contains a ``{ref_key: "name"}`` marker."""
    if _extract_call_arg_ref_name(value=value, ref_key=ref_key) is not None:
        return True
    match value:
        case dict():
            return any(
                _contains_ref_marker(value=v, ref_key=ref_key)
                for v in value.values()
            )
        case list():
            return any(
                _contains_ref_marker(value=item, ref_key=ref_key)
                for item in value
            )
        case _:
            return False


@beartype
def _collect_ref_names(*, value: Value, ref_key: str) -> frozenset[str]:
    """Return every reference name a value names."""
    name = _extract_call_arg_ref_name(value=value, ref_key=ref_key)
    if name is not None:
        return frozenset({name})
    match value:
        case dict():
            return frozenset[str]().union(
                *(
                    _collect_ref_names(value=item, ref_key=ref_key)
                    for item in value.values()
                )
            )
        case list():
            return frozenset[str]().union(
                *(
                    _collect_ref_names(value=item, ref_key=ref_key)
                    for item in value
                )
            )
        case _:
            return frozenset[str]()


@beartype
def reject_unbound_refs_in_file(
    *,
    data: Value,
    ref_key: str,
    ref_case: IdentifierCase | None,
    bound_ref_names: frozenset[str],
    language: Language,
    wrap_in_file: bool,
) -> None:
    """Reject a complete file that would name an undeclared reference.

    A wrapped result is a whole file, so every name it uses has to be
    declared in it.  ``bound_refs`` is what emits those declarations;
    a reference with no entry there leaves the file naming an
    identifier nothing gives a value (issue #4499).

    Both sides are read in *ref_case*, which is the spelling the
    emitted code uses, so a binding named in another case still
    answers for the marker.  An unwrapped result is a fragment the
    caller places, so it is free to name what it does not declare, and
    so is a language that binds no name at all.
    """
    if not wrap_in_file or not language.supports_variable_names:
        # A language that binds no name declares no reference either:
        # its wrapped output is the value itself, where a reference is
        # written as the name and nothing more.
        return

    def _spelled(name: str, /) -> str:
        """Return *name* as the emitted code spells it."""
        if ref_case is None:
            return name
        return ref_case.convert(name=name)

    bound = {_spelled(name) for name in bound_ref_names}
    unbound = {
        name
        for name in _collect_ref_names(value=data, ref_key=ref_key)
        if _spelled(name) not in bound
    }
    if len(unbound) > 0:
        raise RefNotSelfContainedError(
            language_name=type(language).__name__,
            ref_names=frozenset(unbound),
        )


@beartype
def _strip_refs_from_value(*, value: Value, ref_key: str) -> Value:
    """Return *value* with ``{"$ref": "name"}`` markers removed at any
    depth.

    Used to produce ref-free data for preamble inference, validation,
    and wrap-id computation so that the ``{str: str}`` shape of a ref
    marker never influences type-dependent logic.
    """
    if isinstance(value, list):
        return [
            _strip_refs_from_value(value=item, ref_key=ref_key)
            for item in value
            if _extract_call_arg_ref_name(value=item, ref_key=ref_key) is None
        ]
    if (
        isinstance(value, dict)
        and _extract_call_arg_ref_name(value=value, ref_key=ref_key) is None
    ):
        return {
            k: _strip_refs_from_value(value=v, ref_key=ref_key)
            for k, v in value.items()
            if _extract_call_arg_ref_name(value=v, ref_key=ref_key) is None
        }
    return value


@beartype
def _resolve_refs_for_inference(
    *,
    value: Value,
    ref_values: Mapping[str, Value] | None,
    ref_key: str,
) -> Value:
    """Resolve known refs and remove unknown refs for type inference."""
    if ref_key is _DISABLED_REF_KEY:
        return value
    if ref_values is not None and len(ref_values) > 0:
        resolved = _resolve_ref_for_preamble(
            value=value,
            ref_values=ref_values,
            ref_key=ref_key,
        )
        return resolved.inference_value()
    return _strip_refs_from_value(value=value, ref_key=ref_key)


@beartype
@dataclasses.dataclass(frozen=True)
class _PreambleRefResolution:
    """Ref-marker resolution result for preamble inference."""

    include: bool
    value: Value

    def inference_value(self) -> Value:
        """Represent an omitted root marker as an empty inference
        input.
        """
        if self.include:
            return self.value
        return []


@beartype
def _resolve_ref_list_for_preamble(
    *,
    values: list[Value],
    ref_values: Mapping[str, Value],
    ref_key: str,
) -> list[Value]:
    """Resolve known refs and remove unknown refs within a list."""
    result: list[Value] = []
    for value in values:
        resolved = _resolve_ref_for_preamble(
            value=value,
            ref_values=ref_values,
            ref_key=ref_key,
        )
        if resolved.include:
            result.append(resolved.value)
    return result


@beartype
def _resolve_ref_for_preamble(
    *,
    value: Value,
    ref_values: Mapping[str, Value],
    ref_key: str,
) -> _PreambleRefResolution:
    """Resolve ref markers for preamble inference.

    Returns ``include=False`` when *value* is a ref marker whose source
    value was not supplied.  Callers use that flag to drop the
    marker, preserving the historical "strip refs" behavior for
    unknown ref names.
    """
    ref_name = _extract_call_arg_ref_name(value=value, ref_key=ref_key)
    if ref_name is not None:
        if ref_name not in ref_values:
            return _PreambleRefResolution(include=False, value=None)
        return _PreambleRefResolution(
            include=True,
            value=ref_values[ref_name],
        )
    if isinstance(value, list):
        return _PreambleRefResolution(
            include=True,
            value=_resolve_ref_list_for_preamble(
                values=value,
                ref_values=ref_values,
                ref_key=ref_key,
            ),
        )
    if isinstance(value, dict):
        resolved_dict: dict[Scalar, Value] = {}
        for key, item in value.items():
            resolved = _resolve_ref_for_preamble(
                value=item,
                ref_values=ref_values,
                ref_key=ref_key,
            )
            if resolved.include:
                resolved_dict[key] = resolved.value
        # An ordered map is a dict subclass whose tag decides how it is
        # written and typed, so the rebuilt tree keeps whichever it is
        # (issue #4735).
        return _PreambleRefResolution(
            include=True,
            value=type(value)(resolved_dict),
        )
    return _PreambleRefResolution(include=True, value=value)


@beartype
def _compute_call_arg_ref_single_use_names(
    *,
    elements: list[Value],
    ref_key: str,
) -> frozenset[str]:
    """Return ref identifiers that appear exactly once across the calls.

    Names are returned in the original (pre-``ref_case``) form supplied
    by the caller, so they can be compared against the user-supplied
    ``consumable_refs`` set on
    :func:`~literalizer.literalize_call` without further conversion.

    Refs not in this set are unsafe to consume: they appear in more than
    one per-element call (or more than once anywhere inside a single
    call's argument tree), so a language that moves consumable refs
    (notably C++ ``std::move``) would render a use-after-move on the
    second occurrence.
    """
    counts: dict[str, int] = {}
    for element in elements:
        arg_values = element
        if not isinstance(arg_values, list):
            arg_values = [element]
        for value in arg_values:
            for ref_name in _call_arg_ref_names_in_value(
                value=value,
                ref_key=ref_key,
            ):
                counts[ref_name] = counts.get(ref_name, 0) + 1
    return frozenset(name for name, count in counts.items() if count == 1)


@beartype
def _compute_call_arg_ref_consume_inhibited_names(
    *,
    elements: list[Value],
    ref_values: Mapping[str, Value],
    ref_key: str,
    language: Language,
) -> frozenset[str]:
    """Return ref identifiers whose underlying value inhibits the
    language's consume form.

    Languages whose consume operator rejects certain value types (notably
    the Mojo ``^`` on register-trivial scalars) expose
    :attr:`~literalizer._language.Language.consumable_ref_value_inhibits_consuming_form`
    so the call site can route those refs through the non-consuming
    formatter instead.  Names are returned in the original (pre-``ref_case``)
    form so they can be compared against the user-supplied
    ``consumable_refs`` set without further conversion.

    Refs whose value is not present in *ref_values* fall through with the
    consume form intact, matching the historical behavior for callers
    that omit ``ref_values``.
    """
    if len(ref_values) == 0:
        return frozenset[str]()
    inhibits = language.consumable_ref_value_inhibits_consuming_form
    referenced: set[str] = set()
    for element in elements:
        arg_values = element
        if not isinstance(arg_values, list):
            arg_values = [element]
        for value in arg_values:
            referenced.update(
                _call_arg_ref_names_in_value(
                    value=value,
                    ref_key=ref_key,
                )
            )
    return frozenset(
        name
        for name in referenced
        if name in ref_values and inhibits(ref_values[name])
    )


@beartype
def _call_arg_ref_names_in_value(
    *,
    value: Value,
    ref_key: str,
) -> list[str]:
    """Return ref names found recursively in one call argument."""
    ref_name = _extract_call_arg_ref_name(value=value, ref_key=ref_key)
    if ref_name is not None:
        return [ref_name]
    if isinstance(value, list):
        return [
            nested_name
            for item in value
            for nested_name in _call_arg_ref_names_in_value(
                value=item,
                ref_key=ref_key,
            )
        ]
    if isinstance(value, dict):
        return [
            nested_name
            for item in value.values()
            for nested_name in _call_arg_ref_names_in_value(
                value=item,
                ref_key=ref_key,
            )
        ]
    return []


@beartype
def _validate_ref_case_is_injective(
    *,
    value: Value,
    ref_key: str,
    ref_case: IdentifierCase | None,
) -> None:
    """Reject distinct ref names that case-convert to one identifier."""
    if ref_case is None:
        return
    source_name_by_identifier: dict[str, str] = {}
    for source_name in _call_arg_ref_names_in_value(
        value=value,
        ref_key=ref_key,
    ):
        identifier = ref_case.convert(name=source_name)
        previous = source_name_by_identifier.get(identifier)
        if previous is not None and previous != source_name:
            msg = (
                f"cannot convert ref name {source_name!r} to "
                f"{ref_case.name}: its identifier {identifier!r} "
                f"collides with ref name {previous!r}"
            )
            raise UnrepresentableInputError(msg)
        source_name_by_identifier[identifier] = source_name


@beartype
def _format_call_arg_ref_identifier(
    *,
    raw_ref_name: str,
    ref_name: str,
    ref_value: Value | None,
    language: Language,
    consumable_ref_names: frozenset[str],
    single_use_ref_names: frozenset[str],
    consume_inhibited_ref_names: frozenset[str],
) -> str:
    """Render a call ref through its safe regular or consuming form."""
    is_consumable = (
        raw_ref_name in consumable_ref_names
        and raw_ref_name in single_use_ref_names
        and raw_ref_name not in consume_inhibited_ref_names
    )
    if is_consumable:
        return language.format_call_arg_ref_identifier_consumable(
            ref_name, ref_value
        )
    return language.format_call_arg_ref_identifier(ref_name, ref_value)


@beartype
@dataclasses.dataclass(frozen=True)
class _ResolvedCallPreambleData:
    """Ref-resolved data for whole-input or per-element calls."""

    value: Value
    rows: list[Value] | None


@beartype
def _resolve_call_preamble_data(
    *,
    data: Value,
    per_element_data: list[Value] | None,
    ref_key: str,
    ref_values: Mapping[str, Value],
) -> _ResolvedCallPreambleData:
    """Return *data* with call-argument ref markers resolved or removed.

    Ref markers represent a variable declared elsewhere, not real data,
    so they would pollute data-driven preamble inference (e.g. dragging
    in ``Data.Map`` imports for Haskell just because the marker happens
    to be a ``{str: str}`` dict).  Drop refs whose values are unknown
    before computing the preamble while leaving :func:`_format_call_args`
    to render them.

    When *ref_values* supplies the value behind a marker, substitute
    that value into the preamble input so the referenced variable's
    types participate in body-preamble computation.

    When *per_element_data* is present, refs are resolved within each
    call row and the typed rows are retained alongside the general
    preamble value.  Otherwise a top-level ref becomes an empty list,
    standing in for "no data".  Refs nested inside list or dict argument
    values are also stripped recursively.
    """
    if per_element_data is not None:
        rows: list[Value]
        if len(ref_values) > 0:
            rows = _resolve_ref_list_for_preamble(
                values=per_element_data,
                ref_values=ref_values,
                ref_key=ref_key,
            )
        else:
            rows = []
            for element in per_element_data:
                match element:
                    case list():
                        rows.append(
                            [
                                _strip_refs_from_value(
                                    value=value,
                                    ref_key=ref_key,
                                )
                                for value in element
                                if _extract_call_arg_ref_name(
                                    value=value,
                                    ref_key=ref_key,
                                )
                                is None
                            ]
                        )
                    case _ if (
                        _extract_call_arg_ref_name(
                            value=element,
                            ref_key=ref_key,
                        )
                        is None
                    ):
                        rows.append(
                            _strip_refs_from_value(
                                value=element,
                                ref_key=ref_key,
                            )
                        )
                    case _:
                        # A ref-named non-list element is dropped entirely.
                        pass
        return _ResolvedCallPreambleData(value=rows, rows=rows)

    if len(ref_values) > 0:
        resolved = _resolve_ref_for_preamble(
            value=data,
            ref_values=ref_values,
            ref_key=ref_key,
        )
        value: Value = []
        if resolved.include:
            value = resolved.value
        return _ResolvedCallPreambleData(value=value, rows=None)
    if _extract_call_arg_ref_name(value=data, ref_key=ref_key) is not None:
        return _ResolvedCallPreambleData(value=[], rows=None)
    return _ResolvedCallPreambleData(
        value=_strip_refs_from_value(value=data, ref_key=ref_key),
        rows=None,
    )


@beartype
def _format_single_call_arg(
    *,
    value: Value,
    language: Language,
    wrap_ids: frozenset[int],
    tuple_list_ids: frozenset[int],
    scalar_wrap_ids: frozenset[int],
    wrap_arg: Callable[[Value, str], str],
    dict_open_override: str | None,
    ref_case: IdentifierCase | None,
    ref_values: Mapping[str, Value] | None,
    consumable_ref_names: frozenset[str],
    single_use_ref_names: frozenset[str],
    consume_inhibited_ref_names: frozenset[str],
    ref_key: str,
    collection_layout: CollectionLayout,
) -> str:
    """Format one argument value for a function call.

    A ref marker renders as the bare identifier; the ``format_call_arg``
    hook is skipped for refs because the referenced variable already has
    the call's parameter type.  When *ref_case* is not ``None``, the ref
    name is converted to that case before being emitted.

    *consumable_ref_names* is the caller's declaration of which refs
    this call owns and may move from.  *single_use_ref_names* is the
    set of refs that appear exactly once across this call's argument
    lists.  *consume_inhibited_ref_names* is the set of refs whose
    underlying value type inhibits the language's consume form (e.g.
    the Mojo ``^`` on register-trivial scalars).  All three sets use the
    original (pre-``ref_case``) name.  A ref is rendered via the
    language's ``format_call_arg_ref_identifier_consumable`` hook only
    when it is in *consumable_ref_names* and *single_use_ref_names* and
    not in *consume_inhibited_ref_names*; otherwise it goes through the
    regular ``format_call_arg_ref_identifier`` hook.  This ensures that
    a ref used in more than one call -- or whose value type the
    language's consume operator rejects -- is never consumed, even when
    the caller listed it as consumable.
    """
    raw_ref_name = _extract_call_arg_ref_name(value=value, ref_key=ref_key)
    if raw_ref_name is not None:
        ref_name = _validated_ref_name(
            raw_ref_name=raw_ref_name,
            ref_case=ref_case,
            language=language,
        )
        ref_value = reference_values_or_empty(values=ref_values).get(
            raw_ref_name
        )
        return _format_call_arg_ref_identifier(
            raw_ref_name=raw_ref_name,
            ref_name=ref_name,
            ref_value=ref_value,
            language=language,
            consumable_ref_names=consumable_ref_names,
            single_use_ref_names=single_use_ref_names,
            consume_inhibited_ref_names=consume_inhibited_ref_names,
        )
    ctx = _RenderContext(
        spec=language,
        wrap_ids=wrap_ids,
        tuple_list_ids=tuple_list_ids,
        # Nested sibling-map widening (#2878) is scoped to the
        # ``literalize`` literal and ``$zipped`` paths; call arguments
        # already reconcile sibling dict types across slots via
        # ``_compute_call_slot_overrides``, so this map stays empty here.
        dict_open_overrides={},
        dict_int_formatters=_collect_dict_int_formatters(
            data=value, spec=language
        ),
        empty_container_overrides=_empty_container_literal_overrides(
            data=value, spec=language
        ),
        list_int_formatters=_collect_list_int_formatters(
            data=value, spec=language
        ),
        ref_case=ref_case,
        ref_values=ref_values,
        expand_refs=True,
        ref_key=ref_key,
        collection_layout=collection_layout,
        multiline_prefix="",
        consumable_ref_names=consumable_ref_names,
        single_use_ref_names=single_use_ref_names,
        consume_inhibited_ref_names=consume_inhibited_ref_names,
        yaml_comment_nodes={},
        toml_comments=None,
        comment_root_id=None,
    )
    formatted = wrap_arg(
        value,
        _format_value(
            value=value,
            dict_open_override=dict_open_override,
            sequence_open_override=None,
            ctx=ctx,
            int_formatter=None,
        ),
    )
    wrap_scalar = language.heterogeneous_behavior.wrap_scalar
    if (
        wrap_scalar is None
        or id(value) not in scalar_wrap_ids
        or not isinstance(value, _SCALAR_TYPES)
    ):
        return formatted
    return wrap_scalar(value, formatted)


@beartype
def _validate_call_parameter_count(
    *,
    params: Sequence[str],
    formatted: Sequence[str],
) -> None:
    """Require one rendered call value for every declared parameter."""
    if len(params) != len(formatted):
        raise ParameterCountMismatchError(
            expected=len(params),
            got=len(formatted),
        )


@beartype
def _format_prefix_call_args(
    *,
    formatted: list[str],
    params: Sequence[str],
    sep: str,
    kw_prefix: str,
) -> str:
    """Format values for :class:`PrefixCallStyle`.

    When *kw_prefix* is empty the call is positional (values only).
    Otherwise each value is emitted as ``{kw_prefix}{name}{sep}{value}``.
    """
    if kw_prefix == "":
        return sep.join(formatted)
    _validate_call_parameter_count(params=params, formatted=formatted)
    return sep.join(
        f"{kw_prefix}{name}{sep}{val}"
        for name, val in zip(params, formatted, strict=True)
    )


@beartype
def _format_call_args(
    *,
    values: Sequence[Value],
    params: Sequence[str],
    language: Language,
    wrap_ids: frozenset[int],
    tuple_list_ids: frozenset[int],
    scalar_wrap_ids: frozenset[int],
    style: CallStyle,
    dict_open_overrides: Sequence[str | None],
    ref_case: IdentifierCase | None,
    ref_values: Mapping[str, Value] | None,
    consumable_ref_names: frozenset[str],
    single_use_ref_names: frozenset[str],
    consume_inhibited_ref_names: frozenset[str],
    ref_key: str,
    collection_layout: CollectionLayout,
) -> str:
    """Format argument values for a single function call.

    For infix styles returns the parenthesized argument list
    ``(arg1, arg2)``.  A positional style can instead parenthesize
    each argument separately for curried application forms such as
    Dhall's ``target (arg1) (arg2)``. For :class:`PostfixCallStyle`
    returns the unwrapped, space-separated argument list so the caller
    can assemble ``args target`` directly.

    A value shaped like ``{"$ref": "name"}`` renders as the bare
    identifier ``name`` instead of being formatted as a literal, so
    callers can refer to a variable declared elsewhere (e.g. via
    :class:`NewVariable`).

    *dict_open_overrides* supplies a per-positional dict opener so that
    dict arguments at the same slot across sibling calls share a
    widened type.  ``None`` at a given position means "no override".

    *ref_case*, when not ``None``, converts each ``{"$ref": "name"}``
    identifier to that :class:`IdentifierCase` before emitting it.
    """
    wrap_arg = language.format_call_arg
    formatted = [
        _format_single_call_arg(
            value=arg_value,
            language=language,
            wrap_ids=wrap_ids,
            tuple_list_ids=tuple_list_ids,
            scalar_wrap_ids=scalar_wrap_ids,
            wrap_arg=wrap_arg,
            dict_open_override=dict_open_overrides[slot_index],
            ref_case=ref_case,
            ref_values=ref_values,
            consumable_ref_names=consumable_ref_names,
            single_use_ref_names=single_use_ref_names,
            consume_inhibited_ref_names=consume_inhibited_ref_names,
            ref_key=ref_key,
            collection_layout=collection_layout,
        )
        for slot_index, arg_value in enumerate(iterable=values)
    ]

    if len(formatted) == 0 and not language.allows_empty_call_parens:
        return ""

    match style:
        case PositionalCallStyle(
            arg_separator=sep,
            parenthesize_each_arg=parenthesize_each_arg,
        ):
            _validate_call_parameter_count(
                params=params,
                formatted=formatted,
            )
            if parenthesize_each_arg:
                result = sep.join(f"({value})" for value in formatted)
            else:
                result = f"({sep.join(formatted)})"
        case KeywordCallStyle(separator=kw_sep):
            _validate_call_parameter_count(
                params=params,
                formatted=formatted,
            )
            inner = ", ".join(
                f"{name}{kw_sep}{val}"
                for name, val in zip(params, formatted, strict=True)
            )
            result = f"({inner})"
        case ObjectCallStyle(separator=kw_sep):
            _validate_call_parameter_count(
                params=params,
                formatted=formatted,
            )
            collected_named: list[str] = []
            for entry_entry_entry_entry_entry_name, entry_val in zip(
                params, formatted, strict=True
            ):
                effective_entry_entry_entry_entry_entry_name = (
                    entry_entry_entry_entry_entry_name
                )
                if (
                    effective_entry_entry_entry_entry_entry_name
                    in style.computed_names
                ):
                    effective_entry_entry_entry_entry_entry_name = (
                        f"[{entry_entry_entry_entry_entry_name!r}]"
                    )
                collected_named.append(
                    f"{(effective_entry_entry_entry_entry_entry_name)}{kw_sep}{entry_val}"
                )
            named = ", ".join(collected_named)
            result = f"({{ {named} }})"
        case (
            PostfixCallStyle(arg_separator=sep)
            | CommandCallStyle(arg_separator=sep)
            | DottedCommandCallStyle(arg_separator=sep)
        ):
            # These styles write the arguments without naming them, but
            # the declared parameters still fix the generated stub's
            # arity, so a mismatch is a call the stub cannot take
            # (issue #3956).
            _validate_call_parameter_count(
                params=params,
                formatted=formatted,
            )
            result = sep.join(formatted)
        case _:
            result = _format_prefix_call_args(
                formatted=formatted,
                params=params,
                sep=style.arg_separator,
                kw_prefix=style.keyword_prefix,
            )
    return result


@beartype
def _assemble_bare_call_expr(
    *,
    target_function: str,
    args_str: str,
    style: CallStyle,
) -> str:
    """Build the bare call expression (no transform, no terminator).

    ``call_transform`` is only valid for the substitution call styles
    (:class:`PositionalCallStyle`, :class:`KeywordCallStyle`,
    :class:`ObjectCallStyle`); the prefix/postfix/command styles never
    receive one (:func:`_validate_call_preconditions` rejects it), so
    each style here just renders the language-native call form.
    """
    match style:
        case PostfixCallStyle():
            resolved_result_1: str = target_function
            if args_str != "":
                resolved_result_1 = f"{args_str} {target_function}"
            return resolved_result_1
        case PositionalCallStyle() | KeywordCallStyle() | ObjectCallStyle():
            return f"{target_function}{args_str}"
        case PrefixCallStyle(arg_separator=sep):
            inside = target_function
            if args_str != "":
                inside = f"{target_function}{sep}{args_str}"
            return f"({inside})"
        case (
            DottedCommandCallStyle(arg_separator=sep)
            | CommandCallStyle(arg_separator=sep)
        ):
            command = target_function
            if args_str != "":
                command = f"{target_function}{sep}{args_str}"
            return command
        case _ as unreachable:
            assert_never(unreachable)


@beartype
def _assemble_call(
    *,
    target_function: str,
    args_str: str,
    call_transform: Callable[[CallContext], str] | None,
    statement_terminator: str,
    style: CallStyle,
    index: int,
    row: Sequence[Value],
    zipped: str | None,
) -> str:
    """Build one complete call statement.

    Renders the bare call expression and, when a *call_transform* is
    supplied, threads it through :class:`CallContext` so the transform
    can pair the call with per-row data.  The language's statement
    terminator is appended last.
    """
    call_expr = _assemble_bare_call_expr(
        target_function=target_function,
        args_str=args_str,
        style=style,
    )
    if call_transform is not None:
        call_expr = call_transform(
            CallContext(
                call=call_expr,
                index=index,
                row=row,
                zipped=zipped,
            )
        )
    return f"{call_expr}{statement_terminator}"


@beartype
def _append_trailing_comment(
    *,
    rendered: str,
    comment: str,
    language: Language,
) -> str:
    """Append *comment* as a trailing line comment to *rendered*.

    The comment is placed on the last line of the fully rendered
    statement -- after the language's statement terminator and any
    ``format_call_statement`` wrapping -- so a line-comment leader
    (``//``, ``#``, ...) cannot swallow the terminator.  The
    language's :attr:`~Language.comment_config` supplies the leader and
    any closer; languages with no line comment fall back to their
    block-comment form (``/* ... */``), which is valid on a single
    line.  An empty *comment* leaves *rendered* unchanged.
    """
    if comment == "":
        return rendered
    cfg = language.comment_config
    escaped_comment = neutralize_inline_comment(
        text=comment,
        comment_prefix=cfg.trailing_prefix,
        comment_suffix=cfg.suffix,
    )
    lines = rendered.split(sep="\n")
    lines[-1] = (
        f"{lines[-1]}  {cfg.trailing_prefix} {escaped_comment}{cfg.suffix}"
    )
    return "\n".join(lines)


@beartype
def _resolve_comment_literals(
    *,
    comment_source: Sequence[str] | None,
    call_count: int,
) -> list[str] | None:
    """Validate *comment_source* against the generated call count.

    Returns ``None`` when no *comment_source* was supplied.  Otherwise
    the entry count must equal *call_count* (each comment pairs
    positionally with one call) and no entry may span multiple lines.
    """
    if comment_source is None:
        return None
    comments = list(comment_source)
    if len(comments) != call_count:
        raise CommentSourceLengthMismatchError(
            call_count=call_count,
            comment_count=len(comments),
        )
    for index, comment in enumerate(iterable=comments):
        if "\n" in comment or "\r" in comment:
            raise CommentSourceMultilineError(index=index)
        if "\0" in comment:
            raise CommentSourceNulError(index=index)
    return comments


@beartype
def _render_variable_bound_call(
    *,
    target_function: str,
    args_str: str,
    call_transform: Callable[[CallContext], str] | None,
    style: CallStyle,
    index: int,
    row: Sequence[Value],
    zipped: str | None,
    language: Language,
    data: Value,
    variable_form: NewVariable | ExistingVariable,
    comment: str,
) -> str:
    """Assemble one call expression and bind it to *variable_form*.

    Shared by the whole-value and single-element call paths.  The call
    is assembled with an empty statement terminator (the binding
    template supplies its own), wrapped via the language's
    call-binding declaration/assignment hook, and any trailing
    *comment* appended to the fully terminated binding so a line-comment
    leader cannot swallow the terminator.
    """
    call_expr = _assemble_call(
        target_function=target_function,
        args_str=args_str,
        call_transform=call_transform,
        statement_terminator="",
        style=style,
        index=index,
        row=row,
        zipped=zipped,
    )
    return _append_trailing_comment(
        rendered=_apply_variable_wrapper(
            result=call_expr,
            language=language,
            data=data,
            variable_form=variable_form,
            line_prefix="",
            is_call_binding=True,
        ),
        comment=comment,
        language=language,
    )


@beartype
def _render_call_per_element(
    *,
    data: list[Value],
    language: Language,
    style: CallStyle,
    target_function: str,
    parameter_names: Sequence[str],
    call_transform: Callable[[CallContext], str] | None,
    zip_literals: Sequence[str] | None,
    ref_case: IdentifierCase | None,
    consumable_ref_names: frozenset[str],
    ref_values: Mapping[str, Value],
    ref_key: str,
    comment_literals: Sequence[str] | None,
    variable_form: NewVariable | ExistingVariable | None,
    collection_comments: CollectionComments | None,
    collection_layout: CollectionLayout,
) -> str:
    """Render one call per top-level list element.

    Variable-reference markers (``{"$ref": "name"}``) are syntactic
    pointers rather than real data, so they are skipped during
    data-shape validation and wrap-id computation while still
    appearing as identifiers in the rendered call.
    :func:`_compute_call_slot_overrides` and
    :func:`_compute_call_per_element_wrap_ids` similarly filter them
    out so the marker's ``{str: str}`` shape does not influence
    per-slot widening.

    When *variable_form* is supplied the single generated call
    (:func:`_validate_call_variable_form` has already required exactly
    one element) is bound to the variable instead of being routed
    through ``format_call_statement`` -- the path that produces the
    zero-argument ``p2 = Playlist()`` constructor from a ``[[]]``
    source.
    """
    slot_overrides = _compute_call_slot_overrides(
        elements=data,
        spec=language,
        ref_key=ref_key,
    )
    slot_wrap_ids = _compute_call_per_element_wrap_ids(
        elements=data,
        spec=language,
        ref_key=ref_key,
    )
    scalar_wrap_ids = _compute_call_slot_scalar_wrap_ids(
        elements=data,
        spec=language,
        ref_key=ref_key,
    )
    single_use_ref_names = _compute_call_arg_ref_single_use_names(
        elements=data,
        ref_key=ref_key,
    )
    consume_inhibited_ref_names = (
        _compute_call_arg_ref_consume_inhibited_names(
            elements=data,
            ref_values=ref_values,
            ref_key=ref_key,
            language=language,
        )
    )
    rendered_elements: list[str] = []
    for index, element in enumerate(iterable=data):
        arg_values = element
        if not isinstance(arg_values, list):
            arg_values = [element]
        non_ref_args = [
            v
            for v in arg_values
            if _extract_call_arg_ref_name(value=v, ref_key=ref_key) is None
        ]
        for value in non_ref_args:
            stripped_value = _strip_refs_from_value(
                value=value, ref_key=ref_key
            )
            check_data(data=stripped_value, spec=language)
            language.validate_call_arg(stripped_value)
        call_wrap_ids = (
            _compute_wrap_ids(data=non_ref_args, spec=language) | slot_wrap_ids
        )
        call_tuple_list_ids = _compute_tuple_list_ids(
            data=non_ref_args,
            spec=language,
        )
        args_str = _format_call_args(
            values=arg_values,
            params=parameter_names,
            language=language,
            wrap_ids=call_wrap_ids,
            tuple_list_ids=call_tuple_list_ids,
            scalar_wrap_ids=scalar_wrap_ids,
            style=style,
            dict_open_overrides=slot_overrides,
            ref_case=ref_case,
            ref_values=ref_values,
            consumable_ref_names=consumable_ref_names,
            single_use_ref_names=single_use_ref_names,
            consume_inhibited_ref_names=consume_inhibited_ref_names,
            ref_key=ref_key,
            collection_layout=collection_layout,
        )
        zipped = None
        if zip_literals is not None:
            zipped = zip_literals[index]
        comment = ""
        if comment_literals is not None:
            comment = comment_literals[index]
        if variable_form is not None:
            # Exactly one element here: ``_validate_call_variable_form``
            # rejected any other call count, so the single name binds
            # this one call's result.
            rendered_elements.append(
                _render_variable_bound_call(
                    target_function=target_function,
                    args_str=args_str,
                    call_transform=call_transform,
                    style=style,
                    index=index,
                    row=arg_values,
                    zipped=zipped,
                    language=language,
                    data=element,
                    variable_form=variable_form,
                    comment=comment,
                )
            )
        else:
            rendered_elements.append(
                _append_trailing_comment(
                    rendered=language.format_call_statement(
                        _assemble_call(
                            target_function=target_function,
                            args_str=args_str,
                            call_transform=call_transform,
                            statement_terminator=(
                                language.statement_terminator
                            ),
                            style=style,
                            index=index,
                            row=arg_values,
                            zipped=zipped,
                        )
                    ),
                    comment=comment,
                    language=language,
                )
            )
    if collection_comments is not None:
        comment_cfg = language.comment_config
        return apply_collection_comments_to_elements(
            rendered_elements=rendered_elements,
            collection_comments=collection_comments,
            comment_prefix=comment_cfg.trailing_prefix,
            comment_suffix=comment_cfg.suffix,
            line_prefix="",
        )
    return "\n".join(rendered_elements)


@beartype
def _render_call_whole(
    *,
    data: Value,
    language: Language,
    style: CallStyle,
    target_function: str,
    parameter_names: Sequence[str],
    call_transform: Callable[[CallContext], str] | None,
    zip_literal: str | None,
    ref_case: IdentifierCase | None,
    consumable_ref_names: frozenset[str],
    ref_values: Mapping[str, Value],
    ref_key: str,
    comment: str,
    collection_layout: CollectionLayout,
    variable_form: NewVariable | ExistingVariable | None,
) -> str:
    """Render a single call from the whole parsed value.

    A single top-level ref marker renders as just the identifier; in
    that case shape validation and wrap-id computation are skipped.

    When *variable_form* is supplied, the assembled call expression is
    wrapped via the language's ``format_variable_declaration`` /
    ``format_variable_assignment`` hook (instead of being routed through
    ``format_call_statement`` and the language's statement terminator),
    producing an idiomatic binding such as ``let p2 = Playlist::new();``.
    """
    if _extract_call_arg_ref_name(value=data, ref_key=ref_key) is None:
        stripped_data = _strip_refs_from_value(value=data, ref_key=ref_key)
        check_data(data=stripped_data, spec=language)
        language.validate_call_arg(stripped_data)
        call_wrap_ids = _compute_wrap_ids(data=[data], spec=language)
        call_tuple_list_ids = _compute_tuple_list_ids(
            data=[data],
            spec=language,
        )
    else:
        call_wrap_ids = frozenset[int]()
        call_tuple_list_ids = frozenset[int]()
    args_str = _format_call_args(
        values=[data],
        params=parameter_names,
        language=language,
        wrap_ids=call_wrap_ids,
        tuple_list_ids=call_tuple_list_ids,
        scalar_wrap_ids=frozenset[int](),
        style=style,
        dict_open_overrides=[None],
        ref_case=ref_case,
        ref_values=ref_values,
        consumable_ref_names=consumable_ref_names,
        single_use_ref_names=_compute_call_arg_ref_single_use_names(
            elements=[[data]],
            ref_key=ref_key,
        ),
        consume_inhibited_ref_names=(
            _compute_call_arg_ref_consume_inhibited_names(
                elements=[[data]],
                ref_values=ref_values,
                ref_key=ref_key,
                language=language,
            )
        ),
        ref_key=ref_key,
        collection_layout=collection_layout,
    )
    if variable_form is None:
        return _append_trailing_comment(
            rendered=language.format_call_statement(
                _assemble_call(
                    target_function=target_function,
                    args_str=args_str,
                    call_transform=call_transform,
                    statement_terminator=language.statement_terminator,
                    style=style,
                    index=0,
                    row=[data],
                    zipped=zip_literal,
                )
            ),
            comment=comment,
            language=language,
        )
    return _render_variable_bound_call(
        target_function=target_function,
        args_str=args_str,
        call_transform=call_transform,
        style=style,
        index=0,
        row=[data],
        zipped=zip_literal,
        language=language,
        data=data,
        variable_form=variable_form,
        comment=comment,
    )


@beartype
def _has_inline_multiline_dict_arg(
    *,
    arg_values: Sequence[Value],
    ref_key: str,
) -> bool:
    """Return ``True`` when *arg_values* contains a dict with two or
    more entries that is not a ``$ref`` marker.
    """
    return any(
        _value_is_multikey_non_ref_dict(value=value, ref_key=ref_key)
        for value in arg_values
    )


@beartype
def _value_is_multikey_non_ref_dict(*, value: Value, ref_key: str) -> bool:
    """Return ``True`` if *value* is a dict with multiple keys that is
    not a single-key ``$ref`` marker.
    """
    if not isinstance(value, dict):
        return False
    if len(value) == 1 and isinstance(value.get(ref_key), str):
        return False
    return len(value) > 1


@beartype
def _yaml_has_standalone_comments(*, parsed: ParsedInput) -> bool:
    """Return ``True`` when the YAML source carries standalone comments.

    Standalone comments are comments that appear on their own line —
    either before a top-level element or after the last element.  Inline
    comments (those that follow a value on the same line) do not count.
    Returns ``False`` for non-YAML input or for YAML that parses to a
    scalar; ``ruamel.yaml`` only attaches collection-comment metadata
    to :class:`CommentedSeq` / :class:`CommentedMap` / :class:`CommentedSet`.
    """
    if not isinstance(parsed, ParsedYaml):
        return False
    if not isinstance(
        parsed.raw_data, CommentedSeq | CommentedMap | CommentedSet
    ):
        return False
    collection_comments = extract_yaml_comments(
        ruamel_data=parsed.raw_data,
        nested=False,
        hoist_nested_inline=False,
    )
    if len(collection_comments.trailing) > 0:
        return True
    return any(element.before for element in collection_comments.elements)


@beartype
def _validate_wrap_in_file_supports_standalone_comments(
    *,
    language: Language,
    wrap_in_file: bool,
    contains_standalone_comments: bool,
) -> None:
    """Raise when wrapping calls would drop required standalone
    comments.
    """
    if (
        wrap_in_file
        and contains_standalone_comments
        and not language.supports_standalone_comments_in_wrapped_calls
    ):
        raise UnsupportedCallShapeError(
            language_name=type(language).__name__,
            reason=(
                "standalone comments cannot be preserved when wrapping "
                "calls in this language"
            ),
        )


@beartype
def _validate_comment_source_supported(
    *,
    language: Language,
    comment_literals: list[str] | None,
) -> None:
    """Raise when ``comment_source`` would produce invalid code.

    A trailing comment is only safe when every generated call is a
    self-contained line: languages that assemble the call sequence into
    a single clause/list/expression append separators, terminators or
    closers *after* the per-call text (Erlang's clause ``.``, a Jsonnet
    list ``,``, a Roc ``dbg ( ... )`` wrapper), which a line comment
    would then swallow.
    :attr:`~Language.supports_standalone_comments_in_wrapped_calls`
    already marks exactly the languages that can carry a trailing
    comment through their call-sequence form, so reuse it rather than
    emit code that fails to compile.  All-empty entries emit no comment
    and are always allowed.
    """
    if (
        comment_literals is not None
        and any(comment_literals)
        and not language.supports_standalone_comments_in_wrapped_calls
    ):
        raise UnsupportedCallShapeError(
            language_name=type(language).__name__,
            reason=(
                "comment_source trailing comments cannot be preserved "
                "in this language's call-sequence form"
            ),
        )


@beartype
def _validate_parameter_count(
    *,
    language: Language,
    parameter_names: Sequence[str],
) -> None:
    """Raise ``UnsupportedCallShapeError`` if the parameter count is out
    of range for ``language``.
    """
    if (
        len(parameter_names) == 0
        and not language.supports_zero_parameter_calls
    ):
        raise UnsupportedCallShapeError(
            language_name=type(language).__name__,
            reason=(
                "zero-parameter calls have no representation in this language"
            ),
        )
    max_params = language.max_call_parameters
    if len(parameter_names) > max_params:
        raise UnsupportedCallShapeError(
            language_name=type(language).__name__,
            reason=(
                f"call exceeds this language's {max_params}-parameter limit"
            ),
        )


_CALL_BINDING_PROBE = "probe"
"""A stand-in call result, used only to compare binding spellings."""


@beartype
def _validate_call_variable_form(
    *,
    language: Language,
    variable_form: NewVariable | ExistingVariable,
    call_count: int,
    wrap_in_file: bool,
) -> None:
    """Raise typed errors for unsupported ``variable_form``
    combinations.

    ``BothVariableForms`` is rejected upstream by ``literalize_call``
    itself, so the ``variable_form`` parameter here is narrower.

    A ``variable_form`` binds the result of one call to one name, so it
    is well-defined only when the input produces exactly one call.  With
    ``per_element=False`` that is always the case (the whole value is a
    single call's argument); with ``per_element=True`` it holds when the
    source has exactly one top-level element (the zero-argument
    constructor ``p2 = Playlist()`` is reached this way, via a
    single-element ``[[]]`` source).  Zero calls (an empty
    ``per_element`` source) or more than one call leave the single name
    with nothing, or with several call results, to bind.
    """
    if call_count != 1:
        raise UnsupportedCallShapeError(
            language_name=type(language).__name__,
            reason=(
                "variable_form binds a single call result, but this "
                f"input produces {call_count} calls; supply exactly one "
                "call (per_element=False, or per_element=True with a "
                "single-element source)"
            ),
        )
    if not language.supports_variable_names:
        raise VariableNameNotSupportedError(
            language_name=type(language).__name__,
            variable_name=variable_form.name,
        )
    if not language.call_returns_expression:
        raise UnsupportedCallShapeError(
            language_name=type(language).__name__,
            reason=(
                "calls in this language are statements, not expressions, "
                "so the call result cannot be bound to a variable"
            ),
        )
    if wrap_in_file and isinstance(variable_form, ExistingVariable):
        # A whole file that assigns to a name it never declares does not
        # compile, the same rule ``literalize`` applies to a value
        # binding (issue #4468).  An assignment reading as one of the
        # language's declarations introduces the name itself.
        assignment = language.format_call_variable_assignment(
            variable_form.name,
            _CALL_BINDING_PROBE,
            None,
        )

        def _render_call_declaration(styled: Language) -> str:
            """Return the call-binding declaration *styled* would emit."""
            return styled.format_call_variable_declaration(
                variable_form.name,
                _CALL_BINDING_PROBE,
                None,
                frozenset(),
            )

        if assignment not in _declaration_spellings(
            language=language,
            render=_render_call_declaration,
        ):
            raise ExistingVariableNotSelfContainedError(
                language_name=type(language).__name__
            )


_CONSTRUCTOR_CLASS_NAME = re.compile(pattern=r"[A-Z][A-Za-z0-9_]*")
"""The shape a class name takes in a constructor call target."""


@beartype
def _is_constructor_target(
    *,
    language: Language,
    target_function: str,
) -> bool:
    """Return whether *target_function* is a constructor call target.

    A constructor target is spelled by the language rather than by the
    caller (``Foo::new``, ``new Foo``, or the bare class name), so its
    shape is exempt from the identifier grammar.  Only a PascalCase
    class name is taken as evidence of one: a language that spells a
    constructor as the bare class name otherwise matches every target
    and exempts the lot (issue #3913).
    """
    return any(
        language.format_constructor_target(candidate) == target_function
        for candidate in re.findall(
            pattern=r"[^\W\d]\w*", string=target_function
        )
        if _CONSTRUCTOR_CLASS_NAME.fullmatch(string=candidate) is not None
    )


@beartype
def _validate_call_target(
    *,
    language: Language,
    target_function: str,
    target_function_parts: tuple[str, ...],
) -> None:
    """Raise when a dotted call target contains an unsafe component."""
    if target_function == "" or any(
        part == "" for part in target_function_parts
    ):
        raise InvalidCallTargetError(
            language_name=type(language).__name__,
            target_function=target_function,
            reason="it must contain non-empty dotted components",
        )
    is_constructor_target = _is_constructor_target(
        language=language,
        target_function=target_function,
    )
    # A bare constructor target is just the class name, which some
    # languages do not admit as a function name at all (issue #3914).
    # Sliced rather than measured by ``len``: a length test narrows the
    # tuple type, and that narrowing reaches the head index below.
    exempt = is_constructor_target and (
        bool(target_function_parts[1:])
        or language.accepts_type_name_call_target
    )
    component_syntax = language.call_target_name_syntax
    if component_syntax is None:
        component_syntax = language.new_variable_name_syntax
    # The leading component names a function, or the value a member is
    # read from, so it follows the declaration keyword rules of the
    # target language.  A later component is a member name, which a
    # keyword may spell (``obj.class`` in JavaScript), and is checked
    # against the narrower ``reserved_identifiers`` alone (#3905).
    head = target_function_parts[0]
    # A language may match keywords without regard to case while still
    # spelling identifiers case-sensitively, so both must agree before
    # the head is compared by case.
    head_case_sensitive = (
        language.reserved_variable_identifiers_case_sensitive
        and language.reserved_call_target_keywords_case_sensitive
    )
    # A language that declares a plain function only for a target with
    # no dot in it reserves those names here.  PHP matches a function
    # name without regard to case, which ``head_case_sensitive``
    # already carries (issue #4495).
    if len(target_function_parts[1:]) > 0:
        bare_target_identifiers = frozenset[str]()
    else:
        bare_target_identifiers = (
            language.reserved_bare_call_target_identifiers
        )
    if is_reserved_identifier(
        case_sensitive=head_case_sensitive,
        name=head,
        reserved_identifiers=(
            language.reserved_variable_identifiers
            | language.reserved_call_target_head_identifiers
            | bare_target_identifiers
        )
        - language.contextual_call_target_identifiers,
    ):
        raise InvalidCallTargetError(
            language_name=type(language).__name__,
            target_function=target_function,
            reason=f"component {head!r} is a reserved identifier",
        )
    for part in target_function_parts:
        if (
            language.max_variable_identifier_length is not None
            and len(part) > language.max_variable_identifier_length
        ):
            raise InvalidCallTargetError(
                language_name=type(language).__name__,
                target_function=target_function,
                reason=f"component {part!r} is longer than allowed",
            )
        if not component_syntax.accepts(name=part):
            if exempt:
                return
            raise InvalidCallTargetError(
                language_name=type(language).__name__,
                target_function=target_function,
                reason=f"component {part!r} is not a valid identifier",
            )
        # A language that folds identifier case matches a member
        # component without regard to case too: the Common Lisp reader
        # folds a symbol name, so ``MOD`` and ``mod`` name one symbol
        # (issue #4547).
        if is_reserved_identifier(
            case_sensitive=head_case_sensitive,
            name=part,
            reserved_identifiers=language.reserved_identifiers,
        ):
            raise InvalidCallTargetError(
                language_name=type(language).__name__,
                target_function=target_function,
                reason=f"component {part!r} is a reserved identifier",
            )


@beartype
def _validate_wrapped_call_entrypoint(
    *,
    language: Language,
    target_function: str,
    target_function_parts: tuple[str, ...],
) -> None:
    """Reject a call target that names the generated entry point.

    A dotted root usually names a different construct from the entry
    point -- Java's root is a ``static`` field beside the entry-point
    method, which compiles -- so only a language whose stub declares
    the root where the entry point itself lives collides on it.
    """
    if not isinstance(language, _HasCallWrapperEntrypoint):
        return
    shares_scope = language.dotted_call_root_shares_entrypoint_namespace
    collides = target_function == language.call_wrapper_entrypoint_name or (
        len(target_function_parts) > 1
        and shares_scope
        and target_function_parts[0] == language.call_wrapper_entrypoint_name
    )
    if collides:
        raise InvalidCallTargetError(
            language_name=type(language).__name__,
            target_function=target_function,
            reason="it collides with the generated file entrypoint",
        )


@beartype
def _validate_wrapped_call_declarations(
    *,
    language: Language,
    target_function: str,
    target_function_parts: tuple[str, ...],
) -> None:
    """Reject a target component the generated file cannot declare.

    Every component becomes a declaration in that file, so each follows
    the declaration grammar as well as the call-target one.  The two
    differ where a language spells a call target more freely than a
    name it can declare -- V calls ``http.Server`` but can declare
    neither half of it (issue #3989).
    """
    if (
        _is_constructor_target(
            language=language,
            target_function=target_function,
        )
        and language.declares_type_name_call_target
    ):
        return
    for part in target_function_parts:
        if not language.new_variable_name_syntax.accepts(name=part):
            raise InvalidCallTargetError(
                language_name=type(language).__name__,
                target_function=target_function,
                reason=(
                    f"component {part!r} cannot name a declaration "
                    "in the generated file"
                ),
            )


@beartype
def _comparison_identifier(*, name: str, case_sensitive: bool) -> str:
    """Normalize an identifier for the target language's case rules."""
    if case_sensitive:
        return name
    return name.casefold()


@beartype
def _validate_wrapped_call_parameter_shadowing(
    *,
    language: Language,
    target_function_parts: tuple[str, ...],
    parameter_names: Sequence[str],
) -> None:
    """Reject a stub parameter repeating a name the stub declares.

    The stub declares the target and its parameters in one statement,
    so a language that treats the declared name as in scope there
    refuses a parameter repeating it (issue #4528).
    """
    match language.call_parameter_shadowing:
        case CallParameterShadowing.ALLOWED:
            return
        case CallParameterShadowing.TARGET_NAME:
            declared_parts = target_function_parts[-1:]
        case CallParameterShadowing.ANY_DECLARATION:
            declared_parts = target_function_parts
        case _ as unreachable:
            assert_never(unreachable)
    case_sensitive = language.reserved_variable_identifiers_case_sensitive
    declared = {
        _comparison_identifier(name=part, case_sensitive=case_sensitive)
        for part in declared_parts
    }
    for parameter_name in parameter_names:
        comparison_name = _comparison_identifier(
            name=parameter_name,
            case_sensitive=case_sensitive,
        )
        if comparison_name in declared:
            raise InvalidCallParameterNameError(
                language_name=type(language).__name__,
                parameter_name=parameter_name,
                reason="it shadows the generated call-target declaration",
            )


@beartype
def _validate_wrapped_call_scaffold(
    *,
    language: Language,
    target_function: str,
    target_function_parts: tuple[str, ...],
    parameter_names: Sequence[str],
    arg_values: Sequence[Value],
    ref_case: IdentifierCase | None,
    bound_ref_names: Sequence[str],
    variable_form: NewVariable | ExistingVariable | None,
) -> None:
    """Reject call inputs that collide with or empty a file scaffold."""
    if len(arg_values) == 0:
        raise UnsupportedCallShapeError(
            language_name=type(language).__name__,
            reason=(
                "wrap_in_file requires at least one generated call; "
                "the per-element input is empty"
            ),
        )
    _validate_wrapped_call_entrypoint(
        language=language,
        target_function=target_function,
        target_function_parts=target_function_parts,
    )
    _validate_wrapped_call_declarations(
        language=language,
        target_function=target_function,
        target_function_parts=target_function_parts,
    )
    _validate_wrapped_call_parameter_shadowing(
        language=language,
        target_function_parts=target_function_parts,
        parameter_names=parameter_names,
    )
    # Some languages in this group derive one helper type name per
    # component through a case-normalizing transform (``Foo`` and
    # ``foo`` both become ``FooType_``), so uniqueness holds on the
    # folded components rather than on the components as spelled
    # (issue #3908).  Others interpolate the component as spelled, and
    # folding there would refuse targets that emit distinct helpers.
    normalizes_case = (
        isinstance(language, _NormalizesDottedCallPartCase)
        and language.dotted_call_stub_normalizes_part_case
    )
    collected_compared_parts: list[str] = []
    for entry_entry_part in target_function_parts:
        effective_entry_entry_part = entry_entry_part
        if normalizes_case:
            effective_entry_entry_part = entry_entry_part.casefold()
        collected_compared_parts.append(effective_entry_entry_part)
    compared_parts = collected_compared_parts
    if (
        isinstance(language, _RequiresUniqueDottedCallParts)
        and language.dotted_call_stub_requires_unique_parts
        and len(set(compared_parts)) != len(compared_parts)
    ):
        raise InvalidCallTargetError(
            language_name=type(language).__name__,
            target_function=target_function,
            reason=(
                "repeated components collide with generated dotted-call "
                "helper declarations"
            ),
        )
    # The generated stub declares the target's leading component, and
    # the call's result binding is declared beside it.  A language that
    # can carry both names is the exception rather than the rule, so
    # the shape is refused rather than emitted (issue #3907).
    if (
        isinstance(variable_form, NewVariable)
        and variable_form.name == target_function_parts[0]
    ):
        raise UnsupportedCallShapeError(
            language_name=type(language).__name__,
            reason=(
                "the call result binding would redeclare the generated "
                f"stub {variable_form.name!r}"
            ),
        )
    collected_converted_bound_ref_names: set[str] = set()
    for entry_name in bound_ref_names:
        effective_ref_case_2 = entry_name
        if ref_case is not None:
            effective_ref_case_2 = ref_case.convert(name=entry_name)
        collected_converted_bound_ref_names.add(effective_ref_case_2)
    converted_bound_ref_names = collected_converted_bound_ref_names
    colliding_names = converted_bound_ref_names.intersection(
        target_function_parts
    )
    if len(colliding_names) > 0:
        collision = min(colliding_names)
        raise UnsupportedCallShapeError(
            language_name=type(language).__name__,
            reason=(
                f"bound ref {collision!r} collides with the generated "
                "call-target scaffold"
            ),
        )


@beartype
def _validate_call_preconditions(
    *,
    language: Language,
    target_function: str,
    target_function_parts: tuple[str, ...],
    parameter_names: Sequence[str],
    arg_values: Sequence[Value],
    ref_key: str,
    ref_case: IdentifierCase | None,
    call_transform: Callable[[CallContext], str] | None,
    style: CallStyle,
    variable_form: NewVariable | ExistingVariable | None,
    wrap_in_file: bool,
    bound_ref_names: Sequence[str],
) -> None:
    """Raise typed errors for unsupported ``literalize_call`` inputs.

    *arg_values* has one entry per generated call (a per-element row, or
    the single whole-value argument), so its length is the call count
    that ``variable_form`` validation requires to be exactly one.
    """
    _validate_parameter_count(
        language=language, parameter_names=parameter_names
    )
    validate_call_parameter_names(
        language=language,
        names=parameter_names,
        reject_reserved=(isinstance(style, KeywordCallStyle) or wrap_in_file),
    )
    _validate_call_target(
        language=language,
        target_function=target_function,
        target_function_parts=target_function_parts,
    )
    if wrap_in_file:
        _validate_wrapped_call_scaffold(
            language=language,
            target_function=target_function,
            target_function_parts=target_function_parts,
            parameter_names=parameter_names,
            arg_values=arg_values,
            ref_case=ref_case,
            bound_ref_names=bound_ref_names,
            variable_form=variable_form,
        )
    if variable_form is not None:
        _validate_call_variable_form(
            language=language,
            variable_form=variable_form,
            call_count=len(arg_values),
            wrap_in_file=wrap_in_file,
        )
    if (
        not language.supports_inline_multiline_dict_args
        and _has_inline_multiline_dict_arg(
            arg_values=arg_values, ref_key=ref_key
        )
    ):
        raise UnsupportedCallShapeError(
            language_name=type(language).__name__,
            reason=(
                "multi-key dict call arguments have no inline multiline "
                "representation in this language"
            ),
        )
    if call_transform is not None and not language.call_returns_expression:
        raise UnsupportedCallShapeError(
            language_name=type(language).__name__,
            reason=(
                "calls in this language are statements, not expressions, "
                "so a call_transform cannot consume the call as a value"
            ),
        )
    if call_transform is not None and not isinstance(
        style, PositionalCallStyle | KeywordCallStyle | ObjectCallStyle
    ):
        raise UnsupportedCallShapeError(
            language_name=type(language).__name__,
            reason=(
                "call_transform is only supported for languages whose "
                "call form is an expression that can be wrapped "
                "(positional, keyword, or object call style); this "
                "language uses a prefix, postfix, or command call "
                "style whose language-native wrapper cannot be built "
                "from a context-aware transform"
            ),
        )
    if len(target_function_parts) > 1 and not language.supports_dotted_calls:
        raise DottedCallTargetNotSupportedError(
            language_name=type(language).__name__,
            target_function=target_function,
        )
    if ref_case is not None and ref_case not in language.supported_ref_cases:
        raise UnsupportedIdentifierCaseError(
            language_name=type(language).__name__,
            case_name=ref_case.name,
        )


@beartype
def _is_value_mapping(
    value: ValueInput, /
) -> TypeIs[ValueItemsMap[Scalar, ValueInput]]:
    """Narrow ``value`` to the mapping arm of ``ValueInput``.

    The arm is the covariant-key ``ValueItemsMap`` protocol; every
    :class:`~collections.abc.Mapping` satisfies it structurally, so the
    ``isinstance`` guard is sound and the negative branch subtracts the
    whole mapping arm.
    """
    return isinstance(value, Mapping)


@beartype
def _is_value_sequence(value: ValueInput, /) -> TypeIs[Sequence[ValueInput]]:
    """Narrow ``value`` to the ``Sequence`` arm of ``ValueInput``,
    excluding the ``str``/``bytes`` scalars that are also sequences.
    """
    return isinstance(value, Sequence) and not isinstance(value, (str, bytes))


@beartype
def _wrap_call_in_file(
    *,
    language: Language,
    result: str,
    variable_form: NewVariable | ExistingVariable | None,
    target_function_parts: tuple[str, ...],
    parameter_names: Sequence[str],
    arg_values: Sequence[Value],
    call_transform: Callable[[CallContext], str] | None,
    preamble: tuple[str, ...],
    computed_body: tuple[str, ...],
) -> str:
    """Wrap a rendered ``literalize_call`` result in a complete file.

    Emits a no-op stub for the target function so the wrapped file
    compiles on its own.  ``StubReturn.VALUE`` is used whenever the
    call's return value is consumed -- either by a ``call_transform``
    or by binding it to a ``variable_form``; otherwise the call result
    is discarded and a void stub suffices.
    """
    if call_transform is not None or variable_form is not None:
        stub_return = StubReturn.VALUE
    else:
        stub_return = StubReturn.VOID
    body_stubs = language.format_call_stub(
        target_function_parts, parameter_names, stub_return, arg_values
    )
    preamble_stubs = language.format_call_preamble_stub(
        target_function_parts, parameter_names, stub_return, arg_values
    )
    wrap_variable_name = ""
    if variable_form is not None:
        wrap_variable_name = variable_form.name
    wrap_in_file_hook = language.wrap_in_file
    if variable_form is not None and isinstance(
        language, _SupportsCallVariableWrapInFile
    ):
        # A call-result binding cannot reuse a language's literal-binding
        # scaffold when that scaffold's shape depends on the bound value
        # (e.g. Elm's top-level ``name : Val`` form, forced externally by
        # the test driver, versus a call-mode ``Check.main`` entry point).
        # Languages that need a different scaffold opt in here; the rest
        # fall back to ``wrap_in_file`` unchanged.
        wrap_in_file_hook = language.wrap_call_variable_in_file
    # An inference-bound call result (``my_data = make_widget (...)``)
    # may rely on module-internal preamble lines that the literal
    # binding never needs -- e.g. PureScript's call stub returns
    # ``Unit``, so the binding module must ``import Prelude`` even
    # though the literal binding for the same data does not.  Languages
    # that do not define the hook return ``()`` so ``body_preamble`` is
    # unchanged.
    call_binding_body_preamble: tuple[str, ...] = ()
    if variable_form is not None:
        call_binding_body_preamble = (
            language.format_call_binding_body_preamble()
        )
    wrapped = wrap_in_file_hook(
        content=result,
        variable_name=wrap_variable_name,
        body_preamble=call_binding_body_preamble + body_stubs + computed_body,
    )
    call_binding_pragmas: tuple[str, ...] = ()
    if variable_form is not None:
        call_binding_pragmas = language.format_call_binding_file_pragmas()
    # Stubs follow the language's static preamble (e.g. Go's
    # ``package main`` must come first).
    full_preamble = preamble + call_binding_pragmas + preamble_stubs
    if len(full_preamble) > 0:
        wrapped = "\n".join(full_preamble) + "\n" + wrapped
    return wrapped


@beartype
def _compose_call_with_bound_ref_declarations(
    *,
    language: Language,
    bound_refs: Mapping[str, Value],
    ref_case: IdentifierCase | None,
    result: str,
    preamble: tuple[str, ...],
    data_dependent_preamble: tuple[str, ...],
    body_preamble: tuple[str, ...],
    types_present: frozenset[type],
    contains_standalone_comments: bool,
    data_for_preamble: Value,
    per_element: bool,
    target_function_parts: tuple[str, ...],
    parameter_names: Sequence[str],
    call_transform: Callable[[CallContext], str] | None,
    collection_layout: CollectionLayout,
) -> LiteralizeResult:
    """Emit a binding for each bound ref before the calls.

    Reconstructs the call :class:`LiteralizeResult` from the rendered
    *result* and its preamble pieces, renders one :class:`NewVariable`
    declaration (via :func:`_literalize_value_binding`) for every name
    in *bound_refs* in iteration order, then composes them with a no-op
    stub for the target function through
    :func:`literalize_call_with_declarations` so the duplicate-preamble
    reconciliation is shared with every other call/declaration caller.

    The refs are now real declarations, so the target stub's parameter
    types are inferred from the ref-substituted values
    (*data_for_preamble*), not from the raw ``$ref`` markers a call's
    own ``arg_values`` still carries.  ``variable_form`` is rejected
    upstream for the ``bound_refs`` path, so the call result is never
    consumed here: a value stub is emitted only for a ``call_transform``
    wrapper; otherwise a void stub suffices.
    """
    call_result = LiteralizeResult(
        declaration_code=result,
        preamble=preamble,
        body_preamble=body_preamble,
        types_present=types_present,
        contains_standalone_comments=contains_standalone_comments,
        source_data=data_for_preamble,
        pre_declaration_comments=(),
        sections=(),
        data_dependent_preamble=data_dependent_preamble,
    )
    stub_arg_values: Sequence[Value]
    stub_arg_values = [data_for_preamble]
    if per_element and isinstance(data_for_preamble, list):
        stub_arg_values = data_for_preamble
    collected_decl_results: list[LiteralizeResult] = []
    for entry_entry_name, entry_entry_value in bound_refs.items():
        effective_name = entry_entry_name
        if ref_case is not None:
            effective_name = ref_case.convert(name=entry_entry_name)
        collected_decl_results.append(
            _literalize_value_binding(
                value=entry_entry_value,
                language=language,
                variable_form=NewVariable(
                    name=effective_name, modifiers=frozenset()
                ),
                collection_layout=collection_layout,
                record_context_data=None,
                line_prefix="",
            )
        )
    decl_results = collected_decl_results
    if call_transform is not None:
        stub_return = StubReturn.VALUE
    else:
        stub_return = StubReturn.VOID
    body_stubs = language.format_call_stub(
        target_function_parts, parameter_names, stub_return, stub_arg_values
    )
    preamble_stubs = language.format_call_preamble_stub(
        target_function_parts, parameter_names, stub_return, stub_arg_values
    )
    return literalize_call_with_declarations(
        language=language,
        declarations=decl_results,
        call=call_result,
        extra_body_preamble=body_stubs,
        extra_preamble=preamble_stubs,
    )


@beartype
def _wrap_call_result_in_file(
    *,
    language: Language,
    materialized_bound_refs: Mapping[str, Value],
    ref_case: IdentifierCase | None,
    result: str,
    preamble: tuple[str, ...],
    data_dependent_preamble: tuple[str, ...],
    computed_body: tuple[str, ...],
    types_present: frozenset[type],
    contains_standalone_comments: bool,
    data_for_preamble: Value,
    per_element: bool,
    variable_form: NewVariable | ExistingVariable | None,
    target_function_parts: tuple[str, ...],
    parameter_names: Sequence[str],
    arg_values: Sequence[Value],
    call_transform: Callable[[CallContext], str] | None,
    collection_layout: CollectionLayout,
) -> LiteralizeResult:
    """Assemble a ``wrap_in_file=True`` ``literalize_call`` result.

    Routes through :func:`_compose_call_with_bound_ref_declarations`
    when ``bound_refs`` were supplied (a complete file that declares
    each ref before the calls) and through :func:`_wrap_call_in_file`
    (calls plus a target stub, refs left as free identifiers)
    otherwise.  Keeping this dispatch out of :func:`literalize_call`
    keeps that public entry point within its complexity budget.
    """
    if len(materialized_bound_refs) > 0:
        if variable_form is not None:
            # The ref declarations are composed through
            # ``wrap_calls_with_declarations``, which routes to a
            # language's plain ``wrap_in_file`` and so never applies
            # the call-result variable-binding file scaffold a few
            # languages need (the ``_SupportsCallVariableWrapInFile``
            # protocol ``_wrap_call_in_file`` consults).  Rather than
            # emit a silently wrong scaffold, reject the combination:
            # ``bound_refs`` declares the call's inputs, not a binding
            # for its result.
            raise UnsupportedCallShapeError(
                language_name=type(language).__name__,
                reason=(
                    "variable_form cannot be combined with bound_refs; "
                    "bound_refs declares the call's input refs, not a "
                    "binding for the call result"
                ),
            )
        # ``bound_refs`` requests a complete file that declares each
        # ref and then calls the target with it.  Reconcile the
        # declaration and call preambles through the shared composer so
        # the result matches every other call/declaration caller.
        return _compose_call_with_bound_ref_declarations(
            language=language,
            bound_refs=materialized_bound_refs,
            ref_case=ref_case,
            result=result,
            preamble=preamble,
            data_dependent_preamble=data_dependent_preamble,
            body_preamble=computed_body,
            types_present=types_present,
            contains_standalone_comments=contains_standalone_comments,
            data_for_preamble=data_for_preamble,
            per_element=per_element,
            target_function_parts=target_function_parts,
            parameter_names=parameter_names,
            call_transform=call_transform,
            collection_layout=collection_layout,
        )
    scoped = _scope_preamble_for_wrap(
        language=language,
        preamble=preamble,
        data_dependent_entries=data_dependent_preamble,
    )
    wrapped = _wrap_call_in_file(
        language=language,
        result=result,
        variable_form=variable_form,
        target_function_parts=target_function_parts,
        parameter_names=parameter_names,
        arg_values=arg_values,
        call_transform=call_transform,
        preamble=scoped.file_scope,
        computed_body=scoped.body + computed_body,
    )
    return LiteralizeResult(
        declaration_code=wrapped,
        preamble=(),
        body_preamble=(),
        types_present=types_present,
        contains_standalone_comments=contains_standalone_comments,
        source_data=data_for_preamble,
        pre_declaration_comments=(),
        sections=(),
        data_dependent_preamble=(),
    )


@beartype
def materialize_value_mapping(
    *,
    values: Mapping[str, ValueInput] | None,
    argument_name: str,
) -> dict[str, Value]:
    """Materialize each supplied reference or substitution value."""
    if values is None:
        return {}
    return {
        name: materialize_value_input(value=value, argument_name=argument_name)
        for name, value in values.items()
    }


@beartype
def reference_values_or_empty(
    *,
    values: Mapping[str, Value] | None,
) -> Mapping[str, Value]:
    """Normalize absent materialized reference values to an empty
    mapping.
    """
    if values is None:
        return dict[str, Value]()
    return values


@beartype
def reference_inputs_or_empty(
    *,
    values: Mapping[str, ValueInput] | None,
) -> Mapping[str, ValueInput]:
    """Normalize absent reference inputs to an empty mapping."""
    if values is None:
        return dict[str, ValueInput]()
    return values


@beartype
def nonempty_mapping[T](*, values: Mapping[str, T]) -> Mapping[str, T] | None:
    """Return a reference mapping only when it contains entries."""
    if len(values) == 0:
        return None
    return values


@beartype
def materialize_value_input(*, value: ValueInput, argument_name: str) -> Value:
    """Convert a user-supplied ``ValueInput`` into the internal ``Value``
    form, replacing any non-``list`` ``Sequence`` and non-``dict``
    ``Mapping`` with concrete ``list`` / ``dict`` instances.
    """
    active: set[int] = set()

    def materialize(item: ValueInput) -> Value:
        """Materialize one node while tracking its active ancestors."""
        if not _is_value_mapping(item) and not _is_value_sequence(item):
            return item
        identity = id(item)
        if identity in active:
            raise InvalidValueInputError(argument_name=argument_name)
        active.add(identity)
        try:
            if _is_value_mapping(item):
                return {
                    key: materialize(item=child) for key, child in item.items()
                }
            return [materialize(item=child) for child in item]
        finally:
            active.remove(identity)

    try:
        return materialize(item=value)
    except RecursionError as exc:
        raise InvalidValueInputError(argument_name=argument_name) from exc


@beartype
@dataclasses.dataclass(frozen=True)
class _ZipResolution:
    """Resolved ``zip_source``: rendered literals plus the parsed
    values (the latter feed preamble/body-type inference so languages
    with generated value types declare the zip literal's type).
    """

    literals: list[str]
    values: list[Value]


@beartype
def _preamble_data_with_zip(
    *,
    data_for_preamble: Value,
    zip_resolution: "_ZipResolution | None",
    per_element_rows: list[Value] | None,
) -> Value:
    """Fold the parsed ``zip_source`` values into the data used for
    preamble inference.

    The rendered zip literals reference whatever type machinery the
    language uses for a value (e.g. Haskell's ``data Val`` constructors,
    Gleam's ``pub type GVal``).  Including the materialized zip values
    here makes :func:`compute_preamble` /
    ``call_data_dependent_preamble`` see their types so the generated
    declarations cover them.  The call data is nested as a single
    element so its shape is preserved while the zip values are added
    as siblings; only the *set of types present* matters here, not the
    structure.
    """
    if per_element_rows is None:
        if zip_resolution is None:
            return data_for_preamble
        return [data_for_preamble, *zip_resolution.values]

    # The top-level list and any list row are call syntax, not rendered
    # literals.  Preserve the existing data shape for general preamble
    # and body-type inference, while giving container-sensitive language
    # preambles the precise values that appear as call arguments.
    rows = per_element_rows
    collected_argument_values: list[Value] = []
    for entry_row in rows:
        if isinstance(entry_row, list):
            effective_entry_row = entry_row
        else:
            effective_entry_row = [entry_row]
        collected_argument_values.extend(effective_entry_row)
    argument_values = tuple(collected_argument_values)
    collected_normalized_rows: list[list[Value]] = []
    for entry_entry_row in rows:
        effective_entry_entry_row = entry_entry_row
        if not isinstance(effective_entry_entry_row, list):
            effective_entry_entry_row = [entry_entry_row]
        collected_normalized_rows.append(effective_entry_entry_row)
    normalized_rows = tuple(collected_normalized_rows)
    argument_slots = tuple(
        [row[index] for row in normalized_rows if index < len(row)]
        for index in range(
            max((len(row) for row in normalized_rows), default=0)
        )
    )
    if zip_resolution is not None:
        argument_values += tuple(zip_resolution.values)
        argument_slots += tuple([value] for value in zip_resolution.values)
        preamble_data: list[Value] = [rows, *zip_resolution.values]
    else:
        preamble_data = rows
    return CallPreambleData(
        data=preamble_data,
        argument_values=argument_values,
        argument_slots=argument_slots,
    )


@beartype
def _render_zip_literal(
    *,
    value: Value,
    language: Language,
    collection_layout: CollectionLayout,
) -> str:
    """Render one paired zip value as a language-native literal.

    The whole value is rendered through :func:`_format_value` -- the
    same path call arguments take -- so ``$zipped`` is symmetric with
    the call-argument value rendered by the same call for every
    *collection_layout* (issue #2532): under
    :attr:`CollectionLayout.COMPACT` a mapping stays single-line, and
    under :attr:`CollectionLayout.MULTILINE` it expands exactly as a
    call-argument mapping would.  Refs are disabled here just as in the
    surrounding zip path, so the whole-value renderer needs no ref
    wiring.
    """
    check_data(data=value, spec=language)
    ctx = _RenderContext(
        spec=language,
        wrap_ids=_compute_wrap_ids(data=value, spec=language),
        tuple_list_ids=_compute_tuple_list_ids(data=value, spec=language),
        dict_open_overrides=_collect_dict_open_overrides(
            data=value, spec=language, ref_key=disabled_ref_key()
        ),
        dict_int_formatters=_collect_dict_int_formatters(
            data=value, spec=language
        ),
        empty_container_overrides=_empty_container_literal_overrides(
            data=value, spec=language
        ),
        list_int_formatters=_collect_list_int_formatters(
            data=value, spec=language
        ),
        ref_case=None,
        ref_values=None,
        expand_refs=False,
        ref_key=_DISABLED_REF_KEY,
        collection_layout=collection_layout,
        multiline_prefix="",
        consumable_ref_names=frozenset(),
        single_use_ref_names=frozenset(),
        consume_inhibited_ref_names=frozenset(),
        yaml_comment_nodes={},
        toml_comments=None,
        comment_root_id=None,
    )
    return _format_value(
        value=value,
        dict_open_override=None,
        sequence_open_override=None,
        ctx=ctx,
        int_formatter=None,
    )


@beartype
def _resolve_zip_literals(
    *,
    zip_source: str | None,
    zip_input_format: InputFormat | None,
    call_transform: Callable[[CallContext], str] | None,
    per_element: bool,
    call_count: int,
    language: Language,
    collection_layout: CollectionLayout,
) -> _ZipResolution | None:
    """Parse ``zip_source`` and render each paired value to a
    language-native literal.

    Returns ``None`` when no ``zip_source`` was supplied.  Otherwise
    ``zip_input_format`` and a ``call_transform`` are required (the
    paired values are only reachable through the transform).
    ``zip_source`` is parsed with the same parser as the primary
    ``source``; when ``per_element`` is ``True`` it must parse to a
    list whose top-level elements pair element-by-element with the
    generated calls, otherwise the whole parsed value pairs with the
    single call.  Violations raise
    :class:`~literalizer.exceptions.ZipSourceWithoutInputFormatError`,
    :class:`~literalizer.exceptions.ZipValuesWithoutCallTransformError`,
    :class:`~literalizer.exceptions.PerElementNotListError`, or
    :class:`~literalizer.exceptions.ZipValuesLengthMismatchError`.
    Each entry is rendered by :func:`_render_zip_literal` so the paired
    literal matches the target language (``True`` in Python, ``true``
    in TypeScript, ...) and honors *collection_layout* consistently
    with the call arguments rendered by the same call.
    """
    if zip_source is None:
        if zip_input_format is not None:
            raise ZipInputFormatWithoutSourceError
        return None
    if zip_input_format is None:
        raise ZipSourceWithoutInputFormatError
    if call_transform is None:
        raise ZipValuesWithoutCallTransformError
    zip_data = parse_input(
        source=zip_source,
        input_format=zip_input_format,
    ).data
    zip_values: Sequence[Value]
    if per_element:
        if not isinstance(zip_data, list):
            msg = (
                "per_element=True requires zip_source to parse to a "
                f"top-level list, got {type(zip_data).__name__}"
            )
            raise PerElementNotListError(msg)
        zip_values = zip_data
    else:
        zip_values = [zip_data]
    if len(zip_values) != call_count:
        raise ZipValuesLengthMismatchError(
            call_count=call_count,
            zip_count=len(zip_values),
        )
    literals: list[str] = []
    values: list[Value] = []
    for value in zip_values:
        language.validate_spec_for_data(data=value)
        values.append(value)
        literals.append(
            _render_zip_literal(
                value=value,
                language=language,
                collection_layout=collection_layout,
            )
        )
    return _ZipResolution(literals=literals, values=values)


@beartype
def _render_parsed_call(
    *,
    data: Value,
    per_element_data: list[Value] | None,
    parsed: ParsedInput,
    language: Language,
    style: CallStyle,
    target_function: str,
    parameter_names: Sequence[str],
    call_transform: Callable[[CallContext], str] | None,
    zip_literals: Sequence[str] | None,
    ref_case: IdentifierCase | None,
    consumable_refs: frozenset[str],
    materialized_ref_values: Mapping[str, Value],
    ref_key: str,
    comment_literals: Sequence[str] | None,
    variable_form: NewVariable | ExistingVariable | None,
    collection_layout: CollectionLayout,
) -> str:
    """Render one whole-document call or a sequence of per-element
    calls.
    """
    if per_element_data is not None:
        collection_comments: CollectionComments | None = None
        if (
            isinstance(parsed, ParsedYaml)
            and parsed.needs_comment_resolve
            and isinstance(parsed.raw_data, CommentedSeq)
        ):
            collection_comments = extract_yaml_comments(
                ruamel_data=parsed.raw_data,
                nested=False,
                # A call statement is one line, so an inline
                # comment inside the element belongs on it.
                hoist_nested_inline=True,
            )
        result = _render_call_per_element(
            data=per_element_data,
            language=language,
            style=style,
            target_function=target_function,
            parameter_names=parameter_names,
            call_transform=call_transform,
            zip_literals=zip_literals,
            ref_case=ref_case,
            consumable_ref_names=consumable_refs,
            ref_values=materialized_ref_values,
            ref_key=ref_key,
            comment_literals=comment_literals,
            variable_form=variable_form,
            collection_comments=collection_comments,
            collection_layout=collection_layout,
        )
    else:
        effective_zip_literal = None
        if zip_literals is not None:
            effective_zip_literal = zip_literals[0]
        effective_comment = ""
        if comment_literals is not None:
            effective_comment = comment_literals[0]
        result = _render_call_whole(
            data=data,
            language=language,
            style=style,
            target_function=target_function,
            parameter_names=parameter_names,
            call_transform=call_transform,
            zip_literal=effective_zip_literal,
            ref_case=ref_case,
            consumable_ref_names=consumable_refs,
            ref_values=materialized_ref_values,
            ref_key=ref_key,
            comment=(effective_comment),
            collection_layout=collection_layout,
            variable_form=variable_form,
        )
    return result


@beartype
def _call_argument_rows(
    *,
    data: Value,
    per_element: bool,
) -> tuple[list[Value] | None, Sequence[Value]]:
    """Validate and select the values supplying each rendered call."""
    if not per_element:
        return None, [data]
    if not isinstance(data, list):
        msg = (
            "per_element=True requires a top-level list, "
            f"got {type(data).__name__}"
        )
        raise PerElementNotListError(msg)
    return data, data


@beartype
def literalize_call_parsed(
    *,
    parsed: ParsedInput,
    language: Language,
    target_function: str,
    parameter_names: Sequence[str],
    call_transform: Callable[[CallContext], str] | None,
    zip_source: str | None,
    zip_input_format: InputFormat | None,
    comment_source: Sequence[str] | None,
    per_element: bool,
    wrap_in_file: bool,
    ref_case: IdentifierCase | None,
    consumable_refs: frozenset[str],
    ref_values: Mapping[str, ValueInput] | None,
    bound_refs: Mapping[str, ValueInput] | None,
    ref_key: str,
    collection_layout: CollectionLayout,
    variable_form: NewVariable | ExistingVariable | None,
) -> LiteralizeResult:
    """Render a call from input parsed by :func:`parse_input`.

    This is the shared rendering core behind :func:`literalize_call`.
    Keeping parsing outside the core lets the golden-file harness select
    the call-row array from a TOML document, whose root is necessarily a
    table, while exercising the same production renderer as the public
    entry point.
    """
    data = parsed.data
    effective_bound_ref_names = frozenset(
        reference_inputs_or_empty(values=bound_refs)
    )
    reject_unbound_refs_in_file(
        data=data,
        ref_key=ref_key,
        ref_case=ref_case,
        bound_ref_names=(effective_bound_ref_names),
        language=language,
        wrap_in_file=wrap_in_file,
    )
    _validate_ref_case_is_injective(
        value=data,
        ref_key=ref_key,
        ref_case=ref_case,
    )
    contains_standalone_comments = _yaml_has_standalone_comments(parsed=parsed)
    match language.call_style_config:
        case CallSupport.NOT_IN_LANGUAGE:
            raise CallsNotSupportedByLanguageError(
                language_name=type(language).__name__,
            )
        case CallSupport.NOT_IMPLEMENTED_BY_TOOL:
            raise CallsNotSupportedByToolError(
                language_name=type(language).__name__,
            )
        case _ as style:
            pass

    per_element_data, arg_values = _call_argument_rows(
        data=data, per_element=per_element
    )
    target_function_parts = tuple(target_function.split(sep="."))
    effective_bound_ref_names_2 = tuple(
        reference_inputs_or_empty(values=bound_refs)
    )
    _validate_call_preconditions(
        language=language,
        target_function=target_function,
        target_function_parts=target_function_parts,
        parameter_names=parameter_names,
        arg_values=arg_values,
        ref_key=ref_key,
        ref_case=ref_case,
        call_transform=call_transform,
        style=style,
        variable_form=variable_form,
        wrap_in_file=wrap_in_file,
        bound_ref_names=(effective_bound_ref_names_2),
    )
    if (
        isinstance(style, DottedCommandCallStyle)
        and len(target_function_parts) > 1
    ):
        style = style.dotted_call_style
    zip_resolution = _resolve_zip_literals(
        zip_source=zip_source,
        zip_input_format=zip_input_format,
        call_transform=call_transform,
        per_element=per_element,
        call_count=len(arg_values),
        language=language,
        collection_layout=collection_layout,
    )
    zip_literals = None
    if zip_resolution is not None:
        zip_literals = zip_resolution.literals
    comment_literals = _resolve_comment_literals(
        comment_source=comment_source,
        call_count=len(arg_values),
    )
    _validate_comment_source_supported(
        language=language,
        comment_literals=comment_literals,
    )
    _validate_wrap_in_file_supports_standalone_comments(
        language=language,
        wrap_in_file=wrap_in_file,
        contains_standalone_comments=contains_standalone_comments,
    )
    target_function = language.format_call_target(target_function_parts)

    explicit_ref_values = materialize_value_mapping(
        values=ref_values,
        argument_name="ref_values",
    )
    materialized_bound_refs = materialize_value_mapping(
        values=bound_refs,
        argument_name="bound_refs",
    )
    materialized_ref_values: Mapping[str, Value] = {
        **materialized_bound_refs,
        **explicit_ref_values,
    }

    resolved_preamble_data = _resolve_call_preamble_data(
        data=data,
        per_element_data=per_element_data,
        ref_key=ref_key,
        ref_values=materialized_ref_values,
    )

    result = _render_parsed_call(
        data=data,
        per_element_data=per_element_data,
        parsed=parsed,
        language=language,
        style=style,
        target_function=target_function,
        parameter_names=parameter_names,
        call_transform=call_transform,
        zip_literals=zip_literals,
        ref_case=ref_case,
        consumable_refs=consumable_refs,
        materialized_ref_values=materialized_ref_values,
        ref_key=ref_key,
        comment_literals=comment_literals,
        variable_form=variable_form,
        collection_layout=collection_layout,
    )
    rendered_uses_zip = zip_resolution is not None and any(
        literal in result for literal in zip_resolution.literals
    )
    effective_zip_resolution = None
    if rendered_uses_zip:
        effective_zip_resolution = zip_resolution
    preamble_data = _preamble_data_with_zip(
        data_for_preamble=resolved_preamble_data.value,
        zip_resolution=effective_zip_resolution,
        per_element_rows=resolved_preamble_data.rows,
    )
    computed = compute_preamble(
        data=preamble_data,
        language=language,
        # A ``variable_form`` here binds a *call result*, not a literal,
        # so the call-binding declaration carries no value-type
        # annotation (languages whose literal binding injects one drop
        # it via ``format_call_variable_declaration``).  Treating it as
        # an annotated declaration would emit an annotation-only
        # preamble (e.g. Python's ``from typing import Any``) that the
        # call binding never uses, leaving a stale import.
        has_variable_declaration=False,
    )
    data_dependent_preamble = language.call_data_dependent_preamble(
        preamble_data
    )
    preamble = deduplicate_preamble_entries(
        entries=(
            computed.leading
            + tuple(language.static_preamble)
            + computed.header
            + data_dependent_preamble
        )
    )

    if wrap_in_file:
        return _wrap_call_result_in_file(
            language=language,
            materialized_bound_refs=materialized_bound_refs,
            ref_case=ref_case,
            result=result,
            preamble=preamble,
            data_dependent_preamble=data_dependent_preamble,
            computed_body=computed.body,
            types_present=computed.types_present,
            contains_standalone_comments=contains_standalone_comments,
            data_for_preamble=resolved_preamble_data.value,
            per_element=per_element,
            variable_form=variable_form,
            target_function_parts=target_function_parts,
            parameter_names=parameter_names,
            arg_values=arg_values,
            call_transform=call_transform,
            collection_layout=collection_layout,
        )

    return LiteralizeResult(
        declaration_code=result,
        preamble=preamble,
        body_preamble=computed.body,
        types_present=computed.types_present,
        contains_standalone_comments=contains_standalone_comments,
        source_data=resolved_preamble_data.value,
        pre_declaration_comments=(),
        sections=(),
        data_dependent_preamble=data_dependent_preamble,
    )


@beartype
def literalize_call_with_declarations(
    *,
    language: Language,
    declarations: Sequence[LiteralizeResult],
    call: LiteralizeResult,
    extra_body_preamble: tuple[str, ...],
    extra_preamble: tuple[str, ...],
) -> LiteralizeResult:
    r"""Render N ref declarations and a call into one coherent file.

    Shared reconciliation core behind :func:`literalize_call`'s
    *bound_refs* argument (and the call golden-file harness).  Composes
    the per-ref :func:`literalize` results in *declarations* (each a
    ``NewVariable`` binding for a ``$ref`` target) with the
    :func:`literalize_call` result *call* (rendered with those refs
    folded into ``ref_values``) into a single
    :class:`LiteralizeResult` whose :attr:`~LiteralizeResult.code` is a
    complete file: one coherent preamble (header *and* body) followed by
    the declarations and the calls wrapped via
    :meth:`Language.wrap_calls_with_declarations`.

    Concatenating the two halves' independently computed
    preambles instead would emit overlapping type definitions (e.g.
    Haskell's ``data Val = ...`` with disjoint constructor sets) that no
    string-level duplicate filter can reconcile.  The body preamble is
    recomputed across the union of types observed in every declaration
    *and* the call (so e.g. Haskell's datetime microsecond-precision
    check sees actual values).  The data-dependent header block (e.g.
    Gleam's ``pub type GVal {...}``) is likewise recomputed once over
    the combined source data of every declaration and the call, so a
    single block covers every type in the file; each independently
    computed declaration and call block is dropped.

    Args:
        language: The :class:`Language` to render with.  Must be the
            same instance used to produce *declarations* and *call*.
        declarations: The per-ref :func:`literalize` results, in the
            order they should appear, ahead of their first use in the
            call.
        call: The :func:`literalize_call` result.  Refs represented by
            *declarations* may be omitted from its ``ref_values``;
            declaration-only types are included when the composed
            preamble is recomputed.
        extra_body_preamble: Additional body-preamble lines to append
            after the unified body preamble (e.g. a caller-supplied
            no-op stub for the called function).  Defaults to ``()``.
        extra_preamble: Additional header-preamble entries to append
            after the unified header preamble (e.g. the stub's own
            import lines).  Defaults to ``()``.

    Returns:
        A :class:`LiteralizeResult` whose
        :attr:`~LiteralizeResult.declaration_code` (and therefore
        :attr:`~LiteralizeResult.code`) is the full file with the
        unified preamble already prepended;
        :attr:`~LiteralizeResult.preamble` and
        :attr:`~LiteralizeResult.body_preamble` are empty (their content
        has been folded into the code).

    Raises:
        UnsupportedCallShapeError: If *call* carries standalone comments
            but *language* cannot preserve them when wrapping calls.
    """
    if (
        call.contains_standalone_comments
        and not language.supports_standalone_comments_in_wrapped_calls
    ):
        raise UnsupportedCallShapeError(
            language_name=type(language).__name__,
            reason=(
                "standalone comments cannot be preserved when wrapping "
                "calls in this language"
            ),
        )
    empty_types = frozenset[type]()
    union_types = empty_types.union(
        *(d.types_present for d in declarations),
        call.types_present,
    )
    declaration_source_data: list[Value] = [
        d.source_data for d in declarations
    ]
    combined_source_data: list[Value] = [
        *declaration_source_data,
        call.source_data,
    ]
    unified_body_preamble = language.compute_body_preamble(
        union_types, combined_source_data
    )
    # Each declaration emitted its data-dependent block (e.g. Gleam's
    # ``pub type GVal {...}``) from *its own* data alone, so the
    # per-declaration blocks disagree on which constructors they
    # declare.  How they are reconciled depends on whether the language
    # renders call arguments and declarations through the *same*
    # data-dependent construct:
    #
    # * When ``call_data_dependent_preamble`` and
    #   ``data_dependent_preamble`` agree (Gleam, C++, ...), compute one
    #   canonical block over the declarations and call together when a
    #   declaration requires lines absent from the call's block.  This
    #   includes types used only by a declaration whose ref was omitted
    #   from the call's ``ref_values``.  Otherwise retain the call block
    #   verbatim, avoiding structural re-inference for languages whose
    #   preambles depend on collection shape.  Drop the exact
    #   independently inferred declaration entries in either case.
    # * When they diverge (Nim drops ``import json`` for call
    #   arguments), ``call.preamble`` cannot carry the
    #   declaration-side construct, so keep each declaration's own
    #   block; duplicate-line filtering collapses the copies.  This
    #   also keeps a *multi-line* declaration-only block, which the
    #   previous "drop any entry containing a newline" heuristic
    #   silently lost.
    call_form_matches_declaration_form = language.data_dependent_preamble(
        combined_source_data
    ) == language.call_data_dependent_preamble(combined_source_data)
    dropped_declaration_blocks: set[str] = set()
    call_preamble = call.preamble
    unified_data_dependent_preamble: tuple[str, ...] = ()
    if call_form_matches_declaration_form:
        for d in declarations:
            dropped_declaration_blocks.update(d.data_dependent_preamble)
        declaration_data_lines = {
            line
            for d in declarations
            for entry in d.data_dependent_preamble
            for line in entry.splitlines()
        }
        call_data_lines = {
            line
            for entry in call.data_dependent_preamble
            for line in entry.splitlines()
        }
        declaration_requires_unified_block = bool(
            declaration_data_lines - call_data_lines
        )
        if declaration_requires_unified_block:
            call_data_dependent_entries = set(call.data_dependent_preamble)
            call_preamble = tuple(
                entry
                for entry in call.preamble
                if entry not in call_data_dependent_entries
            )
            unified_data_dependent_preamble = (
                language.call_data_dependent_preamble(combined_source_data)
            )
    declaration_preamble = tuple(
        entry
        for d in declarations
        for entry in d.preamble
        if entry not in dropped_declaration_blocks
    )
    all_preamble = deduplicate_preamble_entries(
        entries=(
            declaration_preamble
            + call_preamble
            + unified_data_dependent_preamble
            + extra_preamble
        )
    )
    scoped = _scope_preamble_for_wrap(
        language=language,
        preamble=all_preamble,
        data_dependent_entries=(
            tuple(
                entry
                for d in declarations
                for entry in d.data_dependent_preamble
            )
            + call.data_dependent_preamble
            + unified_data_dependent_preamble
        ),
    )
    wrapped = language.wrap_calls_with_declarations(
        declarations=tuple(d.bare_code for d in declarations),
        calls=call.bare_code,
        body_preamble=(
            scoped.body + unified_body_preamble + extra_body_preamble
        ),
    )
    if len(scoped.file_scope) > 0:
        wrapped = "\n".join(scoped.file_scope) + "\n" + wrapped
    return LiteralizeResult(
        declaration_code=wrapped,
        preamble=(),
        body_preamble=(),
        types_present=union_types,
        contains_standalone_comments=call.contains_standalone_comments,
        source_data=call.source_data,
        pre_declaration_comments=(),
        sections=(),
        data_dependent_preamble=(),
    )
