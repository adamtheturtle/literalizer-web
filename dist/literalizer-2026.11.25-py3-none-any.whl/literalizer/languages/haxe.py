"""Haxe language specification."""

import dataclasses
import datetime as dt
import enum
import re
import textwrap
from collections.abc import Callable, Sequence
from functools import cached_property
from typing import TYPE_CHECKING, ClassVar

from beartype import beartype

from literalizer._formatters.collection_openers import (
    fixed_open,
    sequence_surrogate_set_open,
)
from literalizer._formatters.format_dates import (
    format_date_iso,
    format_datetime_epoch,
    format_datetime_iso,
    format_time_iso,
)
from literalizer._formatters.format_entries import (
    dict_entry_with_separator,
    format_bytes_base64,
    format_bytes_hex,
    passthrough_sequence_entry,
    passthrough_set_entry,
    variable_declaration_formatter,
    variable_formatter,
)
from literalizer._formatters.format_factories import set_format_factory
from literalizer._formatters.format_floats import (
    format_float_fixed,
    format_float_repr,
    format_float_scientific,
)
from literalizer._formatters.format_integers import (
    format_integer_hex,
    make_overflow_fallback_formatter,
    raise_for_unrepresentable_int,
)
from literalizer._formatters.format_strings import (
    format_string_backslash_nul_hex,
)
from literalizer._language import (
    NO_CALL_PARAMETER_LIMIT,
    NO_HETEROGENEOUS_BEHAVIOR,
    NON_KEBAB_REF_CASES,
    BareIntegerWidthStrategies,
    CallParameterShadowing,
    CallStubResult,
    CallStyle,
    CommentConfig,
    DateFormatConfig,
    DateFormatEnum,
    DatetimeFormatConfig,
    DatetimeFormatEnum,
    DeclarationStyleConfig,
    DictFormatConfig,
    FileWrapperContext,
    FloatSpecialsMixin,
    FormatValueMixin,
    HeterogeneousBehavior,
    IdentifierCase,
    JsonType,
    LanguageCls,
    ModifierCombination,
    NewVariableNameSyntax,
    NullableObjectCallStubResult,
    OrderedMapFormatConfig,
    PositionalCallStyle,
    RoundTripCapability,
    SequenceFormatConfig,
    SetFormatConfig,
    StubReturn,
    TrailingCommaConfig,
    VariantMetadata,
    body_preamble_from_scalars,
    default_call_data_dependent_preamble,
    default_consumable_ref_value_inhibits_consuming_form,
    default_format_call_arg_ref_identifier,
    default_format_call_arg_ref_identifier_consumable,
    default_format_call_ref_identifier,
    default_format_call_statement,
    default_format_call_stub,
    default_format_call_target,
    default_sequence_binding_declarations,
    default_type_hint_collection_preamble_lines,
    default_validate_call_arg,
    default_wrap_calls_with_declarations,
    default_wrap_combined_in_file,
    identity_call_arg,
    line_comment_call_variable_assignment,
    line_comment_call_variable_declaration,
    new_constructor_target,
    no_call_binding_body_preamble,
    no_call_binding_file_pragmas,
    no_data_preamble,
    no_format_integer_beyond_i64,
    no_format_integer_widened,
    no_leading_preamble,
    no_validate_spec_for_data,
    prepend_body_preamble,
    requires_declared_binding,
)
from literalizer._statements import CallLiteralSyntax
from literalizer._types import Value

_NULL_OBJECT_STUB = NullableObjectCallStubResult(
    type_name="Dynamic",
    value="null",
    conditional_template=(
        "{call} != {null} ?\n{call}{inner_comment}\n: {null}{trailing_comment}"
    ),
    comment_prefix="//",
)


@beartype
def _haxe_type_hint(data: Value, /) -> str:
    """Derive the coarse Haxe annotation for *data*.

    Every collection literal is rendered with an explicit
    ``(... : Array<Dynamic>)`` / ``(... : Map<String, Dynamic>)`` cast
    and every scalar is assignable to ``Dynamic``, so the variable
    annotation is the same coarse type regardless of element types.
    """
    match data:
        case dict():
            return "Map<String, Dynamic>"
        case list() | set():
            return "Array<Dynamic>"
        case _:
            return "Dynamic"


@beartype
def _format_haxe_typed_declaration(
    *,
    name: str,
    value: str,
    data: Value,
    _modifiers: frozenset[enum.Enum],
    keyword: str,
) -> str:
    """Format a Haxe variable declaration with an explicit type."""
    return f"{keyword}{name}:{_haxe_type_hint(data)} = {value};"


@beartype
def _haxe_params(params: Sequence[str]) -> str:
    """Render a stub parameter list, typing every parameter
    ``Dynamic``.
    """
    return ", ".join(f"{param}:Dynamic" for param in params)


@beartype
def _haxe_call_stub(
    parts: Sequence[str],
    params: Sequence[str],
    _stub_return: StubReturn,
    _args: Sequence[Value],
    /,
) -> tuple[str, ...]:
    """Return Haxe stub declarations for a call name.

    Stubs are emitted as local declarations so they are valid inside the
    ``static function main()`` body that :meth:`Haxe.wrap_in_file`
    produces.  A bare name becomes a local function; a dotted name
    becomes a local bound to a nested anonymous structure of closures
    (``var app = { client: { fetch: function(...) ... } };``).
    """
    return_type = _NULL_OBJECT_STUB.type_name
    return_value = _NULL_OBJECT_STUB.value
    if len(parts) == 1 and parts[0].startswith("new "):
        return ()
    param_list = _haxe_params(params=params)
    if len(parts) == 1:
        return (
            (
                f"function {parts[0]}({param_list}):{return_type}"
                f" return {return_value};"
            ),
        )
    method = parts[-1]
    fields = parts[1:-1]
    closure = f"function({param_list}):{return_type} return {return_value}"
    structure = f"{{ {method}: {closure} }}"
    for field in reversed(fields):
        structure = f"{{ {field}: {structure} }}"
    return (f"var {parts[0]} = {structure};",)


@beartype
def _haxe_constructor_stub(
    parts: Sequence[str],
    params: Sequence[str],
    _stub_return: StubReturn,
    _args: Sequence[Value],
    /,
) -> tuple[str, ...]:
    """Declare constructor types outside the generated entry point."""
    if len(parts) == 1 and parts[0].startswith("new "):
        class_name = parts[0].removeprefix("new ")
        param_list = _haxe_params(params=params)
        return (
            f"class {class_name} {{ public function new({param_list}) {{}} }}",
        )
    return ()


_HAXE_RESERVED: frozenset[str] = frozenset(
    {
        "abstract",
        "break",
        "case",
        "cast",
        "catch",
        "class",
        "continue",
        "default",
        "do",
        "dynamic",
        "else",
        "enum",
        "extends",
        "extern",
        "false",
        "final",
        "for",
        "function",
        "if",
        "implements",
        "import",
        "in",
        "inline",
        "interface",
        "macro",
        "new",
        "null",
        "operator",
        "overload",
        "override",
        "package",
        "private",
        "public",
        "return",
        "static",
        "switch",
        "this",
        "throw",
        "true",
        "try",
        "typedef",
        "untyped",
        "using",
        "var",
        "while",
    }
)


@beartype
def _format_haxe_hex(value: int) -> str:
    """Use hexadecimal only where Haxe preserves a signed ``Int``."""
    if value < -(1 << 31) or value >= 1 << 31:
        return f"{value}"
    return format_integer_hex(value=value)


# Work around https://github.com/astral-sh/ty/issues/4573.
if TYPE_CHECKING:
    _BytesEnumMember = enum.member[Callable[[bytes], str]]
    _StringEnumMember = enum.member[Callable[[str], str]]
    _IntegerEnumMember = enum.member[Callable[[int], str]]
else:
    _BytesEnumMember = enum.member
    _StringEnumMember = enum.member
    _IntegerEnumMember = enum.member


_CALL_LITERAL_SYNTAX = CallLiteralSyntax(
    prefix="//",
    regex_literals=True,
    raw_string_prefixes=(),
    verbatim_strings=False,
    interpolation_syntax=("${", "'"),
    quotes="\"'",
    literal_span_end=None,
    backtick_strings=False,
)


@beartype
@dataclasses.dataclass(frozen=True, kw_only=True)
class Haxe(metaclass=LanguageCls):
    """Haxe language specification.

    Args:
        date_format: How to format :class:`datetime.date` values.

            * ``date_formats.ISO`` — ISO 8601 quoted string,
              e.g. ``"2024-01-15"``.

        datetime_format: How to format :class:`datetime.datetime` values.

            * ``datetime_formats.ISO`` — ISO 8601 quoted string,
              e.g. ``"2024-01-15T12:30:00"``.
            * ``datetime_formats.EPOCH`` — Unix timestamp integer.
    """

    format_call_class_scope_stub = default_format_call_stub

    immutable_variable_modifiers: ClassVar[frozenset[enum.Enum]] = frozenset()
    wrap_in_file_tolerates_pre_indent = True
    module_name_shares_variable_scope = False
    reserved_variable_identifier_pattern: ClassVar[re.Pattern[str] | None] = (
        None
    )
    reserved_call_parameter_identifiers: ClassVar[frozenset[str]] = frozenset()
    reserved_call_parameter_identifier_pattern: ClassVar[
        re.Pattern[str] | None
    ] = None
    uses_data_keyword_for_algebraic_constructors = False
    accepts_type_name_call_target = True
    declares_type_name_call_target = True
    dotted_call_root_shares_entrypoint_namespace = True
    reserved_bare_call_target_identifiers: ClassVar[frozenset[str]] = (
        frozenset()
    )
    reserved_call_target_head_identifiers: ClassVar[frozenset[str]] = (
        frozenset()
    )
    contextual_call_target_identifiers: ClassVar[frozenset[str]] = frozenset()
    call_parameter_shadowing = CallParameterShadowing.ALLOWED
    reserved_call_target_keywords_case_sensitive = True
    new_variable_name_syntax = NewVariableNameSyntax.ASCII
    max_variable_identifier_length: ClassVar[int | None] = None
    call_stub_result: ClassVar[CallStubResult | None] = _NULL_OBJECT_STUB
    call_literal_syntax: ClassVar[CallLiteralSyntax | None] = (
        _CALL_LITERAL_SYNTAX
    )
    call_target_name_syntax: ClassVar[NewVariableNameSyntax | None] = None
    supports_multiline_dict_layout = True
    pools_map_integer_width = True

    format_integer_widened = no_format_integer_widened
    format_integer_beyond_i64 = no_format_integer_beyond_i64
    format_constructor_target: ClassVar["staticmethod[[str], str]"] = (
        staticmethod(new_constructor_target)
    )
    format_call_variable_declaration: ClassVar[property] = (
        line_comment_call_variable_declaration(syntax=_CALL_LITERAL_SYNTAX)
    )
    format_call_variable_assignment: ClassVar[property] = (
        line_comment_call_variable_assignment(syntax=_CALL_LITERAL_SYNTAX)
    )
    sequence_binding_declarations = default_sequence_binding_declarations
    format_call_binding_body_preamble = no_call_binding_body_preamble
    format_call_binding_file_pragmas = no_call_binding_file_pragmas

    leading_preamble = no_leading_preamble
    validate_spec_for_data = no_validate_spec_for_data
    extension = ".hx"
    pygments_name = "haxe"
    stringifies_nested_collections = False
    supports_special_floats = True
    supports_variable_names = True
    supports_no_variable_wrap_in_file = False
    wraps_data_dependent_preamble_in_body = False
    dict_supports_heterogeneous_values = True
    supports_local_binding_documents = False
    supports_stateful_free_call_consumers = True
    supports_stateful_receiver_result_checks = True
    supports_native_invocations = False
    supports_dotted_calls = True
    has_free_function_calls = True
    reserved_identifiers: ClassVar[frozenset[str]] = _HAXE_RESERVED
    declares_call_parameter_names = True
    reserved_variable_identifiers_case_sensitive: bool = True
    reserved_variable_identifiers: frozenset[str] = frozenset(
        {
            "abstract",
            "break",
            "case",
            "cast",
            "catch",
            "class",
            "continue",
            "default",
            "do",
            "dynamic",
            "else",
            "enum",
            "extends",
            "extern",
            "false",
            "final",
            "for",
            "function",
            "if",
            "implements",
            "import",
            "in",
            "inline",
            "interface",
            "macro",
            "new",
            "null",
            "operator",
            "overload",
            "override",
            "package",
            "private",
            "public",
            "return",
            "static",
            "super",
            "switch",
            "this",
            "throw",
            "true",
            "try",
            "typedef",
            "untyped",
            "using",
            "var",
            "while",
        }
    )
    allows_empty_call_parens = True
    supports_dotted_call_stub = True
    dotted_call_stub_indexes_colliding_helpers = False
    call_returns_expression = True
    supports_json_call_result_binding = False
    supports_zero_parameter_calls = True
    max_call_parameters = NO_CALL_PARAMETER_LIMIT
    supports_inline_multiline_dict_args = True
    supports_standalone_comments_in_wrapped_calls = True
    supports_multi_param_call_wrapper_stub = True
    supports_variadic_calls = False
    supports_dict_literal_as_free_expression = True
    # A top-level type declaration named after a standard library
    # type shadows it, and the generated code and the compiler itself
    # reach for those types, so the wrapper cannot take their names
    # (issue #4533).
    reserved_module_identifiers: ClassVar[frozenset[str]] = frozenset(
        {
            "begin",
            "end",
            "Any",
            "Array",
            "Bool",
            "Class",
            "Dynamic",
            "Enum",
            "Float",
            "Int",
            "Iterable",
            "Iterator",
            "KeyValueIterable",
            "KeyValueIterator",
            "Map",
            "Null",
            "Reflect",
            "Std",
            "StringBuf",
            "Type",
            "ValueType",
            "Void",
        }
    )
    # The wrapper is a type declaration, which both languages
    # require to start with an uppercase letter (issue #4533).
    module_name_must_start_uppercase: ClassVar[bool] = True
    supports_module_name = True
    supports_empty_dict_key = False
    supports_call_style = True
    supports_bare_mapping_documents = False
    supports_json_object_documents = False
    supports_default_dict_key_type = False
    supports_default_dict_value_type = False
    supports_nullable_object_fallbacks = False
    supports_default_sequence_element_type = False
    supports_key_value_assignment_documents = False
    supports_default_set_element_type = False
    supports_default_ordered_map_value_type = False
    json_type_variant_name_suffix: ClassVar[str | None] = None
    supports_non_ascii_string_literals = True
    supports_multiline_string_literals = False
    supports_empty_sibling_sequence_type_hints = True
    supports_typed_dict_open = False
    language_id: ClassVar[str] = "haxe"
    variant_metadata: ClassVar[VariantMetadata] = VariantMetadata(
        round_trip_capabilities=frozenset(
            {
                RoundTripCapability.INTERPOLATION_STRINGS,
            }
        ),
        modifier_sequence_format_overrides={},
        string_literals_escape_null_byte=True,
        supports_ref_elements_in_tuple_strategy=False,
    )
    supports_record_struct_name_prefix = False
    supports_record_shape_names = False
    record_shape_names_emit_declarations = False
    supports_non_string_dict_keys = False
    checks_raw_control_dict_keys_separately = False

    format_call_arg: ClassVar["staticmethod[[Value, str], str]"] = (
        staticmethod(
            identity_call_arg,
        )
    )
    """Callable that rewrites a formatted direct call argument."""

    class DateFormats(DateFormatEnum):
        """Date formatting options for Haxe."""

        ISO = DateFormatConfig(
            formatter=format_date_iso, type_produced=str, preamble_lines=()
        )

    class DatetimeFormats(DatetimeFormatEnum):
        """Datetime formatting options for Haxe."""

        ISO = DatetimeFormatConfig(
            formatter=format_datetime_iso,
            type_produced=str,
            preamble_lines=(),
        )
        EPOCH = DatetimeFormatConfig(
            formatter=format_datetime_epoch,
            type_produced=int,
            preamble_lines=(),
        )

    class BytesFormats(FormatValueMixin[Callable[[bytes], str]], enum.Enum):
        """Bytes formatting options."""

        HEX = _BytesEnumMember(value=format_bytes_hex)
        BASE64 = _BytesEnumMember(value=format_bytes_base64)

        def __call__(self, data: bytes, /) -> str:
            """Format bytes."""
            return self.value(data)

    class SequenceFormats(enum.Enum):
        """Sequence type options for Haxe."""

        ARRAY = SequenceFormatConfig(
            length_is_part_of_type=False,
            sequence_open=fixed_open(open_str="(["),
            close="] : Array<Dynamic>)",
            supports_heterogeneity=True,
            single_element_trailing_comma=False,
            single_element_template=None,
            supports_trailing_comma=True,
            empty_sequence=None,
            preamble_lines=(),
            format_entry=passthrough_sequence_entry,
            typed_opener_fallback=None,
            uses_typed_literal_for_scalars=False,
            requires_uniform_record_shapes=False,
            declared_type=None,
            narrowed_empty_form=None,
        )

    class SetFormats(
        FormatValueMixin[Callable[[str], SetFormatConfig]], enum.Enum
    ):
        """Set type options for Haxe.

        Haxe has no native set literal, so a set is rendered as a
        type-annotated ``Array`` literal.
        """

        SET = enum.member(
            value=set_format_factory(
                open_template="([",
                close="] : Array<Dynamic>)",
                empty_template="([] : Array<Dynamic>)",
                preamble_lines=(),
                set_opener_template="",
                supports_heterogeneity=True,
                supports_trailing_comma=True,
            )
        )

        def __call__(self, default_type: str) -> SetFormatConfig:
            """Create a set format config for the given type."""
            return self.value(default_type)

    class CommentFormats(enum.Enum):
        """Comment style options."""

        DOUBLE_SLASH = CommentConfig(
            prefix="//",
            suffix="",
        )
        BLOCK = CommentConfig(
            prefix="/*",
            suffix=" */",
        )

    class DeclarationStyles(enum.Enum):
        """Declaration style options."""

        FINAL = DeclarationStyleConfig(
            formatter=variable_declaration_formatter(
                template="final {name} = {value};"
            ),
            supports_redefinition=False,
        )
        VAR = DeclarationStyleConfig(
            formatter=variable_declaration_formatter(
                template="var {name} = {value};"
            ),
            supports_redefinition=True,
        )

    class DictEntryStyles(enum.Enum):
        """Dict entry style options."""

        DEFAULT = enum.auto()

    class DictFormats(enum.Enum):
        """Dict/map format options."""

        DEFAULT = enum.auto()

    class EmptyDictKey(enum.Enum):
        """Empty dict key options."""

        ALLOW = enum.auto()

    class FloatFormats(
        FloatSpecialsMixin,
        enum.Enum,
        positive_infinity="Math.POSITIVE_INFINITY",
        negative_infinity="Math.NEGATIVE_INFINITY",
        nan="Math.NaN",
    ):
        """Float format options."""

        REPR = enum.member(value=format_float_repr)
        SCIENTIFIC = enum.member(value=format_float_scientific)
        FIXED = enum.member(value=format_float_fixed)

    class IntegerFormats(FormatValueMixin[Callable[[int], str]], enum.Enum):
        """Integer format options."""

        DECIMAL = _IntegerEnumMember(value=str)
        HEX = _IntegerEnumMember(value=_format_haxe_hex)

        def __call__(self, value: int, /) -> str:
            """Format an integer."""
            formatter: Callable[[int], str] = self.value
            return formatter(value)

    class NumericLiteralSuffixes(enum.Enum):
        """Numeric literal suffix options."""

        NONE = enum.auto()

    class NumericSeparators(enum.Enum):
        """Numeric separator options."""

        NONE = enum.auto()

    class NumericStyles(enum.Enum):
        """Numeric literal style options."""

        OVERLOADED = enum.auto()

    class StringFormats(FormatValueMixin[Callable[[str], str]], enum.Enum):
        """String format options.

        Only double-quoted strings are emitted: Haxe performs string
        interpolation in single-quoted strings, so double quotes give a
        literal ``$`` with no escaping.
        """

        DOUBLE = _StringEnumMember(value=format_string_backslash_nul_hex)

        def __call__(self, value: str, /) -> str:
            """Format a string."""
            return self.value(value)

    class TrailingCommas(enum.Enum):
        """Trailing comma options."""

        YES = TrailingCommaConfig(multiline_trailing_comma=True)
        NO = TrailingCommaConfig(multiline_trailing_comma=False)

    date_formats = DateFormats
    datetime_formats = DatetimeFormats
    bytes_formats = BytesFormats
    sequence_formats = SequenceFormats
    set_formats = SetFormats
    comment_formats = CommentFormats

    class VariableTypeHints(enum.Enum):
        """Variable type hint options."""

        NEVER = enum.auto()
        ALWAYS = enum.auto()
        SAFE = enum.auto()

        def formatter(
            self,
            *,
            auto_formatter: Callable[
                [str, str, Value, frozenset[enum.Enum]], str
            ],
            keyword: str,
        ) -> Callable[[str, str, Value, frozenset[enum.Enum]], str]:
            """Return the variable declaration formatter.

            Collection literals already carry an explicit type cast, so
            ``NEVER`` and ``SAFE`` need no annotation; ``ALWAYS`` adds a
            redundant-but-valid annotation.
            """
            if self in {type(self).NEVER, type(self).SAFE}:
                return auto_formatter

            @beartype
            def _typed_formatter(
                name: str,
                value: str,
                data: Value,
                modifiers: frozenset[enum.Enum],
            ) -> str:
                """Adapt :func:`_format_haxe_typed_declaration` to the
                positional formatter interface.
                """
                return _format_haxe_typed_declaration(
                    name=name,
                    value=value,
                    data=data,
                    _modifiers=modifiers,
                    keyword=keyword,
                )

            return _typed_formatter

    variable_type_hints_formats = VariableTypeHints
    declaration_styles = DeclarationStyles
    dict_entry_styles = DictEntryStyles
    dict_formats = DictFormats
    empty_dict_keys = EmptyDictKey
    float_formats = FloatFormats
    integer_formats = IntegerFormats
    integer_width_strategies = BareIntegerWidthStrategies
    numeric_literal_suffixes = NumericLiteralSuffixes
    numeric_separators = NumericSeparators
    numeric_styles = NumericStyles
    string_formats = StringFormats
    trailing_commas = TrailingCommas

    class StatementTerminatorStyles(enum.Enum):
        """Statement terminator options."""

        SEMICOLON = enum.auto()

    statement_terminator_styles = StatementTerminatorStyles

    class CallStyles(enum.Enum):
        """Haxe call style options."""

        POSITIONAL = PositionalCallStyle(
            arg_separator=", ", parenthesize_each_arg=False
        )

    call_styles = CallStyles

    class Modifiers(enum.Enum):
        """C++/Java/C#-style declaration modifiers: this language has none."""

    modifiers = Modifiers

    class HeterogeneousStrategies(enum.Enum):
        """Heterogeneous-scalar strategy options — this language only
        supports raising.
        """

        ERROR = NO_HETEROGENEOUS_BEHAVIOR

    heterogeneous_strategies = HeterogeneousStrategies

    class JsonTypes(JsonType):
        """Empty: this language has no JSON value-type variants."""

    json_types = JsonTypes

    class BoolFormats(enum.Enum):
        """Empty: this language has no alternative boolean formats."""

    bool_formats = BoolFormats

    class VersionFormats(enum.Enum):
        """Version options for Haxe."""

        V4 = enum.auto()

    version_formats = VersionFormats

    modifier_combinations: ClassVar[tuple[ModifierCombination, ...]] = ()
    identifier_cases: ClassVar[tuple[IdentifierCase, ...]] = (
        IdentifierCase.CAMEL,
        IdentifierCase.PASCAL,
        IdentifierCase.UPPER_SNAKE,
    )
    supported_ref_cases: ClassVar[frozenset[IdentifierCase]] = (
        NON_KEBAB_REF_CASES
    )
    module_name_case: ClassVar[IdentifierCase] = IdentifierCase.PASCAL

    def wrap_in_file(
        self,
        content: str,
        context: FileWrapperContext,
    ) -> str:
        """Wrap code in a valid Haxe file.

        Everything (reference declarations, call stubs and the value
        itself) goes inside ``static function main()`` of a single
        class.  Haxe permits local functions and anonymous-structure
        closures inside a function body, so call stubs are emitted as
        local declarations rather than file-scope types.
        """
        body_preamble = context.body_preamble
        inner = prepend_body_preamble(
            content=content,
            body_preamble=body_preamble,
        )
        body_indent = self.indent + self.indent
        indented = textwrap.indent(text=inner, prefix=body_indent)
        return "\n".join(
            [
                f"class {self.module_name} {{",
                f"{self.indent}public static function main() {{",
                indented,
                f"{self.indent}}}",
                "}",
            ]
        )

    wrap_combined_in_file = default_wrap_combined_in_file

    date_format: DateFormats = DateFormats.ISO
    datetime_format: DatetimeFormats = DatetimeFormats.ISO
    bytes_format: BytesFormats = BytesFormats.HEX
    sequence_format: SequenceFormats = SequenceFormats.ARRAY
    set_format: SetFormats = SetFormats.SET
    variable_type_hints: VariableTypeHints = VariableTypeHints.NEVER
    comment_format: CommentFormats = CommentFormats.DOUBLE_SLASH
    declaration_style: DeclarationStyles = DeclarationStyles.FINAL
    dict_entry_style: DictEntryStyles = DictEntryStyles.DEFAULT
    dict_format: DictFormats = DictFormats.DEFAULT
    float_format: FloatFormats = FloatFormats.REPR
    integer_format: IntegerFormats = IntegerFormats.DECIMAL
    integer_width_strategy: BareIntegerWidthStrategies = (
        BareIntegerWidthStrategies.BARE
    )
    numeric_literal_suffix: NumericLiteralSuffixes = (
        NumericLiteralSuffixes.NONE
    )
    numeric_separator: NumericSeparators = NumericSeparators.NONE
    numeric_style: NumericStyles = NumericStyles.OVERLOADED
    string_format: StringFormats = StringFormats.DOUBLE
    trailing_comma: TrailingCommas = TrailingCommas.YES
    statement_terminator_style: StatementTerminatorStyles = (
        StatementTerminatorStyles.SEMICOLON
    )
    call_style: CallStyles = CallStyles.POSITIONAL
    heterogeneous_strategy: HeterogeneousStrategies = (
        HeterogeneousStrategies.ERROR
    )
    # `4` matches the major version of `Haxe.language_version` (`V4`);
    # keep in sync with the `haxe` install pinned in
    # `.github/workflows/lint.yml`.
    language_version: VersionFormats = VersionFormats.V4
    module_name: str = "Main"
    indent: str = "    "

    null_literal: ClassVar[str] = "null"
    true_literal: ClassVar[str] = "true"
    false_literal: ClassVar[str] = "false"
    indent_closing_delimiter: ClassVar[bool] = False
    element_separator: ClassVar[str] = ", "
    skip_null_dict_values: ClassVar[bool] = False
    supports_collection_comments: ClassVar[bool] = True
    supports_scalar_before_comments: ClassVar[bool] = True
    supports_scalar_inline_comments: ClassVar[bool] = False
    statement_terminator: ClassVar[str] = ";"
    static_preamble: ClassVar[Sequence[str]] = ()
    static_body_preamble: ClassVar[Sequence[str]] = ()
    special_float_preamble: ClassVar[tuple[str, ...]] = ()

    wrap_calls_with_declarations = default_wrap_calls_with_declarations

    validate_call_arg = default_validate_call_arg

    format_call_statement = default_format_call_statement

    @cached_property
    @beartype
    def format_sequence_entry(self) -> Callable[[Value, str], str]:
        """Format a sequence entry."""
        return passthrough_sequence_entry

    format_set_entry: ClassVar["staticmethod[[Value, str], str]"] = (
        staticmethod(passthrough_set_entry)
    )
    """Callable that formats a set entry."""

    assignment_declares_binding = requires_declared_binding
    reference_assignment_declares_binding = assignment_declares_binding
    call_assignment_declares_binding = False

    @cached_property
    @beartype
    def format_variable_assignment(self) -> Callable[[str, str, Value], str]:
        """Format an assignment to an existing variable."""
        return variable_formatter(template="{name} = {value};")

    @cached_property
    @beartype
    def format_ordered_map_entry(self) -> Callable[[str, Value, str], str]:
        """Format one ordered-map entry."""
        return dict_entry_with_separator(
            separator=" => ", format_value=passthrough_sequence_entry
        )

    @cached_property
    @beartype
    def data_dependent_preamble(self) -> Callable[[Value], tuple[str, ...]]:
        """Return data-dependent preamble lines."""
        return no_data_preamble

    @cached_property
    @beartype
    def heterogeneous_behavior(self) -> HeterogeneousBehavior:
        """Return the heterogeneous-behavior config."""
        return self.heterogeneous_strategy.value

    call_data_dependent_preamble = default_call_data_dependent_preamble

    type_hint_collection_preamble_lines = (
        default_type_hint_collection_preamble_lines
    )

    @cached_property
    @beartype
    def call_style_config(self) -> CallStyle:
        """Configuration for the chosen call style."""
        config: CallStyle = self.call_style.value
        return config

    @cached_property
    @beartype
    def format_call_stub(
        self,
    ) -> Callable[
        [Sequence[str], Sequence[str], StubReturn, Sequence[Value]],
        tuple[str, ...],
    ]:
        """Return stub declarations for a call expression."""
        return _haxe_call_stub

    @cached_property
    @beartype
    def format_call_preamble_stub(
        self,
    ) -> Callable[
        [Sequence[str], Sequence[str], StubReturn, Sequence[Value]],
        tuple[str, ...],
    ]:
        """Return constructor declarations outside the entry point."""
        return _haxe_constructor_stub

    format_call_target = default_format_call_target

    format_call_ref_identifier = default_format_call_ref_identifier

    format_call_arg_ref_identifier = default_format_call_arg_ref_identifier

    format_call_arg_ref_identifier_consumable = (
        default_format_call_arg_ref_identifier_consumable
    )

    consumable_ref_value_inhibits_consuming_form = (
        default_consumable_ref_value_inhibits_consuming_form
    )

    @cached_property
    @beartype
    def sequence_format_config(self) -> SequenceFormatConfig:
        """Configuration for the chosen sequence format."""
        return self.sequence_format.value

    @cached_property
    @beartype
    def set_format_config(self) -> SetFormatConfig:
        """Configuration for the chosen set format."""
        base = self.set_format(
            default_type="Dynamic",
        )
        return dataclasses.replace(
            base,
            set_open=sequence_surrogate_set_open(open_str="["),
        )

    @cached_property
    @beartype
    def sequence_open(self) -> Callable[[list[Value]], str]:
        """Callable that returns the opening delimiter for a sequence."""
        return self.sequence_format.value.sequence_open

    @cached_property
    @beartype
    def dict_format_config(self) -> DictFormatConfig:
        """Configuration for dict formatting."""
        return DictFormatConfig(
            dict_open=fixed_open(open_str="(["),
            close="] : Map<String, Dynamic>)",
            format_entry=dict_entry_with_separator(
                separator=" => ",
                format_value=passthrough_sequence_entry,
            ),
            empty_dict=None,
            preamble_lines=(),
            narrowed_open=None,
            supports_trailing_comma=True,
            narrowed_empty_form=None,
        )

    @cached_property
    @beartype
    def trailing_comma_config(self) -> TrailingCommaConfig:
        """Configuration for trailing-comma behavior."""
        return self.trailing_comma.value

    @cached_property
    @beartype
    def format_bytes(self) -> Callable[[bytes], str]:
        """Callable that formats a bytes value as a string literal."""
        return self.bytes_format

    @cached_property
    @beartype
    def format_date(self) -> Callable[[dt.date], str]:
        """Callable that formats a date as a string literal."""
        return self.date_format

    @cached_property
    @beartype
    def format_datetime(self) -> Callable[[dt.datetime], str]:
        """Callable that formats a datetime as a string literal."""
        return self.datetime_format

    @cached_property
    @beartype
    def format_time(self) -> Callable[[dt.time], str]:
        """Callable that formats a time as a string literal."""
        return format_time_iso

    @cached_property
    @beartype
    def format_string(self) -> Callable[[str], str]:
        """Callable that formats a string value as a quoted literal."""
        return self.string_format

    @cached_property
    @beartype
    def format_float(self) -> Callable[[float], str]:
        """Callable that formats a float value as a literal."""
        return self.float_format

    @cached_property
    @beartype
    def format_integer(self) -> Callable[[int], str]:
        """Callable that formats an int value as a literal.

        A wide integer lands in a ``Dynamic`` slot backed by the
        target's own number type, which on the ``eval`` and JavaScript
        targets is a double, so a value outside the range a double
        holds exactly is silently rounded (issue #4475).
        """
        return make_overflow_fallback_formatter(
            base=self.integer_format,
            min_value=-(2**53),
            max_value=2**53,
            fallback=raise_for_unrepresentable_int(language_name="Haxe"),
        )

    @cached_property
    @beartype
    def comment_config(self) -> CommentConfig:
        """Configuration for the language's comment syntax."""
        return self.comment_format.value

    @cached_property
    @beartype
    def ordered_map_format_config(self) -> OrderedMapFormatConfig:
        """Configuration for ordered-map formatting."""
        return OrderedMapFormatConfig(
            ordered_map_open=fixed_open(open_str="(["),
            close="] : Map<String, Dynamic>)",
            preamble_lines=(),
        )

    @cached_property
    @beartype
    def format_variable_declaration(
        self,
    ) -> Callable[[str, str, Value, frozenset[enum.Enum]], str]:
        """Callable that formats a new variable declaration."""
        return self.variable_type_hints.formatter(
            auto_formatter=self.declaration_style.value.formatter,
            keyword=f"{self.declaration_style.name.lower()} ",
        )

    @cached_property
    @beartype
    def scalar_preamble(self) -> dict[type[object], tuple[str, ...]]:
        """Per-instance scalar preamble (Haxe needs none)."""
        return {}

    @cached_property
    @beartype
    def scalar_body_preamble(self) -> dict[type[object], tuple[str, ...]]:
        """Per-instance scalar body preamble (Haxe needs none)."""
        return {}

    @cached_property
    @beartype
    def compute_body_preamble(
        self,
    ) -> Callable[[frozenset[type[object]], Value], tuple[str, ...]]:
        """Compute body-preamble lines from the scalar map."""
        return body_preamble_from_scalars(
            scalar_body_preamble=self.scalar_body_preamble,
            format_lines=tuple,
        )
