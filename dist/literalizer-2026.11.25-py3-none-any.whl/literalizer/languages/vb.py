"""Visual Basic (.NET) language specification."""

import dataclasses
import datetime as dt
import enum
import re
import textwrap
from collections.abc import Callable, Sequence
from functools import cached_property, partial
from typing import TYPE_CHECKING, ClassVar

from beartype import beartype

from literalizer._formatters.collection_openers import (
    make_element_to_type,
    make_type_to_opener,
    typed_collection_open,
)
from literalizer._formatters.format_dates import (
    date_ymd_formatter,
    format_date_iso,
    format_datetime_epoch,
    format_datetime_iso,
    format_time_vb,
)
from literalizer._formatters.format_entries import (
    braced_dict_entry,
    format_bytes_base64,
    format_bytes_hex,
    passthrough_sequence_entry,
    passthrough_set_entry,
    variable_formatter,
)
from literalizer._formatters.format_factories import (
    dict_format_factory,
    ordered_map_format_factory,
    set_format_factory,
)
from literalizer._formatters.format_floats import (
    format_float_fixed,
    format_float_repr,
    format_float_scientific,
)
from literalizer._formatters.format_integers import (
    I64_MAX,
    I64_MIN,
    make_long_suffix_formatter,
    make_overflow_fallback_formatter,
    make_unsigned_overflow_fallback,
)
from literalizer._formatters.type_inference import DictType, ListType
from literalizer._language import (
    NO_CALL_PARAMETER_LIMIT,
    NO_HETEROGENEOUS_BEHAVIOR,
    NON_KEBAB_REF_CASES,
    BareIntegerWidthStrategies,
    CallParameterShadowing,
    CallStubResult,
    CallStyle,
    CommentConfig,
    DateFormatConfig,
    DateFormatEnum,
    DatetimeFormatConfig,
    DatetimeFormatEnum,
    DeclarationStyleConfig,
    DictFormatBuilder,
    DictFormatConfig,
    FileWrapperContext,
    FloatSpecialsMixin,
    FormatValueMixin,
    HeterogeneousBehavior,
    IdentifierCase,
    JsonType,
    KeywordCallStyle,
    LanguageCls,
    ModifierCombination,
    NewVariableNameSyntax,
    NullableObjectCallStubResult,
    OrderedMapFormatConfig,
    PositionalCallStyle,
    RoundTripCapability,
    SequenceFormatConfig,
    SetFormatConfig,
    StubReturn,
    TrailingCommaConfig,
    VariantMetadata,
    body_preamble_from_scalars,
    default_call_data_dependent_preamble,
    default_consumable_ref_value_inhibits_consuming_form,
    default_format_call_arg_ref_identifier,
    default_format_call_arg_ref_identifier_consumable,
    default_format_call_ref_identifier,
    default_format_call_statement,
    default_format_call_stub,
    default_format_call_variable_assignment,
    default_format_call_variable_declaration,
    default_sequence_binding_declarations,
    default_type_hint_collection_preamble_lines,
    default_validate_call_arg,
    default_wrap_calls_with_declarations,
    identity_call_arg,
    no_call_binding_body_preamble,
    no_call_binding_file_pragmas,
    no_data_preamble,
    no_leading_preamble,
    no_validate_spec_for_data,
    prepend_body_preamble,
    requires_declared_binding,
)
from literalizer._types import Value

_NULL_OBJECT_STUB = NullableObjectCallStubResult(
    type_name="Object",
    value="Nothing",
    conditional_template=(
        "If({call} IsNot {null},\n"
        "{call}, {inner_comment}\n"
        "{null}){trailing_comment}"
    ),
    comment_prefix="'",
)


@beartype
def _format_vb_long(value: int, /, *, base: Callable[[int], str]) -> str:
    """Format a Long, spelling the minimum as ``Long.MinValue``.

    Visual Basic reads ``-9223372036854775808L`` as a negation of a
    literal one past ``Long.MaxValue``, which is ``BC30036: Overflow``
    wherever it appears -- inside a typed array element as much as at
    scalar position (issue #4487).
    """
    if value == I64_MIN:
        return "Long.MinValue"
    return base(value)


@beartype
def _format_vb_ulong_positive(value: int) -> str:
    """Format a positive value above signed 64-bit range as a VB.NET
    ``UL`` unsigned 64-bit literal.

    The default VB.NET integer type is signed 64-bit; values above
    that range need the ``UL`` suffix to select the unsigned 64-bit
    type, which covers up to 2^64 - 1.
    """
    return f"{value}UL"


@beartype
def _flush_vb_current(
    *,
    parts: list[str],
    current: str,
) -> str:
    """Flush accumulated literal characters into parts."""
    if current != "":
        parts.append(f'"{current}"')
    return ""


@beartype
def _vb_string_parts(value: str) -> list[str]:
    """Generate VB.NET string parts for control character handling."""
    control_char_threshold = 32
    parts: list[str] = []
    current = ""
    i = 0
    char_replacements = {"\n": "Chr(10)", "\r": "Chr(13)", "\t": "vbTab"}
    while i < len(value):
        c = value[i]
        match c:
            case '"':
                current += '""'
                i += 1
            case "\r" if i + 1 < len(value) and value[i + 1] == "\n":
                current = _flush_vb_current(parts=parts, current=current)
                parts.append("vbCrLf")
                i += 2
            case _ if c in char_replacements:
                current = _flush_vb_current(parts=parts, current=current)
                parts.append(char_replacements[c])
                i += 1
            case _ if ord(c) < control_char_threshold:
                current = _flush_vb_current(parts=parts, current=current)
                parts.append(f"Chr({ord(c)})")
                i += 1
            case _:
                current += c
                i += 1
    _ = _flush_vb_current(parts=parts, current=current)
    return parts


@beartype
def _format_string_vb(value: str) -> str:
    r"""Format a string using VB.NET string escaping rules.

    VB.NET strings use ``""`` to escape embedded double quotes and do not
    support backslash escapes.  Control characters such as newlines and
    tabs are expressed via ``vbCrLf``, ``vbTab``, or ``Chr(N)`` string
    concatenation.
    """
    parts = _vb_string_parts(value=value)
    if len(parts) == 0:
        return '""'
    if len(parts) == 1:
        return parts[0]
    return " & ".join(parts)


_VB_RESERVED_IDENTIFIERS = frozenset(
    {
        "addhandler",
        "and",
        "andalso",
        "as",
        "boolean",
        "byref",
        "byte",
        "byval",
        "case",
        "catch",
        "cbool",
        "cbyte",
        "cchar",
        "cdate",
        "cdbl",
        "cdec",
        "char",
        "cint",
        "class",
        "clng",
        "cobj",
        "const",
        "continue",
        "csbyte",
        "cshort",
        "csng",
        "cstr",
        "ctype",
        "cuint",
        "culng",
        "cushort",
        "date",
        "decimal",
        "declare",
        "default",
        "delegate",
        "dim",
        "directcast",
        "do",
        "double",
        "each",
        "else",
        "elseif",
        "end",
        "endif",
        "enum",
        "erase",
        "error",
        "event",
        "exit",
        "false",
        "finally",
        "for",
        "friend",
        "function",
        "get",
        "global",
        "goto",
        "handles",
        "if",
        "implements",
        "imports",
        "in",
        "inherits",
        "integer",
        "interface",
        "is",
        "isnot",
        "let",
        "lib",
        "like",
        "long",
        "loop",
        "me",
        "mod",
        "module",
        "mustinherit",
        "mustoverride",
        "mybase",
        "myclass",
        "namespace",
        "narrowing",
        "new",
        "next",
        "not",
        "nothing",
        "notinheritable",
        "notoverridable",
        "object",
        "of",
        "on",
        "operator",
        "option",
        "or",
        "orelse",
        "overloads",
        "overridable",
        "overrides",
        "paramarray",
        "partial",
        "private",
        "property",
        "protected",
        "public",
        "raiseevent",
        "readonly",
        "redim",
        "removehandler",
        "resume",
        "return",
        "select",
        "set",
        "shadows",
        "shared",
        "short",
        "single",
        "static",
        "step",
        "stop",
        "string",
        "structure",
        "sub",
        "synclock",
        "then",
        "throw",
        "to",
        "true",
        "try",
        "trycast",
        "typeof",
        "uinteger",
        "ulong",
        "ushort",
        "using",
        "variant",
        "wend",
        "when",
        "while",
        "widening",
        "with",
        "withevents",
        "writeonly",
        "xor",
    }
)


@beartype
def _vb_call_identifier(name: str, /) -> str:
    """Escape reserved words in call member and parameter declarations."""
    return f"[{name}]" if name.casefold() in _VB_RESERVED_IDENTIFIERS else name


@beartype
def _vb_format_call_target(parts: Sequence[str], /) -> str:
    """Preserve native constructor targets and escape keyword members."""
    return ".".join(_vb_call_identifier(part) for part in parts)


@beartype
def _vb_unique_class_name(*, segment: str, position: int) -> str:
    """Build a stub class name unique to a segment's path position.

    VB.NET is case-insensitive, so two segments that differ only in
    case (or repeat exactly) — e.g. ``app.app.method`` — would
    otherwise produce duplicate ``Class`` declarations.  Suffixing
    with the segment's position in the dotted target keeps every
    generated name distinct.
    """
    return f"{segment.title()}Type_{position}_"


@beartype
def _vb_call_stub(
    parts: Sequence[str],
    params: Sequence[str],
    _stub_return: StubReturn,
    _args: Sequence[Value],
    /,
    *,
    indent: str,
) -> tuple[str, ...]:
    """Return Visual Basic stub declarations for a call name.

    For a single-name target the stub is a module-level ``Function``
    whose parameter list matches the given names; for a dotted target
    a chain of nested stub classes is emitted so ``a.b.c.d(...)``
    dispatches to a real method whose body returns ``Nothing``.

    Each declaration block is returned as one tuple entry containing
    embedded newlines so that the call-test harness's whole-line
    duplicate filter does not strip repeated structural keywords like
    ``End Class`` or ``End Function`` that legitimately appear in
    every block.
    """
    return_type = _NULL_OBJECT_STUB.type_name
    return_value = _NULL_OBJECT_STUB.value
    param_list = ", ".join(
        f"{_vb_call_identifier(p)} As Object" for p in params
    )
    method_block = (
        f"Public Function {{method}}({param_list}) As {return_type}\n"
        f"{indent}Return {return_value}\n"
        "End Function"
    )
    if len(parts) == 1 and parts[0].startswith("New "):
        class_name = parts[0].removeprefix("New ")
        return (
            (
                f"Class {class_name}\n"
                f"{indent}Public Sub New({param_list})\n"
                f"{indent}End Sub\n"
                "End Class"
            ),
        )
    if len(parts) == 1:
        return (
            (
                f"Function {_vb_call_identifier(parts[0])}"
                f"({param_list}) As {return_type}\n"
                f"{indent}Return {return_value}\n"
                "End Function"
            ),
        )
    root = parts[0]
    method = parts[-1]
    fields = parts[1:-1]
    method_body = textwrap.indent(
        text=method_block.format(method=_vb_call_identifier(method)),
        prefix=indent,
    )
    if len(fields) == 0:
        type_name = _vb_unique_class_name(segment=root, position=0)
        return (
            f"Class {type_name}\n{method_body}\nEnd Class",
            f"Dim {root} As New {type_name}()",
        )
    blocks: list[str] = []
    inner_type = _vb_unique_class_name(
        segment=fields[-1],
        position=len(fields),
    )
    blocks.append(f"Class {inner_type}\n{method_body}\nEnd Class")
    prev_type = inner_type
    for i in range(len(fields) - 2, -1, -1):
        curr_type = _vb_unique_class_name(segment=fields[i], position=i + 1)
        blocks.append(
            f"Class {curr_type}\n"
            f"    Public {_vb_call_identifier(fields[i + 1])}"
            f" As New {prev_type}()\n"
            "End Class"
        )
        prev_type = curr_type
    root_type = _vb_unique_class_name(segment=root, position=0)
    blocks.append(
        f"Class {root_type}\n"
        f"    Public {_vb_call_identifier(fields[0])} As New {prev_type}()\n"
        "End Class"
    )
    blocks.append(f"Dim {root} As New {root_type}()")
    return tuple(blocks)


@beartype
def _format_variable_declaration(
    name: str,
    value: str,
    _data: Value,
    _modifiers: frozenset[enum.Enum],
) -> str:
    """Format a VB.NET variable declaration."""
    return f"Dim {name} = {value}"


@beartype
def _format_constructor_target(class_name: str, /) -> str:
    """Format a VB.NET constructor call target."""
    return f"New {class_name}"


_constructor_target: Callable[[str], str] = _format_constructor_target


# Work around https://github.com/astral-sh/ty/issues/4573.
if TYPE_CHECKING:
    _BytesEnumMember = enum.member[Callable[[bytes], str]]
else:
    _BytesEnumMember = enum.member


@beartype
@dataclasses.dataclass(frozen=True, kw_only=True)
class VisualBasic(metaclass=LanguageCls):
    """Visual Basic (.NET) language specification.

    VB.NET collection initializers (``New T() { ... }``,
    ``New HashSet(Of T) From { ... }``, etc.) do not support comments
    inside the ``{ ... }`` block.  YAML comments associated with
    collection elements are therefore emitted as standalone comment lines
    *before* the collection — or before the variable declaration when a
    variable name is supplied.
    """

    format_call_stub = default_format_call_stub

    reserved_module_identifiers: ClassVar[frozenset[str]] = frozenset()
    immutable_variable_modifiers: ClassVar[frozenset[enum.Enum]] = frozenset()
    wrap_in_file_tolerates_pre_indent = True
    module_name_shares_variable_scope = False
    reserved_variable_identifier_pattern: ClassVar[re.Pattern[str] | None] = (
        None
    )
    reserved_call_parameter_identifiers: ClassVar[frozenset[str]] = frozenset(
        {"_"}
    )
    reserved_call_parameter_identifier_pattern: ClassVar[
        re.Pattern[str] | None
    ] = None
    uses_data_keyword_for_algebraic_constructors = False
    accepts_type_name_call_target = True
    declares_type_name_call_target = True
    dotted_call_root_shares_entrypoint_namespace = True
    reserved_bare_call_target_identifiers: ClassVar[frozenset[str]] = (
        frozenset()
    )
    reserved_call_target_head_identifiers: ClassVar[frozenset[str]] = (
        frozenset()
    )
    contextual_call_target_identifiers: ClassVar[frozenset[str]] = frozenset()
    reserved_call_target_keywords_case_sensitive = True
    module_name_must_start_uppercase = False
    new_variable_name_syntax = NewVariableNameSyntax.ASCII
    max_variable_identifier_length: ClassVar[int | None] = None
    call_stub_result: ClassVar[CallStubResult | None] = _NULL_OBJECT_STUB
    call_literal_syntax: ClassVar[None] = None
    call_target_name_syntax: ClassVar[NewVariableNameSyntax | None] = None
    supports_multiline_dict_layout = True

    format_call_variable_declaration = default_format_call_variable_declaration
    format_call_variable_assignment = default_format_call_variable_assignment
    format_constructor_target: ClassVar["staticmethod[[str], str]"] = (
        staticmethod(_constructor_target)
    )
    sequence_binding_declarations = default_sequence_binding_declarations
    format_call_binding_body_preamble = no_call_binding_body_preamble
    format_call_binding_file_pragmas = no_call_binding_file_pragmas

    leading_preamble = no_leading_preamble
    extension = ".vb"
    pygments_name = "vb.net"
    stringifies_nested_collections = False
    supports_special_floats = True
    supports_variable_names = True
    supports_no_variable_wrap_in_file = False
    wraps_data_dependent_preamble_in_body = False
    dict_supports_heterogeneous_values = True
    supports_local_binding_documents = False
    supports_stateful_free_call_consumers = True
    supports_stateful_receiver_result_checks = True
    supports_native_invocations = False
    supports_dotted_calls = True
    has_free_function_calls = True
    reserved_identifiers: ClassVar[frozenset[str]] = frozenset()
    # The stub declares the target and its parameters in one
    # statement, and this language treats that name as in scope
    # there.  An earlier dotted component names something else
    # (issue #4528).
    call_parameter_shadowing: ClassVar[CallParameterShadowing] = (
        CallParameterShadowing.TARGET_NAME
    )
    declares_call_parameter_names = True
    reserved_variable_identifiers_case_sensitive: bool = False
    reserved_variable_identifiers: frozenset[str] = _VB_RESERVED_IDENTIFIERS
    allows_empty_call_parens = True
    supports_dotted_call_stub = True
    dotted_call_stub_indexes_colliding_helpers = False
    call_returns_expression = True
    supports_json_call_result_binding = False
    supports_zero_parameter_calls = True
    max_call_parameters = NO_CALL_PARAMETER_LIMIT
    supports_inline_multiline_dict_args = True
    supports_standalone_comments_in_wrapped_calls = True
    supports_multi_param_call_wrapper_stub = True
    supports_variadic_calls = False
    supports_dict_literal_as_free_expression = True
    supports_module_name = False
    supports_empty_dict_key = False
    supports_call_style = True
    supports_bare_mapping_documents = False
    supports_json_object_documents = False
    supports_default_dict_key_type = True
    # A Visual Basic map is Dictionary(Of String, Object), so each
    # value carries its own type and there is no shared width to
    # pool (issue #4488).
    pools_map_integer_width: ClassVar[bool] = False
    supports_default_dict_value_type = True
    supports_nullable_object_fallbacks = False
    supports_default_sequence_element_type = True
    supports_key_value_assignment_documents = False
    supports_default_set_element_type = True
    supports_default_ordered_map_value_type = False
    json_type_variant_name_suffix: ClassVar[str | None] = None
    supports_non_ascii_string_literals = True
    supports_multiline_string_literals = False
    supports_empty_sibling_sequence_type_hints = True
    supports_typed_dict_open = False
    language_id: ClassVar[str] = "vb"
    variant_metadata: ClassVar[VariantMetadata] = VariantMetadata(
        round_trip_capabilities=frozenset(
            {
                RoundTripCapability.I64_BOUNDARIES,
                RoundTripCapability.INTERPOLATION_STRINGS,
                RoundTripCapability.CONTROL_STRINGS,
                RoundTripCapability.EMBEDDED_NUL,
            }
        ),
        modifier_sequence_format_overrides={},
        string_literals_escape_null_byte=True,
        supports_ref_elements_in_tuple_strategy=False,
    )
    supports_record_struct_name_prefix = False
    supports_record_shape_names = False
    record_shape_names_emit_declarations = False
    supports_non_string_dict_keys = False
    checks_raw_control_dict_keys_separately = False

    format_call_arg: ClassVar["staticmethod[[Value, str], str]"] = (
        staticmethod(
            identity_call_arg,
        )
    )
    """Callable that rewrites a formatted direct call argument."""

    class DateFormats(DateFormatEnum):
        """Date format options for VisualBasic."""

        ISO = DateFormatConfig(
            formatter=format_date_iso, type_produced=str, preamble_lines=()
        )
        VISUAL_BASIC = DateFormatConfig(
            formatter=date_ymd_formatter(
                template="New DateOnly({year}, {month}, {day})",
            ),
            type_produced=dt.date,
            preamble_lines=("Imports System",),
        )

    class DatetimeFormats(DatetimeFormatEnum):
        """Datetime format options for VisualBasic."""

        ISO = DatetimeFormatConfig(
            formatter=format_datetime_iso,
            type_produced=str,
            preamble_lines=(),
        )

        EPOCH = DatetimeFormatConfig(
            formatter=format_datetime_epoch,
            type_produced=int,
            preamble_lines=(),
        )

    class BytesFormats(FormatValueMixin[Callable[[bytes], str]], enum.Enum):
        """Bytes formatting options."""

        HEX = _BytesEnumMember(value=format_bytes_hex)
        BASE64 = _BytesEnumMember(value=format_bytes_base64)

        def __call__(self, data: bytes, /) -> str:
            """Format bytes."""
            return self.value(data)

    class SequenceFormats(enum.Enum):
        """Sequence type options for Visual Basic."""

        ARRAY = enum.auto()

    class SetFormats(
        FormatValueMixin[Callable[[str], SetFormatConfig]], enum.Enum
    ):
        """Set type options for Visual Basic."""

        HASH_SET = enum.member(
            value=set_format_factory(
                open_template="New HashSet(Of {type}) From {{",
                close="}}",
                empty_template="New HashSet(Of {type})()",
                preamble_lines=(),
                set_opener_template=("New HashSet(Of {type_name}) From {{"),
                supports_heterogeneity=True,
                supports_trailing_comma=True,
            )
        )

        def __call__(self, default_type: str) -> SetFormatConfig:
            """Create a set format config for the given type."""
            return self.value(default_type)

    class CommentFormats(enum.Enum):
        """Comment style options."""

        APOSTROPHE = CommentConfig(
            prefix="'",
            suffix="",
        )

    class DeclarationStyles(enum.Enum):
        """Declaration style options."""

        DIM = DeclarationStyleConfig(
            formatter=_format_variable_declaration,
            supports_redefinition=True,
        )

    class DictEntryStyles(enum.Enum):
        """Dict entry style options."""

        DEFAULT = enum.auto()

    class DictFormats(FormatValueMixin[DictFormatBuilder], enum.Enum):
        """Dict/map format options."""

        DEFAULT = enum.member(
            value=dict_format_factory(
                open_template=(
                    "New Dictionary(Of {key_type}, {type}) From {{"
                ),
                close="}",
                format_entry=braced_dict_entry(
                    format_value=passthrough_sequence_entry,
                ),
                empty_template=None,
                preamble_lines=("Imports System.Collections.Generic",),
                narrowed_open=None,
                supports_trailing_comma=True,
            )
        )

        def __call__(
            self,
            default_type: str,
            *,
            default_key_type: str = "String",
        ) -> DictFormatConfig:
            """Create a dict format config for the given type."""
            return self.value(
                default_type=default_type,
                default_key_type=default_key_type,
            )

    class EmptyDictKey(enum.Enum):
        """Empty dict key options."""

        ALLOW = enum.auto()

    class FloatFormats(
        FloatSpecialsMixin,
        enum.Enum,
        positive_infinity="Double.PositiveInfinity",
        negative_infinity="Double.NegativeInfinity",
        nan="Double.NaN",
    ):
        """Float format options."""

        REPR = enum.member(value=format_float_repr)
        SCIENTIFIC = enum.member(value=format_float_scientific)
        FIXED = enum.member(value=format_float_fixed)

    class IntegerFormats(enum.Enum):
        """Integer format options."""

        DECIMAL = enum.auto()

    class NumericLiteralSuffixes(enum.Enum):
        """Numeric literal suffix options."""

        NONE = enum.auto()

    class NumericSeparators(enum.Enum):
        """Numeric separator options."""

        NONE = enum.auto()

    class NumericStyles(enum.Enum):
        """Numeric literal style options."""

        OVERLOADED = enum.auto()

    class StringFormats(enum.Enum):
        """String format options."""

        DOUBLE = enum.auto()

    class TrailingCommas(enum.Enum):
        """Trailing comma options."""

        NO = TrailingCommaConfig(multiline_trailing_comma=False)

    date_formats = DateFormats
    datetime_formats = DatetimeFormats
    bytes_formats = BytesFormats
    sequence_formats = SequenceFormats
    set_formats = SetFormats
    comment_formats = CommentFormats

    class VariableTypeHints(enum.Enum):
        """Variable type hint options."""

        NEVER = enum.auto()
        SAFE = enum.auto()

    variable_type_hints_formats = VariableTypeHints
    declaration_styles = DeclarationStyles
    dict_entry_styles = DictEntryStyles
    dict_formats = DictFormats
    empty_dict_keys = EmptyDictKey
    float_formats = FloatFormats
    integer_formats = IntegerFormats
    integer_width_strategies = BareIntegerWidthStrategies
    numeric_literal_suffixes = NumericLiteralSuffixes
    numeric_separators = NumericSeparators
    numeric_styles = NumericStyles
    string_formats = StringFormats
    trailing_commas = TrailingCommas

    class StatementTerminatorStyles(enum.Enum):
        """Statement terminator options."""

        SEMICOLON = enum.auto()

    statement_terminator_styles = StatementTerminatorStyles

    class CallStyles(enum.Enum):
        """VisualBasic call style options."""

        POSITIONAL = PositionalCallStyle(
            arg_separator=", ", parenthesize_each_arg=False
        )
        NAMED = KeywordCallStyle(separator=":=")

    call_styles = CallStyles

    class Modifiers(enum.Enum):
        """C++/Java/C#-style declaration modifiers: this language has none."""

    modifiers = Modifiers

    class HeterogeneousStrategies(enum.Enum):
        """Heterogeneous-scalar strategy options — this language only
        supports raising.
        """

        ERROR = NO_HETEROGENEOUS_BEHAVIOR

    heterogeneous_strategies = HeterogeneousStrategies

    class JsonTypes(JsonType):
        """Empty: this language has no JSON value-type variants."""

    json_types = JsonTypes

    class BoolFormats(enum.Enum):
        """Empty: this language has no alternative boolean formats."""

    bool_formats = BoolFormats

    class VersionFormats(enum.Enum):
        """Version options for Visual Basic."""

        DOTNET_6 = enum.auto()

    version_formats = VersionFormats

    modifier_combinations: ClassVar[tuple[ModifierCombination, ...]] = ()
    identifier_cases: ClassVar[tuple[IdentifierCase, ...]] = (
        IdentifierCase.PASCAL,
        IdentifierCase.CAMEL,
    )
    supported_ref_cases: ClassVar[frozenset[IdentifierCase]] = (
        NON_KEBAB_REF_CASES
    )

    validate_spec_for_data = no_validate_spec_for_data

    validate_call_arg = default_validate_call_arg

    format_call_statement = default_format_call_statement

    wrap_calls_with_declarations = default_wrap_calls_with_declarations

    def wrap_in_file(
        self,
        content: str,
        context: FileWrapperContext,
    ) -> str:
        """Wrap a VB.NET Dim declaration inside a Module.

        The context carries module-member call stubs separately from
        body bindings. When member declarations are present, *content* is
        placed inside ``Sub _calls()``: VB rejects bare expression
        statements at module level, but shared subs taking no
        arguments are invoked by the fixture linter so the calls
        still execute.
        """
        body_preamble = context.body_preamble
        if len(context.class_preamble) > 0:
            preamble_block = "\n".join(context.class_preamble)
            content = prepend_body_preamble(
                content=content, body_preamble=body_preamble
            )
            preamble_indented = textwrap.indent(
                text=preamble_block,
                prefix=self.indent,
            )
            content_indented = textwrap.indent(
                text=content, prefix=self.indent * 2
            )
            return (
                "Module Check\n"
                f"{preamble_indented}\n"
                f"{self.indent}Sub _calls()\n"
                f"{content_indented}\n"
                f"{self.indent}End Sub\n"
                "End Module"
            )
        content = prepend_body_preamble(
            content=content,
            body_preamble=body_preamble,
        )
        indented = textwrap.indent(text=content, prefix=self.indent)
        return f"Module Check\n{indented}\nEnd Module"

    def wrap_combined_in_file(
        self,
        declaration: str,
        assignment: str,
        context: FileWrapperContext,
    ) -> str:
        """Wrap declaration and assignment in separate VB.NET procedures.

        Bound references need declarations in each procedure's scope.
        """
        variable_name = context.variable_name
        body_preamble = context.body_preamble
        declaration = prepend_body_preamble(
            content=declaration,
            body_preamble=body_preamble,
        )
        decl_indented = textwrap.indent(
            text=declaration, prefix=self.indent * 2
        )
        assignment_preamble = f"Dim {variable_name} As Object"
        if len(context.bound_variable_names) > 0:
            assignment_preamble = declaration
        assignment = prepend_body_preamble(
            content=assignment,
            body_preamble=(assignment_preamble,),
        )
        assign_indented = textwrap.indent(
            text=assignment, prefix=self.indent * 2
        )
        return (
            "Module Check\n"
            f"{self.indent}Sub _declaration()\n"
            f"{decl_indented}\n"
            f"{self.indent}End Sub\n"
            f"{self.indent}Sub _assignment()\n"
            f"{assign_indented}\n"
            f"{self.indent}End Sub\n"
            "End Module"
        )

    date_format: DateFormats = DateFormats.VISUAL_BASIC
    datetime_format: DatetimeFormats = DatetimeFormats.ISO
    bytes_format: BytesFormats = BytesFormats.HEX
    sequence_format: SequenceFormats = SequenceFormats.ARRAY
    set_format: SetFormats = SetFormats.HASH_SET
    default_set_element_type: str = "Object"
    default_sequence_element_type: str = "Object"
    default_dict_key_type: str = "String"
    default_dict_value_type: str = "Object"
    variable_type_hints: VariableTypeHints = VariableTypeHints.NEVER
    comment_format: CommentFormats = CommentFormats.APOSTROPHE
    declaration_style: DeclarationStyles = DeclarationStyles.DIM
    dict_entry_style: DictEntryStyles = DictEntryStyles.DEFAULT
    dict_format: DictFormats = DictFormats.DEFAULT
    float_format: FloatFormats = FloatFormats.REPR
    integer_format: IntegerFormats = IntegerFormats.DECIMAL
    integer_width_strategy: BareIntegerWidthStrategies = (
        BareIntegerWidthStrategies.BARE
    )
    numeric_literal_suffix: NumericLiteralSuffixes = (
        NumericLiteralSuffixes.NONE
    )
    numeric_separator: NumericSeparators = NumericSeparators.NONE
    numeric_style: NumericStyles = NumericStyles.OVERLOADED
    string_format: StringFormats = StringFormats.DOUBLE
    trailing_comma: TrailingCommas = TrailingCommas.NO
    statement_terminator_style: StatementTerminatorStyles = (
        StatementTerminatorStyles.SEMICOLON
    )
    call_style: CallStyles = CallStyles.POSITIONAL
    heterogeneous_strategy: HeterogeneousStrategies = (
        HeterogeneousStrategies.ERROR
    )
    # Keep in sync with the `LanguageVersion` passed to the VB lint host
    # in `scripts/lint-vb/Program.cs`.
    language_version: VersionFormats = VersionFormats.DOTNET_6
    indent: str = "    "

    null_literal: ClassVar[str] = "Nothing"
    true_literal: ClassVar[str] = "True"
    false_literal: ClassVar[str] = "False"
    indent_closing_delimiter: ClassVar[bool] = False
    element_separator: ClassVar[str] = ", "
    skip_null_dict_values: ClassVar[bool] = False
    supports_collection_comments: ClassVar[bool] = False
    # A numeric value after leading comments can be parsed as a line label.
    supports_scalar_before_comments: ClassVar[bool] = False
    supports_scalar_inline_comments: ClassVar[bool] = True
    statement_terminator: ClassVar[str] = ""
    static_preamble: ClassVar[Sequence[str]] = ()
    static_body_preamble: ClassVar[Sequence[str]] = ()
    special_float_preamble: ClassVar[tuple[str, ...]] = ()

    @cached_property
    @beartype
    def format_string(self) -> Callable[[str], str]:
        """Format a string value as a quoted literal."""
        return _format_string_vb

    @cached_property
    @beartype
    def format_integer(self) -> Callable[[int], str]:
        """Format an int value as a literal."""
        return make_overflow_fallback_formatter(
            base=partial(_format_vb_long, base=str),
            fallback=make_unsigned_overflow_fallback(
                format_positive=_format_vb_ulong_positive,
                language_name="VB.NET",
            ),
            min_value=I64_MIN,
            max_value=I64_MAX,
        )

    @cached_property
    @beartype
    def format_integer_widened(self) -> Callable[[int], str]:
        """Always-``L``-suffixed integer formatter for widened
        collections (mixed-magnitude int sets/lists).
        """
        return make_overflow_fallback_formatter(
            base=partial(
                _format_vb_long,
                base=make_long_suffix_formatter(base=str),
            ),
            fallback=make_unsigned_overflow_fallback(
                format_positive=_format_vb_ulong_positive,
                language_name="VB.NET",
            ),
            min_value=I64_MIN,
            max_value=I64_MAX,
        )

    @cached_property
    @beartype
    def format_integer_beyond_i64(self) -> Callable[[int], str]:
        """Always-unsigned formatter for collections that exceed signed
        64-bit range.
        """
        return make_unsigned_overflow_fallback(
            format_positive=_format_vb_ulong_positive,
            language_name="VB.NET",
        )

    @cached_property
    @beartype
    def format_sequence_entry(self) -> Callable[[Value, str], str]:
        """Format a sequence entry."""
        return passthrough_sequence_entry

    @cached_property
    @beartype
    def format_set_entry(self) -> Callable[[Value, str], str]:
        """Format a set entry."""
        return passthrough_set_entry

    assignment_declares_binding = requires_declared_binding
    reference_assignment_declares_binding = assignment_declares_binding
    call_assignment_declares_binding = False

    @cached_property
    @beartype
    def format_variable_assignment(self) -> Callable[[str, str, Value], str]:
        """Format an assignment to an existing variable."""
        return variable_formatter(template="{name} = {value}")

    @cached_property
    @beartype
    def data_dependent_preamble(self) -> Callable[[Value], tuple[str, ...]]:
        """Return data-dependent preamble lines."""
        return no_data_preamble

    @cached_property
    @beartype
    def heterogeneous_behavior(self) -> HeterogeneousBehavior:
        """Return the heterogeneous-behavior config."""
        return self.heterogeneous_strategy.value

    call_data_dependent_preamble = default_call_data_dependent_preamble

    type_hint_collection_preamble_lines = (
        default_type_hint_collection_preamble_lines
    )

    @cached_property
    @beartype
    def format_call_class_scope_stub(
        self,
    ) -> Callable[
        [Sequence[str], Sequence[str], StubReturn, Sequence[Value]],
        tuple[str, ...],
    ]:
        """Return stub declarations for a call expression."""
        return partial(_vb_call_stub, indent=self.indent)

    @cached_property
    @beartype
    def call_style_config(self) -> CallStyle:
        """Configuration for the chosen call style."""
        config: CallStyle = self.call_style.value
        return config

    format_call_preamble_stub = default_format_call_stub

    @cached_property
    @beartype
    def format_call_target(self) -> Callable[[Sequence[str]], str]:
        """Format call targets with Visual Basic keyword escaping."""
        return _vb_format_call_target

    format_call_ref_identifier = default_format_call_ref_identifier

    format_call_arg_ref_identifier = default_format_call_arg_ref_identifier

    format_call_arg_ref_identifier_consumable = (
        default_format_call_arg_ref_identifier_consumable
    )

    consumable_ref_value_inhibits_consuming_form = (
        default_consumable_ref_value_inhibits_consuming_form
    )

    @cached_property
    @beartype
    def _element_to_type(
        self,
    ) -> Callable[[type[object] | ListType | DictType], str | None]:
        """Shared element-to-type mapping used by collection openers."""
        datetime_type = "String"
        if self.datetime_format.value.type_produced is int:
            datetime_type = "Long"
        date_type = "String"
        if self.date_format.value.type_produced is dt.date:
            date_type = "DateOnly"
        return make_element_to_type(
            dict_value_to_type=None,
            str_type="String",
            bool_type="Boolean",
            int_type="Integer",
            wide_int_type="Long",
            beyond_i64_type="ULong",
            float_type="Double",
            mixed_numeric_type="Double",
            bytes_type="String",
            date_type=date_type,
            datetime_type=datetime_type,
            time_type="TimeOnly",
            list_template="{inner}()",
            enable_list_type=True,
            dict_type_template=None,
            fallback_value_type=None,
        )

    @cached_property
    @beartype
    def sequence_format_config(self) -> SequenceFormatConfig:
        """Configuration for the chosen sequence format."""
        vb_type_to_opener = make_type_to_opener(
            element_to_type=self._element_to_type,
            opener_template="New {type_name}() {{",
        )
        return SequenceFormatConfig(
            length_is_part_of_type=False,
            sequence_open=typed_collection_open(
                type_to_opener=vb_type_to_opener,
                fallback="New Object() {",
            ),
            close="}",
            supports_heterogeneity=True,
            single_element_trailing_comma=False,
            single_element_template=None,
            supports_trailing_comma=True,
            empty_sequence=f"New {self.default_sequence_element_type}() {{}}",
            preamble_lines=("Imports System.Collections.Generic",),
            format_entry=passthrough_sequence_entry,
            typed_opener_fallback=None,
            uses_typed_literal_for_scalars=False,
            requires_uniform_record_shapes=False,
            declared_type=None,
            narrowed_empty_form=None,
        )

    @cached_property
    @beartype
    def set_format_config(self) -> SetFormatConfig:
        """Configuration for the chosen set format."""
        base = self.set_format(default_type=self.default_set_element_type)
        return base.with_typed_opener(
            type_to_opener=make_type_to_opener(
                element_to_type=self._element_to_type,
                opener_template="New HashSet(Of {type_name}) From {{",
            ),
            fallback=base.set_open([]),
        )

    @cached_property
    @beartype
    def sequence_open(self) -> Callable[[list[Value]], str]:
        """Callable that returns the opening delimiter for a sequence."""
        return self.sequence_format_config.sequence_open

    @cached_property
    @beartype
    def dict_format_config(self) -> DictFormatConfig:
        """Configuration for dict formatting."""
        return self.dict_format(
            default_type=self.default_dict_value_type,
            default_key_type=self.default_dict_key_type,
        )

    @cached_property
    @beartype
    def trailing_comma_config(self) -> TrailingCommaConfig:
        """Configuration for trailing-comma behavior."""
        return self.trailing_comma.value

    @cached_property
    @beartype
    def format_bytes(self) -> Callable[[bytes], str]:
        """Callable that formats a bytes value as a string literal."""
        return self.bytes_format

    @cached_property
    @beartype
    def format_date(self) -> Callable[[dt.date], str]:
        """Callable that formats a date as a string literal."""
        return self.date_format

    @cached_property
    @beartype
    def format_datetime(self) -> Callable[[dt.datetime], str]:
        """Callable that formats a datetime as a string literal."""
        return self.datetime_format

    @cached_property
    @beartype
    def format_time(self) -> Callable[[dt.time], str]:
        """Callable that formats a time as a string literal."""
        return format_time_vb

    @cached_property
    @beartype
    def format_float(self) -> Callable[[float], str]:
        """Callable that formats a float value as a literal."""
        return self.float_format

    @cached_property
    @beartype
    def comment_config(self) -> CommentConfig:
        """Configuration for the language's comment syntax."""
        return self.comment_format.value

    @cached_property
    @beartype
    def ordered_map_format_config(self) -> OrderedMapFormatConfig:
        """Configuration for ordered-map formatting."""
        return ordered_map_format_factory(
            open_template=("New Dictionary(Of {key_type}, {type}) From {{"),
            close="}",
            preamble_lines=(),
        )(
            self.default_dict_value_type,
            default_key_type=self.default_dict_key_type,
        )

    @cached_property
    @beartype
    def format_ordered_map_entry(self) -> Callable[[str, Value, str], str]:
        """Callable that formats one ordered-map entry."""
        return braced_dict_entry(format_value=passthrough_sequence_entry)

    @cached_property
    @beartype
    def format_variable_declaration(
        self,
    ) -> Callable[[str, str, Value, frozenset[enum.Enum]], str]:
        """Callable that formats a new variable declaration."""
        return self.declaration_style.value.formatter

    @cached_property
    @beartype
    def scalar_preamble(self) -> dict[type[object], tuple[str, ...]]:
        """Per-instance scalar preamble."""
        return {dt.time: ("Imports System",)}

    @cached_property
    @beartype
    def scalar_body_preamble(self) -> dict[type[object], tuple[str, ...]]:
        """Per-instance scalar body preamble (VisualBasic needs none)."""
        return {}

    @cached_property
    @beartype
    def compute_body_preamble(
        self,
    ) -> Callable[[frozenset[type[object]], Value], tuple[str, ...]]:
        """Compute body-preamble lines from the scalar map."""
        return body_preamble_from_scalars(
            scalar_body_preamble=self.scalar_body_preamble,
            format_lines=tuple,
        )
