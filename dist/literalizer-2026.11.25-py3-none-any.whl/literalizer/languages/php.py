"""PHP language specification."""

import dataclasses
import datetime as dt
import enum
import re
from collections.abc import Callable, Sequence
from functools import cached_property
from types import MappingProxyType
from typing import TYPE_CHECKING, ClassVar

from beartype import beartype

from literalizer._formatters.call_stubs import dotted_helper_type_names
from literalizer._formatters.collection_openers import (
    fixed_open,
)
from literalizer._formatters.format_dates import (
    format_date_iso,
    format_datetime_epoch,
    format_datetime_iso,
    format_time_iso,
    normalize_datetime_utc,
)
from literalizer._formatters.format_entries import (
    dict_entry_with_separator,
    format_bytes_base64,
    format_bytes_hex,
    passthrough_sequence_entry,
    passthrough_set_entry,
    variable_declaration_formatter,
    variable_formatter,
)
from literalizer._formatters.format_floats import (
    format_float_fixed,
    format_float_repr,
    format_float_scientific,
)
from literalizer._formatters.format_integers import (
    I64_MAX,
    I64_MIN,
    format_integer_binary,
    format_integer_hex,
    format_integer_octal,
    format_integer_octal_c_style,
    format_integer_underscore,
    make_overflow_fallback_formatter,
    raise_for_unrepresentable_int,
)
from literalizer._formatters.format_strings import (
    format_string_backslash_control,
    format_string_backslash_dollar_nul_hex,
    format_string_backslash_single_minimal,
)
from literalizer._language import (
    NO_CALL_PARAMETER_LIMIT,
    NO_HETEROGENEOUS_BEHAVIOR,
    NON_KEBAB_REF_CASES,
    BareIntegerWidthStrategies,
    CallParameterShadowing,
    CallStubResult,
    CallStyle,
    CommentConfig,
    DateFormatConfig,
    DateFormatEnum,
    DatetimeFormatConfig,
    DatetimeFormatEnum,
    DeclarationStyleConfig,
    DictFormatConfig,
    FileWrapperContext,
    FloatSpecialsMixin,
    FormatValueMixin,
    HeterogeneousBehavior,
    IdentifierCase,
    JsonType,
    KeywordCallStyle,
    LanguageCls,
    ModifierCombination,
    NewVariableNameSyntax,
    OrderedMapFormatConfig,
    PositionalCallStyle,
    RoundTripCapability,
    SequenceFormatConfig,
    SetFormatConfig,
    StubReturn,
    TrailingCommaConfig,
    VariantMetadata,
    body_preamble_from_scalars,
    declares_binding,
    default_call_data_dependent_preamble,
    default_consumable_ref_value_inhibits_consuming_form,
    default_format_call_arg_ref_identifier,
    default_format_call_arg_ref_identifier_consumable,
    default_format_call_statement,
    default_format_call_stub,
    default_sequence_binding_declarations,
    default_type_hint_collection_preamble_lines,
    default_validate_call_arg,
    default_wrap_calls_with_declarations,
    identity_call_arg,
    line_comment_call_variable_assignment,
    line_comment_call_variable_declaration,
    new_constructor_target,
    no_call_binding_body_preamble,
    no_call_binding_file_pragmas,
    no_data_preamble,
    no_format_integer_beyond_i64,
    no_format_integer_widened,
    no_leading_preamble,
    reject_empty_dicts,
    wrap_combined_in_file_noop_static,
    wrap_in_file_noop_static,
)
from literalizer._statements import CallLiteralSyntax
from literalizer._types import Scalar, Value
from literalizer.exceptions import UnrepresentableInputError


@beartype
def _format_date_php(value: dt.date) -> str:
    """Format a date at a deterministic UTC midnight."""
    return f'new DateTime("{value.isoformat()}", new DateTimeZone("UTC"))'


@beartype
def _format_datetime_php(value: dt.datetime) -> str:
    """Format a datetime without consulting PHP's default time zone.

    PHP parses whole-second offsets. Normalize fractional offsets to
    their UTC instant before passing the timestamp to its parser.
    """
    offset = value.utcoffset()
    if offset is not None and offset.microseconds != 0:
        value = normalize_datetime_utc(value=value, language_name="PHP")
    iso = value.isoformat()
    if value.utcoffset() is None:
        return f'new DateTime("{iso}", new DateTimeZone("UTC"))'
    return f'new DateTime("{iso}")'


_UNSAFE_MULTILINE_CONTROL = re.compile(pattern=r"[\x00-\x08\x0b-\x1f]")
_TRAILING_LINE_WHITESPACE = re.compile(pattern=r"[ \t]+(?=\n)")
_INTEGER_STRING_KEY = re.compile(pattern=r"(?:0|-[1-9][0-9]*|[1-9][0-9]*)\Z")


@beartype
def _reject_numeric_string_key(key: Scalar) -> None:
    """Reject one string key that PHP converts to an integer."""
    if (
        isinstance(key, str)
        and _INTEGER_STRING_KEY.fullmatch(string=key) is not None
    ):
        msg = (
            f"PHP arrays coerce numeric string mapping key {key!r} "
            "to an integer key"
        )
        raise UnrepresentableInputError(msg)


@beartype
def _reject_numeric_string_keys(data: Value) -> None:
    """Reject mapping keys that PHP arrays coerce from strings to integers."""
    stack = [data]
    while len(stack) > 0:
        value = stack.pop()
        match value:
            case dict():
                for key, child in value.items():
                    _reject_numeric_string_key(key=key)
                    stack.append(child)
            case list() | set():
                stack.extend(value)
            case _:
                pass


@beartype
def _php_dict_open(data: dict[Scalar, Value]) -> str:
    """Validate the actual mapping before emitting its PHP array opener.

    Call validation removes opaque references, which can leave an empty
    inference placeholder or hide a numeric key whose value is a reference.
    Only the mapping being constructed determines these restrictions.
    """
    if len(data) == 0:
        reject_empty_dicts(data=data, language_name="PHP")
    for key in data:
        _reject_numeric_string_key(key=key)
    return "["


@beartype
def _php_integer_formatter(
    *, base: Callable[[int], str]
) -> Callable[[int], str]:
    """Preserve PHP's signed minimum without a positive overflow
    operand.
    """
    checked = make_overflow_fallback_formatter(
        base=base,
        fallback=raise_for_unrepresentable_int(language_name="PHP"),
        min_value=I64_MIN,
        max_value=I64_MAX,
    )

    @beartype
    def _format(value: int) -> str:
        """Format one PHP integer."""
        if value == I64_MIN:
            return "PHP_INT_MIN"
        return checked(value)

    return _format


@beartype
def _format_string_multiline_fallback(value: str) -> str:
    r"""Format *value* as an interpolation-safe escaped PHP string."""
    escaped = format_string_backslash_control(
        value=value,
        control_char_fmt=r"\x{:02x}",
        escape_delete=False,
    )
    return escaped.replace("$", r"\$")


@beartype
def _format_string_multiline(value: str) -> str:
    r"""Format *value* as a non-interpolating multiline PHP string."""
    if (
        _UNSAFE_MULTILINE_CONTROL.search(string=value) is not None
        or _TRAILING_LINE_WHITESPACE.search(string=value) is not None
    ):
        return _format_string_multiline_fallback(value=value)
    return format_string_backslash_single_minimal(value=value)


@beartype
def _format_string_single(value: str) -> str:
    """Fall back when a single-quoted source literal is not exact."""
    if "\0" in value or "\r" in value:
        return format_string_backslash_dollar_nul_hex(value=value)
    return format_string_backslash_single_minimal(value=value)


@beartype
def _format_string_double(value: str) -> str:
    r"""Format *value* as an interpolation-safe double-quoted PHP string."""
    return format_string_backslash_dollar_nul_hex(value=value)


@beartype
def _php_format_call_target(parts: Sequence[str], /) -> str:
    """Rewrite a dotted call target into PHP's ``$obj->method`` form."""
    if len(parts) == 1:
        return parts[0]
    return "$" + parts[0] + "".join(f"->{p}" for p in parts[1:])


@beartype
def _php_format_call_ref_identifier(name: str, _value: Value | None, /) -> str:
    """Prepend PHP's ``$`` variable sigil to a call-ref identifier."""
    return f"${name}"


@beartype
def _php_call_stub(
    parts: Sequence[str],
    params: Sequence[str],
    _stub_return: StubReturn,
    _args: Sequence[Value],
    /,
) -> tuple[str, ...]:
    """Return PHP stub declarations for a call name."""
    param_list = ", ".join(f"${p}" for p in params)
    if parts[0].startswith("new "):
        name = parts[0].removeprefix("new ")
        return (f"class {name} {{ function __construct({param_list}) {{}} }}",)
    if len(parts) == 1:
        return (f"function {parts[0]}({param_list}) {{}}",)
    root = parts[0]
    method = parts[-1]
    fields = parts[1:-1]
    helper_types = dotted_helper_type_names(
        parts=parts[:-1],
        suffix="Type",
        ignore_underscores=False,
        capitalize_parts=True,
    )
    if len(fields) == 0:
        cls = helper_types[0]
        return (
            f"class {cls} {{ function {method}({param_list}) {{}} }}",
            f"${root} = new {cls}();",
        )
    lines: list[str] = []
    inner_cls = helper_types[-1]
    lines.append(
        f"class {inner_cls} {{ function {method}({param_list}) {{}} }}",
    )
    prev_cls = inner_cls
    for i in range(len(fields) - 2, -1, -1):
        cls = helper_types[i + 1]
        field = fields[i + 1]
        lines.append(
            f"class {cls} {{ public ${field}; "
            f"function __construct() {{ "
            f"$this->{field} = new {prev_cls}(); }} }}"
        )
        prev_cls = cls
    root_cls = helper_types[0]
    lines.append(
        f"class {root_cls} {{ public ${fields[0]}; "
        f"function __construct() {{ "
        f"$this->{fields[0]} = new {prev_cls}(); }} }}"
    )
    lines.append(f"${root} = new {root_cls}();")
    return tuple(lines)


# The functions PHP always defines: the ``Core`` and ``standard``
# extensions, neither of which can be disabled.  Declaring one of
# these names again is a fatal error, so a generated stub named after
# it does not load (issue #4495).
_PHP_ALWAYS_DEFINED_FUNCTIONS: frozenset[str] = frozenset(
    {
        "abs",
        "acos",
        "acosh",
        "addcslashes",
        "addslashes",
        "array_all",
        "array_any",
        "array_change_key_case",
        "array_chunk",
        "array_column",
        "array_combine",
        "array_count_values",
        "array_diff",
        "array_diff_assoc",
        "array_diff_key",
        "array_diff_uassoc",
        "array_diff_ukey",
        "array_fill",
        "array_fill_keys",
        "array_filter",
        "array_find",
        "array_find_key",
        "array_first",
        "array_flip",
        "array_intersect",
        "array_intersect_assoc",
        "array_intersect_key",
        "array_intersect_uassoc",
        "array_intersect_ukey",
        "array_is_list",
        "array_key_exists",
        "array_key_first",
        "array_key_last",
        "array_keys",
        "array_last",
        "array_map",
        "array_merge",
        "array_merge_recursive",
        "array_multisort",
        "array_pad",
        "array_pop",
        "array_product",
        "array_push",
        "array_rand",
        "array_reduce",
        "array_replace",
        "array_replace_recursive",
        "array_reverse",
        "array_search",
        "array_shift",
        "array_slice",
        "array_splice",
        "array_sum",
        "array_udiff",
        "array_udiff_assoc",
        "array_udiff_uassoc",
        "array_uintersect",
        "array_uintersect_assoc",
        "array_uintersect_uassoc",
        "array_unique",
        "array_unshift",
        "array_values",
        "array_walk",
        "array_walk_recursive",
        "arsort",
        "asin",
        "asinh",
        "asort",
        "assert",
        "assert_options",
        "atan",
        "atan2",
        "atanh",
        "base64_decode",
        "base64_encode",
        "base_convert",
        "basename",
        "bin2hex",
        "bindec",
        "boolval",
        "call_user_func",
        "call_user_func_array",
        "ceil",
        "chdir",
        "checkdnsrr",
        "chgrp",
        "chmod",
        "chop",
        "chown",
        "chr",
        "chunk_split",
        "class_alias",
        "class_exists",
        "clearstatcache",
        "cli_get_process_title",
        "cli_set_process_title",
        "clone",
        "closedir",
        "closelog",
        "compact",
        "connection_aborted",
        "connection_status",
        "constant",
        "convert_uudecode",
        "convert_uuencode",
        "copy",
        "cos",
        "cosh",
        "count",
        "count_chars",
        "crc32",
        "crypt",
        "current",
        "debug_backtrace",
        "debug_print_backtrace",
        "debug_zval_dump",
        "decbin",
        "dechex",
        "decoct",
        "define",
        "defined",
        "deg2rad",
        "die",
        "dir",
        "dirname",
        "disk_free_space",
        "disk_total_space",
        "diskfreespace",
        "dl",
        "dns_check_record",
        "dns_get_mx",
        "dns_get_record",
        "doubleval",
        "end",
        "enum_exists",
        "error_clear_last",
        "error_get_last",
        "error_log",
        "error_reporting",
        "escapeshellarg",
        "escapeshellcmd",
        "exec",
        "exit",
        "exp",
        "explode",
        "expm1",
        "extension_loaded",
        "extract",
        "fclose",
        "fdatasync",
        "fdiv",
        "feof",
        "fflush",
        "fgetc",
        "fgetcsv",
        "fgets",
        "file",
        "file_exists",
        "file_get_contents",
        "file_put_contents",
        "fileatime",
        "filectime",
        "filegroup",
        "fileinode",
        "filemtime",
        "fileowner",
        "fileperms",
        "filesize",
        "filetype",
        "floatval",
        "flock",
        "floor",
        "flush",
        "fmod",
        "fnmatch",
        "fopen",
        "forward_static_call",
        "forward_static_call_array",
        "fpassthru",
        "fpow",
        "fprintf",
        "fputcsv",
        "fputs",
        "fread",
        "fscanf",
        "fseek",
        "fsockopen",
        "fstat",
        "fsync",
        "ftell",
        "ftok",
        "ftruncate",
        "func_get_arg",
        "func_get_args",
        "func_num_args",
        "function_exists",
        "fwrite",
        "gc_collect_cycles",
        "gc_disable",
        "gc_enable",
        "gc_enabled",
        "gc_mem_caches",
        "gc_status",
        "get_browser",
        "get_called_class",
        "get_cfg_var",
        "get_class",
        "get_class_methods",
        "get_class_vars",
        "get_current_user",
        "get_debug_type",
        "get_declared_classes",
        "get_declared_interfaces",
        "get_declared_traits",
        "get_defined_constants",
        "get_defined_functions",
        "get_defined_vars",
        "get_error_handler",
        "get_exception_handler",
        "get_extension_funcs",
        "get_headers",
        "get_html_translation_table",
        "get_include_path",
        "get_included_files",
        "get_loaded_extensions",
        "get_mangled_object_vars",
        "get_meta_tags",
        "get_object_vars",
        "get_parent_class",
        "get_required_files",
        "get_resource_id",
        "get_resource_type",
        "get_resources",
        "getcwd",
        "getenv",
        "gethostbyaddr",
        "gethostbyname",
        "gethostbynamel",
        "gethostname",
        "getimagesize",
        "getimagesizefromstring",
        "getlastmod",
        "getmxrr",
        "getmygid",
        "getmyinode",
        "getmypid",
        "getmyuid",
        "getopt",
        "getprotobyname",
        "getprotobynumber",
        "getrusage",
        "getservbyname",
        "getservbyport",
        "gettimeofday",
        "gettype",
        "glob",
        "header",
        "header_register_callback",
        "header_remove",
        "headers_list",
        "headers_sent",
        "hebrev",
        "hex2bin",
        "hexdec",
        "highlight_file",
        "highlight_string",
        "hrtime",
        "html_entity_decode",
        "htmlentities",
        "htmlspecialchars",
        "htmlspecialchars_decode",
        "http_build_query",
        "http_clear_last_response_headers",
        "http_get_last_response_headers",
        "http_response_code",
        "hypot",
        "ignore_user_abort",
        "image_type_to_extension",
        "image_type_to_mime_type",
        "implode",
        "in_array",
        "inet_ntop",
        "inet_pton",
        "ini_alter",
        "ini_get",
        "ini_get_all",
        "ini_parse_quantity",
        "ini_restore",
        "ini_set",
        "intdiv",
        "interface_exists",
        "intval",
        "ip2long",
        "iptcembed",
        "iptcparse",
        "is_a",
        "is_array",
        "is_bool",
        "is_callable",
        "is_countable",
        "is_dir",
        "is_double",
        "is_executable",
        "is_file",
        "is_finite",
        "is_float",
        "is_infinite",
        "is_int",
        "is_integer",
        "is_iterable",
        "is_link",
        "is_long",
        "is_nan",
        "is_null",
        "is_numeric",
        "is_object",
        "is_readable",
        "is_resource",
        "is_scalar",
        "is_string",
        "is_subclass_of",
        "is_uploaded_file",
        "is_writable",
        "is_writeable",
        "join",
        "key",
        "key_exists",
        "krsort",
        "ksort",
        "lcfirst",
        "lchgrp",
        "lchown",
        "levenshtein",
        "link",
        "linkinfo",
        "localeconv",
        "log",
        "log10",
        "log1p",
        "long2ip",
        "lstat",
        "ltrim",
        "mail",
        "max",
        "md5",
        "md5_file",
        "memory_get_peak_usage",
        "memory_get_usage",
        "memory_reset_peak_usage",
        "metaphone",
        "method_exists",
        "microtime",
        "min",
        "mkdir",
        "move_uploaded_file",
        "natcasesort",
        "natsort",
        "net_get_interfaces",
        "next",
        "nl2br",
        "nl_langinfo",
        "number_format",
        "ob_clean",
        "ob_end_clean",
        "ob_end_flush",
        "ob_flush",
        "ob_get_clean",
        "ob_get_contents",
        "ob_get_flush",
        "ob_get_length",
        "ob_get_level",
        "ob_get_status",
        "ob_implicit_flush",
        "ob_list_handlers",
        "ob_start",
        "octdec",
        "opendir",
        "openlog",
        "ord",
        "output_add_rewrite_var",
        "output_reset_rewrite_vars",
        "pack",
        "parse_ini_file",
        "parse_ini_string",
        "parse_str",
        "parse_url",
        "passthru",
        "password_algos",
        "password_get_info",
        "password_hash",
        "password_needs_rehash",
        "password_verify",
        "pathinfo",
        "pclose",
        "pfsockopen",
        "php_ini_loaded_file",
        "php_ini_scanned_files",
        "php_sapi_name",
        "php_strip_whitespace",
        "php_uname",
        "phpcredits",
        "phpinfo",
        "phpversion",
        "pi",
        "popen",
        "pos",
        "pow",
        "prev",
        "print_r",
        "printf",
        "proc_close",
        "proc_get_status",
        "proc_nice",
        "proc_open",
        "proc_terminate",
        "property_exists",
        "putenv",
        "quoted_printable_decode",
        "quoted_printable_encode",
        "quotemeta",
        "rad2deg",
        "range",
        "rawurldecode",
        "rawurlencode",
        "readdir",
        "readfile",
        "readlink",
        "realpath",
        "realpath_cache_get",
        "realpath_cache_size",
        "register_shutdown_function",
        "register_tick_function",
        "rename",
        "request_parse_body",
        "reset",
        "restore_error_handler",
        "restore_exception_handler",
        "rewind",
        "rewinddir",
        "rmdir",
        "round",
        "rsort",
        "rtrim",
        "scandir",
        "serialize",
        "set_error_handler",
        "set_exception_handler",
        "set_file_buffer",
        "set_include_path",
        "set_time_limit",
        "setcookie",
        "setlocale",
        "setrawcookie",
        "settype",
        "sha1",
        "sha1_file",
        "shell_exec",
        "show_source",
        "shuffle",
        "similar_text",
        "sin",
        "sinh",
        "sizeof",
        "sleep",
        "socket_get_status",
        "socket_set_blocking",
        "socket_set_timeout",
        "sort",
        "soundex",
        "sprintf",
        "sqrt",
        "sscanf",
        "stat",
        "str_contains",
        "str_decrement",
        "str_ends_with",
        "str_getcsv",
        "str_increment",
        "str_ireplace",
        "str_pad",
        "str_repeat",
        "str_replace",
        "str_rot13",
        "str_shuffle",
        "str_split",
        "str_starts_with",
        "str_word_count",
        "strcasecmp",
        "strchr",
        "strcmp",
        "strcoll",
        "strcspn",
        "stream_bucket_append",
        "stream_bucket_make_writeable",
        "stream_bucket_new",
        "stream_bucket_prepend",
        "stream_context_create",
        "stream_context_get_default",
        "stream_context_get_options",
        "stream_context_get_params",
        "stream_context_set_default",
        "stream_context_set_option",
        "stream_context_set_options",
        "stream_context_set_params",
        "stream_copy_to_stream",
        "stream_filter_append",
        "stream_filter_prepend",
        "stream_filter_register",
        "stream_filter_remove",
        "stream_get_contents",
        "stream_get_filters",
        "stream_get_line",
        "stream_get_meta_data",
        "stream_get_transports",
        "stream_get_wrappers",
        "stream_is_local",
        "stream_isatty",
        "stream_register_wrapper",
        "stream_resolve_include_path",
        "stream_select",
        "stream_set_blocking",
        "stream_set_chunk_size",
        "stream_set_read_buffer",
        "stream_set_timeout",
        "stream_set_write_buffer",
        "stream_socket_accept",
        "stream_socket_client",
        "stream_socket_enable_crypto",
        "stream_socket_get_name",
        "stream_socket_pair",
        "stream_socket_recvfrom",
        "stream_socket_sendto",
        "stream_socket_server",
        "stream_socket_shutdown",
        "stream_supports_lock",
        "stream_wrapper_register",
        "stream_wrapper_restore",
        "stream_wrapper_unregister",
        "strip_tags",
        "stripcslashes",
        "stripos",
        "stripslashes",
        "stristr",
        "strlen",
        "strnatcasecmp",
        "strnatcmp",
        "strncasecmp",
        "strncmp",
        "strpbrk",
        "strpos",
        "strptime",
        "strrchr",
        "strrev",
        "strripos",
        "strrpos",
        "strspn",
        "strstr",
        "strtok",
        "strtolower",
        "strtoupper",
        "strtr",
        "strval",
        "substr",
        "substr_compare",
        "substr_count",
        "substr_replace",
        "symlink",
        "sys_get_temp_dir",
        "sys_getloadavg",
        "syslog",
        "system",
        "tan",
        "tanh",
        "tempnam",
        "time_nanosleep",
        "time_sleep_until",
        "tmpfile",
        "touch",
        "trait_exists",
        "trigger_error",
        "trim",
        "uasort",
        "ucfirst",
        "ucwords",
        "uksort",
        "umask",
        "uniqid",
        "unlink",
        "unpack",
        "unregister_tick_function",
        "unserialize",
        "urldecode",
        "urlencode",
        "user_error",
        "usleep",
        "usort",
        "utf8_decode",
        "utf8_encode",
        "var_dump",
        "var_export",
        "version_compare",
        "vfprintf",
        "vprintf",
        "vsprintf",
        "wordwrap",
        "zend_version",
    }
)


# Work around https://github.com/astral-sh/ty/issues/4573.
if TYPE_CHECKING:
    _BytesEnumMember = enum.member[Callable[[bytes], str]]
    _StringEnumMember = enum.member[Callable[[str], str]]
else:
    _BytesEnumMember = enum.member
    _StringEnumMember = enum.member


_CALL_LITERAL_SYNTAX = CallLiteralSyntax(
    prefix="//",
    regex_literals=False,
    raw_string_prefixes=(),
    verbatim_strings=False,
    interpolation_syntax=None,
    quotes="\"'",
    literal_span_end=None,
    backtick_strings=False,
)


@beartype
@dataclasses.dataclass(frozen=True, kw_only=True)
class Php(metaclass=LanguageCls):
    """PHP language specification."""

    format_call_class_scope_stub = default_format_call_stub

    reserved_module_identifiers: ClassVar[frozenset[str]] = frozenset()
    immutable_variable_modifiers: ClassVar[frozenset[enum.Enum]] = frozenset()
    wrap_in_file_tolerates_pre_indent = True
    module_name_shares_variable_scope = False
    reserved_variable_identifier_pattern: ClassVar[re.Pattern[str] | None] = (
        None
    )
    reserved_call_parameter_identifiers: ClassVar[frozenset[str]] = frozenset()
    reserved_call_parameter_identifier_pattern: ClassVar[
        re.Pattern[str] | None
    ] = None
    uses_data_keyword_for_algebraic_constructors = False
    accepts_type_name_call_target = True
    declares_type_name_call_target = True
    dotted_call_root_shares_entrypoint_namespace = True
    reserved_call_target_head_identifiers: ClassVar[frozenset[str]] = (
        frozenset()
    )
    call_parameter_shadowing = CallParameterShadowing.ALLOWED
    module_name_must_start_uppercase = False
    new_variable_name_syntax = NewVariableNameSyntax.ASCII
    max_variable_identifier_length: ClassVar[int | None] = None
    call_stub_result: ClassVar[CallStubResult | None] = None
    call_literal_syntax: ClassVar[CallLiteralSyntax | None] = (
        _CALL_LITERAL_SYNTAX
    )
    call_target_name_syntax: ClassVar[NewVariableNameSyntax | None] = None
    supports_multiline_dict_layout = True
    pools_map_integer_width = True

    format_integer_widened = no_format_integer_widened
    format_integer_beyond_i64 = no_format_integer_beyond_i64
    format_constructor_target: ClassVar["staticmethod[[str], str]"] = (
        staticmethod(new_constructor_target)
    )
    format_call_variable_declaration: ClassVar[property] = (
        line_comment_call_variable_declaration(syntax=_CALL_LITERAL_SYNTAX)
    )
    format_call_variable_assignment: ClassVar[property] = (
        line_comment_call_variable_assignment(syntax=_CALL_LITERAL_SYNTAX)
    )
    sequence_binding_declarations = default_sequence_binding_declarations
    format_call_binding_body_preamble = no_call_binding_body_preamble
    format_call_binding_file_pragmas = no_call_binding_file_pragmas

    leading_preamble = no_leading_preamble
    extension = ".php"
    pygments_name = "php"
    stringifies_nested_collections = False
    supports_special_floats = True
    supports_variable_names = True
    supports_no_variable_wrap_in_file = False
    wraps_data_dependent_preamble_in_body = False
    dict_supports_heterogeneous_values = True
    supports_local_binding_documents = False
    supports_stateful_free_call_consumers = True
    supports_stateful_receiver_result_checks = True
    supports_native_invocations = False
    supports_dotted_calls = True
    has_free_function_calls = True
    reserved_identifiers: ClassVar[frozenset[str]] = frozenset()
    declares_call_parameter_names = True
    reserved_variable_identifiers_case_sensitive: bool = True
    reserved_call_target_keywords_case_sensitive = False
    contextual_call_target_identifiers: ClassVar[frozenset[str]] = frozenset(
        {"self"}
    )
    reserved_variable_identifiers: frozenset[str] = frozenset(
        {
            "__halt_compiler",
            "abstract",
            "and",
            "array",
            "as",
            "break",
            "callable",
            "case",
            "catch",
            "class",
            "clone",
            "const",
            "continue",
            "declare",
            "default",
            "die",
            "do",
            "echo",
            "else",
            "elseif",
            "empty",
            "enddeclare",
            "endfor",
            "endforeach",
            "endif",
            "endswitch",
            "endwhile",
            "eval",
            "exit",
            "extends",
            "final",
            "finally",
            "fn",
            "for",
            "foreach",
            "function",
            "global",
            "goto",
            "if",
            "implements",
            "include",
            "include_once",
            "instanceof",
            "insteadof",
            "interface",
            "isset",
            "list",
            "match",
            "namespace",
            "new",
            "or",
            "parent",
            "print",
            "private",
            "protected",
            "public",
            "readonly",
            "require",
            "require_once",
            "return",
            "self",
            "static",
            "switch",
            "this",
            "throw",
            "trait",
            "try",
            "unset",
            "use",
            "var",
            "while",
            "xor",
            "yield",
        }
    )
    reserved_bare_call_target_identifiers: ClassVar[frozenset[str]] = (
        _PHP_ALWAYS_DEFINED_FUNCTIONS
    )
    allows_empty_call_parens = True
    supports_dotted_call_stub = False
    dotted_call_stub_indexes_colliding_helpers = True
    call_returns_expression = True
    supports_json_call_result_binding = False
    supports_zero_parameter_calls = True
    max_call_parameters = NO_CALL_PARAMETER_LIMIT
    supports_inline_multiline_dict_args = True
    supports_standalone_comments_in_wrapped_calls = True
    supports_multi_param_call_wrapper_stub = True
    supports_variadic_calls = False
    supports_dict_literal_as_free_expression = True
    supports_module_name = False
    supports_empty_dict_key = False
    supports_call_style = True
    supports_bare_mapping_documents = False
    supports_json_object_documents = False
    supports_default_dict_key_type = False
    supports_default_dict_value_type = False
    supports_nullable_object_fallbacks = False
    supports_default_sequence_element_type = False
    supports_key_value_assignment_documents = False
    supports_default_set_element_type = False
    supports_default_ordered_map_value_type = False
    json_type_variant_name_suffix: ClassVar[str | None] = None
    supports_non_ascii_string_literals = True
    supports_multiline_string_literals = False
    supports_empty_sibling_sequence_type_hints = True
    supports_typed_dict_open = False
    language_id: ClassVar[str] = "php"
    variant_metadata: ClassVar[VariantMetadata] = VariantMetadata(
        round_trip_capabilities=frozenset(
            {
                RoundTripCapability.I64_BOUNDARIES,
                RoundTripCapability.INTERPOLATION_STRINGS,
                RoundTripCapability.EMBEDDED_NUL,
            }
        ),
        modifier_sequence_format_overrides={},
        string_literals_escape_null_byte=True,
        supports_ref_elements_in_tuple_strategy=False,
    )
    supports_record_struct_name_prefix = False
    supports_record_shape_names = False
    record_shape_names_emit_declarations = False
    supports_non_string_dict_keys = False
    checks_raw_control_dict_keys_separately = False

    format_call_arg: ClassVar["staticmethod[[Value, str], str]"] = (
        staticmethod(
            identity_call_arg,
        )
    )
    """Callable that rewrites a formatted direct call argument."""

    class DateFormats(DateFormatEnum):
        """Date format options for Php."""

        PHP = DateFormatConfig(
            formatter=_format_date_php,
            preamble_lines=(),
            type_produced=dt.date,
        )
        ISO = DateFormatConfig(
            formatter=format_date_iso, type_produced=str, preamble_lines=()
        )

    class DatetimeFormats(DatetimeFormatEnum):
        """Datetime format options for Php."""

        PHP = DatetimeFormatConfig(
            formatter=_format_datetime_php,
            preamble_lines=(),
            type_produced=dt.datetime,
        )
        ISO = DatetimeFormatConfig(
            formatter=format_datetime_iso,
            type_produced=str,
            preamble_lines=(),
        )

        EPOCH = DatetimeFormatConfig(
            formatter=format_datetime_epoch,
            type_produced=int,
            preamble_lines=(),
        )

    class BytesFormats(FormatValueMixin[Callable[[bytes], str]], enum.Enum):
        """Bytes formatting options."""

        HEX = _BytesEnumMember(value=format_bytes_hex)
        BASE64 = _BytesEnumMember(value=format_bytes_base64)

        def __call__(self, data: bytes, /) -> str:
            """Format bytes."""
            return self.value(data)

    class SequenceFormats(enum.Enum):
        """Sequence type options for PHP."""

        ARRAY = SequenceFormatConfig(
            length_is_part_of_type=False,
            sequence_open=fixed_open(open_str="["),
            close="]",
            supports_heterogeneity=True,
            single_element_trailing_comma=False,
            single_element_template=None,
            supports_trailing_comma=True,
            empty_sequence=None,
            preamble_lines=(),
            format_entry=passthrough_sequence_entry,
            typed_opener_fallback=None,
            uses_typed_literal_for_scalars=False,
            requires_uniform_record_shapes=False,
            declared_type=None,
            narrowed_empty_form=None,
        )

    class SetFormats(enum.Enum):
        """Set type options for PHP."""

        SET = SetFormatConfig(
            set_open=fixed_open(open_str="["),
            close="]",
            empty_set=None,
            preamble_lines=(),
            set_opener_template="",
            supports_heterogeneity=True,
            supports_trailing_comma=True,
        )

    class CommentFormats(enum.Enum):
        """Comment style options."""

        DOUBLE_SLASH = CommentConfig(
            prefix="//",
            suffix="",
        )
        BLOCK = CommentConfig(
            prefix="/*",
            suffix=" */",
        )

    class DeclarationStyles(enum.Enum):
        """Declaration style options."""

        ASSIGN = DeclarationStyleConfig(
            formatter=variable_declaration_formatter(
                template="${name} = {value};"
            ),
            supports_redefinition=True,
        )

    class DictEntryStyles(enum.Enum):
        """Dict entry style options."""

        DEFAULT = enum.auto()

    class DictFormats(enum.Enum):
        """Dict/map format options."""

        DEFAULT = enum.auto()

    class EmptyDictKey(enum.Enum):
        """Empty dict key options."""

        ALLOW = enum.auto()

    class FloatFormats(
        FloatSpecialsMixin,
        enum.Enum,
        positive_infinity="INF",
        negative_infinity="-INF",
        nan="NAN",
    ):
        """Float format options."""

        REPR = enum.member(value=format_float_repr)
        SCIENTIFIC = enum.member(value=format_float_scientific)
        FIXED = enum.member(value=format_float_fixed)

    class IntegerFormats(enum.Enum):
        """Integer format options."""

        DECIMAL = MappingProxyType(
            mapping={
                "NONE": str,
                "UNDERSCORE": format_integer_underscore,
            }
        )
        HEX = MappingProxyType(
            mapping={
                "NONE": format_integer_hex,
                "UNDERSCORE": format_integer_hex,
            }
        )
        OCTAL = MappingProxyType(
            mapping={
                "NONE": format_integer_octal,
                "UNDERSCORE": format_integer_octal,
            }
        )
        OCTAL_C_STYLE = MappingProxyType(
            mapping={
                "NONE": format_integer_octal_c_style,
                "UNDERSCORE": format_integer_octal_c_style,
            }
        )
        BINARY = MappingProxyType(
            mapping={
                "NONE": format_integer_binary,
                "UNDERSCORE": format_integer_binary,
            }
        )

        def get_formatter(
            self,
            numeric_separator: enum.Enum,
        ) -> Callable[[int], str]:
            """Return the integer formatter for the given separator."""
            formatter: Callable[[int], str] = self.value[
                numeric_separator.name
            ]
            return formatter

    class NumericLiteralSuffixes(enum.Enum):
        """Numeric literal suffix options."""

        NONE = enum.auto()

    class NumericSeparators(enum.Enum):
        """Numeric separator options."""

        NONE = enum.auto()
        UNDERSCORE = enum.auto()

    class NumericStyles(enum.Enum):
        """Numeric literal style options."""

        OVERLOADED = enum.auto()

    class StringFormats(FormatValueMixin[Callable[[str], str]], enum.Enum):
        """String format options."""

        DOUBLE = _StringEnumMember(value=_format_string_double)
        SINGLE = _StringEnumMember(value=_format_string_single)
        MULTILINE = _StringEnumMember(value=_format_string_multiline)

        def __call__(self, value: str, /) -> str:
            """Format a string."""
            return self.value(value)

    class TrailingCommas(enum.Enum):
        """Trailing comma options."""

        YES = TrailingCommaConfig(multiline_trailing_comma=True)
        NO = TrailingCommaConfig(multiline_trailing_comma=False)

    date_formats = DateFormats
    datetime_formats = DatetimeFormats
    bytes_formats = BytesFormats
    sequence_formats = SequenceFormats
    set_formats = SetFormats
    comment_formats = CommentFormats

    class VariableTypeHints(enum.Enum):
        """Variable type hint options."""

        NEVER = enum.auto()
        SAFE = enum.auto()

    variable_type_hints_formats = VariableTypeHints
    declaration_styles = DeclarationStyles
    dict_entry_styles = DictEntryStyles
    dict_formats = DictFormats
    empty_dict_keys = EmptyDictKey
    float_formats = FloatFormats
    integer_formats = IntegerFormats
    integer_width_strategies = BareIntegerWidthStrategies
    numeric_literal_suffixes = NumericLiteralSuffixes
    numeric_separators = NumericSeparators
    numeric_styles = NumericStyles
    string_formats = StringFormats
    trailing_commas = TrailingCommas

    class StatementTerminatorStyles(enum.Enum):
        """Statement terminator options."""

        SEMICOLON = enum.auto()

    statement_terminator_styles = StatementTerminatorStyles

    class CallStyles(enum.Enum):
        """Php call style options."""

        KEYWORD = KeywordCallStyle(separator=": ")
        POSITIONAL = PositionalCallStyle(
            arg_separator=", ", parenthesize_each_arg=False
        )

    call_styles = CallStyles

    class Modifiers(enum.Enum):
        """C++/Java/C#-style declaration modifiers: this language has none."""

    modifiers = Modifiers

    class HeterogeneousStrategies(enum.Enum):
        """Heterogeneous-scalar strategy options — this language only
        supports raising.
        """

        ERROR = NO_HETEROGENEOUS_BEHAVIOR

    heterogeneous_strategies = HeterogeneousStrategies

    class JsonTypes(JsonType):
        """Empty: this language has no JSON value-type variants."""

    json_types = JsonTypes

    class BoolFormats(enum.Enum):
        """Empty: this language has no alternative boolean formats."""

    bool_formats = BoolFormats

    class VersionFormats(enum.Enum):
        """Version options for PHP."""

        V8_1 = enum.auto()

    version_formats = VersionFormats

    modifier_combinations: ClassVar[tuple[ModifierCombination, ...]] = ()
    identifier_cases: ClassVar[tuple[IdentifierCase, ...]] = (
        IdentifierCase.SNAKE,
        IdentifierCase.CAMEL,
        IdentifierCase.PASCAL,
        IdentifierCase.UPPER_SNAKE,
    )
    supported_ref_cases: ClassVar[frozenset[IdentifierCase]] = (
        NON_KEBAB_REF_CASES
    )

    @staticmethod
    def validate_spec_for_data(data: Value) -> None:
        """Reject mapping shapes that PHP arrays cannot preserve."""
        reject_empty_dicts(data=data, language_name="PHP")
        _reject_numeric_string_keys(data=data)

    validate_call_arg = default_validate_call_arg

    format_call_statement = default_format_call_statement

    wrap_calls_with_declarations = default_wrap_calls_with_declarations

    wrap_in_file: ClassVar["staticmethod[[str, FileWrapperContext], str]"] = (
        wrap_in_file_noop_static
    )

    wrap_combined_in_file: ClassVar[
        "staticmethod[[str, str, FileWrapperContext], str]"
    ] = wrap_combined_in_file_noop_static

    date_format: DateFormats = DateFormats.PHP
    datetime_format: DatetimeFormats = DatetimeFormats.PHP
    bytes_format: BytesFormats = BytesFormats.HEX
    sequence_format: SequenceFormats = SequenceFormats.ARRAY
    set_format: SetFormats = SetFormats.SET
    variable_type_hints: VariableTypeHints = VariableTypeHints.NEVER
    comment_format: CommentFormats = CommentFormats.DOUBLE_SLASH
    declaration_style: DeclarationStyles = DeclarationStyles.ASSIGN
    dict_entry_style: DictEntryStyles = DictEntryStyles.DEFAULT
    dict_format: DictFormats = DictFormats.DEFAULT
    float_format: FloatFormats = FloatFormats.REPR
    integer_format: IntegerFormats = IntegerFormats.DECIMAL
    integer_width_strategy: BareIntegerWidthStrategies = (
        BareIntegerWidthStrategies.BARE
    )
    numeric_literal_suffix: NumericLiteralSuffixes = (
        NumericLiteralSuffixes.NONE
    )
    numeric_separator: NumericSeparators = NumericSeparators.NONE
    numeric_style: NumericStyles = NumericStyles.OVERLOADED
    string_format: StringFormats = StringFormats.DOUBLE
    trailing_comma: TrailingCommas = TrailingCommas.YES
    statement_terminator_style: StatementTerminatorStyles = (
        StatementTerminatorStyles.SEMICOLON
    )
    call_style: CallStyles = CallStyles.KEYWORD
    heterogeneous_strategy: HeterogeneousStrategies = (
        HeterogeneousStrategies.ERROR
    )
    # Keep in sync with the ``php-version`` pin passed to
    # ``shivammathur/setup-php`` in the ``Set up PHP`` step of
    # ``.github/workflows/lint.yml``. PHP has no ``--langversion``-style
    # flag, so the pinned interpreter is the only mechanism for pinning
    # the language version; ``V8_1`` maps to ``8.1``.
    language_version: VersionFormats = VersionFormats.V8_1
    indent: str = "    "

    null_literal: ClassVar[str] = "null"
    true_literal: ClassVar[str] = "true"
    false_literal: ClassVar[str] = "false"
    indent_closing_delimiter: ClassVar[bool] = False
    element_separator: ClassVar[str] = ", "
    skip_null_dict_values: ClassVar[bool] = False
    supports_collection_comments: ClassVar[bool] = True
    supports_scalar_before_comments: ClassVar[bool] = True
    supports_scalar_inline_comments: ClassVar[bool] = False
    statement_terminator: ClassVar[str] = ";"
    static_preamble: ClassVar[Sequence[str]] = ("<?php",)
    static_body_preamble: ClassVar[Sequence[str]] = ()
    special_float_preamble: ClassVar[tuple[str, ...]] = ()

    @cached_property
    @beartype
    def format_sequence_entry(self) -> Callable[[Value, str], str]:
        """Format a sequence entry."""
        return passthrough_sequence_entry

    @cached_property
    @beartype
    def format_set_entry(self) -> Callable[[Value, str], str]:
        """Format a set entry."""
        return passthrough_set_entry

    assignment_declares_binding = declares_binding
    reference_assignment_declares_binding = assignment_declares_binding
    call_assignment_declares_binding = True

    @cached_property
    @beartype
    def format_variable_assignment(self) -> Callable[[str, str, Value], str]:
        """Format an assignment to an existing variable."""
        return variable_formatter(template="${name} = {value};")

    @cached_property
    @beartype
    def data_dependent_preamble(self) -> Callable[[Value], tuple[str, ...]]:
        """Return data-dependent preamble lines."""
        return no_data_preamble

    @cached_property
    @beartype
    def heterogeneous_behavior(self) -> HeterogeneousBehavior:
        """Return the heterogeneous-behavior config."""
        return self.heterogeneous_strategy.value

    call_data_dependent_preamble = default_call_data_dependent_preamble

    type_hint_collection_preamble_lines = (
        default_type_hint_collection_preamble_lines
    )

    @cached_property
    @beartype
    def format_call_stub(
        self,
    ) -> Callable[
        [Sequence[str], Sequence[str], StubReturn, Sequence[Value]],
        tuple[str, ...],
    ]:
        """Return stub declarations for a call expression."""
        return _php_call_stub

    @cached_property
    @beartype
    def format_call_target(self) -> Callable[[Sequence[str]], str]:
        """Rewrite a dotted call target into PHP's ``$obj->method``
        form.
        """
        return _php_format_call_target

    @cached_property
    @beartype
    def format_call_ref_identifier(
        self,
    ) -> Callable[[str, Value | None], str]:
        """Prepend PHP's ``$`` sigil so a ``{"$ref": "name"}`` argument
        renders as ``$name`` at the call site.
        """
        return _php_format_call_ref_identifier

    format_call_arg_ref_identifier = default_format_call_arg_ref_identifier

    format_call_arg_ref_identifier_consumable = (
        default_format_call_arg_ref_identifier_consumable
    )

    consumable_ref_value_inhibits_consuming_form = (
        default_consumable_ref_value_inhibits_consuming_form
    )

    format_call_preamble_stub = default_format_call_stub

    @cached_property
    @beartype
    def sequence_format_config(self) -> SequenceFormatConfig:
        """Configuration for the chosen sequence format."""
        return self.sequence_format.value

    @cached_property
    @beartype
    def set_format_config(self) -> SetFormatConfig:
        """Configuration for the chosen set format."""
        return self.set_format.value

    @cached_property
    @beartype
    def sequence_open(self) -> Callable[[list[Value]], str]:
        """Callable that returns the opening delimiter for a sequence."""
        return self.sequence_format.value.sequence_open

    @cached_property
    @beartype
    def _dict_entry(self) -> Callable[[str, Value, str], str]:
        """Shared dict-entry formatter used by dict and ordered-map."""
        return dict_entry_with_separator(
            separator=" => ",
            format_value=passthrough_sequence_entry,
        )

    @cached_property
    @beartype
    def dict_format_config(self) -> DictFormatConfig:
        """Configuration for dict formatting."""
        return DictFormatConfig(
            dict_open=_php_dict_open,
            close="]",
            format_entry=self._dict_entry,
            empty_dict=None,
            preamble_lines=(),
            narrowed_open=None,
            supports_trailing_comma=True,
            narrowed_empty_form=None,
        )

    @cached_property
    @beartype
    def trailing_comma_config(self) -> TrailingCommaConfig:
        """Configuration for trailing-comma behavior."""
        return self.trailing_comma.value

    @cached_property
    @beartype
    def format_bytes(self) -> Callable[[bytes], str]:
        """Callable that formats a bytes value as a string literal."""
        return self.bytes_format

    @cached_property
    @beartype
    def format_date(self) -> Callable[[dt.date], str]:
        """Callable that formats a date as a string literal."""
        return self.date_format

    @cached_property
    @beartype
    def format_datetime(self) -> Callable[[dt.datetime], str]:
        """Callable that formats a datetime as a string literal."""
        return self.datetime_format

    @cached_property
    @beartype
    def format_time(self) -> Callable[[dt.time], str]:
        """Callable that formats a time as a string literal."""
        return format_time_iso

    @cached_property
    @beartype
    def format_string(self) -> Callable[[str], str]:
        """Callable that formats a string value as a quoted literal."""
        return self.string_format

    @cached_property
    @beartype
    def format_float(self) -> Callable[[float], str]:
        """Callable that formats a float value as a literal."""
        return self.float_format

    @cached_property
    @beartype
    def format_integer(self) -> Callable[[int], str]:
        """Callable that formats an int value as a literal."""
        return _php_integer_formatter(
            base=self.integer_format.get_formatter(
                numeric_separator=self.numeric_separator,
            ),
        )

    @cached_property
    @beartype
    def comment_config(self) -> CommentConfig:
        """Configuration for the language's comment syntax."""
        return self.comment_format.value

    @cached_property
    @beartype
    def ordered_map_format_config(self) -> OrderedMapFormatConfig:
        """Configuration for ordered-map formatting."""
        return OrderedMapFormatConfig(
            ordered_map_open=_php_dict_open,
            close="]",
            preamble_lines=(),
        )

    @cached_property
    @beartype
    def format_ordered_map_entry(self) -> Callable[[str, Value, str], str]:
        """Callable that formats one ordered-map entry."""
        return self._dict_entry

    @cached_property
    @beartype
    def format_variable_declaration(
        self,
    ) -> Callable[[str, str, Value, frozenset[enum.Enum]], str]:
        """Callable that formats a new variable declaration."""
        return self.declaration_style.value.formatter

    @cached_property
    @beartype
    def scalar_preamble(self) -> dict[type[object], tuple[str, ...]]:
        """Per-instance scalar preamble (PHP needs none)."""
        return {}

    @cached_property
    @beartype
    def scalar_body_preamble(self) -> dict[type[object], tuple[str, ...]]:
        """Per-instance scalar body preamble (PHP needs none)."""
        return {}

    @cached_property
    @beartype
    def compute_body_preamble(
        self,
    ) -> Callable[[frozenset[type[object]], Value], tuple[str, ...]]:
        """Compute body-preamble lines from the scalar map."""
        return body_preamble_from_scalars(
            scalar_body_preamble=self.scalar_body_preamble,
            format_lines=tuple,
        )

    @cached_property
    @beartype
    def call_style_config(self) -> CallStyle:
        """Configuration for the chosen call style."""
        config: CallStyle = self.call_style.value
        return config
