"""Haskell language specification."""

import dataclasses
import datetime as dt
import enum
import itertools
import math
import re
import unicodedata
from collections.abc import Callable, Sequence
from functools import cached_property
from typing import TYPE_CHECKING, ClassVar, Self

from beartype import beartype

from literalizer._checks import reject_negative_zero
from literalizer._comments import NestingCommentSuffix
from literalizer._formatters.collection_openers import (
    fixed_open,
)
from literalizer._formatters.format_dates import (
    date_ymd_formatter,
    datetime_epoch_formatter,
    format_date_iso,
    format_datetime_epoch,
    format_datetime_iso,
    format_time_iso,
    normalize_datetime_utc,
)
from literalizer._formatters.format_entries import (
    dict_entry_with_template,
    format_bytes_base64,
    format_bytes_hex,
    passthrough_sequence_entry,
    passthrough_set_entry,
    tuple_dict_entry,
    variable_declaration_formatter,
    variable_formatter,
)
from literalizer._formatters.format_floats import (
    data_has_special_float,
    format_float_fixed,
    format_float_repr,
    format_float_scientific,
)
from literalizer._formatters.format_integers import (
    format_integer_binary,
    format_integer_hex,
    format_integer_octal,
)
from literalizer._formatters.format_json_value import (
    JsonValue,
    format_json_value_text,
    to_jsonable,
)
from literalizer._formatters.format_strings import (
    bidi_escape_replacements,
    format_string_backslash_control,
)
from literalizer._formatters.preamble_roles import (
    import_preamble,
    imports_first,
    join_preamble,
)
from literalizer._formatters.record_strategy import (
    ActiveRecordStrategy,
    RecordDeclarationField,
    RecordFieldType,
    RecordLiteralField,
    RecordRenderer,
    build_record_strategy,
    identity_field_identifier_key,
    nested_record_sequence_type,
)
from literalizer._formatters.type_inference import collect_record_shapes
from literalizer._json_native_document import (
    register_json_native_document_fast,
)
from literalizer._language import (
    NO_CALL_PARAMETER_LIMIT,
    NO_HETEROGENEOUS_BEHAVIOR,
    NON_KEBAB_REF_CASES,
    BareIntegerWidthStrategies,
    CallParameterShadowing,
    CallStubResult,
    CallStyle,
    CommandCallStyle,
    CommentConfig,
    DateFormatConfig,
    DateFormatEnum,
    DatetimeFormatConfig,
    DatetimeFormatEnum,
    DeclarationStyleConfig,
    DictFormatConfig,
    FileWrapperContext,
    FloatSpecialsMixin,
    FormatValueMixin,
    HeterogeneousBehavior,
    IdentifierCase,
    JsonType,
    LanguageCls,
    ModifierCombination,
    NewVariableNameSyntax,
    OrderedMapFormatConfig,
    PositionalCallStyle,
    RenderedRecordLiteral,
    RoundTripCapability,
    SequenceFormatConfig,
    SetFormatConfig,
    StubReturn,
    TrailingCommaConfig,
    VariantMetadata,
    date_scalar_preamble,
    default_call_data_dependent_preamble,
    default_consumable_ref_value_inhibits_consuming_form,
    default_format_call_arg_ref_identifier,
    default_format_call_arg_ref_identifier_consumable,
    default_format_call_ref_identifier,
    default_format_call_statement,
    default_format_call_stub,
    default_format_call_target,
    default_format_call_variable_assignment,
    default_sequence_binding_declarations,
    default_type_hint_collection_preamble_lines,
    empty_scalar_preamble,
    identity_call_arg,
    identity_constructor_target,
    no_call_binding_body_preamble,
    no_data_preamble,
    no_format_integer_beyond_i64,
    no_format_integer_widened,
    no_leading_preamble,
    no_validate_call_arg,
    unsupported_wrap_combined_in_file_static,
    value_contains,
)
from literalizer._statements import split_statements
from literalizer._types import CallStubData, OrderedMap, Value
from literalizer.exceptions import (
    IncompatibleFormatsError,
    UnrepresentableInputError,
    UnrepresentableSpecialFloatError,
)


@beartype
def _haskell_call_preamble_stub(
    parts: Sequence[str],
    _params: Sequence[str],
    _stub_return: StubReturn,
    _args: Sequence[Value],
    /,
) -> tuple[str, ...]:
    """Emit ``OverloadedRecordDot`` when the call target contains dots."""
    if len(parts) > 1:
        return ("{-# LANGUAGE OverloadedRecordDot #-}",)
    return ()


@beartype
def _haskell_arg_type_str(
    *,
    params: Sequence[str],
    type_name: str,
    curried: bool,
    call_result_slots: frozenset[int],
) -> str | None:
    """Return the Haskell argument-type string for a call signature.

    Curried: ``Val -> Val -> Val``, or ``None`` for the zero-parameter case
    (which is a thunk binding ``f :: IO Val`` with no arrow).
    Positional: ``Val`` for one param, or a tuple ``(Val, ...)`` for
    many (including ``()`` for zero, since :class:`PositionalCallStyle`
    emits ``f()`` at the call site).
    """
    parameter_types = [
        f"(IO {type_name})" if index in call_result_slots else type_name
        for index in range(len(params))
    ]
    if curried:
        if len(params) == 0:
            return None
        return " -> ".join(parameter_types)
    if len(params) == 1:
        return parameter_types[0]
    return "(" + ", ".join(parameter_types) + ")"


_HASKELL_IMPORT_PREFIX = import_preamble(code="import ")


@beartype
def _haskell_imports_first(*, lines: Sequence[str]) -> tuple[str, ...]:
    """Return *lines* with the import declarations hoisted to the top.

    GHC requires every import to precede the first declaration, and a
    wrapped call assembles its target stub ahead of the preamble the
    argument values need, so a datetime argument would otherwise put
    ``import Data.Time`` below the stub (issue #4531).  The relative
    order within each group is kept.
    """
    return imports_first(entries=lines, deduplicate_imports=False)


@beartype
def _build_haskell_call_stub_lines(
    *,
    parts: Sequence[str],
    params: Sequence[str],
    stub_return: StubReturn,
    type_name: str,
    curried: bool,
    is_wrapper_stub: bool,
    call_result_slots: frozenset[int],
) -> tuple[str, ...]:
    """Return Haskell stub declarations for a call name."""
    if stub_return is StubReturn.VALUE:
        ret = f"IO {type_name}"
        body = "return undefined"
    else:
        ret = "IO ()"
        body = "return ()"
    # Transform-wrapper stubs are passed a single placeholder param
    # starting with ``_`` and receive the (already typed) result of
    # another call. Declare them with a polymorphic argument so GHC
    # never needs to default the wrapped expression's type.
    effective_curried = curried and not is_wrapper_stub
    arg_type = _haskell_arg_type_str(
        params=params,
        type_name=type_name,
        curried=effective_curried,
        call_result_slots=call_result_slots,
    )
    lhs_wildcards = "_"
    if effective_curried:
        lhs_wildcards = " ".join("_" for _ in params)
    lambda_wildcards = lhs_wildcards
    if len(parts) == 1:
        if is_wrapper_stub:
            sig = f"{parts[0]} :: a -> IO ()"
            return (sig, f"{parts[0]} _ = {body}")
        if arg_type is None:
            return (f"{parts[0]} :: {ret}", f"{parts[0]} = {body}")
        sig = f"{parts[0]} :: {arg_type} -> {ret}"
        return (sig, f"{parts[0]} {lhs_wildcards} = {body}")
    root = parts[0]
    method = parts[-1]
    fields = parts[1:-1]
    if arg_type is None:
        field_type = ret
        construction_lambda = body
    else:
        field_type = f"{arg_type} -> {ret}"
        construction_lambda = f"\\{lambda_wildcards} -> {body}"
    if len(fields) == 0:
        cls = root.capitalize() + "Type_"
        return (
            f"data {cls} = {cls} {{ {method} :: {field_type} }}",
            f"{root} :: {cls}",
            f"{root} = {cls} {{ {method} = {construction_lambda} }}",
        )
    lines: list[str] = []
    inner_cls = fields[-1].capitalize() + "Type_"
    lines.append(
        f"data {inner_cls} = {inner_cls} {{ {method} :: {field_type} }}",
    )
    prev_cls = inner_cls
    for i in range(len(fields) - 2, -1, -1):
        cls = fields[i].capitalize() + "Type_"
        lines.append(
            f"data {cls} = {cls} {{ {fields[i + 1]} :: {prev_cls} }}",
        )
        prev_cls = cls
    root_cls = root.capitalize() + "Type_"
    lines.append(
        f"data {root_cls} = {root_cls} {{ {fields[0]} :: {prev_cls} }}",
    )
    construction = f"{inner_cls} {{ {method} = {construction_lambda} }}"
    for i in range(len(fields) - 2, -1, -1):
        cls = fields[i].capitalize() + "Type_"
        construction = f"{cls} {{ {fields[i + 1]} = {construction} }}"
    construction = f"{root_cls} {{ {fields[0]} = {construction} }}"
    lines.append(f"{root} :: {root_cls}")
    lines.append(f"{root} = {construction}")
    return tuple(lines)


@beartype
def _build_haskell_call_stub(
    *,
    type_name: str,
    curried: bool,
    validate_arg: Callable[[Value], None],
) -> Callable[
    [Sequence[str], Sequence[str], StubReturn, Sequence[Value]],
    tuple[str, ...],
]:
    """Build a call stub function that uses *type_name* for field
    types.
    """

    @beartype
    def _haskell_call_stub(
        parts: Sequence[str],
        params: Sequence[str],
        stub_return: StubReturn,
        args: Sequence[Value],
        /,
    ) -> tuple[str, ...]:
        """Validate resolved arguments before declaring Val parameters."""
        for row in args:
            row_args = row if isinstance(row, list) else [row]
            for value in row_args:
                validate_arg(value)
        return _build_haskell_call_stub_lines(
            parts=parts,
            params=params,
            stub_return=stub_return,
            type_name=type_name,
            curried=curried,
            is_wrapper_stub=(
                len(params) == 1
                and params[0].startswith("_")
                and len(args) == 0
            ),
            call_result_slots=(
                args.call_result_slots
                if isinstance(args, CallStubData)
                else frozenset()
            ),
        )

    return _haskell_call_stub


@beartype
def _haskell_format_call_arg(_original: Value, formatted: str, /) -> str:
    """Wrap a formatted Haskell value in parentheses for curried
    application.
    """
    return f"({formatted})"


@beartype
def _haskell_utc_time_expression(value: dt.datetime) -> str:
    """Format a datetime as a native Haskell UTC time expression.

    Timezone-aware datetimes are converted to UTC first, since
    ``UTCTime`` represents a point in time in UTC.
    """
    if value.tzinfo is not None:
        value = normalize_datetime_utc(value=value, language_name="Haskell")
    total_seconds = value.hour * 3600 + value.minute * 60 + value.second
    if value.microsecond != 0:
        picos = total_seconds * 10**12 + value.microsecond * 10**6
        time_part = f"picosecondsToDiffTime {picos}"
    else:
        time_part = f"secondsToDiffTime {total_seconds}"
    return (
        "UTCTime "
        f"(fromGregorian {value.year} {value.month} {value.day}) "
        f"({time_part})"
    )


@beartype
def _format_haskell_datetime(value: dt.datetime, prefix: str) -> str:
    """Wrap a UTC time expression in the tagged datetime constructor."""
    return f"{prefix}Datetime ({_haskell_utc_time_expression(value=value)})"


@beartype
def _build_haskell_datetime_formatter(
    prefix: str,
) -> Callable[[dt.datetime], str]:
    """Build a datetime formatter that produces ``{prefix}Datetime``
    constructors.
    """

    @beartype
    def _format(value: dt.datetime) -> str:
        """Delegate to module-level implementation."""
        return _format_haskell_datetime(value=value, prefix=prefix)

    return _format


_format_datetime_haskell = _build_haskell_datetime_formatter(prefix="H")


@beartype
def _haskell_native_record_declaration(
    name: str, fields: Sequence[RecordDeclarationField], /
) -> str:
    """Declare a concrete Haskell record type and constructor."""
    members = ", ".join(
        f"{field.identifier} :: {field.type_name}" for field in fields
    )
    return f"data {name} = {name} {{ {members} }}"


@beartype
def _haskell_native_record_literal(
    name: str, fields: Sequence[RecordLiteralField], /
) -> RenderedRecordLiteral:
    """Render a constructor application with named record fields."""
    return RenderedRecordLiteral(
        head=f"{name} {{",
        entries=tuple(
            f"{field.identifier} = {field.formatted}" for field in fields
        ),
        closer="}",
        compact_pad=" ",
    )


@beartype
def _haskell_native_field_identifier(key: str, /) -> str:
    """Return a source-safe Haskell field selector."""
    return key


@beartype
def _validate_haskell_native_record(
    data: Value, *, reserved_fields: frozenset[str]
) -> None:
    """Reject values outside the concrete Haskell record subset."""
    if isinstance(data, OrderedMap):
        msg = "Haskell record mode cannot represent ordered maps"
        raise UnrepresentableInputError(msg)
    if isinstance(data, dict):
        if len(data) == 0:
            msg = "Haskell record mode cannot represent empty records"
            raise UnrepresentableInputError(msg)
        for key, value in data.items():
            if (
                not isinstance(key, str)
                or re.fullmatch(pattern=r"[a-z][A-Za-z0-9_']*", string=key)
                is None
                or key in reserved_fields
            ):
                msg = f"Haskell record mode cannot represent field {key!r}"
                raise UnrepresentableInputError(msg)
            _validate_haskell_native_record(
                data=value, reserved_fields=reserved_fields
            )
    elif isinstance(data, list):
        for value in data:
            _validate_haskell_native_record(
                data=value, reserved_fields=reserved_fields
            )
    elif isinstance(data, (set, type(None))):
        msg = f"Haskell record mode cannot represent {type(data).__name__}"
        raise UnrepresentableInputError(msg)


@beartype
@dataclasses.dataclass(frozen=True)
class _DateTimeFormatters:
    """Resolved date and datetime formatters."""

    format_date: Callable[[dt.date], str]
    format_datetime: Callable[[dt.datetime], str]


@beartype
def _wrap_with_str_constructor_date(
    value: dt.date,
    str_prefix: str,
    formatter: Callable[[dt.date], str],
) -> str:
    """Wrap an ISO date string with the HStr constructor."""
    return f"{str_prefix}{formatter(value)}"


@beartype
def _wrap_with_str_constructor_datetime(
    value: dt.datetime,
    str_prefix: str,
    formatter: Callable[[dt.datetime], str],
) -> str:
    """Wrap an ISO datetime string with the HStr constructor."""
    return f"{str_prefix}{formatter(value)}"


@beartype
def _build_date_formatters(
    *,
    date_format_name: str,
    date_formatter: Callable[[dt.date], str],
    datetime_format_name: str,
    datetime_formatter: Callable[[dt.datetime], str],
    constructor_prefix: str,
    is_explicit: bool,
) -> _DateTimeFormatters:
    """Build date and datetime formatters based on format settings."""
    match date_format_name:
        case "HASKELL":
            fmt_date: Callable[[dt.date], str] = date_ymd_formatter(
                template=(
                    f"{constructor_prefix}Date "
                    f"(fromGregorian {{year}} {{month}} {{day}})"
                ),
            )
        case _ if is_explicit:
            _str_pfx = f"{constructor_prefix}Str "

            @beartype
            def _explicit_date(value: dt.date) -> str:
                """Delegate to module-level implementation."""
                return _wrap_with_str_constructor_date(
                    value=value, str_prefix=_str_pfx, formatter=date_formatter
                )

            fmt_date = _explicit_date
        case _:
            fmt_date = date_formatter

    match datetime_format_name:
        case "HASKELL":
            fmt_datetime: Callable[[dt.datetime], str] = (
                _build_haskell_datetime_formatter(prefix=constructor_prefix)
            )
        case "EPOCH":
            fmt_datetime = datetime_formatter
        case _ if is_explicit:
            _str_pfx_dt = f"{constructor_prefix}Str "

            @beartype
            def _explicit_datetime(value: dt.datetime) -> str:
                """Delegate to module-level implementation."""
                return _wrap_with_str_constructor_datetime(
                    value=value,
                    str_prefix=_str_pfx_dt,
                    formatter=datetime_formatter,
                )

            fmt_datetime = _explicit_datetime
        case _:
            fmt_datetime = datetime_formatter

    return _DateTimeFormatters(
        format_date=fmt_date,
        format_datetime=fmt_datetime,
    )


@beartype
@dataclasses.dataclass(frozen=True)
class _StringFormatters:
    """String, bytes, and dict-entry formatters."""

    format_string: Callable[[str], str]
    format_bytes: Callable[[bytes], str]
    format_dict_entry: Callable[[str, Value, str], str]
    format_dict_key: Callable[[str], str]
    is_explicit: bool


@beartype
def _wrap_str_with_constructor(
    value: str,
    string_constructor: str,
    base_format_string: Callable[[str], str],
) -> str:
    """Wrap a formatted string with the constructor prefix."""
    return f"{string_constructor}{base_format_string(value)}"


@beartype
def _wrap_bytes_with_constructor(
    data: bytes,
    string_constructor: str,
    base_format_bytes: Callable[[bytes], str],
) -> str:
    """Wrap formatted bytes with the constructor prefix."""
    return f"{string_constructor}{base_format_bytes(data)}"


@beartype
def _is_haskell_hex_control(character: str) -> bool:
    """Return whether *character* uses a greedy Haskell hex escape."""
    return (
        character <= "\x1f" and character not in "\t\n\r"
    ) or _is_haskell_hex_escaped(character=character)


_HASKELL_NON_GRAPHIC_CATEGORIES = frozenset({"Cf", "Cn", "Zl", "Zp"})
"""Unicode categories GHC refuses to lex inside a string literal.

The format characters (``Cf``), unassigned code points and noncharacters
(``Cn``), and the line and paragraph separators
(``Zl``/``Zp``) all produce "lexical error at character", while an
ordinary space separator such as U+00A0 is accepted (issue #3953).
"""


@beartype
def _is_haskell_hex_escaped(character: str) -> bool:
    """Return whether *character* is written as a Haskell hex escape.

    The category lookup dominates rendering when it runs per character,
    so ASCII leaves before reaching it.  Nothing below ``U+007F`` can
    qualify: the lowest character in any of the categories above is the
    soft hyphen at ``U+00AD``.
    """
    if character < "\x7f":
        return False
    return (
        character <= "\x9f"
        or unicodedata.category(character) in _HASKELL_NON_GRAPHIC_CATEGORIES
    )


@beartype
def _format_haskell_string_character(character: str) -> str:
    """Escape one character for a Haskell string literal."""
    if _is_haskell_hex_escaped(character=character):
        return f"\\x{ord(character):02x}"
    return format_string_backslash_control(
        value=character,
        control_char_fmt="\\x{:02x}",
        escape_delete=False,
    )[1:-1]


@beartype
def _build_string_formatters(
    *,
    string_format_name: str,
    constructor_prefix: str,
    base_format_bytes: Callable[[bytes], str],
) -> _StringFormatters:
    """Build string/bytes/dict-entry formatters.

    For ``EXPLICIT`` format, string and bytes values are wrapped with the
    constructor prefix (e.g. ``HStr "hello"``), and dictionary keys use the
    shared string formatter directly.

    For ``DOUBLE`` format, values pass through unmodified, and dict
    entries use tuple formatting.
    """

    @beartype
    def base_format_string(value: str) -> str:
        r"""Format a Haskell string with ``\x..`` control-char escapes."""
        has_greedy_hex_boundary = any(
            _is_haskell_hex_control(character=character)
            and following in "0123456789abcdefABCDEF"
            for character, following in itertools.pairwise(value)
        )
        has_hex_escaped = any(
            _is_haskell_hex_escaped(character=character) for character in value
        )
        if not has_greedy_hex_boundary and not has_hex_escaped:
            return format_string_backslash_control(
                value=value,
                control_char_fmt="\\x{:02x}",
                escape_delete=False,
            )
        pieces: list[str] = []
        for index, char in enumerate(iterable=value):
            formatted = _format_haskell_string_character(character=char)
            pieces.append(formatted)
            if (
                _is_haskell_hex_control(character=char)
                and index + 1 < len(value)
                and value[index + 1] in "0123456789abcdefABCDEF"
            ):
                pieces.append("\\&")
        return f'"{"".join(pieces)}"'

    if string_format_name != "EXPLICIT":
        return _StringFormatters(
            format_string=base_format_string,
            format_bytes=base_format_bytes,
            format_dict_entry=tuple_dict_entry(
                format_value=passthrough_sequence_entry,
            ),
            format_dict_key=base_format_string,
            is_explicit=False,
        )

    string_constructor = f"{constructor_prefix}Str "

    @beartype
    def _format_string(value: str) -> str:
        """Delegate to module-level implementation."""
        return _wrap_str_with_constructor(
            value=value,
            string_constructor=string_constructor,
            base_format_string=base_format_string,
        )

    @beartype
    def _format_bytes(data: bytes) -> str:
        """Delegate to module-level implementation."""
        return _wrap_bytes_with_constructor(
            data=data,
            string_constructor=string_constructor,
            base_format_bytes=base_format_bytes,
        )

    return _StringFormatters(
        format_string=_format_string,
        format_bytes=_format_bytes,
        format_dict_entry=tuple_dict_entry(
            format_value=passthrough_sequence_entry
        ),
        format_dict_key=base_format_string,
        is_explicit=True,
    )


@beartype
def _num_instance(
    *,
    has_int: bool,
    has_float: bool,
    needs_catchall: bool,
    type_name: str,
    constructor_prefix: str,
    indent: str,
) -> str:
    """Build the ``Num`` instance with only relevant constructors.

    *needs_catchall* controls whether a trailing ``negate _`` clause is
    emitted. When the ``Val`` type has only numeric constructors, the
    specific ``negate (HInt n)`` / ``negate (HFloat f)`` patterns are
    exhaustive, and a catch-all would be redundant.
    """
    if has_int:
        from_integer = f"{indent}fromInteger = {constructor_prefix}Int"
    else:
        from_integer = (
            f"{indent}fromInteger n = "
            f"{constructor_prefix}Float (fromIntegral n)"
        )
    negate_parts: list[str] = []
    if has_int:
        negate_parts.append(
            f"{indent}negate ({constructor_prefix}Int n) = "
            f"{constructor_prefix}Int (negate n)"
        )
    if has_float:
        negate_parts.append(
            f"{indent}negate ({constructor_prefix}Float f) = "
            f"{constructor_prefix}Float (negate f)"
        )
    if needs_catchall:
        negate_parts.append(f'{indent}negate _ = error "not implemented"')
    return join_preamble(
        entries=[
            f"instance Num {type_name} where",
            from_integer,
            f'{indent}_ + _ = error "not implemented"',
            f'{indent}_ * _ = error "not implemented"',
            f'{indent}abs _ = error "not implemented"',
            f'{indent}signum _ = error "not implemented"',
            *negate_parts,
        ]
    )


@beartype
def _has_microsecond_datetime(*, data: Value) -> bool:
    """Return whether *data* contains any datetime with microseconds."""
    match data:
        case dt.datetime():
            return bool(data.microsecond)
        case dt.date():
            return False
        case dict():
            return any(
                _has_microsecond_datetime(data=v) for v in data.values()
            )
        case list() | set():
            return any(_has_microsecond_datetime(data=v) for v in data)
        case _:
            return False


@beartype
def _has_nonmicrosecond_datetime(*, data: Value) -> bool:
    """Return whether *data* contains any datetime without
    microseconds.
    """
    match data:
        case dt.datetime():
            return data.microsecond == 0
        case dt.date():
            return False
        case dict():
            return any(
                _has_nonmicrosecond_datetime(data=v) for v in data.values()
            )
        case list() | set():
            return any(_has_nonmicrosecond_datetime(data=v) for v in data)
        case _:
            return False


@beartype
def _datetime_import_items(
    *,
    has_from_gregorian: bool,
    has_microsecond: bool,
    has_nonmicrosecond: bool,
) -> list[str]:
    """Return ``Data.Time`` import names needed for datetime values.

    ``secondsToDiffTime`` is imported only when at least one datetime
    has no microsecond component; otherwise every datetime is rendered
    via ``picosecondsToDiffTime`` and the seconds helper would be
    flagged as unused.
    """
    items = ["UTCTime(..)"]
    if not has_from_gregorian:
        items.append("fromGregorian")
    if has_nonmicrosecond:
        items.append("secondsToDiffTime")
    if has_microsecond:
        items.append("picosecondsToDiffTime")
    return items


@beartype
@dataclasses.dataclass(frozen=True, kw_only=True)
class _HaskellPreambleConfig:
    """Captured configuration for the Haskell body preamble
    computation.
    """

    include_hdate: bool
    include_hdatetime: bool
    datetime_produces_int: bool
    date_needs_is_string: bool
    datetime_needs_is_string: bool
    date_needs_str_explicit: bool
    datetime_needs_str_explicit: bool
    is_string_import: str
    is_string_instance: str
    type_name: str
    constructor_prefix: str
    emit_is_string: bool
    emit_num: bool
    indent: str


@beartype
def _haskell_base_constructors(
    *,
    types: frozenset[type[object]],
    constructor_prefix: str,
    type_name: str,
) -> list[str]:
    """Return base data-type constructors for the types present in
    data.
    """
    p = constructor_prefix
    return [
        constructor
        for type_set, constructor in (
            (frozenset({type(None)}), f"{p}Null"),
            (frozenset({bool}), f"{p}Bool Bool"),
            (frozenset({int}), f"{p}Int Integer"),
            (frozenset({float}), f"{p}Float Double"),
            (frozenset({str, bytes}), f"{p}Str String"),
            (frozenset({list}), f"{p}List [{type_name}]"),
            (
                frozenset({dict, OrderedMap}),
                f"{p}Map [(String, {type_name})]",
            ),
            (frozenset({set}), f"{p}Set [{type_name}]"),
        )
        if len(types & type_set) > 0
    ]


@beartype
def _haskell_extend_for_dates(
    *,
    cfg: _HaskellPreambleConfig,
    types: frozenset[type[object]],
    data: Value,
    data_val_parts: list[str],
) -> list[str]:
    """Append date/datetime constructors and return the import-item
    list.
    """
    p = cfg.constructor_prefix
    import_items: list[str] = []
    if cfg.include_hdate and dt.date in types:
        data_val_parts.append(f"{p}Date Day")
        import_items.extend(["Day", "fromGregorian"])
    if cfg.include_hdatetime and dt.datetime in types:
        data_val_parts.append(f"{p}Datetime UTCTime")
        import_items.extend(
            _datetime_import_items(
                has_from_gregorian="fromGregorian" in import_items,
                has_microsecond=_has_microsecond_datetime(data=data),
                has_nonmicrosecond=_has_nonmicrosecond_datetime(data=data),
            ),
        )
    if (
        cfg.datetime_produces_int
        and dt.datetime in types
        and f"{p}Int Integer" not in data_val_parts
    ):
        data_val_parts.append(f"{p}Int Integer")
    return import_items


@beartype
def _haskell_needs_str_constructor(
    *,
    cfg: _HaskellPreambleConfig,
    types: frozenset[type[object]],
) -> bool:
    """Return True if an ``HStr String`` constructor must be present."""
    return (
        bool(types & {str, bytes})
        or dt.time in types
        or (cfg.date_needs_is_string and dt.date in types)
        or (cfg.datetime_needs_is_string and dt.datetime in types)
        or (cfg.date_needs_str_explicit and dt.date in types)
        or (cfg.datetime_needs_str_explicit and dt.datetime in types)
    )


@beartype
def _haskell_num_instances(
    *,
    cfg: _HaskellPreambleConfig,
    types: frozenset[type[object]],
    data_val_parts: list[str],
) -> list[str]:
    """Return ``Num``/``Fractional`` instance lines for the data types."""
    if not cfg.emit_num:
        return []
    p = cfg.constructor_prefix
    has_float = float in types
    has_int = int in types or (
        cfg.datetime_produces_int and dt.datetime in types
    )
    instances: list[str] = []
    if has_float or has_int:
        # The numeric catch-all for ``negate`` is redundant when ``Val``
        # has only numeric constructors, because the specific
        # ``HInt`` / ``HFloat`` clauses cover the type.
        effective_num_constructor_count = 0
        if has_int:
            effective_num_constructor_count = 1
        effective_num_constructor_count_2 = 0
        if has_float:
            effective_num_constructor_count_2 = 1
        num_constructor_count = (effective_num_constructor_count) + (
            effective_num_constructor_count_2
        )
        needs_catchall = len(data_val_parts) > num_constructor_count
        instances.append(
            _num_instance(
                has_int=has_int,
                has_float=has_float,
                needs_catchall=needs_catchall,
                type_name=cfg.type_name,
                constructor_prefix=cfg.constructor_prefix,
                indent=cfg.indent,
            ),
        )
    if has_float:
        instances.append(
            f"instance Fractional {cfg.type_name} where\n"
            f"{cfg.indent}fromRational r = {p}Float (realToFrac r)\n"
            f'{cfg.indent}_ / _ = error "not implemented"'
        )
    return instances


@beartype
def _haskell_compute_preamble(
    *,
    cfg: _HaskellPreambleConfig,
    types: frozenset[type[object]],
    data: Value,
) -> tuple[str, ...]:
    """Return body-preamble lines for the given *types* and *data*."""
    p = cfg.constructor_prefix
    data_val_parts = _haskell_base_constructors(
        types=types,
        constructor_prefix=p,
        type_name=cfg.type_name,
    )
    import_items = _haskell_extend_for_dates(
        cfg=cfg,
        types=types,
        data=data,
        data_val_parts=data_val_parts,
    )

    needs_is_string = cfg.emit_is_string and (
        bool(types & {str, bytes})
        or dt.time in types
        or (cfg.date_needs_is_string and dt.date in types)
        or (cfg.datetime_needs_is_string and dt.datetime in types)
    )
    if (
        _haskell_needs_str_constructor(cfg=cfg, types=types)
        and f"{p}Str String" not in data_val_parts
    ):
        data_val_parts.append(f"{p}Str String")

    # Emit imports first, then data declaration, then instances.
    imports: list[str] = []
    if len(import_items) > 0:
        imports.append(
            import_preamble(
                code="import Data.Time (" + ", ".join(import_items) + ")"
            )
        )
    if needs_is_string:
        imports.append(cfg.is_string_import)

    instances: list[str] = []
    if needs_is_string:
        instances.append(cfg.is_string_instance)
    instances.extend(
        _haskell_num_instances(
            cfg=cfg,
            types=types,
            data_val_parts=data_val_parts,
        ),
    )

    lines: list[str] = imports
    lines.append(f"data {cfg.type_name} = " + " | ".join(data_val_parts))
    lines.extend(instances)
    return tuple(lines)


@beartype
def _build_scalar_body_preamble(
    *,
    date_config: DateFormatConfig,
    datetime_config: DatetimeFormatConfig,
    is_string_import: str,
    is_string_instance: str,
    type_name: str,
    constructor_prefix: str,
    emit_is_string: bool,
    emit_num: bool,
    indent: str,
) -> Callable[[frozenset[type[object]], Value], tuple[str, ...]]:
    """Build a callable that computes body-preamble lines for Haskell.

    The callable receives the set of types present in the data and the
    original data value, and returns only the imports, the type
    declaration, and typeclass instances that are actually needed.

    The returned lines are ordered: imports first, then the data type,
    then typeclass instances.

    When *emit_is_string* is ``False``, the ``IsString`` import and
    instance are suppressed (used by the ``EXPLICIT`` string format).

    When *emit_num* is ``False``, the ``Num`` and ``Fractional``
    instances are suppressed (used by the ``EXPLICIT`` numeric style).
    """
    cfg = _HaskellPreambleConfig(
        include_hdate=date_config.type_produced is dt.date,
        include_hdatetime=datetime_config.type_produced is dt.datetime,
        datetime_produces_int=datetime_config.type_produced is int,
        date_needs_is_string=bool(
            emit_is_string and date_config.preamble_lines
        ),
        datetime_needs_is_string=bool(
            emit_is_string and datetime_config.preamble_lines
        ),
        # In EXPLICIT mode, ISO dates/datetimes produce HStr-wrapped
        # strings, so HStr String must appear in the data type.
        date_needs_str_explicit=(
            not emit_is_string and date_config.type_produced is str
        ),
        datetime_needs_str_explicit=(
            not emit_is_string and datetime_config.type_produced is str
        ),
        is_string_import=is_string_import,
        is_string_instance=is_string_instance,
        type_name=type_name,
        constructor_prefix=constructor_prefix,
        emit_is_string=emit_is_string,
        emit_num=emit_num,
        indent=indent,
    )

    @beartype
    def _compute(
        types: frozenset[type[object]], data: Value, /
    ) -> tuple[str, ...]:
        """Return body-preamble lines for the given *types*."""
        return _haskell_compute_preamble(cfg=cfg, types=types, data=data)

    return _compute


@beartype
@dataclasses.dataclass(frozen=True)
class _SequenceSetup:
    """Sequence format configuration and opener."""

    format_config: SequenceFormatConfig
    sequence_open: Callable[[list[Value]], str]


@beartype
@dataclasses.dataclass(frozen=True)
class _DeclarationFormatters:
    """Variable declaration and assignment formatters."""

    format_variable_declaration: Callable[
        [str, str, Value, frozenset[enum.Enum]], str
    ]
    format_variable_assignment: Callable[[str, str, Value], str]


@beartype
def _format_haskell_declaration(
    *,
    name: str,
    value: str,
    data: Value,
    modifiers: frozenset[enum.Enum],
    base_declaration: Callable[[str, str, Value, frozenset[enum.Enum]], str],
    sequence_declared_type: str | None,
    type_name: str,
) -> str:
    """Format a variable declaration with type annotation."""
    base = base_declaration(name, value, data, modifiers)
    if isinstance(data, list):
        if sequence_declared_type is None:
            # TUPLE sequence format: pin each slot to ``Val`` so bare
            # numeric literals in the tuple resolve via ``fromInteger``
            # instead of triggering ``-Wtype-defaults``.
            tuple_type = "(" + ", ".join(type_name for _ in data) + ")"
            return f"{name} :: {tuple_type}\n{base}"
        return f"{name} :: {sequence_declared_type}\n{base}"
    return f"{name} :: {type_name}\n{base}"


@beartype
def _build_declaration_formatters(
    *,
    declaration_config: DeclarationStyleConfig,
    sequence_config: SequenceFormatConfig,
    type_name: str,
) -> _DeclarationFormatters:
    """Build declaration/assignment formatters with type annotations."""
    base_declaration = declaration_config.formatter
    raw_declared = sequence_config.declared_type
    sequence_declared_type = None
    if raw_declared is not None:
        sequence_declared_type = raw_declared.replace("Val", type_name)

    @beartype
    def _haskell_declaration(
        name: str,
        value: str,
        data: Value,
        modifiers: frozenset[enum.Enum],
    ) -> str:
        """Delegate to module-level implementation."""
        return _format_haskell_declaration(
            name=name,
            value=value,
            data=data,
            modifiers=modifiers,
            base_declaration=base_declaration,
            sequence_declared_type=sequence_declared_type,
            type_name=type_name,
        )

    return _DeclarationFormatters(
        format_variable_declaration=_haskell_declaration,
        format_variable_assignment=variable_formatter(
            template="{name} = {value}",
        ),
    )


@beartype
@dataclasses.dataclass(frozen=True)
class _PreambleSetup:
    """Preamble configuration for Haskell output."""

    scalar_preamble: dict[type[object], tuple[str, ...]]
    compute_body_preamble: Callable[
        [frozenset[type[object]], Value], tuple[str, ...]
    ]


@beartype
def _build_preamble_setup(
    *,
    date_format: enum.Enum,
    datetime_format: enum.Enum,
    date_config: DateFormatConfig,
    datetime_config: DatetimeFormatConfig,
    is_explicit: bool,
    type_name: str,
    constructor_prefix: str,
    emit_num: bool,
    indent: str,
) -> _PreambleSetup:
    """Build scalar preamble and body-preamble computation."""
    _overloaded_strings = ("{-# LANGUAGE OverloadedStrings #-}",)
    if is_explicit:
        # EXPLICIT mode wraps dates/datetimes with HStr, so no
        # OverloadedStrings pragma is needed for ISO formats.
        scalar_preamble: dict[type[object], tuple[str, ...]] = {}
    else:
        str_extra: dict[type[object], tuple[str, ...]] = {
            str: _overloaded_strings,
            bytes: _overloaded_strings,
        }
        scalar_preamble = date_scalar_preamble(
            date_format=date_format,
            datetime_format=datetime_format,
            extra=str_extra,
        )
    return _PreambleSetup(
        scalar_preamble=scalar_preamble,
        compute_body_preamble=_build_scalar_body_preamble(
            date_config=date_config,
            datetime_config=datetime_config,
            is_string_import=import_preamble(
                code="import Data.String (IsString(fromString))"
            ),
            is_string_instance=(
                f"instance IsString {type_name} where\n"
                f"{indent}fromString = {constructor_prefix}Str"
            ),
            type_name=type_name,
            constructor_prefix=constructor_prefix,
            emit_is_string=not is_explicit,
            emit_num=emit_num,
            indent=indent,
        ),
    )


@beartype
def _wrap_integer_with_constructor(
    value: int,
    int_prefix: str,
    base_format_integer: Callable[[int], str],
) -> str:
    """Wrap an integer with the constructor prefix."""
    formatted = base_format_integer(value)
    if value < 0:
        return f"{int_prefix}({formatted})"
    return f"{int_prefix}{formatted}"


@beartype
def _wrap_float_with_constructor(
    value: float,
    float_prefix: str,
    base_format_float: Callable[[float], str],
) -> str:
    """Wrap a float with the constructor prefix."""
    formatted = base_format_float(value)
    return f"{float_prefix}({formatted})"


_AESON_VALUE_STATIC_PREAMBLE: tuple[str, ...] = (
    "{-# LANGUAGE QuasiQuotes #-}",
)

_AESON_VALUE_BODY_PREAMBLE: tuple[str, ...] = (
    import_preamble(code="import Data.Aeson (Value)"),
    import_preamble(code="import Data.Aeson.QQ (aesonQQ)"),
)

# Closing bracket sequence of the ``aesonQQ`` quasi-quote bracket; if the
# rendered JSON contains this literal sequence the quasi-quote bracket
# terminates early and the fixture fails to parse.  The terminator is
# recognized by GHC at the lexer level, before ``aesonQQ``'s grammar runs,
# so it bites even inside a JSON string literal -- hence the rejection.
#
# ``aesonQQ``'s other splice forms (``#{...}`` value interpolation and
# ``$ident`` key interpolation) are *not* rejected here: both only trigger
# in unquoted positions, and :func:`format_json_value_text` runs every
# string value and dict key through :func:`json.dumps`, which always
# emits them inside ``"..."`` literals.  See the regression test
# ``test_haskell_json_type_accepts_aeson_qq_interpolation_metasyntax``
# that pins data containing literal ``#{...}`` and ``$ident`` text as a
# round-tripping fixture.
_AESON_QQ_CLOSE = "|]"


@beartype
def _aeson_value_body_preamble(
    _types: frozenset[type[object]], _data: Value, /
) -> tuple[str, ...]:
    """Return the ``Data.Aeson.Value`` import preamble lines."""
    return _AESON_VALUE_BODY_PREAMBLE


# Sequence/dict format definitions used while ``json_type`` is active.
# The framework still walks the data to compute a formatted ``value``,
# but that string is discarded by :func:`_format_haskell_json_declaration`
# and friends in favor of a fresh ``json.dumps`` of the raw data.  These
# definitions only need to be permissive enough that the formatting pass
# does not error on heterogeneous data or nulls inside containers.
_AESON_VALUE_SEQUENCE_CONFIG = SequenceFormatConfig(
    length_is_part_of_type=False,
    sequence_open=fixed_open(open_str="["),
    close="]",
    supports_heterogeneity=True,
    single_element_trailing_comma=False,
    single_element_template=None,
    supports_trailing_comma=True,
    empty_sequence="[]",
    preamble_lines=(),
    format_entry=passthrough_sequence_entry,
    typed_opener_fallback=None,
    uses_typed_literal_for_scalars=False,
    requires_uniform_record_shapes=False,
    declared_type=None,
    narrowed_empty_form=None,
)

_AESON_VALUE_SET_CONFIG = SetFormatConfig(
    set_open=fixed_open(open_str="["),
    close="]",
    empty_set="[]",
    preamble_lines=(),
    set_opener_template="",
    supports_heterogeneity=True,
    supports_trailing_comma=True,
)

_AESON_VALUE_DICT_CONFIG = DictFormatConfig(
    dict_open=fixed_open(open_str="{"),
    close="}",
    format_entry=dict_entry_with_template(
        template="{key}: {value}",
        format_value=passthrough_sequence_entry,
    ),
    empty_dict="{}",
    preamble_lines=(),
    narrowed_open=None,
    supports_trailing_comma=True,
    narrowed_empty_form=None,
)

_AESON_VALUE_ORDERED_MAP_CONFIG = OrderedMapFormatConfig(
    ordered_map_open=fixed_open(open_str="{"),
    close="}",
    preamble_lines=(),
)


@beartype
def _aeson_quasi_expression(data: Value) -> str:
    """Render ``[aesonQQ| <json> |]`` for *data*.

    The ``aesonQQ`` quasi-quote bracket from ``Data.Aeson.QQ`` parses JSON at
    compile time and yields a :class:`Data.Aeson.Value`, mirroring how
    Rust's ``serde_json::json!`` macro builds a ``Value`` from inline
    JSON.  Bare scalars (``42``, ``true``, ``"hello"``, ``null``) are
    accepted by the quasi-quote bracket just like top-level JSON documents.
    """
    if data_has_special_float(data=data):
        msg = (
            "Haskell(json_type=AESON_VALUE) cannot represent special floats "
            "because aesonQQ accepts only finite numbers."
        )
        raise UnrepresentableSpecialFloatError(msg)
    json_text = format_json_value_text(data=data)
    for character, escape in bidi_escape_replacements(template="\\u{:04X}"):
        json_text = json_text.replace(character, escape)
    if _AESON_QQ_CLOSE in json_text:
        msg = (
            "Haskell(json_type=AESON_VALUE) cannot represent a value whose "
            "JSON encoding contains the aesonQQ terminator sequence '|]'."
        )
        raise UnrepresentableInputError(msg)
    return f"[aesonQQ| {json_text} |]"


class _AesonReferenceLiteral(str):
    """A JSON initializer retaining structural reference holes."""

    __slots__ = ("data", "ref_case", "ref_key")
    data: Value
    ref_key: str
    ref_case: IdentifierCase | None

    def __new__(
        cls,
        value: str,
        /,
        *,
        data: Value,
        ref_key: str,
        ref_case: IdentifierCase | None,
    ) -> Self:
        """Keep source identity alongside the ordinary formatted text."""
        del data, ref_key, ref_case
        return super().__new__(cls, object=value)

    def __init__(
        self,
        _value: str,
        /,
        *,
        data: Value,
        ref_key: str,
        ref_case: IdentifierCase | None,
    ) -> None:
        """Initialize retained references alongside the string value."""
        self.data = data
        self.ref_key = ref_key
        self.ref_case = ref_case


@beartype
def _aeson_binding_expression(*, value: str, data: Value) -> str:
    """Interpolate structural references while quoting literal JSON
    data.
    """
    ordinary = _aeson_quasi_expression(data=data)
    if not isinstance(value, _AesonReferenceLiteral):
        return ordinary

    @beartype
    def render(node: JsonValue, /) -> str:
        """Serialize one JSON node or an existing dynamic value."""
        if isinstance(node, dict):
            name = node.get(value.ref_key)
            if len(node) == 1 and isinstance(name, str):
                case = value.ref_case
                identifier = name if case is None else case.convert(name=name)
                return "#{" + identifier + "}"
            return (
                "{"
                + ", ".join(
                    format_json_value_text(data=str(object=key))
                    + ": "
                    + render(child)
                    for key, child in node.items()
                )
                + "}"
            )
        if isinstance(node, list):
            return "[" + ", ".join(render(child) for child in node) + "]"
        return format_json_value_text(data=node)

    return f"[aesonQQ| {render(to_jsonable(data=value.data))} |]"


@beartype
def _format_haskell_json_declaration(
    name: str,
    value: str,
    data: Value,
    _modifiers: frozenset[enum.Enum],
) -> str:
    """Format a ``Value`` declaration backed by ``aesonQQ``."""
    expression = _aeson_binding_expression(value=value, data=data)
    return f"{name} :: Value\n{name} = {expression}"


@beartype
def _format_haskell_json_assignment(
    name: str,
    value: str,
    data: Value,
) -> str:
    """Format a ``Value`` assignment backed by ``aesonQQ``.

    Haskell has no mutable bindings, so an ``ExistingVariable``
    assignment at module top level is just another binding -- emitted
    with the same ``name :: Value`` signature as the declaration form so
    the rendered file keeps the ``Data.Aeson (Value)`` import live
    (otherwise ``-Wunused-imports`` fires) and satisfies
    ``-Wmissing-signatures`` under ``-Wall -Werror``.
    """
    expression = _aeson_binding_expression(value=value, data=data)
    return f"{name} :: Value\n{name} = {expression}"


@beartype
def _format_haskell_json_call_arg(raw_value: Value, formatted: str) -> str:
    """Format a direct call argument as a ``Value`` quasi-quote.

    The ``aesonQQ`` brackets are self-delimiting so no surrounding
    parentheses are needed even inside a curried call.
    """
    return _aeson_binding_expression(value=formatted, data=raw_value)


# The value bindings ``Prelude`` exports, which every module imports
# implicitly.  The wrapped file references its declaration by bare name
# from ``main``, so a declaration taking one of these names makes that
# reference ambiguous and the module does not compile (issue #3942).
_HASKELL_PRELUDE_BINDINGS: frozenset[str] = frozenset(
    {
        "abs",
        "acos",
        "acosh",
        "all",
        "and",
        "any",
        "appendFile",
        "asTypeOf",
        "asin",
        "asinh",
        "atan",
        "atan2",
        "atanh",
        "break",
        "ceiling",
        "compare",
        "concat",
        "concatMap",
        "const",
        "cos",
        "cosh",
        "curry",
        "cycle",
        "decodeFloat",
        "div",
        "divMod",
        "drop",
        "dropWhile",
        "either",
        "elem",
        "encodeFloat",
        "enumFrom",
        "enumFromThen",
        "enumFromThenTo",
        "enumFromTo",
        "error",
        "errorWithoutStackTrace",
        "even",
        "exp",
        "exponent",
        "fail",
        "filter",
        "flip",
        "floatDigits",
        "floatRadix",
        "floatRange",
        "floor",
        "fmap",
        "foldMap",
        "foldl",
        "foldl'",
        "foldl1",
        "foldr",
        "foldr1",
        "fromEnum",
        "fromInteger",
        "fromIntegral",
        "fromRational",
        "fst",
        "gcd",
        "getChar",
        "getContents",
        "getLine",
        "head",
        "id",
        "init",
        "interact",
        "ioError",
        "isDenormalized",
        "isIEEE",
        "isInfinite",
        "isNaN",
        "isNegativeZero",
        "iterate",
        "last",
        "lcm",
        "length",
        "lex",
        "liftA2",
        "lines",
        "log",
        "logBase",
        "lookup",
        "map",
        "mapM",
        "mapM_",
        "mappend",
        "max",
        "maxBound",
        "maximum",
        "maybe",
        "mconcat",
        "mempty",
        "min",
        "minBound",
        "minimum",
        "mod",
        "negate",
        "not",
        "notElem",
        "null",
        "odd",
        "or",
        "otherwise",
        "pi",
        "pred",
        "print",
        "product",
        "properFraction",
        "pure",
        "putChar",
        "putStr",
        "putStrLn",
        "quot",
        "quotRem",
        "read",
        "readFile",
        "readIO",
        "readList",
        "readLn",
        "readParen",
        "reads",
        "readsPrec",
        "realToFrac",
        "recip",
        "rem",
        "repeat",
        "replicate",
        "return",
        "reverse",
        "round",
        "scaleFloat",
        "scanl",
        "scanl1",
        "scanr",
        "scanr1",
        "seq",
        "sequence",
        "sequenceA",
        "sequence_",
        "show",
        "showChar",
        "showList",
        "showParen",
        "showString",
        "shows",
        "showsPrec",
        "significand",
        "signum",
        "sin",
        "sinh",
        "snd",
        "span",
        "splitAt",
        "sqrt",
        "subtract",
        "succ",
        "sum",
        "tail",
        "take",
        "takeWhile",
        "tan",
        "tanh",
        "toEnum",
        "toInteger",
        "toRational",
        "traverse",
        "truncate",
        "uncurry",
        "undefined",
        "unlines",
        "until",
        "unwords",
        "unzip",
        "unzip3",
        "userError",
        "words",
        "writeFile",
        "zip",
        "zip3",
        "zipWith",
        "zipWith3",
    }
)


@beartype
def _reject_negative_zero_call_arg(value: Value, /) -> None:
    """Reject a call argument whose signed zero would not survive."""
    reject_negative_zero(data=value, language_name="Haskell")


@beartype
def _reject_tuple_call_arg(value: Value, /) -> None:
    """Call stubs take Val, which cannot contain a tuple."""
    if value_contains(data=value, predicate=_haskell_is_list):
        msg = (
            "Haskell sequence_format=TUPLE cannot represent "
            "tuple-valued call arguments as Val"
        )
        raise IncompatibleFormatsError(msg)


@beartype
def _reject_native_record_call_arg(_value: Value, /) -> None:
    """Avoid emitting a call stub with the obsolete generic Val type."""
    msg = "Haskell record mode cannot infer concrete call stub types"
    raise IncompatibleFormatsError(msg)


# Work around https://github.com/astral-sh/ty/issues/4573.
if TYPE_CHECKING:
    _BytesEnumMember = enum.member[Callable[[bytes], str]]
    _IntegerEnumMember = enum.member[Callable[[int], str]]
else:
    _BytesEnumMember = enum.member
    _IntegerEnumMember = enum.member


@beartype
def _haskell_is_list(value: Value, /) -> bool:
    """Identify lists that the tuple configuration cannot represent."""
    return isinstance(value, list)


@beartype
@dataclasses.dataclass(frozen=True, kw_only=True)
class Haskell(metaclass=LanguageCls):
    """Haskell language specification.

    The generated output uses custom constructors (``HNull``, ``HBool``,
    ``HList``, ``HMap``, ``HSet``) that are **not** built-in Haskell types.
    To compile the generated code, define a ``Val`` ADT and typeclass
    instances in the consuming module:

    .. code-block:: haskell

       data Val
         = HNull
         | HBool Bool
         | HInt Integer
         | HFloat Double
         | HStr String
         | HList [Val]
         | HMap [(String, Val)]
         | HSet [Val]

       instance Num Val where
           fromInteger = HInt
           negate (HInt n)   = HInt (negate n)
           negate (HFloat f) = HFloat (negate f)
           ...

       instance Fractional Val where
           fromRational r = HFloat (realToFrac r)
           ...

    The ``Num`` / ``Fractional`` instances let numeric literals resolve to
    ``HInt`` / ``HFloat``.

    With the default ``EXPLICIT`` string format, strings are wrapped
    explicitly (e.g. ``HStr "hi"``).  The ``DOUBLE`` format instead uses
    ``OverloadedStrings`` so bare ``"hi"`` literals resolve to ``HStr "hi"``
    via an ``IsString`` instance.

    Args:
        date_format: How to format :class:`datetime.date` values.

            * ``date_formats.HASKELL`` — ``fromGregorian`` call,
              e.g. ``fromGregorian 2024 1 15``.
              Requires the ``time`` package.
            * ``date_formats.ISO`` — ISO 8601 quoted string,
              e.g. ``"2024-01-15"``.

        datetime_format: How to format :class:`datetime.datetime` values.

            * ``datetime_formats.HASKELL`` — ``UTCTime`` constructor,
              e.g. ``UTCTime (fromGregorian 2024 1 15)
              (secondsToDiffTime 45000)``.
              Requires the ``time`` package.
            * ``datetime_formats.ISO`` — ISO 8601 quoted string,
              e.g. ``"2024-01-15T12:30:00"``.

        dict_format: ``DEFAULT`` keeps the generated generic ``Val``;
            ``RECORD`` emits concrete named record types for valid,
            fixed-shape objects. Native records cannot currently be
            passed through generated call stubs.

        type_name: Name of the generated custom type.  Defaults to
            ``"Val"``.

        constructor_prefix: Prefix for generated constructor names.
            Defaults to ``"H"``, producing constructors like ``HNull``,
            ``HBool``, ``HInt``, etc.

        numeric_style: How numeric literals are represented.

            * ``numeric_styles.OVERLOADED`` — emit ``Num`` and
              ``Fractional`` typeclass instances so that bare literals
              like ``42`` and ``3.14`` resolve to the custom type.
            * ``numeric_styles.EXPLICIT`` — wrap every numeric literal
              with its constructor (``HInt 42``, ``HFloat (3.14)``)
              and omit the typeclass instances.

        json_type: When set to ``json_types.AESON_VALUE``, render values
            through the ``aesonQQ`` quasi-quote bracket from ``Data.Aeson.QQ``
            so the output produces a :class:`Data.Aeson.Value` instead
            of Haskell's narrow custom ``Val`` algebraic type.  Dict
            keys must be strings so they remain valid JSON object keys.
    """

    format_call_class_scope_stub = default_format_call_stub

    reserved_module_identifiers: ClassVar[frozenset[str]] = frozenset()
    immutable_variable_modifiers: ClassVar[frozenset[enum.Enum]] = frozenset()
    wrap_in_file_tolerates_pre_indent = False
    module_name_shares_variable_scope = False
    reserved_variable_identifier_pattern: ClassVar[re.Pattern[str] | None] = (
        None
    )
    reserved_call_parameter_identifiers: ClassVar[frozenset[str]] = frozenset()
    reserved_call_parameter_identifier_pattern: ClassVar[
        re.Pattern[str] | None
    ] = None
    uses_data_keyword_for_algebraic_constructors = True
    accepts_type_name_call_target = True
    dotted_call_root_shares_entrypoint_namespace = True
    reserved_bare_call_target_identifiers: ClassVar[frozenset[str]] = (
        frozenset()
    )
    reserved_call_target_head_identifiers: ClassVar[frozenset[str]] = (
        frozenset()
    )
    contextual_call_target_identifiers: ClassVar[frozenset[str]] = frozenset()
    call_parameter_shadowing = CallParameterShadowing.ALLOWED
    reserved_call_target_keywords_case_sensitive = True
    max_variable_identifier_length: ClassVar[int | None] = None
    call_stub_result: ClassVar[CallStubResult | None] = None
    call_literal_syntax: ClassVar[None] = None
    call_target_name_syntax: ClassVar[NewVariableNameSyntax | None] = None
    supports_multiline_dict_layout = True
    pools_map_integer_width = True

    # A wrapped file declares the call target as a function, and a
    # capitalized name is a constructor rather than a function name,
    # so the constructor-target exemption stops there (issue #4525).
    declares_type_name_call_target: ClassVar[bool] = False
    new_variable_name_syntax: ClassVar[NewVariableNameSyntax] = (
        NewVariableNameSyntax.LOWER_ASCII_PRIME_SUFFIX
    )

    format_integer_widened = no_format_integer_widened
    format_integer_beyond_i64 = no_format_integer_beyond_i64
    format_constructor_target: ClassVar["staticmethod[[str], str]"] = (
        staticmethod(identity_constructor_target)
    )
    format_call_variable_assignment = default_format_call_variable_assignment
    sequence_binding_declarations = default_sequence_binding_declarations
    format_call_binding_body_preamble = no_call_binding_body_preamble

    leading_preamble = no_leading_preamble
    extension = ".hs"
    pygments_name = "haskell"
    stringifies_nested_collections = False
    supports_special_floats = True
    supports_variable_names = True
    supports_no_variable_wrap_in_file = False
    wraps_data_dependent_preamble_in_body = False
    dict_supports_heterogeneous_values = True
    supports_local_binding_documents = False
    supports_stateful_free_call_consumers = False
    supports_stateful_receiver_result_checks = False
    supports_native_invocations = False
    supports_dotted_calls = True
    has_free_function_calls = True
    declares_call_parameter_names = True
    reserved_variable_identifiers_case_sensitive: bool = True
    reserved_variable_identifiers: frozenset[str] = (
        _HASKELL_PRELUDE_BINDINGS
    ) | frozenset(
        # The keywords, plus ``main``, the entry point the wrapped file
        # declares alongside the value, plus ``_``: a wildcard pattern
        # rather than a name, which no type signature can head
        # (issue #4510).
        {
            "_",
            "as",
            "case",
            "class",
            "data",
            "default",
            "deriving",
            "do",
            "family",
            "forall",
            "foreign",
            "hiding",
            "if",
            "import",
            "in",
            "infix",
            "infixl",
            "infixr",
            "instance",
            "let",
            "main",
            "module",
            "newtype",
            "of",
            "qualified",
            "safe",
            "then",
            "type",
            "where",
        }
    )
    reserved_identifiers: ClassVar[frozenset[str]] = (
        reserved_variable_identifiers
        - (_HASKELL_PRELUDE_BINDINGS | frozenset({"main"}))
    )
    allows_empty_call_parens = True
    supports_dotted_call_stub = False
    dotted_call_stub_indexes_colliding_helpers = False
    call_returns_expression = True
    supports_json_call_result_binding = False
    supports_zero_parameter_calls = True
    max_call_parameters = NO_CALL_PARAMETER_LIMIT
    supports_inline_multiline_dict_args = True
    supports_standalone_comments_in_wrapped_calls = False
    supports_multi_param_call_wrapper_stub = True
    supports_variadic_calls = False
    supports_dict_literal_as_free_expression = True
    supports_module_name = True
    module_name_must_start_uppercase = True
    supports_empty_dict_key = False
    supports_call_style = True
    supports_bare_mapping_documents = False
    supports_json_object_documents = False
    supports_default_dict_key_type = False
    supports_default_dict_value_type = False
    supports_nullable_object_fallbacks = False
    supports_default_sequence_element_type = False
    supports_key_value_assignment_documents = False
    supports_default_set_element_type = False
    supports_default_ordered_map_value_type = False
    json_type_variant_name_suffix: ClassVar[str | None] = None
    supports_non_ascii_string_literals = True
    supports_multiline_string_literals = False
    supports_empty_sibling_sequence_type_hints = True
    supports_typed_dict_open = False
    language_id: ClassVar[str] = "haskell"
    variant_metadata: ClassVar[VariantMetadata] = VariantMetadata(
        round_trip_capabilities=frozenset(
            {
                RoundTripCapability.I64_BOUNDARIES,
                RoundTripCapability.INTERPOLATION_STRINGS,
                RoundTripCapability.CONTROL_STRINGS,
                RoundTripCapability.EMBEDDED_NUL,
            }
        ),
        modifier_sequence_format_overrides={},
        string_literals_escape_null_byte=True,
        supports_ref_elements_in_tuple_strategy=False,
    )
    supports_record_struct_name_prefix = False
    supports_record_shape_names = False
    record_shape_names_emit_declarations = False
    supports_non_string_dict_keys = False
    checks_raw_control_dict_keys_separately = False

    class DateFormats(DateFormatEnum):
        """Date format options for Haskell."""

        HASKELL = DateFormatConfig(
            formatter=date_ymd_formatter(
                template="HDate (fromGregorian {year} {month} {day})",
            ),
            preamble_lines=(),
            type_produced=dt.date,
        )
        ISO = DateFormatConfig(
            formatter=format_date_iso,
            preamble_lines=("{-# LANGUAGE OverloadedStrings #-}",),
            type_produced=str,
        )

    class DatetimeFormats(DatetimeFormatEnum):
        """Datetime format options for Haskell."""

        HASKELL = DatetimeFormatConfig(
            formatter=_format_datetime_haskell,
            preamble_lines=(),
            type_produced=dt.datetime,
        )
        ISO = DatetimeFormatConfig(
            formatter=format_datetime_iso,
            preamble_lines=("{-# LANGUAGE OverloadedStrings #-}",),
            type_produced=str,
        )

        EPOCH = DatetimeFormatConfig(
            formatter=format_datetime_epoch,
            type_produced=int,
            preamble_lines=(),
        )

    class BytesFormats(FormatValueMixin[Callable[[bytes], str]], enum.Enum):
        """Bytes formatting options."""

        HEX = _BytesEnumMember(value=format_bytes_hex)
        BASE64 = _BytesEnumMember(value=format_bytes_base64)

        def __call__(self, data: bytes, /) -> str:
            """Format bytes."""
            return self.value(data)

    class SequenceFormats(enum.Enum):
        """Sequence type options for Haskell."""

        LIST = SequenceFormatConfig(
            length_is_part_of_type=False,
            sequence_open=fixed_open(open_str="HList ["),
            close="]",
            supports_heterogeneity=True,
            single_element_trailing_comma=False,
            single_element_template=None,
            supports_trailing_comma=True,
            empty_sequence=None,
            preamble_lines=(),
            format_entry=passthrough_sequence_entry,
            typed_opener_fallback=None,
            uses_typed_literal_for_scalars=False,
            requires_uniform_record_shapes=False,
            declared_type="Val",
            narrowed_empty_form=None,
        )
        TUPLE = SequenceFormatConfig(
            length_is_part_of_type=True,
            sequence_open=fixed_open(open_str="("),
            close=")",
            supports_heterogeneity=True,
            single_element_trailing_comma=False,
            single_element_template=None,
            supports_trailing_comma=False,
            empty_sequence=None,
            preamble_lines=(),
            format_entry=passthrough_sequence_entry,
            typed_opener_fallback=None,
            uses_typed_literal_for_scalars=False,
            requires_uniform_record_shapes=False,
            declared_type=None,
            narrowed_empty_form=None,
        )

        def build_setup(self, *, constructor_prefix: str) -> _SequenceSetup:
            """Build sequence configuration and its customized opener."""
            config: SequenceFormatConfig = self.value
            if self is type(self).LIST:
                seq_open = fixed_open(
                    open_str=f"{constructor_prefix}List [",
                )
                return _SequenceSetup(
                    format_config=dataclasses.replace(
                        config,
                        sequence_open=seq_open,
                    ),
                    sequence_open=seq_open,
                )
            return _SequenceSetup(
                format_config=config,
                sequence_open=config.sequence_open,
            )

    class SetFormats(enum.Enum):
        """Set type options for Haskell."""

        SET = SetFormatConfig(
            set_open=fixed_open(open_str="HSet ["),
            close="]",
            empty_set=None,
            preamble_lines=(),
            set_opener_template="",
            supports_heterogeneity=True,
            supports_trailing_comma=True,
        )

    class CommentFormats(enum.Enum):
        """Comment style options."""

        DOUBLE_DASH = CommentConfig(
            prefix="--",
            suffix="",
        )
        BLOCK = CommentConfig(
            prefix="{-",
            suffix=NestingCommentSuffix(object=" -}"),
        )

    class DeclarationStyles(enum.Enum):
        """Declaration style options."""

        ASSIGN = DeclarationStyleConfig(
            formatter=variable_declaration_formatter(
                template="{name} = {value}"
            ),
            supports_redefinition=False,
        )

    class DictEntryStyles(enum.Enum):
        """Dict entry style options."""

        DEFAULT = enum.auto()

    class DictFormats(enum.Enum):
        """Dict/map format options."""

        DEFAULT = enum.auto()
        RECORD = enum.auto()

    class EmptyDictKey(enum.Enum):
        """Empty dict key options."""

        ALLOW = enum.auto()

    class FloatFormats(
        FloatSpecialsMixin,
        enum.Enum,
        positive_infinity="(1/0)",
        negative_infinity="(-1/0)",
        nan="(0/0)",
    ):
        """Float format options."""

        REPR = enum.member(value=format_float_repr)
        SCIENTIFIC = enum.member(value=format_float_scientific)
        FIXED = enum.member(value=format_float_fixed)

    class IntegerFormats(FormatValueMixin[Callable[[int], str]], enum.Enum):
        """Integer format options."""

        DECIMAL = _IntegerEnumMember(value=str)
        HEX = _IntegerEnumMember(value=format_integer_hex)
        OCTAL = _IntegerEnumMember(value=format_integer_octal)
        BINARY = _IntegerEnumMember(value=format_integer_binary)

        def __call__(self, value: int, /) -> str:
            """Format an integer."""
            formatter: Callable[[int], str] = self.value
            return formatter(value)

    class NumericLiteralSuffixes(enum.Enum):
        """Numeric literal suffix options."""

        NONE = enum.auto()

    class NumericSeparators(enum.Enum):
        """Numeric separator options."""

        NONE = enum.auto()

    class NumericStyles(enum.Enum):
        """Numeric literal style options.

        ``OVERLOADED`` emits ``Num`` and ``Fractional`` typeclass
        instances so that bare numeric literals (``42``, ``3.14``)
        resolve to the custom type via ``fromInteger`` /
        ``fromRational``.

        ``EXPLICIT`` wraps every numeric literal with its constructor
        (``HInt 42``, ``HFloat 3.14``) and omits the typeclass
        instances.
        """

        OVERLOADED = enum.auto()
        EXPLICIT = enum.auto()

    numeric_styles = NumericStyles

    class StringFormats(enum.Enum):
        """String format options."""

        DOUBLE = enum.auto()
        EXPLICIT = enum.auto()

    class TrailingCommas(enum.Enum):
        """Trailing comma options."""

        NO = TrailingCommaConfig(multiline_trailing_comma=False)

    date_formats = DateFormats
    datetime_formats = DatetimeFormats
    bytes_formats = BytesFormats
    sequence_formats = SequenceFormats
    set_formats = SetFormats
    comment_formats = CommentFormats

    class VariableTypeHints(enum.Enum):
        """Variable type hint options."""

        NEVER = enum.auto()
        SAFE = enum.auto()

    variable_type_hints_formats = VariableTypeHints
    declaration_styles = DeclarationStyles
    dict_entry_styles = DictEntryStyles
    dict_formats = DictFormats
    empty_dict_keys = EmptyDictKey
    float_formats = FloatFormats
    integer_formats = IntegerFormats
    integer_width_strategies = BareIntegerWidthStrategies
    numeric_literal_suffixes = NumericLiteralSuffixes
    numeric_separators = NumericSeparators
    string_formats = StringFormats
    trailing_commas = TrailingCommas

    class StatementTerminatorStyles(enum.Enum):
        """Statement terminator options."""

        SEMICOLON = enum.auto()

    statement_terminator_styles = StatementTerminatorStyles

    class CallStyles(enum.Enum):
        """Haskell call style options."""

        CURRIED = CommandCallStyle(
            arg_separator=" ",
        )
        POSITIONAL = PositionalCallStyle(
            arg_separator=", ", parenthesize_each_arg=False
        )

    call_styles = CallStyles

    class Modifiers(enum.Enum):
        """C++/Java/C#-style declaration modifiers: this language has none."""

    modifiers = Modifiers

    class HeterogeneousStrategies(enum.Enum):
        """Heterogeneous-scalar strategy options — this language only
        supports raising.
        """

        ERROR = NO_HETEROGENEOUS_BEHAVIOR

    heterogeneous_strategies = HeterogeneousStrategies

    class BoolFormats(enum.Enum):
        """Empty: this language has no alternative boolean formats."""

    bool_formats = BoolFormats

    class JsonTypes(JsonType):
        """JSON value type options for Haskell."""

        AESON_VALUE = "Data.Aeson.Value"
        """``Data.Aeson.Value`` — the dynamic JSON value type from the
        ``aeson`` package.
        """

    json_types = JsonTypes

    class VersionFormats(enum.Enum):
        """Version options for Haskell."""

        GHC2021 = enum.auto()

    version_formats = VersionFormats

    module_name_case: ClassVar[IdentifierCase] = IdentifierCase.PASCAL

    modifier_combinations: ClassVar[tuple[ModifierCombination, ...]] = ()
    identifier_cases: ClassVar[tuple[IdentifierCase, ...]] = (
        IdentifierCase.CAMEL,
        IdentifierCase.PASCAL,
    )
    supported_ref_cases: ClassVar[frozenset[IdentifierCase]] = (
        NON_KEBAB_REF_CASES
    )

    def validate_spec_for_data(self, data: Value) -> None:
        """Reject data this spec cannot produce valid code for.

        A tuple sequence nested inside the generated ``Val`` ADT has
        no constructor, and ``Data.Aeson`` has no signed zero
        (issue #4543).
        """
        if self.json_type is not None:
            reject_negative_zero(data=data, language_name="Haskell")
        if self.dict_format is type(self.dict_format).RECORD:
            if (
                re.fullmatch(
                    pattern=r"[A-Z][A-Za-z0-9_']*",
                    string=self.type_name,
                )
                is None
            ):
                msg = "Haskell record mode requires a valid type_name"
                raise UnrepresentableInputError(msg)
            if self.json_type is not None:
                msg = "Haskell records cannot be combined with json_type"
                raise IncompatibleFormatsError(msg)
            if self.sequence_format is not type(self.sequence_format).LIST:
                msg = "Haskell records require sequence_format=LIST"
                raise IncompatibleFormatsError(msg)
            _validate_haskell_native_record(
                data=data, reserved_fields=self.reserved_variable_identifiers
            )
        if (
            self.json_type is not None
            or self.sequence_format is not type(self.sequence_format).TUPLE
        ):
            return
        if isinstance(data, list):
            nested_list = any(
                value_contains(
                    data=item,
                    predicate=_haskell_is_list,
                )
                for item in data
            )
        else:
            nested_list = value_contains(
                data=data,
                predicate=_haskell_is_list,
            )
        if nested_list:
            msg = (
                "Haskell sequence_format=TUPLE cannot represent a tuple "
                "nested inside the generated Val ADT. Use LIST or select "
                "the Aeson JSON type."
            )
            raise IncompatibleFormatsError(msg)

    @cached_property
    @beartype
    def validate_call_arg(self) -> Callable[[Value], None]:
        """Return call-argument validation for this language.

        Under ``json_type`` an argument is built as the same JSON value
        a declared one is, and that type has no signed zero, so it
        faces the same rejection; ``validate_spec_for_data`` covers
        only the ``literalize`` path (issue #4543).
        """
        if self.json_type is not None:
            return _reject_negative_zero_call_arg
        if self.dict_format is type(self.dict_format).RECORD:
            return _reject_native_record_call_arg
        if self.sequence_format is type(self.sequence_format).TUPLE:
            return _reject_tuple_call_arg
        return no_validate_call_arg

    format_call_statement = default_format_call_statement

    def wrap_in_file(
        self,
        content: str,
        context: FileWrapperContext,
    ) -> str:
        """Wrap a Haskell variable binding in a module."""
        variable_name = context.variable_name
        body_preamble = context.body_preamble
        preamble = join_preamble(
            entries=_haskell_imports_first(lines=body_preamble)
        )
        if variable_name == "":
            # Call mode: bare expressions are not valid at module
            # top level in Haskell, so wrap them in ``main``. Each call
            # statement is bound via ``_ <- `` so that stubs returning
            # ``IO Val`` (``StubReturn.VALUE``) do not trigger
            # ``-Wunused-do-bind``. ``_ <-`` is also valid when the
            # action returns ``IO ()``.
            # The bind belongs to the statement, not to each of its
            # lines: a multiline collection argument spans several, and
            # the rest are continuations that need only the same margin
            # (issue #4527).
            indented = join_preamble(
                entries=tuple(
                    f"{self.indent}_ <- {statement}".replace(
                        "\n", f"\n{self.indent}"
                    )
                    for statement in split_statements(
                        content=content,
                        quotes='"',
                        line_comment_prefixes=("--",),
                    )
                )
            )
            return (
                f"module {self.module_name} where\n"
                + preamble
                + "\nmain :: IO ()\nmain = do\n"
                + indented
                + f"\n{self.indent}pure ()"
            )
        return (
            f"module {self.module_name} where\n"
            + preamble
            + "\n"
            + content
            + f"\nmain :: IO ()\nmain = seq {variable_name} (return ())"
        )

    def wrap_calls_with_declarations(
        self,
        declarations: tuple[str, ...],
        calls: str,
        context: FileWrapperContext,
    ) -> str:
        """Wrap a sequence of top-level *declarations* alongside a
        block of bare call expressions.

        Top-level ``name :: Type`` / ``name = value`` bindings stay at
        module scope and only the *calls* go inside ``main = do``.  The
        integration harness pairs each ``$ref`` declaration's
        ``bare_code`` with a downstream call and uses this hook to
        avoid concatenating both halves into one ``content`` string,
        which would otherwise force the bindings into a ``do``-block
        where they would need ``let`` injection.
        """
        body_preamble = context.body_preamble
        preamble = join_preamble(
            entries=_haskell_imports_first(lines=body_preamble)
        )
        indented_calls = join_preamble(
            entries=tuple(
                f"{self.indent}_ <- {statement}".replace(
                    "\n", f"\n{self.indent}"
                )
                for statement in split_statements(
                    content=calls,
                    quotes='"',
                    line_comment_prefixes=("--",),
                )
            )
        )
        declaration_block = join_preamble(entries=declarations)
        effective_declaration_block = ""
        if declaration_block != "":
            effective_declaration_block = declaration_block + "\n"
        return (
            f"module {self.module_name} where\n"
            + preamble
            + "\n"
            + (effective_declaration_block)
            + "main :: IO ()\nmain = do\n"
            + indented_calls
            + f"\n{self.indent}pure ()"
        )

    wrap_combined_in_file: ClassVar[
        "staticmethod[[str, str, FileWrapperContext], str]"
    ] = unsupported_wrap_combined_in_file_static

    date_format: DateFormats = DateFormats.HASKELL
    datetime_format: DatetimeFormats = DatetimeFormats.HASKELL
    bytes_format: BytesFormats = BytesFormats.HEX
    sequence_format: SequenceFormats = SequenceFormats.LIST
    set_format: SetFormats = SetFormats.SET
    variable_type_hints: VariableTypeHints = VariableTypeHints.NEVER
    comment_format: CommentFormats = CommentFormats.DOUBLE_DASH
    declaration_style: DeclarationStyles = DeclarationStyles.ASSIGN
    dict_entry_style: DictEntryStyles = DictEntryStyles.DEFAULT
    dict_format: DictFormats = DictFormats.DEFAULT
    float_format: FloatFormats = FloatFormats.REPR
    integer_format: IntegerFormats = IntegerFormats.DECIMAL
    integer_width_strategy: BareIntegerWidthStrategies = (
        BareIntegerWidthStrategies.BARE
    )
    numeric_literal_suffix: NumericLiteralSuffixes = (
        NumericLiteralSuffixes.NONE
    )
    numeric_separator: NumericSeparators = NumericSeparators.NONE
    numeric_style: NumericStyles = NumericStyles.OVERLOADED
    string_format: StringFormats = StringFormats.EXPLICIT
    trailing_comma: TrailingCommas = TrailingCommas.NO
    statement_terminator_style: StatementTerminatorStyles = (
        StatementTerminatorStyles.SEMICOLON
    )
    call_style: CallStyles = CallStyles.CURRIED
    heterogeneous_strategy: HeterogeneousStrategies = (
        HeterogeneousStrategies.ERROR
    )
    json_type: JsonTypes | None = None
    # Keep in sync with the `-XGHC2021` flag passed to the Haskell
    # linter in `.github/workflows/lint.yml`.
    language_version: VersionFormats = VersionFormats.GHC2021
    indent: str = "    "
    module_name: str = "Check"
    type_name: str = "Val"
    constructor_prefix: str = "H"

    indent_closing_delimiter: ClassVar[bool] = True
    element_separator: ClassVar[str] = ", "
    skip_null_dict_values: ClassVar[bool] = False
    supports_scalar_before_comments: ClassVar[bool] = False
    supports_scalar_inline_comments: ClassVar[bool] = True
    statement_terminator: ClassVar[str] = ""
    static_body_preamble: ClassVar[Sequence[str]] = ()
    special_float_preamble: ClassVar[tuple[str, ...]] = ()

    @cached_property
    @beartype
    def supports_collection_comments(self) -> bool:
        """Whether a comment can sit inside the rendered value.

        The ``aesonQQ`` quasi-quote holds one JSON document, and
        JSON has no comments, so a comment written inside
        it would be text the parser refuses.  The comments go
        before the declaration instead (issue #4546).
        """
        return not self._json_type_active

    @cached_property
    @beartype
    def _json_type_active(self) -> bool:
        """Return whether Haskell should render via
        ``Data.Aeson.Value``.
        """
        return self.json_type is not None

    @cached_property
    @beartype
    def static_preamble(self) -> Sequence[str]:
        """Static preamble lines emitted once per file.

        When :attr:`json_type` is active the ``QuasiQuotes`` pragma is
        emitted here so the ``aesonQQ`` quasi-quote bracket from
        ``Data.Aeson.QQ`` can parse the inline JSON document into a
        :class:`Data.Aeson.Value` at compile time.
        """
        if self._json_type_active:
            return _AESON_VALUE_STATIC_PREAMBLE
        if self.dict_format is type(self.dict_format).RECORD:
            return ("{-# LANGUAGE DuplicateRecordFields #-}",)
        return ()

    @cached_property
    @beartype
    def format_sequence_entry(self) -> Callable[[Value, str], str]:
        """Format a sequence entry."""
        return passthrough_sequence_entry

    def _native_record_field_type(self, request: RecordFieldType, /) -> str:
        """Return the concrete Haskell type of a record field."""
        if request.record_name is not None:
            return request.record_name
        if request.element_record_name is not None:
            return f"[{request.element_record_name}]"
        return self._native_value_type(data=request.value)

    def _native_value_type(self, data: Value) -> str:
        """Return a concrete type for a native scalar or list."""
        if isinstance(data, list):
            if len(data) == 0:
                msg = (
                    "Haskell record mode cannot infer empty list element types"
                )
                raise UnrepresentableInputError(msg)
            return f"[{self._native_value_type(data=data[0])}]"
        scalar_types: dict[type[object], str] = {
            bool: "Bool",
            int: "Integer",
            float: "Double",
            str: "String",
            bytes: "String",
            dt.time: "String",
        }
        scalar_type = scalar_types.get(type(data))
        if scalar_type is not None:
            return scalar_type
        if isinstance(data, dt.datetime):
            datetime_types: dict[type[object], str] = {
                int: "Integer",
                str: "String",
                dt.datetime: "UTCTime",
            }
            return datetime_types[self.datetime_format.value.type_produced]
        if isinstance(data, dt.date):
            date_types: dict[type[object], str] = {
                str: "String",
                dt.date: "Day",
            }
            return date_types[self.date_format.value.type_produced]
        msg = f"Haskell record mode cannot type {type(data).__name__}"
        raise UnrepresentableInputError(msg)

    def _native_declared_type(self, data: Value) -> str:
        """Name the record type of a bound value or infer its scalar
        type.
        """
        lookup = self._native_record_strategy.record_name_for_value
        nested = nested_record_sequence_type(
            value=data, record_name_for_value=lookup
        )
        if nested is not None:
            depth, name = nested
            return "[" * depth + name + "]" * depth
        return self._native_value_type(data=data)

    @cached_property
    @beartype
    def _native_record_strategy(self) -> ActiveRecordStrategy:
        """Build shared record naming, rendering, and declarations."""
        return build_record_strategy(
            renderer=RecordRenderer(
                name_prefix=self.type_name,
                record_shape_names={},
                field_identifier=_haskell_native_field_identifier,
                field_identifier_key=identity_field_identifier_key,
                field_type=self._native_record_field_type,
                render_declaration=_haskell_native_record_declaration,
                render_literal=_haskell_native_record_literal,
                field_type_names_nested_records=True,
                suppressed_custom_names=frozenset(),
            ),
            widen_unrecordizable_nested_sibling_maps=False,
            derecordized_map_open=None,
        )

    @cached_property
    @beartype
    def format_set_entry(self) -> Callable[[Value, str], str]:
        """Format a set entry."""
        return passthrough_set_entry

    @cached_property
    @beartype
    def data_dependent_preamble(self) -> Callable[[Value], tuple[str, ...]]:
        """Return data-dependent preamble lines."""
        return no_data_preamble

    @cached_property
    @beartype
    def heterogeneous_behavior(self) -> HeterogeneousBehavior:
        """Return the heterogeneous-behavior config."""
        if self._json_type_active:
            return dataclasses.replace(
                NO_HETEROGENEOUS_BEHAVIOR,
                skip_scalar_checks=True,
            )
        if self.dict_format is type(self.dict_format).RECORD:
            return self._native_record_strategy.behavior
        return self.heterogeneous_strategy.value

    call_data_dependent_preamble = default_call_data_dependent_preamble

    type_hint_collection_preamble_lines = (
        default_type_hint_collection_preamble_lines
    )

    @cached_property
    @beartype
    def null_literal(self) -> str:
        """Literal representing ``None``."""
        return f"{self.constructor_prefix}Null"

    @cached_property
    @beartype
    def true_literal(self) -> str:
        """Literal representing ``True``."""
        if self.dict_format is type(self.dict_format).RECORD:
            return "True"
        return f"{self.constructor_prefix}Bool True"

    @cached_property
    @beartype
    def false_literal(self) -> str:
        """Literal representing ``False``."""
        if self.dict_format is type(self.dict_format).RECORD:
            return "False"
        return f"{self.constructor_prefix}Bool False"

    @cached_property
    @beartype
    def _seq_setup(self) -> _SequenceSetup:
        """Shared sequence format setup."""
        return self.sequence_format.build_setup(
            constructor_prefix=self.constructor_prefix,
        )

    @cached_property
    @beartype
    def sequence_format_config(self) -> SequenceFormatConfig:
        """Configuration for the chosen sequence format."""
        if self._json_type_active:
            return _AESON_VALUE_SEQUENCE_CONFIG
        if self.dict_format is type(self.dict_format).RECORD:
            fmt: SequenceFormatConfig = self.sequence_format.value
            return dataclasses.replace(
                fmt,
                sequence_open=fixed_open(open_str="["),
                supports_heterogeneity=False,
                declared_type=None,
            )
        return self._seq_setup.format_config

    @cached_property
    @beartype
    def sequence_open(self) -> Callable[[list[Value]], str]:
        """Callable that returns the opening delimiter for a sequence."""
        if self._json_type_active:
            return _AESON_VALUE_SEQUENCE_CONFIG.sequence_open
        if self.dict_format is type(self.dict_format).RECORD:
            return fixed_open(open_str="[")
        return self._seq_setup.sequence_open

    @cached_property
    @beartype
    def set_format_config(self) -> SetFormatConfig:
        """Configuration for the chosen set format."""
        if self._json_type_active:
            return _AESON_VALUE_SET_CONFIG
        return dataclasses.replace(
            self.set_format.value,
            set_open=fixed_open(
                open_str=f"{self.constructor_prefix}Set [",
            ),
        )

    @cached_property
    @beartype
    def _string_fmts(self) -> _StringFormatters:
        """Shared string/bytes/dict-entry formatters."""
        return _build_string_formatters(
            string_format_name=(
                "DOUBLE"
                if self.dict_format is type(self.dict_format).RECORD
                else self.string_format.name
            ),
            constructor_prefix=self.constructor_prefix,
            base_format_bytes=self.bytes_format,
        )

    @cached_property
    @beartype
    def format_dict_key(self) -> Callable[[str], str]:
        """Render keys with the shared unwrapped string formatter."""
        return self._string_fmts.format_dict_key

    @cached_property
    @beartype
    def format_string(self) -> Callable[[str], str]:
        """Callable that formats a string value as a quoted literal."""
        return self._string_fmts.format_string

    @cached_property
    @beartype
    def format_bytes(self) -> Callable[[bytes], str]:
        """Callable that formats a bytes value as a string literal."""
        return self._string_fmts.format_bytes

    @cached_property
    @beartype
    def dict_format_config(self) -> DictFormatConfig:
        """Configuration for dict formatting."""
        if self._json_type_active:
            return _AESON_VALUE_DICT_CONFIG
        map_open = f"{self.constructor_prefix}Map ["
        return DictFormatConfig(
            dict_open=fixed_open(open_str=map_open),
            close="]",
            format_entry=self._string_fmts.format_dict_entry,
            empty_dict=None,
            preamble_lines=(),
            narrowed_open=None,
            supports_trailing_comma=True,
            narrowed_empty_form=None,
        )

    @cached_property
    @beartype
    def ordered_map_format_config(self) -> OrderedMapFormatConfig:
        """Configuration for ordered-map formatting."""
        if self._json_type_active:
            return _AESON_VALUE_ORDERED_MAP_CONFIG
        map_open = f"{self.constructor_prefix}Map ["
        return OrderedMapFormatConfig(
            ordered_map_open=fixed_open(open_str=map_open),
            close="]",
            preamble_lines=(),
        )

    @cached_property
    @beartype
    def format_ordered_map_entry(self) -> Callable[[str, Value, str], str]:
        """Callable that formats one ordered-map entry."""
        return self._string_fmts.format_dict_entry

    @cached_property
    @beartype
    def trailing_comma_config(self) -> TrailingCommaConfig:
        """Configuration for trailing-comma behavior."""
        return self.trailing_comma.value

    @cached_property
    @beartype
    def _date_fmts(self) -> _DateTimeFormatters:
        """Shared date/datetime formatter bundle."""
        return _build_date_formatters(
            date_format_name=self.date_format.name,
            date_formatter=self.date_format,
            datetime_format_name=self.datetime_format.name,
            datetime_formatter=self.datetime_format,
            constructor_prefix=self.constructor_prefix,
            is_explicit=self._string_fmts.is_explicit,
        )

    @cached_property
    @beartype
    def format_date(self) -> Callable[[dt.date], str]:
        """Callable that formats a date as a string literal."""
        if self.dict_format is type(self.dict_format).RECORD:
            if self.date_format.value.type_produced is dt.date:
                return date_ymd_formatter(
                    template="fromGregorian {year} {month} {day}"
                )
            return self.date_format
        return self._date_fmts.format_date

    @cached_property
    @beartype
    def format_datetime(self) -> Callable[[dt.datetime], str]:
        """Callable that formats a datetime as a string literal."""
        if self.dict_format is type(self.dict_format).RECORD:
            if self.datetime_format.value.type_produced is dt.datetime:
                return _haskell_utc_time_expression
            return self.datetime_format
        if (
            self.datetime_format is type(self.datetime_format).EPOCH
            and self.numeric_style is type(self.numeric_style).EXPLICIT
        ):
            return datetime_epoch_formatter(format_integer=self.format_integer)
        return self._date_fmts.format_datetime

    @cached_property
    @beartype
    def format_time(self) -> Callable[[dt.time], str]:
        """Callable that formats a time as a string literal."""
        if self.dict_format is type(self.dict_format).RECORD:
            return format_time_iso
        if self._string_fmts.is_explicit:
            _str_pfx = f"{self.constructor_prefix}Str "

            @beartype
            def _explicit_time(value: dt.time) -> str:
                """Wrap a bare ISO time literal with the HStr
                constructor.
                """
                return f"{_str_pfx}{format_time_iso(value=value)}"

            return _explicit_time
        return format_time_iso

    @cached_property
    @beartype
    def format_float(self) -> Callable[[float], str]:
        """Callable that formats a float value as a literal."""
        if self.dict_format is type(self.dict_format).RECORD:
            return self.float_format
        if self.numeric_style is type(self.numeric_style).EXPLICIT:
            _float_prefix = f"{self.constructor_prefix}Float "
            _base_format_float: Callable[[float], str] = self.float_format

            @beartype
            def _wrap_float(value: float) -> str:
                """Delegate to module-level implementation."""
                return _wrap_float_with_constructor(
                    value=value,
                    float_prefix=_float_prefix,
                    base_format_float=_base_format_float,
                )

            return _wrap_float

        @beartype
        def _implicit_float(value: float) -> str:
            """Evaluate special-float division inside Double, before
            constructing the tagged value.
            """
            if math.isfinite(value):
                return self.float_format(value)
            return _wrap_float_with_constructor(
                value=value,
                float_prefix=f"{self.constructor_prefix}Float ",
                base_format_float=self.float_format,
            )

        return _implicit_float

    @cached_property
    @beartype
    def format_integer(self) -> Callable[[int], str]:
        """Callable that formats an int value as a literal."""
        if self.dict_format is type(self.dict_format).RECORD:
            return self.integer_format
        if self.numeric_style is type(self.numeric_style).EXPLICIT:
            _int_prefix = f"{self.constructor_prefix}Int "
            _base_format_integer: Callable[[int], str] = self.integer_format

            @beartype
            def _wrap_integer(value: int) -> str:
                """Delegate to module-level implementation."""
                return _wrap_integer_with_constructor(
                    value=value,
                    int_prefix=_int_prefix,
                    base_format_integer=_base_format_integer,
                )

            return _wrap_integer
        return self.integer_format

    @cached_property
    @beartype
    def comment_config(self) -> CommentConfig:
        """Configuration for the language's comment syntax."""
        return self.comment_format.value

    @cached_property
    @beartype
    def _decl_fmts(self) -> _DeclarationFormatters:
        """Shared declaration/assignment formatter bundle."""
        declaration_config: DeclarationStyleConfig = (
            self.declaration_style.value
        )
        sequence_config: SequenceFormatConfig = self.sequence_format.value
        return _build_declaration_formatters(
            declaration_config=declaration_config,
            sequence_config=sequence_config,
            type_name=self.type_name,
        )

    @cached_property
    @beartype
    def format_variable_declaration(
        self,
    ) -> Callable[[str, str, Value, frozenset[enum.Enum]], str]:
        """Callable that formats a new variable declaration."""
        if self._json_type_active:
            return _format_haskell_json_declaration
        if self.dict_format is type(self.dict_format).RECORD:
            base = self.declaration_style.value.formatter

            @beartype
            def _native_declaration(
                name: str,
                value: str,
                data: Value,
                modifiers: frozenset[enum.Enum],
            ) -> str:
                """Bind a native value with its concrete inferred type."""
                self.validate_self_contained_assignment(name, data)
                declared_type = self._native_declared_type(data=data)
                return f"{name} :: {declared_type}\n" + base(
                    name, value, data, modifiers
                )

            return _native_declaration
        return self._decl_fmts.format_variable_declaration

    def validate_self_contained_assignment(
        self, name: str, data: Value, /
    ) -> None:
        """Keep native record labels separate from module binding
        names.
        """
        if self._json_type_active:
            return
        if self.dict_format is type(self.dict_format).RECORD and any(
            name in shape.keys
            for shape in collect_record_shapes(data=data).values()
        ):
            msg = (
                "Haskell record mode cannot use a field label "
                f"as variable name {name!r}"
            )
            raise UnrepresentableInputError(msg)

    def prepare_reference_literal(
        self,
        value: str,
        data: Value,
        ref_key: str,
        ref_case: IdentifierCase | None,
        /,
    ) -> str:
        """Retain reference holes for JSON interpolation."""
        if not self._json_type_active:
            return value
        return _AesonReferenceLiteral(
            value, data=data, ref_key=ref_key, ref_case=ref_case
        )

    def reference_binding_data_dependent_preamble(
        self, data: Value, /
    ) -> tuple[str, ...]:
        """Retain imports used by the selected reference
        representation.
        """
        return self.data_dependent_preamble(data)

    @staticmethod
    def reference_declaration_imports(
        entries: Sequence[str], /
    ) -> tuple[str, ...]:
        """Preserve supporting imports for the caller's declarations."""
        return tuple(entries)

    def format_reference_variable_declaration(
        self,
        name: str,
        value: str,
        data: Value,
        modifiers: frozenset[enum.Enum],
        /,
    ) -> str:
        """Keep a JSON alias as an existing Value rather than a
        document.
        """
        if self._json_type_active:
            return f"{name} :: Value\n{name} = {value}"
        return self.format_variable_declaration(name, value, data, modifiers)

    def format_reference_variable_assignment(
        self, name: str, value: str, data: Value, /
    ) -> str:
        """Retain the representation of a reference on rebinding."""
        if self._json_type_active:
            return f"{name} :: Value\n{name} = {value}"
        return self.format_variable_assignment(name, value, data)

    def assignment_declares_binding(self, _data: Value, /) -> bool:
        """Retain whether the configured literal assignment declares a
        name.
        """
        return self._json_type_active

    reference_assignment_declares_binding = assignment_declares_binding

    @property
    def call_assignment_declares_binding(self) -> bool:
        """JSON assignments carry a literal-only annotation and parser."""
        return not self._json_type_active

    @cached_property
    @beartype
    def format_variable_assignment(
        self,
    ) -> Callable[[str, str, Value], str]:
        """Callable that formats an assignment to an existing variable."""
        if self._json_type_active:
            return _format_haskell_json_assignment
        return self._decl_fmts.format_variable_assignment

    @cached_property
    @beartype
    def format_call_variable_declaration(
        self,
    ) -> Callable[[str, str, Value, frozenset[enum.Enum]], str]:
        """Callable that formats a declaration binding a call expression.

        The literal-binding declaration is prepended with a
        ``name :: Type`` annotation derived from the bound value's
        runtime tagged-enum type; a call expression has no such tag,
        so the annotation is omitted and Haskell infers the call's
        return type instead.
        """
        return self.declaration_style.value.formatter

    @staticmethod
    def format_call_binding_file_pragmas() -> tuple[str, ...]:
        """File-level pragma emitted alongside a ``wrap_in_file``
        scaffold whose top level contains an inference-bound call
        result.

        Without an explicit signature the binding trips
        ``-Wmissing-signatures`` under ``-Wall -Werror``; the
        literalizer cannot synthesize a signature because the call's
        return type is not known at render time.
        """
        return ("{-# OPTIONS_GHC -Wno-missing-signatures #-}",)

    @cached_property
    @beartype
    def _preamble(self) -> _PreambleSetup:
        """Shared preamble setup bundle."""
        date_config: DateFormatConfig = self.date_format.value
        datetime_config: DatetimeFormatConfig = self.datetime_format.value
        setup = _build_preamble_setup(
            date_format=self.date_format,
            datetime_format=self.datetime_format,
            date_config=date_config,
            datetime_config=datetime_config,
            is_explicit=self._string_fmts.is_explicit,
            type_name=self.type_name,
            constructor_prefix=self.constructor_prefix,
            emit_num=self.numeric_style
            is not type(self.numeric_style).EXPLICIT,
            indent=self.indent,
        )
        if self.integer_format is not type(self.integer_format).BINARY:
            return setup
        # Binary integer literals (``0b...``) are not part of Haskell 2010
        # and need the ``BinaryLiterals`` extension. ``GHC2021`` bundles
        # it already, so the pragma is redundant under that base, but
        # emitting it unconditionally lets the generated code build under
        # either base without ceremony. Hex (``0x``) and octal (``0o``)
        # are standard either way.
        scalar_preamble = setup.scalar_preamble
        return dataclasses.replace(
            setup,
            scalar_preamble={
                **scalar_preamble,
                int: (
                    *scalar_preamble.get(int, ()),
                    "{-# LANGUAGE BinaryLiterals #-}",
                ),
            },
        )

    @cached_property
    @beartype
    def scalar_preamble(self) -> dict[type[object], tuple[str, ...]]:
        """Per-instance scalar preamble for Haskell imports.

        Under :attr:`json_type` every temporal value is folded into the
        JSON text as an ISO-8601 string and every string ships inside
        that same JSON literal, so the per-scalar Haskell extension
        directives and imports that the configured ``date_format`` /
        ``datetime_format`` would otherwise add do not apply.
        """
        if self._json_type_active:
            return {}
        if self.dict_format is type(self.dict_format).RECORD:
            return {}
        return self._preamble.scalar_preamble

    scalar_body_preamble: ClassVar[
        cached_property[dict[type[object], tuple[str, ...]]]
    ] = cached_property(func=empty_scalar_preamble)

    @cached_property
    @beartype
    def compute_body_preamble(
        self,
    ) -> Callable[[frozenset[type[object]], Value], tuple[str, ...]]:
        """Compute body-preamble lines for Haskell data declarations.

        Under :attr:`json_type` the body preamble is reduced to the
        ``Data.Aeson`` and ``Data.Aeson.QQ`` imports needed by the
        ``aesonQQ`` quasi-quote bracket, so the custom ``Val`` algebraic type
        and its ``Num`` / ``IsString`` instances are not emitted.
        """
        if self._json_type_active:
            return _aeson_value_body_preamble
        if self.dict_format is type(self.dict_format).RECORD:

            @beartype
            def _native_body_preamble(
                types: frozenset[type[object]], data: Value, /
            ) -> tuple[str, ...]:
                """Import the time types needed by concrete fields."""
                imports: tuple[str, ...] = ()
                if (
                    dt.date in types
                    and self.date_format.value.type_produced is dt.date
                ) or (
                    dt.datetime in types
                    and self.datetime_format.value.type_produced is dt.datetime
                ):
                    imports = (import_preamble(code="import Data.Time"),)
                return imports + self._native_record_strategy.preamble(data)

            return _native_body_preamble
        return self._preamble.compute_body_preamble

    @cached_property
    @beartype
    def call_style_config(self) -> CallStyle:
        """Configuration for the chosen call style."""
        config: CallStyle = self.call_style.value
        return config

    @cached_property
    @beartype
    def format_call_stub(
        self,
    ) -> Callable[
        [Sequence[str], Sequence[str], StubReturn, Sequence[Value]],
        tuple[str, ...],
    ]:
        """Callable that returns Haskell stub declarations for a call."""
        stub_type_name = "Value"
        if not self._json_type_active:
            stub_type_name = self.type_name
        return _build_haskell_call_stub(
            type_name=stub_type_name,
            curried=isinstance(self.call_style.value, CommandCallStyle),
            validate_arg=self.validate_call_arg,
        )

    @cached_property
    @beartype
    def format_call_arg(self) -> Callable[[Value, str], str]:
        """Callable that rewrites a formatted direct call argument.

        Curried calls parenthesize each argument so that constructor
        applications (``HInt 1``) are not parsed as additional arguments
        to the outer call.
        """
        if self._json_type_active:
            return _format_haskell_json_call_arg
        if isinstance(self.call_style.value, CommandCallStyle):
            return _haskell_format_call_arg
        return identity_call_arg

    @cached_property
    @beartype
    def format_call_preamble_stub(
        self,
    ) -> Callable[
        [Sequence[str], Sequence[str], StubReturn, Sequence[Value]],
        tuple[str, ...],
    ]:
        """Callable that returns preamble stub declarations."""
        return _haskell_call_preamble_stub

    format_call_target = default_format_call_target

    format_call_ref_identifier = default_format_call_ref_identifier

    format_call_arg_ref_identifier = default_format_call_arg_ref_identifier

    format_call_arg_ref_identifier_consumable = (
        default_format_call_arg_ref_identifier_consumable
    )

    consumable_ref_value_inhibits_consuming_form = (
        default_consumable_ref_value_inhibits_consuming_form
    )


register_json_native_document_fast(language_cls=Haskell)
