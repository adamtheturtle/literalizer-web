"""Standard ML language specification."""

import dataclasses
import datetime as dt
import enum
import math
import re
from collections.abc import Callable, Mapping, Sequence
from functools import cached_property, partial
from types import MappingProxyType
from typing import TYPE_CHECKING, ClassVar

from beartype import beartype

from literalizer._comments import NestingCommentSuffix
from literalizer._formatters.collection_openers import (
    fixed_open,
)
from literalizer._formatters.format_dates import (
    date_ymd_formatter,
    datetime_epoch_seconds,
    datetime_ymdhms_formatter,
    format_date_iso,
    format_datetime_epoch,
    format_datetime_iso,
    format_time_iso,
)
from literalizer._formatters.format_entries import (
    assignment_formatter_from_declaration,
    declaration_formatter_ignoring_modifiers,
    format_bytes_base64,
    format_bytes_hex,
    passthrough_sequence_entry,
    tuple_dict_entry,
    variable_declaration_formatter,
)
from literalizer._formatters.format_floats import (
    format_float_fixed,
    format_float_repr,
    format_float_scientific,
)
from literalizer._formatters.format_integers import (
    I64_MAX,
    I64_MIN,
    format_integer_hex,
    make_overflow_fallback_formatter,
    raise_for_unrepresentable_int,
)
from literalizer._formatters.format_strings import (
    format_string_backslash_control,
)
from literalizer._formatters.type_inference import (
    RecordShape,
    collect_record_shapes,
)
from literalizer._language import (
    NO_CALL_PARAMETER_LIMIT,
    NO_HETEROGENEOUS_BEHAVIOR,
    NON_KEBAB_REF_CASES,
    BareIntegerWidthStrategies,
    CallParameterShadowing,
    CallStubResult,
    CallStyle,
    CommandCallStyle,
    CommentConfig,
    DateFormatConfig,
    DateFormatEnum,
    DatetimeFormatConfig,
    DatetimeFormatEnum,
    DeclarationStyleConfig,
    DictFormatConfig,
    FileWrapperContext,
    FloatSpecialsMixin,
    FormatValueMixin,
    HeterogeneousBehavior,
    IdentifierCase,
    JsonType,
    LanguageCls,
    ModifierCombination,
    NewVariableNameSyntax,
    OrderedMapFormatConfig,
    PositionalCallStyle,
    RenderedRecordLiteral,
    RoundTripCapability,
    SequenceFormatConfig,
    SetFormatConfig,
    StubReturn,
    TrailingCommaConfig,
    VariantMetadata,
    body_preamble_from_scalars,
    declares_binding,
    default_call_data_dependent_preamble,
    default_consumable_ref_value_inhibits_consuming_form,
    default_format_call_arg_ref_identifier,
    default_format_call_arg_ref_identifier_consumable,
    default_format_call_ref_identifier,
    default_format_call_stub,
    default_format_call_target,
    default_sequence_binding_declarations,
    default_type_hint_collection_preamble_lines,
    default_validate_call_arg,
    default_wrap_calls_with_declarations,
    identity_constructor_target,
    no_call_binding_body_preamble,
    no_call_binding_file_pragmas,
    no_data_preamble,
    no_format_integer_beyond_i64,
    no_format_integer_widened,
    no_leading_preamble,
    prepend_body_preamble,
    unsupported_wrap_combined_in_file_static,
)
from literalizer._types import OrderedMap, Scalar, Value
from literalizer.exceptions import (
    UnrepresentableInputError,
)

_ASCII_DELETE_CODE_POINT = 127
_SML_NATIVE_INT_MIN = -(2**31)
_SML_NATIVE_INT_MAX = 2**31 - 1


@beartype
def _apply_sml_negate_int(value: int, formatter: Callable[[int], str]) -> str:
    """Format an integer, replacing ``-`` with ``~``."""
    result = formatter(value)
    if result.startswith("-"):
        return "~" + result[1:]
    return result


@beartype
def _sml_negate_int(
    formatter: Callable[[int], str],
) -> Callable[[int], str]:
    """Wrap an integer formatter to use SML's ``~`` for negation."""

    @beartype
    def _format(value: int) -> str:
        """Delegate to module-level implementation."""
        return _apply_sml_negate_int(value=value, formatter=formatter)

    return _format


@beartype
def _apply_sml_negate_float(
    value: float, formatter: Callable[[float], str]
) -> str:
    """Format a float, replacing ``-`` with ``~``.

    Scientific-notation output from Python's ``repr`` uses a lower-case
    ``e`` and an explicit ``+`` on positive exponents (``1.0e+16``);
    SML's float grammar requires upper-case ``E``, rejects the ``+``,
    and uses ``~`` for a negative exponent, so the exponent marker is
    normalized here.
    """
    result = formatter(value)
    if result.startswith("-"):
        result = "~" + result[1:]
    return result.replace("e-", "E~").replace("e+", "E").replace("e", "E")


@beartype
def _sml_negate_float(
    formatter: Callable[[float], str],
) -> Callable[[float], str]:
    """Wrap a float formatter to use SML's ``~`` for negation."""

    @beartype
    def _format(value: float) -> str:
        """Delegate to module-level implementation."""
        return _apply_sml_negate_float(value=value, formatter=formatter)

    return _format


@beartype
def _sml_scientific(value: float) -> str:
    """Format a float in SML scientific notation.

    SML uses ``E`` (not ``e``) and ``~`` for negative exponents.
    """
    result = format_float_scientific(value=value)
    if result.startswith("-"):
        result = "~" + result[1:]
    # Convert Python's 'e' to SML's 'E', with ~ for negative exponents.
    return result.replace("e-", "E~").replace("e", "E")


@beartype
def _sml_int_entry(*, original: int, formatted: str, prefix: str) -> str:
    """Wrap a formatted integer in the SML value constructor."""
    negative = original < 0
    if negative:
        result = f"{prefix}Int ({formatted})"
    else:
        result = f"{prefix}Int {formatted}"
    return result


@beartype
def _sml_float_entry(*, original: float, formatted: str, prefix: str) -> str:
    """Wrap a formatted real in the SML value constructor."""
    needs_parentheses = math.copysign(1, original) < 0 or not math.isfinite(
        original
    )
    if needs_parentheses:
        result = f"{prefix}Real ({formatted})"
    else:
        result = f"{prefix}Real {formatted}"
    return result


@beartype
def _sml_epoch_entry(
    *, original: dt.datetime, formatted: str, prefix: str
) -> str:
    """Convert an epoch integer to SML signed literal syntax."""
    negative = datetime_epoch_seconds(value=original) < 0
    literal = formatted
    if negative:
        literal = f"~{formatted[1:]}"
    if negative:
        result = f"{prefix}Int ({literal})"
    else:
        result = f"{prefix}Int {literal}"
    return result


@beartype
def _sml_temporal_entry(
    *,
    formatted: str,
    prefix: str,
    produced_type: type[object],
    native_type: type[object],
) -> str:
    """Wrap string-rendered temporal values in the SML string
    constructor.
    """
    if produced_type is native_type:
        return formatted
    return f"{prefix}Str {formatted}"


@beartype
def _apply_sml_entry_formatter(
    original: Value,
    formatted: str,
    prefix: str,
    date_type: type[object],
    datetime_type: type[object],
) -> str:
    """Wrap a formatted entry in the appropriate SML ``datatype``
    constructor.
    """
    match original:
        case bool():
            result = formatted
        case int():
            result = _sml_int_entry(
                original=original, formatted=formatted, prefix=prefix
            )
        case float():
            result = _sml_float_entry(
                original=original, formatted=formatted, prefix=prefix
            )
        case str() | bytes():
            result = f"{prefix}Str {formatted}"
        case dt.datetime() if datetime_type is int:
            result = _sml_epoch_entry(
                original=original, formatted=formatted, prefix=prefix
            )
        case dt.datetime():
            result = _sml_temporal_entry(
                formatted=formatted,
                prefix=prefix,
                produced_type=datetime_type,
                native_type=dt.datetime,
            )
        case dt.time():
            result = f"{prefix}Str {formatted}"
        case dt.date():
            result = _sml_temporal_entry(
                formatted=formatted,
                prefix=prefix,
                produced_type=date_type,
                native_type=dt.date,
            )
        case _:
            result = formatted
    return result


@beartype
def _build_sml_entry_formatter(
    prefix: str, date_type: type[object], datetime_type: type[object]
) -> Callable[[Value, str], str]:
    """Build an entry formatter that wraps values in SML ``datatype``
    constructors using the given *prefix*.
    """

    @beartype
    def _format(original: Value, formatted: str) -> str:
        """Delegate to module-level implementation."""
        return _apply_sml_entry_formatter(
            original=original,
            formatted=formatted,
            prefix=prefix,
            date_type=date_type,
            datetime_type=datetime_type,
        )

    return _format


@beartype
def _apply_sml_declaration(
    *,
    name: str,
    value: str,
    data: Value,
    sequence_declared_type: str,
    scalar_declared_type: str,
    entry_formatter: Callable[[Value, str], str],
) -> str:
    """Format a variable declaration."""
    decl_type = scalar_declared_type
    if isinstance(data, list):
        decl_type = sequence_declared_type
    wrapped = entry_formatter(data, value)
    return f"val {name} : {decl_type} = {wrapped}"


@beartype
def _build_sml_declaration(
    *,
    sequence_declared_type: str,
    scalar_declared_type: str,
    entry_formatter: Callable[[Value, str], str],
) -> Callable[[str, str, Value], str]:
    """Build an SML variable declaration formatter."""

    @beartype
    def _format(name: str, value: str, data: Value) -> str:
        """Delegate to module-level implementation."""
        return _apply_sml_declaration(
            name=name,
            value=value,
            data=data,
            sequence_declared_type=sequence_declared_type,
            scalar_declared_type=scalar_declared_type,
            entry_formatter=entry_formatter,
        )

    return _format


@beartype
def _format_sml_preamble_lines(
    lines: list[str],
    *,
    indent: str,
) -> tuple[str, ...]:
    """Format deduplicated preamble lines with SML ``datatype`` syntax.

    The first constructor is indented; subsequent constructors are
    prefixed with ``|``.
    """
    pipe_prefix = " " * max(0, len(indent) - 2) + "| "
    return (
        lines[0],
        indent + lines[1],
        *(f"{pipe_prefix}{line}" for line in lines[2:]),
    )


@beartype
def _build_sml_call_stub_lines(
    *,
    parts: Sequence[str],
    params: Sequence[str],
    curried: bool,
) -> tuple[str, ...]:
    """Return SML stub declarations for a call name.

    For dotted names like ``app.client.fetch``, nested SML structures
    are emitted so that ``app.client.fetch arg`` is valid at the call
    site.  The innermost name becomes a ``fun`` declaration that accepts
    any argument and returns unit.

    Under curried calling, each parameter is bound separately
    (``fun f _ _ = ()``); under positional calling, a single placeholder
    accepts the whole tuple (``fun f _ = ()``).
    """
    method = parts[-1]
    if curried:
        if len(params) == 0:
            lines: list[str] = [f"val {method} = ()"]
        else:
            wildcards = " ".join("_" for _ in params)
            lines = [f"fun {method} {wildcards} = ()"]
    else:
        lines = [f"fun {method} _ = ()"]
    for part in reversed(parts[:-1]):
        lines = [f"structure {part} = struct", *lines, "end"]
    return tuple(lines)


@beartype
def _sml_call_stub(
    parts: Sequence[str],
    params: Sequence[str],
    _stub_return: StubReturn,
    _args: Sequence[Value],
    /,
) -> tuple[str, ...]:
    """Return SML positional (tuple-form) stub declarations."""
    return _build_sml_call_stub_lines(
        parts=parts, params=params, curried=False
    )


@beartype
def _sml_curried_call_stub(
    parts: Sequence[str],
    params: Sequence[str],
    _stub_return: StubReturn,
    _args: Sequence[Value],
    /,
) -> tuple[str, ...]:
    """Return SML curried stub declarations."""
    return _build_sml_call_stub_lines(parts=parts, params=params, curried=True)


@beartype
def _sml_format_call_arg(_original: Value, formatted: str, /) -> str:
    """Wrap a formatted SML value in parentheses for curried
    application.
    """
    return f"({formatted})"


@beartype
def _sml_native_record_literal(
    _value: dict[Scalar, Value], formatted_fields: Mapping[str, str]
) -> RenderedRecordLiteral:
    """Render a string-keyed dictionary as an SML record."""
    return RenderedRecordLiteral(
        head="{",
        entries=tuple(
            f"{key} = {value}" for key, value in formatted_fields.items()
        ),
        closer="}",
        compact_pad="",
    )


@beartype
def _sml_native_record_shapes(data: Value, /) -> Mapping[int, RecordShape]:
    """Collect dictionary shapes for native record rendering."""
    return collect_record_shapes(data=data)


@beartype
def _sml_native_shape(data: Value) -> str:
    """Describe a field's inferred SML type for list consistency."""
    if isinstance(data, dict):
        return repr(
            tuple(
                sorted(
                    (key, _sml_native_shape(data=value))
                    for key, value in data.items()
                )
            )
        )
    if isinstance(data, list):
        element_types = sorted(
            {_sml_native_shape(data=value) for value in data}
        )
        return f"list:{element_types!r}"
    return type(data).__name__


@beartype
def _sml_native_epoch(value: dt.datetime) -> str:
    """Use SML's negation syntax for an epoch timestamp."""
    formatted = format_datetime_epoch(value=value)
    if formatted.startswith("-"):
        return "~" + formatted[1:]
    return formatted


@beartype
def _validate_sml_native_scalar(data: Value, *, epoch_datetimes: bool) -> None:
    """Check scalar values against native SML type and width limits."""
    if isinstance(data, (set, type(None))):
        msg = f"SML record mode cannot represent {type(data).__name__}"
        raise UnrepresentableInputError(msg)
    if (
        isinstance(data, int)
        and not isinstance(data, bool)
        and not _SML_NATIVE_INT_MIN <= data <= _SML_NATIVE_INT_MAX
    ):
        msg = "SML record mode requires 32-bit native integers"
        raise UnrepresentableInputError(msg)
    if isinstance(data, dt.datetime) and epoch_datetimes:
        timestamp = int(format_datetime_epoch(value=data))
        if not _SML_NATIVE_INT_MIN <= timestamp <= _SML_NATIVE_INT_MAX:
            msg = "SML record mode requires 32-bit epoch integers"
            raise UnrepresentableInputError(msg)


@beartype
def _validate_sml_native_record(
    data: Value, reserved_fields: frozenset[str], *, epoch_datetimes: bool
) -> None:
    """Reject data that cannot be represented as native SML records."""
    if isinstance(data, OrderedMap):
        msg = "SML record mode cannot represent ordered maps"
        raise UnrepresentableInputError(msg)
    if isinstance(data, dict):
        if len(data) == 0:
            msg = "SML record mode cannot represent empty records"
            raise UnrepresentableInputError(msg)
        for key, value in data.items():
            if (
                not isinstance(key, str)
                or re.fullmatch(pattern=r"[a-z][A-Za-z0-9_]*", string=key)
                is None
                or key in reserved_fields
            ):
                msg = f"SML record mode cannot represent field {key!r}"
                raise UnrepresentableInputError(msg)
            _validate_sml_native_record(
                data=value,
                reserved_fields=reserved_fields,
                epoch_datetimes=epoch_datetimes,
            )
    elif isinstance(data, list):
        types = {_sml_native_shape(data=value) for value in data}
        if len(types) > 1:
            msg = "SML record mode requires uniform list element types"
            raise UnrepresentableInputError(msg)
        for value in data:
            _validate_sml_native_record(
                data=value,
                reserved_fields=reserved_fields,
                epoch_datetimes=epoch_datetimes,
            )
    else:
        _validate_sml_native_scalar(data=data, epoch_datetimes=epoch_datetimes)


# Work around https://github.com/astral-sh/ty/issues/4573.
if TYPE_CHECKING:
    _BytesEnumMember = enum.member[Callable[[bytes], str]]
else:
    _BytesEnumMember = enum.member


@beartype
def _sml_call_statement(statement: str, /) -> str:
    """Bind a call result to the wildcard identifier."""
    return f"val _ = {statement}"


@beartype
def _sml_record_declaration(name: str, value: str, _data: Value, /) -> str:
    """Declare an inferred native record."""
    return f"val {name} = {value}"


@beartype
@dataclasses.dataclass(frozen=True, kw_only=True)
class Sml(metaclass=LanguageCls):
    """Standard ML language specification.

    Args:
        date_format: How to format :class:`datetime.date` values.

            * ``date_formats.SML`` — tuple literal,
              e.g. ``(2024, 1, 15)``.
            * ``date_formats.ISO`` — ISO 8601 quoted string,
              e.g. ``"2024-01-15"``.

        datetime_format: How to format :class:`datetime.datetime` values.

            * ``datetime_formats.SML`` — pair of tuples,
              e.g. ``((2024, 1, 15), (12, 30, 0))``.
            * ``datetime_formats.ISO`` — ISO 8601 quoted string,
              e.g. ``"2024-01-15T12:30:00"``.

        dict_format: ``DEFAULT`` keeps the generated tagged value type;
            ``RECORD`` emits native SML records for valid field names and
            uniform list element types.

        type_name: Name of the generated custom type.  Defaults to
            ``"val_t"``.

        constructor_prefix: Prefix for generated constructor names.
            Defaults to ``"S"``, producing constructors like ``SNull``,
            ``SBool``, ``SInt``, etc.
    """

    reserved_module_identifiers: ClassVar[frozenset[str]] = frozenset()
    immutable_variable_modifiers: ClassVar[frozenset[enum.Enum]] = frozenset()
    wrap_in_file_tolerates_pre_indent = True
    module_name_shares_variable_scope = False
    reserved_variable_identifier_pattern: ClassVar[re.Pattern[str] | None] = (
        None
    )
    reserved_call_parameter_identifiers: ClassVar[frozenset[str]] = frozenset()
    reserved_call_parameter_identifier_pattern: ClassVar[
        re.Pattern[str] | None
    ] = None
    uses_data_keyword_for_algebraic_constructors = False
    accepts_type_name_call_target = True
    declares_type_name_call_target = True
    dotted_call_root_shares_entrypoint_namespace = True
    reserved_bare_call_target_identifiers: ClassVar[frozenset[str]] = (
        frozenset()
    )
    reserved_call_target_head_identifiers: ClassVar[frozenset[str]] = (
        frozenset()
    )
    contextual_call_target_identifiers: ClassVar[frozenset[str]] = frozenset()
    call_parameter_shadowing = CallParameterShadowing.ALLOWED
    reserved_call_target_keywords_case_sensitive = True
    module_name_must_start_uppercase = False
    max_variable_identifier_length: ClassVar[int | None] = None
    call_stub_result: ClassVar[CallStubResult | None] = None
    call_literal_syntax: ClassVar[None] = None
    call_target_name_syntax: ClassVar[NewVariableNameSyntax | None] = None
    supports_multiline_dict_layout = True
    pools_map_integer_width = True

    new_variable_name_syntax: ClassVar[NewVariableNameSyntax] = (
        # ``_`` is the wildcard pattern, so a name beginning with one
        # is read as the wildcard applied to what follows it
        # (issue #4772).
        NewVariableNameSyntax.LOWER_LETTER_ASCII_PRIME_SUFFIX
    )

    format_integer_widened = no_format_integer_widened
    format_integer_beyond_i64 = no_format_integer_beyond_i64
    format_constructor_target: ClassVar["staticmethod[[str], str]"] = (
        staticmethod(identity_constructor_target)
    )
    sequence_binding_declarations = default_sequence_binding_declarations
    format_call_binding_body_preamble = no_call_binding_body_preamble
    format_call_binding_file_pragmas = no_call_binding_file_pragmas

    leading_preamble = no_leading_preamble
    extension = ".sml"
    pygments_name = "sml"
    stringifies_nested_collections = False
    supports_special_floats = True
    supports_variable_names = True
    supports_no_variable_wrap_in_file = False
    wraps_data_dependent_preamble_in_body = False
    dict_supports_heterogeneous_values = True
    supports_local_binding_documents = False
    supports_stateful_free_call_consumers = False
    supports_stateful_receiver_result_checks = False
    supports_native_invocations = False
    supports_dotted_calls = True
    has_free_function_calls = True
    reserved_identifiers: ClassVar[frozenset[str]] = frozenset({"op"})
    declares_call_parameter_names = True
    reserved_variable_identifiers_case_sensitive: bool = True
    reserved_variable_identifiers: frozenset[str] = frozenset(
        {
            "abstype",
            "and",
            "andalso",
            "as",
            "case",
            "datatype",
            "do",
            "else",
            "end",
            "eqtype",
            "exception",
            "false",
            "fn",
            "fun",
            "functor",
            "handle",
            "if",
            "in",
            "include",
            "infix",
            "infixr",
            "let",
            "local",
            "mod",
            "nil",
            "nonfix",
            "of",
            "op",
            "open",
            "orelse",
            "raise",
            "rec",
            "sharing",
            "sig",
            "signature",
            "struct",
            "structure",
            "then",
            "true",
            "type",
            "val",
            "where",
            "while",
            "with",
        }
    )
    allows_empty_call_parens = True
    supports_dotted_call_stub = True
    dotted_call_stub_indexes_colliding_helpers = False
    call_returns_expression = True
    supports_json_call_result_binding = False
    supports_zero_parameter_calls = True
    max_call_parameters = NO_CALL_PARAMETER_LIMIT
    supports_inline_multiline_dict_args = True
    supports_standalone_comments_in_wrapped_calls = True
    supports_multi_param_call_wrapper_stub = True
    supports_variadic_calls = False
    supports_dict_literal_as_free_expression = True
    supports_module_name = False
    supports_empty_dict_key = False
    supports_call_style = True
    supports_bare_mapping_documents = False
    supports_json_object_documents = False
    supports_default_dict_key_type = False
    supports_default_dict_value_type = False
    supports_nullable_object_fallbacks = False
    supports_default_sequence_element_type = False
    supports_key_value_assignment_documents = False
    supports_default_set_element_type = False
    supports_default_ordered_map_value_type = False
    json_type_variant_name_suffix: ClassVar[str | None] = None
    # A portable Standard ML ``string`` is an 8-bit type.  Encode non-ASCII
    # text as decimal escapes for each UTF-8 byte rather than embedding it.
    supports_non_ascii_string_literals = True
    supports_multiline_string_literals = False
    supports_empty_sibling_sequence_type_hints = True
    supports_typed_dict_open = False
    language_id: ClassVar[str] = "sml"
    variant_metadata: ClassVar[VariantMetadata] = VariantMetadata(
        round_trip_capabilities=frozenset(
            {
                RoundTripCapability.I64_BOUNDARIES,
                RoundTripCapability.INTERPOLATION_STRINGS,
                RoundTripCapability.CONTROL_STRINGS,
                RoundTripCapability.EMBEDDED_NUL,
            }
        ),
        modifier_sequence_format_overrides={},
        string_literals_escape_null_byte=True,
        supports_ref_elements_in_tuple_strategy=False,
    )
    supports_record_struct_name_prefix = False
    supports_record_shape_names = False
    record_shape_names_emit_declarations = False
    supports_non_string_dict_keys = False
    checks_raw_control_dict_keys_separately = False

    class DateFormats(DateFormatEnum):
        """Date format options for Standard ML."""

        SML = DateFormatConfig(
            formatter=date_ymd_formatter(
                template="SDate ({year}, {month}, {day})",
            ),
            preamble_lines=(),
            type_produced=dt.date,
        )
        ISO = DateFormatConfig(
            formatter=format_date_iso, type_produced=str, preamble_lines=()
        )

    class DatetimeFormats(DatetimeFormatEnum):
        """Datetime format options for Standard ML."""

        SML = DatetimeFormatConfig(
            formatter=datetime_ymdhms_formatter(
                template="SDatetime (({year}, {month}, {day}), "
                "({hour}, {minute}, {second}))",
                millisecond_template=None,
            ),
            preamble_lines=(),
            type_produced=dt.datetime,
        )
        ISO = DatetimeFormatConfig(
            formatter=format_datetime_iso,
            type_produced=str,
            preamble_lines=(),
        )

        EPOCH = DatetimeFormatConfig(
            formatter=format_datetime_epoch,
            type_produced=int,
            preamble_lines=(),
        )

    class BytesFormats(FormatValueMixin[Callable[[bytes], str]], enum.Enum):
        """Bytes formatting options."""

        HEX = _BytesEnumMember(value=format_bytes_hex)
        BASE64 = _BytesEnumMember(value=format_bytes_base64)

        def __call__(self, data: bytes, /) -> str:
            """Format bytes."""
            return self.value(data)

    class SequenceFormats(enum.Enum):
        """Sequence type options for Standard ML."""

        LIST = SequenceFormatConfig(
            length_is_part_of_type=False,
            sequence_open=fixed_open(open_str="SList ["),
            close="]",
            supports_heterogeneity=True,
            single_element_trailing_comma=False,
            single_element_template=None,
            supports_trailing_comma=False,
            empty_sequence=None,
            preamble_lines=(),
            format_entry=passthrough_sequence_entry,
            typed_opener_fallback=None,
            uses_typed_literal_for_scalars=False,
            requires_uniform_record_shapes=False,
            declared_type="val_t",
            narrowed_empty_form=None,
        )

    class SetFormats(enum.Enum):
        """Set type options for Standard ML."""

        SET = SetFormatConfig(
            set_open=fixed_open(open_str="SSet ["),
            close="]",
            empty_set=None,
            preamble_lines=(),
            set_opener_template="",
            supports_heterogeneity=True,
            supports_trailing_comma=True,
        )

    class CommentFormats(enum.Enum):
        """Comment style options."""

        PAREN_STAR = CommentConfig(
            prefix="(*",
            suffix=NestingCommentSuffix(object=" *)"),
        )

    class DeclarationStyles(enum.Enum):
        """Declaration style options."""

        VAL = DeclarationStyleConfig(
            formatter=variable_declaration_formatter(
                template="val {name} = {value}",
            ),
            supports_redefinition=False,
        )

    class DictEntryStyles(enum.Enum):
        """Dict entry style options."""

        DEFAULT = enum.auto()

    class DictFormats(enum.Enum):
        """Dict/map format options."""

        DEFAULT = enum.auto()
        RECORD = enum.auto()

    class EmptyDictKey(enum.Enum):
        """Empty dict key options."""

        ALLOW = enum.auto()

    class FloatFormats(
        FloatSpecialsMixin,
        enum.Enum,
        positive_infinity="(1.0 / 0.0)",
        negative_infinity="(~1.0 / 0.0)",
        nan="(0.0 / 0.0)",
    ):
        """Float format options."""

        REPR = enum.member(
            value=_sml_negate_float(formatter=format_float_repr),
        )
        SCIENTIFIC = enum.member(value=_sml_scientific)
        FIXED = enum.member(
            value=_sml_negate_float(formatter=format_float_fixed),
        )

    class IntegerFormats(enum.Enum):
        """Integer format options."""

        DECIMAL = MappingProxyType(
            mapping={
                "NONE": _sml_negate_int(formatter=str),
            }
        )
        HEX = MappingProxyType(
            mapping={
                "NONE": _sml_negate_int(formatter=format_integer_hex),
            }
        )

        def get_formatter(
            self,
            numeric_separator: enum.Enum,
        ) -> Callable[[int], str]:
            """Return the integer formatter for the given separator."""
            formatter: Callable[[int], str] = self.value[
                numeric_separator.name
            ]
            return formatter

    class NumericLiteralSuffixes(enum.Enum):
        """Numeric literal suffix options."""

        NONE = enum.auto()

    class NumericSeparators(enum.Enum):
        """Numeric separator options."""

        NONE = enum.auto()

    class NumericStyles(enum.Enum):
        """Numeric literal style options."""

        OVERLOADED = enum.auto()

    class StringFormats(enum.Enum):
        """String format options."""

        DOUBLE = enum.auto()

    class TrailingCommas(enum.Enum):
        """Trailing comma options."""

        NO = TrailingCommaConfig(multiline_trailing_comma=False)

    date_formats = DateFormats
    datetime_formats = DatetimeFormats
    bytes_formats = BytesFormats
    sequence_formats = SequenceFormats
    set_formats = SetFormats
    comment_formats = CommentFormats

    class VariableTypeHints(enum.Enum):
        """Variable type hint options."""

        NEVER = enum.auto()
        SAFE = enum.auto()

    variable_type_hints_formats = VariableTypeHints
    declaration_styles = DeclarationStyles
    dict_entry_styles = DictEntryStyles
    dict_formats = DictFormats
    empty_dict_keys = EmptyDictKey
    float_formats = FloatFormats
    integer_formats = IntegerFormats
    integer_width_strategies = BareIntegerWidthStrategies
    numeric_literal_suffixes = NumericLiteralSuffixes
    numeric_separators = NumericSeparators
    numeric_styles = NumericStyles
    string_formats = StringFormats
    trailing_commas = TrailingCommas

    class StatementTerminatorStyles(enum.Enum):
        """Statement terminator options."""

        SEMICOLON = enum.auto()

    statement_terminator_styles = StatementTerminatorStyles

    class CallStyles(enum.Enum):
        """Sml call style options."""

        POSITIONAL = PositionalCallStyle(
            arg_separator=", ", parenthesize_each_arg=False
        )
        CURRIED = CommandCallStyle(
            arg_separator=" ",
        )

    call_styles = CallStyles

    class Modifiers(enum.Enum):
        """C++/Java/C#-style declaration modifiers: this language has none."""

    modifiers = Modifiers

    class HeterogeneousStrategies(enum.Enum):
        """Heterogeneous-scalar strategy options — this language only
        supports raising.
        """

        ERROR = NO_HETEROGENEOUS_BEHAVIOR

    heterogeneous_strategies = HeterogeneousStrategies

    class JsonTypes(JsonType):
        """Empty: this language has no JSON value-type variants."""

    json_types = JsonTypes

    class BoolFormats(enum.Enum):
        """Empty: this language has no alternative boolean formats."""

    bool_formats = BoolFormats

    class VersionFormats(enum.Enum):
        """Version options for SML."""

        SML_97 = enum.auto()

    version_formats = VersionFormats

    modifier_combinations: ClassVar[tuple[ModifierCombination, ...]] = ()
    identifier_cases: ClassVar[tuple[IdentifierCase, ...]] = (
        IdentifierCase.SNAKE,
        IdentifierCase.CAMEL,
        IdentifierCase.PASCAL,
    )
    supported_ref_cases: ClassVar[frozenset[IdentifierCase]] = (
        NON_KEBAB_REF_CASES
    )

    def validate_spec_for_data(self, data: Value) -> None:
        """Validate values for the selected dictionary representation."""
        if self.dict_format is type(self.dict_format).RECORD:
            _validate_sml_native_record(
                data=data,
                reserved_fields=self.reserved_variable_identifiers,
                epoch_datetimes=(
                    self.datetime_format.value.type_produced is int
                ),
            )

    validate_call_arg = default_validate_call_arg

    wrap_calls_with_declarations = default_wrap_calls_with_declarations

    @staticmethod
    def wrap_in_file(
        content: str,
        context: FileWrapperContext,
    ) -> str:
        """Wrap an SML val declaration at top level."""
        variable_name = context.variable_name
        body_preamble = context.body_preamble
        content = prepend_body_preamble(
            content=content,
            body_preamble=body_preamble,
        )
        force_line = ""
        if variable_name != "":
            force_line = f"\nval _ = {variable_name}"
        return content + force_line

    wrap_combined_in_file: ClassVar[
        "staticmethod[[str, str, FileWrapperContext], str]"
    ] = unsupported_wrap_combined_in_file_static

    date_format: DateFormats = DateFormats.SML
    datetime_format: DatetimeFormats = DatetimeFormats.SML
    bytes_format: BytesFormats = BytesFormats.HEX
    sequence_format: SequenceFormats = SequenceFormats.LIST
    set_format: SetFormats = SetFormats.SET
    variable_type_hints: VariableTypeHints = VariableTypeHints.NEVER
    comment_format: CommentFormats = CommentFormats.PAREN_STAR
    declaration_style: DeclarationStyles = DeclarationStyles.VAL
    dict_entry_style: DictEntryStyles = DictEntryStyles.DEFAULT
    dict_format: DictFormats = DictFormats.DEFAULT
    float_format: FloatFormats = FloatFormats.REPR
    integer_format: IntegerFormats = IntegerFormats.DECIMAL
    integer_width_strategy: BareIntegerWidthStrategies = (
        BareIntegerWidthStrategies.BARE
    )
    numeric_literal_suffix: NumericLiteralSuffixes = (
        NumericLiteralSuffixes.NONE
    )
    numeric_separator: NumericSeparators = NumericSeparators.NONE
    numeric_style: NumericStyles = NumericStyles.OVERLOADED
    string_format: StringFormats = StringFormats.DOUBLE
    trailing_comma: TrailingCommas = TrailingCommas.NO
    statement_terminator_style: StatementTerminatorStyles = (
        StatementTerminatorStyles.SEMICOLON
    )
    heterogeneous_strategy: HeterogeneousStrategies = (
        HeterogeneousStrategies.ERROR
    )
    # The `Install MLton` step in `.github/workflows/lint.yml` pins a
    # `MLton` build implementing the Standard `ML` '97 language, matching
    # this default (`SML_97`). The pin is for reproducible builds, not
    # language selection. Keep the two in sync.
    language_version: VersionFormats = VersionFormats.SML_97
    indent: str = "    "
    type_name: str = "val_t"
    constructor_prefix: str = "S"
    call_style: CallStyles = CallStyles.POSITIONAL

    indent_closing_delimiter: ClassVar[bool] = False
    element_separator: ClassVar[str] = ", "
    skip_null_dict_values: ClassVar[bool] = False
    supports_collection_comments: ClassVar[bool] = True
    supports_scalar_before_comments: ClassVar[bool] = True
    supports_scalar_inline_comments: ClassVar[bool] = True
    statement_terminator: ClassVar[str] = ""
    static_preamble: ClassVar[Sequence[str]] = ()
    static_body_preamble: ClassVar[Sequence[str]] = ()
    special_float_preamble: ClassVar[tuple[str, ...]] = ()

    @cached_property
    @beartype
    def format_string(self) -> Callable[[str], str]:
        """Format a string value as a quoted literal."""

        @beartype
        def _format(value: str) -> str:
            """Format a string as an SML quoted literal."""
            formatted = format_string_backslash_control(
                value=value,
                control_char_fmt="\\{:03d}",
                escape_delete=False,
            )
            collected_entries: list[str] = []
            for entry_char in formatted:
                effective_byte = entry_char
                if ord(effective_byte) >= _ASCII_DELETE_CODE_POINT:
                    effective_byte = "".join(
                        f"\\{byte:03d}" for byte in entry_char.encode()
                    )
                collected_entries.append(effective_byte)
            return "".join(collected_entries)

        return _format

    @cached_property
    @beartype
    def data_dependent_preamble(self) -> Callable[[Value], tuple[str, ...]]:
        """Return data-dependent preamble lines."""
        return no_data_preamble

    @cached_property
    @beartype
    def heterogeneous_behavior(self) -> HeterogeneousBehavior:
        """Return the heterogeneous-behavior config."""
        if self.dict_format is type(self.dict_format).RECORD:
            return dataclasses.replace(
                NO_HETEROGENEOUS_BEHAVIOR,
                compute_record_shapes=_sml_native_record_shapes,
                render_record_literal=_sml_native_record_literal,
            )
        return self.heterogeneous_strategy.value

    call_data_dependent_preamble = default_call_data_dependent_preamble

    type_hint_collection_preamble_lines = (
        default_type_hint_collection_preamble_lines
    )

    @cached_property
    @beartype
    def call_style_config(self) -> CallStyle:
        """Configuration for the chosen call style."""
        config: CallStyle = self.call_style.value
        return config

    @cached_property
    @beartype
    def format_call_stub(
        self,
    ) -> Callable[
        [Sequence[str], Sequence[str], StubReturn, Sequence[Value]],
        tuple[str, ...],
    ]:
        """Return stub declarations for a call expression."""
        if isinstance(self.call_style.value, CommandCallStyle):
            return _sml_curried_call_stub
        return _sml_call_stub

    @cached_property
    @beartype
    def format_call_arg(self) -> Callable[[Value, str], str]:
        """Callable that rewrites a formatted direct call argument.

        Curried calls parenthesize each argument so that constructor
        applications are not parsed as additional arguments to the outer
        call.
        """
        entry_formatter = self._entry_formatter
        if self.dict_format is type(self.dict_format).RECORD:
            if isinstance(self.call_style.value, CommandCallStyle):
                return _sml_format_call_arg
            return passthrough_sequence_entry
        if isinstance(self.call_style.value, CommandCallStyle):

            @beartype
            def _curried_arg(original: Value, formatted: str) -> str:
                """Tag the value and parenthesize the curried argument."""
                tagged = entry_formatter(original, formatted)
                return _sml_format_call_arg(original, tagged)

            return _curried_arg
        return entry_formatter

    format_call_class_scope_stub = default_format_call_stub

    format_call_preamble_stub = default_format_call_stub

    @cached_property
    @beartype
    def format_call_statement(self) -> Callable[[str], str]:
        """Wrap a call expression as a val binding so it is a valid SML
        declaration inside a structure block.
        """
        return _sml_call_statement

    format_call_target = default_format_call_target

    format_call_ref_identifier = default_format_call_ref_identifier

    format_call_arg_ref_identifier = default_format_call_arg_ref_identifier

    format_call_arg_ref_identifier_consumable = (
        default_format_call_arg_ref_identifier_consumable
    )

    consumable_ref_value_inhibits_consuming_form = (
        default_consumable_ref_value_inhibits_consuming_form
    )

    scalar_preamble: ClassVar[dict[type[object], tuple[str, ...]]] = {}

    @cached_property
    @beartype
    def null_literal(self) -> str:
        """Literal for the null value."""
        return f"{self.constructor_prefix}Null"

    @cached_property
    @beartype
    def true_literal(self) -> str:
        """Literal for the true value."""
        if self.dict_format is type(self.dict_format).RECORD:
            return "true"
        return f"{self.constructor_prefix}Bool true"

    @cached_property
    @beartype
    def false_literal(self) -> str:
        """Literal for the false value."""
        if self.dict_format is type(self.dict_format).RECORD:
            return "false"
        return f"{self.constructor_prefix}Bool false"

    @cached_property
    @beartype
    def _entry_formatter(self) -> Callable[[Value, str], str]:
        """Shared entry formatter parameterized by constructor prefix."""
        return _build_sml_entry_formatter(
            prefix=self.constructor_prefix,
            date_type=self.date_format.value.type_produced,
            datetime_type=self.datetime_format.value.type_produced,
        )

    @cached_property
    @beartype
    def sequence_format_config(self) -> SequenceFormatConfig:
        """Configuration for the chosen sequence format."""
        fmt: SequenceFormatConfig = self.sequence_format.value
        if self.dict_format is type(self.dict_format).RECORD:
            return dataclasses.replace(
                fmt,
                sequence_open=fixed_open(open_str="["),
                supports_heterogeneity=False,
                declared_type=None,
            )
        return dataclasses.replace(
            fmt,
            sequence_open=fixed_open(
                open_str=f"{self.constructor_prefix}List [",
            ),
        )

    @cached_property
    @beartype
    def sequence_open(self) -> Callable[[list[Value]], str]:
        """Callable that returns the opening delimiter for a sequence."""
        if self.dict_format is type(self.dict_format).RECORD:
            return fixed_open(open_str="[")
        return fixed_open(
            open_str=f"{self.constructor_prefix}List [",
        )

    @cached_property
    @beartype
    def set_format_config(self) -> SetFormatConfig:
        """Configuration for the chosen set format."""
        return dataclasses.replace(
            self.set_format.value,
            set_open=fixed_open(
                open_str=f"{self.constructor_prefix}Set [",
            ),
        )

    @cached_property
    @beartype
    def dict_format_config(self) -> DictFormatConfig:
        """Configuration for dict formatting."""
        return DictFormatConfig(
            dict_open=fixed_open(
                open_str=f"{self.constructor_prefix}Map [",
            ),
            close="]",
            format_entry=tuple_dict_entry(
                format_value=self._entry_formatter,
            ),
            empty_dict=None,
            preamble_lines=(),
            narrowed_open=None,
            supports_trailing_comma=True,
            narrowed_empty_form=None,
        )

    @cached_property
    @beartype
    def trailing_comma_config(self) -> TrailingCommaConfig:
        """Configuration for trailing-comma behavior."""
        return self.trailing_comma.value

    @cached_property
    @beartype
    def format_bytes(self) -> Callable[[bytes], str]:
        """Callable that formats a bytes value as a string literal."""
        return self.bytes_format

    @cached_property
    @beartype
    def format_date(self) -> Callable[[dt.date], str]:
        """Callable that formats a date as a string literal."""
        base_formatter: Callable[[dt.date], str] = self.date_format
        if self.date_format is type(self.date_format).SML:
            if self.dict_format is type(self.dict_format).RECORD:
                return date_ymd_formatter(template="({year}, {month}, {day})")
            return date_ymd_formatter(
                template=(
                    f"{self.constructor_prefix}Date "
                    f"({{year}}, {{month}}, {{day}})"
                ),
            )
        return base_formatter

    @cached_property
    @beartype
    def format_datetime(self) -> Callable[[dt.datetime], str]:
        """Callable that formats a datetime as a string literal."""
        base_formatter: Callable[[dt.datetime], str] = self.datetime_format
        if self.datetime_format is type(self.datetime_format).SML:
            if self.dict_format is type(self.dict_format).RECORD:
                return datetime_ymdhms_formatter(
                    template="(({year}, {month}, {day}), "
                    "({hour}, {minute}, {second}))",
                    millisecond_template=None,
                )
            return datetime_ymdhms_formatter(
                template=(
                    f"{self.constructor_prefix}Datetime "
                    f"(({{year}}, {{month}}, {{day}}), "
                    f"({{hour}}, {{minute}}, {{second}}))"
                ),
                millisecond_template=None,
            )
        if (
            self.dict_format is type(self.dict_format).RECORD
            and self.datetime_format.value.type_produced is int
        ):
            return _sml_native_epoch
        return base_formatter

    @cached_property
    @beartype
    def format_time(self) -> Callable[[dt.time], str]:
        """Callable that formats a time as a string literal."""
        return format_time_iso

    @cached_property
    @beartype
    def format_float(self) -> Callable[[float], str]:
        """Callable that formats a float value as a literal."""
        return self.float_format

    @cached_property
    @beartype
    def format_integer(self) -> Callable[[int], str]:
        """Callable that formats an int value as a literal."""
        return make_overflow_fallback_formatter(
            base=self.integer_format.get_formatter(
                numeric_separator=self.numeric_separator,
            ),
            fallback=raise_for_unrepresentable_int(language_name="SML"),
            min_value=I64_MIN,
            max_value=I64_MAX,
        )

    @cached_property
    @beartype
    def format_set_entry(self) -> Callable[[Value, str], str]:
        """Callable that formats a set entry."""
        return self._entry_formatter

    @cached_property
    @beartype
    def format_sequence_entry(self) -> Callable[[Value, str], str]:
        """Callable that formats a sequence entry."""
        if self.dict_format is type(self.dict_format).RECORD:
            return passthrough_sequence_entry
        return self._entry_formatter

    @cached_property
    @beartype
    def comment_config(self) -> CommentConfig:
        """Configuration for the language's comment syntax."""
        return self.comment_format.value

    @cached_property
    @beartype
    def ordered_map_format_config(self) -> OrderedMapFormatConfig:
        """Configuration for ordered-map formatting."""
        return OrderedMapFormatConfig(
            ordered_map_open=fixed_open(
                open_str=f"{self.constructor_prefix}Map [",
            ),
            close="]",
            preamble_lines=(),
        )

    @cached_property
    @beartype
    def format_ordered_map_entry(self) -> Callable[[str, Value, str], str]:
        """Callable that formats one ordered-map entry."""
        return tuple_dict_entry(format_value=self._entry_formatter)

    @cached_property
    @beartype
    def _sml_decl(self) -> Callable[[str, str, Value], str]:
        """Shared SML variable declaration formatter."""
        if self.dict_format is type(self.dict_format).RECORD:
            return _sml_record_declaration
        _sequence_declared_type = (
            self.sequence_format.value.declared_type.replace(
                "val_t", self.type_name
            )
        )
        return _build_sml_declaration(
            sequence_declared_type=_sequence_declared_type,
            scalar_declared_type=self.type_name,
            entry_formatter=self._entry_formatter,
        )

    @cached_property
    @beartype
    def format_variable_declaration(
        self,
    ) -> Callable[[str, str, Value, frozenset[enum.Enum]], str]:
        """Callable that formats a new variable declaration."""
        return declaration_formatter_ignoring_modifiers(
            formatter=self._sml_decl
        )

    assignment_declares_binding = declares_binding
    reference_assignment_declares_binding = assignment_declares_binding

    @property
    def call_assignment_declares_binding(self) -> bool:
        """Native record assignments omit the tagged-literal
        annotation.
        """
        return self.dict_format is type(self.dict_format).RECORD

    @cached_property
    @beartype
    def format_variable_assignment(
        self,
    ) -> Callable[[str, str, Value], str]:
        """Callable that formats an assignment to an existing variable."""
        return self._sml_decl

    @cached_property
    @beartype
    def format_call_variable_declaration(
        self,
    ) -> Callable[[str, str, Value, frozenset[enum.Enum]], str]:
        """Callable that formats a declaration binding a call expression.

        The literal-binding declaration is prepended with a ``: val_t``
        type annotation and wraps the value in a ``datatype``
        constructor derived from the bound value's runtime type; a call
        expression has no such tag, so both are omitted and SML infers
        the call's return type instead.
        """
        return self.declaration_style.value.formatter

    @cached_property
    @beartype
    def format_call_variable_assignment(
        self,
    ) -> Callable[[str, str, Value], str]:
        """Bind a call result without a literal constructor or type
        tag.
        """
        return assignment_formatter_from_declaration(
            formatter=self.format_call_variable_declaration
        )

    @cached_property
    @beartype
    def scalar_body_preamble(self) -> dict[type[object], tuple[str, ...]]:
        """Per-instance scalar body preamble for SML datatype declarations."""
        p = self.constructor_prefix
        _h = f"datatype {self.type_name} ="
        if self.date_format.value.type_produced is str:
            _date_constructor = f"{p}Str of string"
        else:
            _date_constructor = f"{p}Date of (int * int * int)"
        if self.datetime_format.value.type_produced is int:
            _datetime_constructor = f"{p}Int of LargeInt.int"
        elif self.datetime_format.value.type_produced is str:
            _datetime_constructor = f"{p}Str of string"
        else:
            _datetime_constructor = (
                f"{p}Datetime of ((int * int * int) * (int * int * int))"
            )
        return {
            type(None): (_h, f"{p}Null"),
            bool: (_h, f"{p}Bool of bool"),
            int: (_h, f"{p}Int of LargeInt.int"),
            float: (_h, f"{p}Real of real"),
            str: (_h, f"{p}Str of string"),
            bytes: (_h, f"{p}Str of string"),
            dt.time: (_h, f"{p}Str of string"),
            dt.date: (_h, _date_constructor),
            dt.datetime: (_h, _datetime_constructor),
            list: (_h, f"{p}List of {self.type_name} list"),
            dict: (_h, f"{p}Map of (string * {self.type_name}) list"),
            OrderedMap: (
                _h,
                f"{p}Map of (string * {self.type_name}) list",
            ),
            set: (_h, f"{p}Set of {self.type_name} list"),
        }

    @cached_property
    @beartype
    def compute_body_preamble(
        self,
    ) -> Callable[[frozenset[type[object]], Value], tuple[str, ...]]:
        """Compute body-preamble lines from the scalar map."""
        if self.dict_format is type(self.dict_format).RECORD:
            return body_preamble_from_scalars(
                scalar_body_preamble={}, format_lines=tuple
            )
        return body_preamble_from_scalars(
            scalar_body_preamble=self.scalar_body_preamble,
            format_lines=partial(
                _format_sml_preamble_lines,
                indent=self.indent,
            ),
        )
