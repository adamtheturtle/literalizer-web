"""Objective-C language specification."""

import base64
import dataclasses
import datetime as dt
import enum
import re
from collections.abc import Callable, Sequence
from functools import cached_property, partial
from typing import TYPE_CHECKING, ClassVar

from beartype import beartype

from literalizer._formatters.collection_openers import (
    fixed_open,
)
from literalizer._formatters.format_dates import (
    date_iso_formatter,
    datetime_epoch_seconds,
    datetime_iso_formatter,
    format_datetime_epoch,
    format_datetime_epoch_fractional,
    format_time_iso,
)
from literalizer._formatters.format_entries import (
    dict_entry_with_separator,
    passthrough_sequence_entry,
)
from literalizer._formatters.format_floats import (
    format_float_fixed,
    format_float_repr,
    format_float_scientific,
)
from literalizer._formatters.format_integers import (
    I64_MAX,
    I64_MIN,
    format_integer_hex,
    format_integer_octal_c_style,
    make_i64_min_safe_formatter,
    make_overflow_fallback_formatter,
    make_ull_fallback,
)
from literalizer._formatters.format_strings import (
    format_string_c,
    has_bidi_formatting_character,
)
from literalizer._language import (
    NO_CALL_PARAMETER_LIMIT,
    NO_HETEROGENEOUS_BEHAVIOR,
    NON_KEBAB_REF_CASES,
    BareIntegerWidthStrategies,
    CallParameterShadowing,
    CallStubResult,
    CollectionLayout,
    CommentConfig,
    DateFormatConfig,
    DateFormatEnum,
    DatetimeFormatConfig,
    DatetimeFormatEnum,
    DeclarationStyleConfig,
    DictFormatConfig,
    FileWrapperContext,
    FloatSpecialsMixin,
    FormatValueMixin,
    HeterogeneousBehavior,
    IdentifierCase,
    JsonType,
    Language,
    LanguageCls,
    ModifierCombination,
    NewVariableNameSyntax,
    NullableObjectCallStubResult,
    OrderedMapFormatConfig,
    PositionalCallStyle,
    RoundTripCapability,
    SequenceFormatConfig,
    SetFormatConfig,
    StubReturn,
    TrailingCommaConfig,
    VariantMetadata,
    body_preamble_from_scalars,
    default_call_data_dependent_preamble,
    default_consumable_ref_value_inhibits_consuming_form,
    default_format_call_arg_ref_identifier,
    default_format_call_arg_ref_identifier_consumable,
    default_format_call_ref_identifier,
    default_format_call_statement,
    default_format_call_stub,
    default_sequence_binding_declarations,
    default_type_hint_collection_preamble_lines,
    default_validate_call_arg,
    default_wrap_calls_with_declarations,
    identity_constructor_target,
    no_call_binding_body_preamble,
    no_call_binding_file_pragmas,
    no_data_preamble,
    no_format_integer_beyond_i64,
    no_format_integer_widened,
    no_leading_preamble,
    no_validate_spec_for_data,
    prepend_body_preamble,
    requires_declared_binding,
)
from literalizer._statements import (
    CallLiteralSyntax,
)
from literalizer._types import Value
from literalizer.native_calls import (
    NativeInvocation,
    NativeType,
    objective_c_invocation,
    objective_c_type,
)

_NULL_OBJECT_STUB = NullableObjectCallStubResult(
    type_name="id",
    value="nil",
    conditional_template=(
        "{call} ?\n{call}{inner_comment}\n: {null}{trailing_comment}"
    ),
    comment_prefix="//",
)


@beartype
def _stub_parameter_signature(*, parameters: str) -> str:
    """Use the C void parameter spelling for an empty stub signature."""
    if parameters == "":
        return "void"
    return parameters


@beartype
def _format_date_objc(value: dt.date) -> str:
    """Format a date as an ``NSDate`` at midnight UTC."""
    midnight = dt.datetime.combine(date=value, time=dt.time(), tzinfo=dt.UTC)
    seconds = datetime_epoch_seconds(value=midnight)
    return f"[NSDate dateWithTimeIntervalSince1970:{seconds}]"


@beartype
def _format_datetime_objc(value: dt.datetime) -> str:
    """Format a datetime as an ``NSDate`` preserving its instant."""
    seconds = format_datetime_epoch_fractional(value=value)
    return f"[NSDate dateWithTimeIntervalSince1970:{seconds}]"


# A formatted numeric value can follow ``@`` directly when it is a
# bare unsigned numeric literal (digits, hex/exponent letters, dot,
# optional ``+``/``-`` after ``e``/``E`` for scientific notation, and
# integer-suffix letters).  Anything else — a leading ``-``, an
# identifier like ``INFINITY``/``NAN``, or an embedded comment —
# requires the ``@(...)`` boxed-expression form.
_OBJC_BARE_NUMERIC = re.compile(
    pattern=r"\A[0-9](?:[0-9a-zA-Z._]|[eE][+-])*\Z",
)


@beartype
def _format_objc_entry(
    original: Value, formatted: str, /, *, datetime_as_number: bool
) -> str:
    """Wrap a formatted entry for use inside an Objective-C collection.

    Only bare numeric values (``int`` / ``float``, but not ``bool``)
    and epoch datetime values need ``@`` boxing; everything else is
    already a valid Objective-C object expression.  The redundant
    ``@(...)`` parentheses are dropped when the formatted value is a
    bare numeric literal so that clang-tidy's
    ``readability-redundant-parentheses`` check passes.
    """
    match original:
        case bool():
            return formatted
        case dt.datetime() if datetime_as_number:
            pass
        case int() | float():
            pass
        case _:
            return formatted
    if _OBJC_BARE_NUMERIC.fullmatch(string=formatted) is not None:
        return f"@{formatted}"
    if formatted.startswith("(") and formatted.endswith(")"):
        return f"@{formatted}"
    return f"@({formatted})"


@beartype
def _build_objc_entry_formatter(
    *, datetime_as_number: bool
) -> Callable[[Value, str], str]:
    """Build an entry formatter from datetime output metadata."""

    @beartype
    def _format(original: Value, formatted: str) -> str:
        """Box one Objective-C value."""
        return _format_objc_entry(
            original,
            formatted,
            datetime_as_number=datetime_as_number,
        )

    return _format


@beartype
def _build_objc_declaration(
    *, format_entry: Callable[[Value, str], str]
) -> Callable[[str, str, Value, frozenset[enum.Enum]], str]:
    """Build an Objective-C declaration formatter."""

    @beartype
    def _format(
        name: str,
        value: str,
        data: Value,
        _modifiers: frozenset[enum.Enum],
    ) -> str:
        """Declare one boxed Objective-C value."""
        return f"id {name} = {format_entry(data, value)};"

    return _format


@beartype
def _build_objc_assignment(
    *, format_entry: Callable[[Value, str], str]
) -> Callable[[str, str, Value], str]:
    """Build an Objective-C assignment formatter."""

    @beartype
    def _format(name: str, value: str, data: Value) -> str:
        """Assign one boxed Objective-C value."""
        return f"{name} = {format_entry(data, value)};"

    return _format


_format_objc_entry_iso = _build_objc_entry_formatter(datetime_as_number=False)


_CALL_LITERAL_SYNTAX = CallLiteralSyntax(
    prefix="//",
    regex_literals=False,
    backtick_strings=False,
    raw_string_prefixes=(),
    verbatim_strings=False,
    interpolation_syntax=None,
    quotes="\"'",
    literal_span_end=None,
)


@beartype
def _format_objc_call_declaration(
    name: str,
    value: str,
    _data: Value,
    _modifiers: frozenset[enum.Enum],
) -> str:
    """Format an Objective-C ``id`` declaration binding a call result.

    The literal-binding declaration boxes a primitive right-hand side
    as ``NSNumber`` / ``NSString`` because an ``id`` is a pointer type.
    A call expression already evaluates to an object pointer, so the
    ``@(...)`` boxing is dropped and the call result is bound directly.
    """
    comments = _CALL_LITERAL_SYNTAX.split(value)
    return f"id {name} = {comments.code};" + comments.trailing_comments


@beartype
def _format_objc_call_assignment(name: str, value: str, _data: Value) -> str:
    """Format an Objective-C reassignment binding a call result.

    The call-expression counterpart of the literal assignment formatter;
    no ``@(...)`` boxing since a call already yields an object pointer.
    """
    comments = _CALL_LITERAL_SYNTAX.split(value)
    return f"{name} = {comments.code};" + comments.trailing_comments


@beartype
def _format_objc_string(value: str) -> str:
    r"""Format a string as an Objective-C ``NSString`` literal.

    Escapes backslashes, double quotes, newlines, carriage returns, and
    tabs, then wraps the result in ``@"..."``.

    Example: ``hello "world"`` → ``@"hello \"world\""``.
    """
    if has_bidi_formatting_character(value=value):
        segments = value.split(sep="\0")
        formatted = f"@({format_string_c(value=segments[0])})"
        for segment in segments[1:]:
            formatted = f'[{formatted} stringByAppendingString:@"\\000"]'
            suffix = _format_objc_string(value=segment)
            formatted = f"[{formatted} stringByAppendingString:{suffix}]"
        return formatted
    return f"@{format_string_c(value=value)}"


@beartype
def _format_objc_bytes(value: bytes) -> str:
    """Format bytes as an Objective-C ``NSString`` hex literal.

    Example: ``b"Hi"`` → ``@"4869"``.
    """
    return f'@"{value.hex()}"'


@beartype
def _format_objc_bytes_base64(value: bytes) -> str:
    """Format bytes as an Objective-C ``NSString`` base64 literal.

    Example: ``b"Hello"`` → ``@"SGVsbG8="``.
    """
    encoded = base64.b64encode(s=value)
    return f'@"{encoded.decode(encoding="ascii")}"'


@beartype
def _objc_global_root(root: str, /) -> str:
    """Return a ``k``-prefixed, title-cased root for an Objective-C
    const global, so the emitted name satisfies clang-tidy's
    ``google-objc-global-variable-declaration`` check.
    """
    return f"k{root.title()}"


@beartype
def _objc_format_call_target(parts: Sequence[str], /) -> str:
    """Rewrite the root of a dotted call target to its k-prefixed form
    so the call site matches the renamed const global emitted by
    :func:`_objc_call_stub`.  Single-name calls resolve to a ``static``
    function (not a const global) and are returned unchanged.
    """
    if len(parts) == 1:
        return parts[0]
    return ".".join((_objc_global_root(parts[0]), *parts[1:]))


@beartype
def _expanded_objc_stub_body(
    params: Sequence[str], indent: str, /, *, is_value: bool
) -> str:
    """Emit each generated helper statement on its own indented line."""
    statements = [f"(void)_a{i};" for i in range(len(params))]
    if is_value:
        statements.append(f"return {_NULL_OBJECT_STUB.value};")
    return (
        "{\n"
        + "".join(indent + statement + "\n" for statement in statements)
        + "}"
    )


@beartype
def _objc_call_stub(
    parts: Sequence[str],
    params: Sequence[str],
    stub_return: StubReturn,
    _args: Sequence[Value],
    /,
    *,
    indent: str,
    expand_body: bool,
) -> tuple[str, ...]:
    """Return Objective-C stub declarations for a call name.

    Objective-C is a superset of C, so call stubs reuse C's structure:
    dotted targets become a nested chain of ``struct`` types whose leaf
    field is a function pointer.  Each prototype declares one ``id``
    parameter per call argument; primitive arguments are boxed via
    ``@(...)`` at the call site so every actual argument is an
    Objective-C object.  This avoids K&R unspecified-parameter syntax
    and the ``-Wstrict-prototypes`` / ``-Wdeprecated-non-prototype``
    warnings that clang would otherwise emit.

    The root of a dotted target is rewritten to ``k{Title}`` form (e.g.
    ``throttler`` → ``kThrottler``) so the const global satisfies
    clang-tidy's ``google-objc-global-variable-declaration`` check.

    Single-name calls emit a ``static`` definition so the fixture links
    under the lint workflow's run step — a bare prototype without a body
    would otherwise fail at link time.
    """
    is_value = stub_return is StubReturn.VALUE
    return_keyword = "void"
    return_stmt = ""
    if is_value:
        return_keyword = _NULL_OBJECT_STUB.type_name
        return_stmt = f" return {_NULL_OBJECT_STUB.value};"
    proto = "void"
    if len(params) > 0:
        proto = ", ".join(["id"] * len(params))
    stub_params = ", ".join(f"id _a{i}" for i in range(len(params)))
    stub_signature = _stub_parameter_signature(parameters=stub_params)
    # Discard the parameters together: the stub treats every argument alike.
    discards = ""
    if len(params) > 0:
        expressions = ", ".join(f"(void)_a{i}" for i in range(len(params)))
        discards = f" {expressions};"
    has_body = discards != "" or is_value
    stub_body = "{}"
    if has_body:
        stub_body = f"{{{discards}{return_stmt} }}"
    if expand_body:
        stub_body = _expanded_objc_stub_body(params, indent, is_value=is_value)
    if len(parts) == 1:
        return (
            (
                f"static {return_keyword} {parts[0]}({stub_signature}) "
                f"{stub_body}"
            ),
        )
    root = _objc_global_root(parts[0])
    method = parts[-1]
    fields = parts[1:-1]
    stub_fn = "_".join((root, *parts[1:], "stub_"))
    if len(fields) == 0:
        type_name = f"{root}Type_"
        return (
            f"static {return_keyword} {stub_fn}({stub_signature}) {stub_body}",
            (
                f"struct {type_name} "
                f"{{ {return_keyword} (*{method})({proto}); }};"
            ),
            (
                f"static const struct {type_name} {root} = "
                f"{{ .{method} = {stub_fn} }};"
            ),
        )
    lines: list[str] = [
        f"static {return_keyword} {stub_fn}({stub_signature}) {stub_body}",
    ]
    inner_type = f"{fields[-1]}Type_"
    lines.append(
        f"struct {inner_type} {{ {return_keyword} (*{method})({proto}); }};",
    )
    prev_type = inner_type
    for i in range(len(fields) - 2, -1, -1):
        curr_type = f"{fields[i]}Type_"
        lines.append(
            f"struct {curr_type} {{ struct {prev_type} {fields[i + 1]}; }};",
        )
        prev_type = curr_type
    root_type = f"{root}Type_"
    lines.append(
        f"struct {root_type} {{ struct {prev_type} {fields[0]}; }};",
    )
    init = f"{{ .{method} = {stub_fn} }}"
    for field in reversed(fields):
        init = f"{{ .{field} = {init} }}"
    lines.append(f"static const struct {root_type} {root} = {init};")
    return tuple(lines)


# The C standard library and common POSIX function names.  A
# wrapped file imports Foundation, which brings their prototypes
# into scope, so a wrapper of one of these names declares it again
# with a different signature and clang refuses the file with
# ``conflicting types`` (issue #4534).
_LIBC_FUNCTION_NAMES: frozenset[str] = frozenset(
    {
        "abort",
        "abs",
        "acos",
        "acosh",
        "asctime",
        "asin",
        "asinh",
        "atan",
        "atan2",
        "atanh",
        "atexit",
        "atof",
        "atoi",
        "atol",
        "atoll",
        "bcopy",
        "bsearch",
        "btowc",
        "bzero",
        "cabs",
        "cacos",
        "calloc",
        "casin",
        "catan",
        "cbrt",
        "ceil",
        "cimag",
        "clearerr",
        "clock",
        "close",
        "cos",
        "cosh",
        "creal",
        "ctime",
        "difftime",
        "div",
        "exit",
        "exp",
        "exp2",
        "expm1",
        "fabs",
        "fclose",
        "feof",
        "ferror",
        "fflush",
        "fgetc",
        "fgetpos",
        "fgets",
        "floor",
        "fmax",
        "fmin",
        "fmod",
        "fopen",
        "fprintf",
        "fputc",
        "fputs",
        "fread",
        "free",
        "freopen",
        "frexp",
        "fscanf",
        "fseek",
        "fsetpos",
        "ftell",
        "fwrite",
        "getc",
        "getchar",
        "getenv",
        "gets",
        "gmtime",
        "hypot",
        "index",
        "isalnum",
        "isalpha",
        "isblank",
        "iscntrl",
        "isdigit",
        "isgraph",
        "islower",
        "isprint",
        "ispunct",
        "isspace",
        "isupper",
        "isxdigit",
        "kill",
        "labs",
        "ldexp",
        "ldiv",
        "llabs",
        "lldiv",
        "localeconv",
        "localtime",
        "log",
        "log10",
        "log1p",
        "log2",
        "longjmp",
        "malloc",
        "mblen",
        "mbstowcs",
        "mbtowc",
        "memchr",
        "memcmp",
        "memcpy",
        "memmove",
        "memset",
        "mktime",
        "modf",
        "nan",
        "nearbyint",
        "open",
        "perror",
        "pow",
        "printf",
        "putc",
        "putchar",
        "puts",
        "qsort",
        "quick_exit",
        "raise",
        "rand",
        "read",
        "realloc",
        "remainder",
        "remove",
        "rename",
        "rewind",
        "rindex",
        "round",
        "scanf",
        "setbuf",
        "setlocale",
        "setvbuf",
        "signal",
        "sin",
        "sinh",
        "sleep",
        "snprintf",
        "sprintf",
        "sqrt",
        "srand",
        "sscanf",
        "strcat",
        "strchr",
        "strcmp",
        "strcoll",
        "strcpy",
        "strcspn",
        "strerror",
        "strftime",
        "strlen",
        "strncat",
        "strncmp",
        "strncpy",
        "strpbrk",
        "strrchr",
        "strspn",
        "strstr",
        "strtod",
        "strtof",
        "strtok",
        "strtol",
        "strtold",
        "strtoll",
        "strtoul",
        "strtoull",
        "strxfrm",
        "system",
        "tan",
        "tanh",
        "time",
        "tmpfile",
        "tmpnam",
        "tolower",
        "toupper",
        "trunc",
        "ungetc",
        "usleep",
        "vfprintf",
        "vprintf",
        "vsprintf",
        "wcstombs",
        "wctomb",
        "write",
    }
)


# Work around https://github.com/astral-sh/ty/issues/4573.
if TYPE_CHECKING:
    _BytesEnumMember = enum.member[Callable[[bytes], str]]
    _IntegerEnumMember = enum.member[Callable[[int], str]]
else:
    _BytesEnumMember = enum.member
    _IntegerEnumMember = enum.member


@beartype
@dataclasses.dataclass(frozen=True, kw_only=True)
class ObjectiveC(metaclass=LanguageCls):
    """Objective-C language specification."""

    format_call_class_scope_stub = default_format_call_stub

    immutable_variable_modifiers: ClassVar[frozenset[enum.Enum]] = frozenset()
    wrap_in_file_tolerates_pre_indent = True
    module_name_shares_variable_scope = False
    reserved_variable_identifier_pattern: ClassVar[re.Pattern[str] | None] = (
        None
    )
    reserved_call_parameter_identifiers: ClassVar[frozenset[str]] = frozenset()
    reserved_call_parameter_identifier_pattern: ClassVar[
        re.Pattern[str] | None
    ] = None
    uses_data_keyword_for_algebraic_constructors = False
    accepts_type_name_call_target = True
    declares_type_name_call_target = True
    dotted_call_root_shares_entrypoint_namespace = True
    reserved_bare_call_target_identifiers: ClassVar[frozenset[str]] = (
        frozenset()
    )
    reserved_call_target_head_identifiers: ClassVar[frozenset[str]] = (
        frozenset()
    )
    contextual_call_target_identifiers: ClassVar[frozenset[str]] = frozenset()
    call_parameter_shadowing = CallParameterShadowing.ALLOWED
    reserved_call_target_keywords_case_sensitive = True
    module_name_must_start_uppercase = False
    new_variable_name_syntax = NewVariableNameSyntax.ASCII
    max_variable_identifier_length: ClassVar[int | None] = None
    call_stub_result: ClassVar[CallStubResult | None] = _NULL_OBJECT_STUB
    call_literal_syntax: ClassVar[CallLiteralSyntax | None] = (
        _CALL_LITERAL_SYNTAX
    )
    call_target_name_syntax: ClassVar[NewVariableNameSyntax | None] = None
    supports_multiline_dict_layout = True
    pools_map_integer_width = True

    format_integer_widened = no_format_integer_widened
    format_integer_beyond_i64 = no_format_integer_beyond_i64
    format_constructor_target: ClassVar["staticmethod[[str], str]"] = (
        staticmethod(identity_constructor_target)
    )
    sequence_binding_declarations = default_sequence_binding_declarations
    format_call_binding_body_preamble = no_call_binding_body_preamble
    format_call_binding_file_pragmas = no_call_binding_file_pragmas

    class NativeArgumentLayouts(enum.Enum):
        """Line breaks selected by the typed invocation emitter."""

        INLINE = enum.auto()
        MULTILINE = enum.auto()
        AUTO = enum.auto()

    indent_file_body: bool = False
    expand_call_stubs: bool = False

    native_argument_layout: NativeArgumentLayouts = (
        NativeArgumentLayouts.INLINE
    )
    native_align_selectors: bool = True
    native_continuation_indent: int = 1
    native_column_limit: int = 80
    native_collection_layout: CollectionLayout = CollectionLayout.COMPACT

    module_name: str = "Module"

    leading_preamble = no_leading_preamble
    extension = ".m"
    pygments_name = "objective-c"
    stringifies_nested_collections = False
    supports_special_floats = True
    supports_variable_names = True
    supports_no_variable_wrap_in_file = False
    wraps_data_dependent_preamble_in_body = False
    dict_supports_heterogeneous_values = True
    supports_local_binding_documents = False
    supports_stateful_free_call_consumers = True
    supports_stateful_receiver_result_checks = True
    supports_native_invocations = True
    supports_dotted_calls = True
    has_free_function_calls = True
    reserved_identifiers: ClassVar[frozenset[str]] = frozenset()
    declares_call_parameter_names = True
    reserved_variable_identifiers_case_sensitive: bool = True
    reserved_variable_identifiers: frozenset[str] = frozenset(
        {
            "BOOL",
            "Class",
            "IMP",
            "NO",
            "NULL",
            "Nil",
            "SEL",
            "YES",
            "auto",
            "break",
            "case",
            "char",
            "const",
            "continue",
            "default",
            "do",
            "double",
            "else",
            "enum",
            "extern",
            "float",
            "for",
            "goto",
            "id",
            "if",
            "inline",
            "int",
            "long",
            "nil",
            "register",
            "restrict",
            "return",
            "short",
            "signed",
            "sizeof",
            "static",
            "struct",
            "super",
            "switch",
            "typedef",
            "typeof",
            "union",
            "unsigned",
            "void",
            "volatile",
            "while",
        }
    )
    allows_empty_call_parens = True
    supports_dotted_call_stub = False
    dotted_call_stub_indexes_colliding_helpers = False
    call_returns_expression = True
    supports_json_call_result_binding = False
    supports_zero_parameter_calls = True
    max_call_parameters = NO_CALL_PARAMETER_LIMIT
    supports_inline_multiline_dict_args = True
    supports_standalone_comments_in_wrapped_calls = True
    supports_multi_param_call_wrapper_stub = True
    supports_variadic_calls = False
    supports_dict_literal_as_free_expression = True
    reserved_module_identifiers: ClassVar[frozenset[str]] = (
        frozenset(
            {
                "begin",
                "class",
                "end",
            }
        )
        | _LIBC_FUNCTION_NAMES
    )
    supports_module_name = True
    supports_empty_dict_key = False
    supports_call_style = True
    supports_bare_mapping_documents = False
    supports_json_object_documents = False
    supports_default_dict_key_type = False
    supports_default_dict_value_type = False
    supports_nullable_object_fallbacks = False
    supports_default_sequence_element_type = False
    supports_key_value_assignment_documents = False
    supports_default_set_element_type = False
    supports_default_ordered_map_value_type = False
    json_type_variant_name_suffix: ClassVar[str | None] = None
    supports_non_ascii_string_literals = True
    supports_multiline_string_literals = False
    supports_empty_sibling_sequence_type_hints = True
    supports_typed_dict_open = False
    language_id: ClassVar[str] = "objective_c"
    variant_metadata: ClassVar[VariantMetadata] = VariantMetadata(
        round_trip_capabilities=frozenset(
            {
                RoundTripCapability.I64_BOUNDARIES,
                RoundTripCapability.INTERPOLATION_STRINGS,
                RoundTripCapability.EMBEDDED_NUL,
            }
        ),
        modifier_sequence_format_overrides={},
        string_literals_escape_null_byte=True,
        supports_ref_elements_in_tuple_strategy=False,
    )
    supports_record_struct_name_prefix = False
    supports_record_shape_names = False
    record_shape_names_emit_declarations = False
    supports_non_string_dict_keys = False
    checks_raw_control_dict_keys_separately = False

    class DateFormats(DateFormatEnum):
        """Date format options for ObjectiveC."""

        OBJC = DateFormatConfig(
            formatter=_format_date_objc,
            preamble_lines=(),
            type_produced=dt.date,
        )
        ISO = DateFormatConfig(
            formatter=date_iso_formatter(template='@"{iso}"'),
            type_produced=str,
            preamble_lines=(),
        )

    class DatetimeFormats(DatetimeFormatEnum):
        """Datetime format options for ObjectiveC."""

        OBJC = DatetimeFormatConfig(
            formatter=_format_datetime_objc,
            preamble_lines=(),
            type_produced=dt.datetime,
        )
        ISO = DatetimeFormatConfig(
            formatter=datetime_iso_formatter(template='@"{iso}"'),
            type_produced=str,
            preamble_lines=(),
        )

        EPOCH = DatetimeFormatConfig(
            formatter=format_datetime_epoch,
            type_produced=int,
            preamble_lines=(),
        )

    class BytesFormats(FormatValueMixin[Callable[[bytes], str]], enum.Enum):
        """Bytes formatting options."""

        HEX = _BytesEnumMember(value=_format_objc_bytes)
        BASE64 = _BytesEnumMember(value=_format_objc_bytes_base64)

        def __call__(self, data: bytes, /) -> str:
            """Format bytes."""
            return self.value(data)

    class SequenceFormats(enum.Enum):
        """Sequence type options for Objective-C."""

        ARRAY = SequenceFormatConfig(
            length_is_part_of_type=False,
            sequence_open=fixed_open(open_str="@["),
            close="]",
            empty_sequence="@[]",
            supports_heterogeneity=True,
            single_element_trailing_comma=False,
            single_element_template=None,
            supports_trailing_comma=True,
            preamble_lines=(),
            format_entry=passthrough_sequence_entry,
            typed_opener_fallback=None,
            uses_typed_literal_for_scalars=False,
            requires_uniform_record_shapes=False,
            declared_type=None,
            narrowed_empty_form=None,
        )

    class SetFormats(enum.Enum):
        """Set type options for Objective-C."""

        SET = SetFormatConfig(
            set_open=fixed_open(open_str="[NSSet setWithArray:@["),
            close="]]",
            empty_set="[NSSet set]",
            preamble_lines=(),
            set_opener_template="",
            supports_heterogeneity=True,
            supports_trailing_comma=True,
        )

    class CommentFormats(enum.Enum):
        """Comment style options."""

        DOUBLE_SLASH = CommentConfig(
            prefix="//",
            suffix="",
        )
        BLOCK = CommentConfig(
            prefix="/*",
            suffix=" */",
        )

    class DeclarationStyles(enum.Enum):
        """Declaration style options."""

        TYPED = DeclarationStyleConfig(
            formatter=_build_objc_declaration(
                format_entry=_format_objc_entry_iso
            ),
            supports_redefinition=True,
        )

    class DictEntryStyles(enum.Enum):
        """Spacing around an Objective-C dictionary entry colon."""

        DEFAULT = enum.auto()
        SPACED = enum.auto()

    class DictFormats(enum.Enum):
        """Dict/map format options."""

        DEFAULT = enum.auto()

    class EmptyDictKey(enum.Enum):
        """Empty dict key options."""

        ALLOW = enum.auto()

    class FloatFormats(
        FloatSpecialsMixin,
        enum.Enum,
        positive_infinity="INFINITY",
        negative_infinity="-INFINITY",
        nan="NAN",
    ):
        """Float format options."""

        REPR = enum.member(value=format_float_repr)
        SCIENTIFIC = enum.member(value=format_float_scientific)
        FIXED = enum.member(value=format_float_fixed)

    class IntegerFormats(FormatValueMixin[Callable[[int], str]], enum.Enum):
        """Integer format options."""

        DECIMAL = _IntegerEnumMember(value=str)
        HEX = _IntegerEnumMember(value=format_integer_hex)
        OCTAL = _IntegerEnumMember(value=format_integer_octal_c_style)

        def __call__(self, value: int, /) -> str:
            """Format an integer."""
            formatter: Callable[[int], str] = self.value
            return formatter(value)

    class NumericLiteralSuffixes(enum.Enum):
        """Numeric literal suffix options."""

        NONE = enum.auto()

    class NumericSeparators(enum.Enum):
        """Numeric separator options."""

        NONE = enum.auto()

    class NumericStyles(enum.Enum):
        """Numeric literal style options."""

        OVERLOADED = enum.auto()

    class StringFormats(enum.Enum):
        """String format options."""

        DOUBLE = enum.auto()

    class TrailingCommas(enum.Enum):
        """Trailing comma options."""

        YES = TrailingCommaConfig(multiline_trailing_comma=True)
        NO = TrailingCommaConfig(multiline_trailing_comma=False)

    date_formats = DateFormats
    datetime_formats = DatetimeFormats
    bytes_formats = BytesFormats
    sequence_formats = SequenceFormats
    set_formats = SetFormats
    comment_formats = CommentFormats

    class VariableTypeHints(enum.Enum):
        """Variable type hint options."""

        NEVER = enum.auto()
        SAFE = enum.auto()

    variable_type_hints_formats = VariableTypeHints
    declaration_styles = DeclarationStyles
    dict_entry_styles = DictEntryStyles
    dict_formats = DictFormats
    empty_dict_keys = EmptyDictKey
    float_formats = FloatFormats
    integer_formats = IntegerFormats
    integer_width_strategies = BareIntegerWidthStrategies
    numeric_literal_suffixes = NumericLiteralSuffixes
    numeric_separators = NumericSeparators
    numeric_styles = NumericStyles
    string_formats = StringFormats
    trailing_commas = TrailingCommas

    class StatementTerminatorStyles(enum.Enum):
        """Statement terminator options."""

        SEMICOLON = enum.auto()

    statement_terminator_styles = StatementTerminatorStyles

    class CallStyles(enum.Enum):
        """ObjectiveC call style options."""

        POSITIONAL = PositionalCallStyle(
            arg_separator=", ", parenthesize_each_arg=False
        )

    call_styles = CallStyles

    class Modifiers(enum.Enum):
        """C++/Java/C#-style declaration modifiers: this language has none."""

    modifiers = Modifiers

    class HeterogeneousStrategies(enum.Enum):
        """Heterogeneous-scalar strategy options — this language only
        supports raising.
        """

        ERROR = NO_HETEROGENEOUS_BEHAVIOR

    heterogeneous_strategies = HeterogeneousStrategies

    class JsonTypes(JsonType):
        """Empty: this language has no JSON value-type variants."""

    json_types = JsonTypes

    class BoolFormats(enum.Enum):
        """Empty: this language has no alternative boolean formats."""

    bool_formats = BoolFormats

    class VersionFormats(enum.Enum):
        """Version options for Objective-C."""

        V2 = enum.auto()

    version_formats = VersionFormats

    module_name_case: ClassVar[IdentifierCase] = IdentifierCase.SNAKE

    modifier_combinations: ClassVar[tuple[ModifierCombination, ...]] = ()
    identifier_cases: ClassVar[tuple[IdentifierCase, ...]] = (
        IdentifierCase.CAMEL,
        IdentifierCase.PASCAL,
    )
    supported_ref_cases: ClassVar[frozenset[IdentifierCase]] = (
        NON_KEBAB_REF_CASES
    )

    validate_spec_for_data = no_validate_spec_for_data

    validate_call_arg = default_validate_call_arg

    format_call_statement = default_format_call_statement

    wrap_calls_with_declarations = default_wrap_calls_with_declarations

    def wrap_in_file(
        self,
        content: str,
        context: FileWrapperContext,
    ) -> str:
        """Wrap an Objective-C declaration in a main function."""
        variable_name = context.variable_name
        body_preamble = context.body_preamble
        content = prepend_body_preamble(
            content=content,
            body_preamble=body_preamble,
        )
        if self.indent_file_body:
            body = "\n".join(
                self.indent * 2 + line if line != "" else line
                for line in content.split(sep="\n")
            )
            use = (
                ""
                if variable_name == ""
                else f"\n{self.indent * 2}(void){variable_name};"
            )
            return (
                f"int {self.module_name}(void) {{\n"
                f"{self.indent}@autoreleasepool {{\n{body}{use}\n"
                f"{self.indent}}}\n{self.indent}return 0;\n}}"
            )
        use_line = ""
        if variable_name != "":
            use_line = f"\n{self.indent}(void){variable_name};"
        return (
            f"int {self.module_name}(void) {{\n"
            f"@autoreleasepool {{\n{content}{use_line}\n"
            f"}}\n{self.indent}return 0;\n}}"
        )

    def wrap_combined_in_file(
        self,
        declaration: str,
        assignment: str,
        context: FileWrapperContext,
    ) -> str:
        """Wrap Objective-C declaration + assignment in a function.

        Reads ``variable_name`` between the declaration and the
        assignment so the initial value is not a dead store flagged by
        clang-tidy's ``clang-analyzer-deadcode.DeadStores`` check.
        """
        variable_name = context.variable_name
        mid_use = f"(void){variable_name};\n"
        return self.wrap_in_file(
            content=f"{declaration}\n{mid_use}{assignment}",
            context=context,
        )

    date_format: DateFormats = DateFormats.OBJC
    datetime_format: DatetimeFormats = DatetimeFormats.OBJC
    bytes_format: BytesFormats = BytesFormats.HEX
    sequence_format: SequenceFormats = SequenceFormats.ARRAY
    set_format: SetFormats = SetFormats.SET
    variable_type_hints: VariableTypeHints = VariableTypeHints.NEVER
    comment_format: CommentFormats = CommentFormats.DOUBLE_SLASH
    declaration_style: DeclarationStyles = DeclarationStyles.TYPED
    dict_entry_style: DictEntryStyles = DictEntryStyles.DEFAULT
    dict_format: DictFormats = DictFormats.DEFAULT
    float_format: FloatFormats = FloatFormats.REPR
    integer_format: IntegerFormats = IntegerFormats.DECIMAL
    integer_width_strategy: BareIntegerWidthStrategies = (
        BareIntegerWidthStrategies.BARE
    )
    numeric_literal_suffix: NumericLiteralSuffixes = (
        NumericLiteralSuffixes.NONE
    )
    numeric_separator: NumericSeparators = NumericSeparators.NONE
    numeric_style: NumericStyles = NumericStyles.OVERLOADED
    string_format: StringFormats = StringFormats.DOUBLE
    trailing_comma: TrailingCommas = TrailingCommas.YES
    statement_terminator_style: StatementTerminatorStyles = (
        StatementTerminatorStyles.SEMICOLON
    )
    heterogeneous_strategy: HeterogeneousStrategies = (
        HeterogeneousStrategies.ERROR
    )
    # Keep in sync with the ``macos-15`` runner image pinned for the
    # ``lint-objectivec`` / ``lint-objectivec-tidy`` jobs in
    # ``.github/workflows/lint.yml``, whose Apple ``clang`` supports this
    # Objective-C 2.0 (``V2``) language generation.
    language_version: VersionFormats = VersionFormats.V2
    indent: str = "    "

    null_literal: ClassVar[str] = "[NSNull null]"
    true_literal: ClassVar[str] = "@YES"
    false_literal: ClassVar[str] = "@NO"
    indent_closing_delimiter: ClassVar[bool] = False
    element_separator: ClassVar[str] = ", "
    skip_null_dict_values: ClassVar[bool] = False
    supports_collection_comments: ClassVar[bool] = True
    supports_scalar_before_comments: ClassVar[bool] = False
    supports_scalar_inline_comments: ClassVar[bool] = False
    statement_terminator: ClassVar[str] = ";"
    static_preamble: ClassVar[Sequence[str]] = (
        "#import <Foundation/Foundation.h>",
    )
    static_body_preamble: ClassVar[Sequence[str]] = ()
    special_float_preamble: ClassVar[tuple[str, ...]] = ()
    call_style: CallStyles = CallStyles.POSITIONAL

    @staticmethod
    @beartype
    def render_native_invocation(
        language: Language, invocation: NativeInvocation, /
    ) -> str:
        """Render an explicitly typed native call expression."""
        return objective_c_invocation(language, invocation)

    @staticmethod
    @beartype
    def render_native_invocation_at_column(
        language: Language,
        invocation: NativeInvocation,
        /,
        *,
        initial_column: int,
        scope_indent: int,
    ) -> str:
        """Emit native syntax with the caller's binding and scope
        columns.
        """
        return objective_c_invocation(
            language,
            invocation,
            initial_column=initial_column,
            scope_indent=scope_indent,
        )

    @staticmethod
    @beartype
    def native_type_name(native_type: NativeType, /) -> str:
        """Spell a declared native scalar or object type."""
        return objective_c_type(native_type)

    @cached_property
    @beartype
    def call_style_config(self) -> PositionalCallStyle:
        """Configuration for the chosen call style."""
        return self.call_style.value

    @cached_property
    @beartype
    def format_string(self) -> Callable[[str], str]:
        """Format a string value as a quoted literal."""
        return _format_objc_string

    @cached_property
    @beartype
    def _entry_formatter(self) -> Callable[[Value, str], str]:
        """Entry formatter built from datetime output metadata."""
        return _build_objc_entry_formatter(
            datetime_as_number=self.datetime_format.value.type_produced is int
        )

    @cached_property
    @beartype
    def format_sequence_entry(self) -> Callable[[Value, str], str]:
        """Format a sequence entry."""
        return self._entry_formatter

    @cached_property
    @beartype
    def format_set_entry(self) -> Callable[[Value, str], str]:
        """Format a set entry."""
        return self._entry_formatter

    assignment_declares_binding = requires_declared_binding
    reference_assignment_declares_binding = assignment_declares_binding
    call_assignment_declares_binding = False

    @cached_property
    @beartype
    def format_variable_assignment(self) -> Callable[[str, str, Value], str]:
        """Format an assignment to an existing variable."""
        return _build_objc_assignment(format_entry=self._entry_formatter)

    @cached_property
    @beartype
    def format_call_variable_declaration(
        self,
    ) -> Callable[[str, str, Value, frozenset[enum.Enum]], str]:
        """Callable that formats a declaration binding a call expression.

        The literal-binding declaration boxes a primitive right-hand
        side as ``NSNumber`` / ``NSString`` (an ``id`` is a pointer
        type); a call expression already yields an object pointer, so
        the ``@(...)`` boxing is dropped and the call result is bound
        directly.
        """
        return _format_objc_call_declaration

    @cached_property
    @beartype
    def format_call_variable_assignment(
        self,
    ) -> Callable[[str, str, Value], str]:
        """Callable that formats an assignment binding a call expression.

        The call-expression counterpart of
        :attr:`format_variable_assignment`; the ``@(...)`` boxing is
        dropped since a call already yields an object pointer.
        """
        return _format_objc_call_assignment

    @cached_property
    @beartype
    def data_dependent_preamble(self) -> Callable[[Value], tuple[str, ...]]:
        """Return data-dependent preamble lines."""
        return no_data_preamble

    @cached_property
    @beartype
    def heterogeneous_behavior(self) -> HeterogeneousBehavior:
        """Return the heterogeneous-behavior config."""
        return self.heterogeneous_strategy.value

    call_data_dependent_preamble = default_call_data_dependent_preamble

    type_hint_collection_preamble_lines = (
        default_type_hint_collection_preamble_lines
    )

    format_call_stub = default_format_call_stub

    @cached_property
    @beartype
    def format_call_preamble_stub(
        self,
    ) -> Callable[
        [Sequence[str], Sequence[str], StubReturn, Sequence[Value]],
        tuple[str, ...],
    ]:
        """Return file-scope stubs for a call expression."""
        return partial(
            _objc_call_stub,
            indent=self.indent,
            expand_body=self.expand_call_stubs,
        )

    @cached_property
    @beartype
    def format_call_target(self) -> Callable[[Sequence[str]], str]:
        """Rewrite a dotted call target so the root matches the
        ``k``-prefixed const global emitted by :func:`_objc_call_stub`.
        """
        return _objc_format_call_target

    format_call_ref_identifier = default_format_call_ref_identifier

    format_call_arg_ref_identifier = default_format_call_arg_ref_identifier

    format_call_arg_ref_identifier_consumable = (
        default_format_call_arg_ref_identifier_consumable
    )

    consumable_ref_value_inhibits_consuming_form = (
        default_consumable_ref_value_inhibits_consuming_form
    )

    @cached_property
    @beartype
    def format_call_arg(self) -> Callable[[Value, str], str]:
        """Box each call argument as an ``id`` so call sites match the
        concrete prototype emitted by :func:`_objc_call_stub`.
        """
        return self._entry_formatter

    @cached_property
    @beartype
    def sequence_format_config(self) -> SequenceFormatConfig:
        """Configuration for the chosen sequence format."""
        return self.sequence_format.value

    @cached_property
    @beartype
    def set_format_config(self) -> SetFormatConfig:
        """Configuration for the chosen set format."""
        return self.set_format.value

    @cached_property
    @beartype
    def sequence_open(self) -> Callable[[list[Value]], str]:
        """Callable that returns the opening delimiter for a sequence."""
        return self.sequence_format.value.sequence_open

    @cached_property
    @beartype
    def _dict_entry(self) -> Callable[[str, Value, str], str]:
        """Shared dict-entry formatter used by dict and ordered-map."""
        return dict_entry_with_separator(
            separator=" : "
            if self.dict_entry_style.name == "SPACED"
            else ": ",
            format_value=self._entry_formatter,
        )

    @cached_property
    @beartype
    def dict_format_config(self) -> DictFormatConfig:
        """Configuration for dict formatting."""
        return DictFormatConfig(
            dict_open=fixed_open(open_str="@{"),
            close="}",
            format_entry=self._dict_entry,
            empty_dict="@{}",
            preamble_lines=(),
            narrowed_open=None,
            supports_trailing_comma=True,
            narrowed_empty_form=None,
        )

    @cached_property
    @beartype
    def trailing_comma_config(self) -> TrailingCommaConfig:
        """Configuration for trailing-comma behavior."""
        return self.trailing_comma.value

    @cached_property
    @beartype
    def format_bytes(self) -> Callable[[bytes], str]:
        """Callable that formats a bytes value as a string literal."""
        return self.bytes_format

    @cached_property
    @beartype
    def format_date(self) -> Callable[[dt.date], str]:
        """Callable that formats a date as a string literal."""
        return self.date_format

    @cached_property
    @beartype
    def format_datetime(self) -> Callable[[dt.datetime], str]:
        """Callable that formats a datetime as a string literal."""
        return self.datetime_format

    @cached_property
    @beartype
    def format_time(self) -> Callable[[dt.time], str]:
        """Callable that formats a time as a string literal."""

        @beartype
        def _format(value: dt.time) -> str:
            """Format a time as an Objective-C ``NSString`` literal."""
            return f"@{format_time_iso(value=value)}"

        return _format

    @cached_property
    @beartype
    def format_float(self) -> Callable[[float], str]:
        """Callable that formats a float value as a literal."""
        return self.float_format

    @cached_property
    @beartype
    def format_integer(self) -> Callable[[int], str]:
        """Callable that formats an int value as a literal.

        Values above ``LLONG_MAX`` get a ``ULL`` suffix so clang does
        not reinterpret the literal as an unsigned type and emit the
        warning the lint workflow treats as an error; values below
        ``LLONG_MIN`` raise ``UnrepresentableIntegerError`` since no
        signed or unsigned 64-bit integer can hold them.
        """
        return make_overflow_fallback_formatter(
            base=make_i64_min_safe_formatter(base=self.integer_format),
            fallback=make_ull_fallback(language_name="Objective-C"),
            min_value=I64_MIN,
            max_value=I64_MAX,
        )

    @cached_property
    @beartype
    def comment_config(self) -> CommentConfig:
        """Configuration for the language's comment syntax."""
        return self.comment_format.value

    @cached_property
    @beartype
    def ordered_map_format_config(self) -> OrderedMapFormatConfig:
        """Configuration for ordered-map formatting."""
        return OrderedMapFormatConfig(
            ordered_map_open=fixed_open(open_str="@{"),
            close="}",
            preamble_lines=(),
        )

    @cached_property
    @beartype
    def format_ordered_map_entry(self) -> Callable[[str, Value, str], str]:
        """Callable that formats one ordered-map entry."""
        return self._dict_entry

    @cached_property
    @beartype
    def format_variable_declaration(
        self,
    ) -> Callable[[str, str, Value, frozenset[enum.Enum]], str]:
        """Callable that formats a new variable declaration."""
        return _build_objc_declaration(format_entry=self._entry_formatter)

    @cached_property
    @beartype
    def scalar_preamble(self) -> dict[type[object], tuple[str, ...]]:
        """Per-instance scalar preamble (Objective-C needs none)."""
        return {}

    @cached_property
    @beartype
    def scalar_body_preamble(self) -> dict[type[object], tuple[str, ...]]:
        """Per-instance scalar body preamble (Objective-C needs none)."""
        return {}

    @cached_property
    @beartype
    def compute_body_preamble(
        self,
    ) -> Callable[[frozenset[type[object]], Value], tuple[str, ...]]:
        """Compute body-preamble lines from the scalar map."""
        return body_preamble_from_scalars(
            scalar_body_preamble=self.scalar_body_preamble,
            format_lines=tuple,
        )
