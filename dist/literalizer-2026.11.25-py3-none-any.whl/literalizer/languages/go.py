"""Go language specification."""

import dataclasses
import datetime as dt
import enum
import math
import re
from collections.abc import Callable, Mapping, Sequence
from functools import cached_property
from types import MappingProxyType
from typing import TYPE_CHECKING, ClassVar

from beartype import beartype
from ruamel.yaml.compat import ordereddict as _ordereddict

from literalizer._formatters.collection_openers import (
    CollectionSignature,
    collection_signature,
    fixed_open,
    make_element_to_type,
    make_type_to_opener,
    signature_open,
    typed_collection_open,
    typed_dict_open,
)
from literalizer._formatters.format_dates import (
    datetime_epoch_seconds,
    format_date_iso,
    format_datetime_epoch,
    format_datetime_iso,
)
from literalizer._formatters.format_entries import (
    braced_dict_entry,
    dict_entry_with_separator,
    format_bytes_base64,
    format_bytes_hex,
    passthrough_sequence_entry,
    variable_declaration_formatter,
    variable_formatter,
)
from literalizer._formatters.format_factories import set_format_factory
from literalizer._formatters.format_floats import (
    format_float_fixed,
    format_float_repr,
    format_float_scientific,
)
from literalizer._formatters.format_integers import (
    I64_MAX,
    I64_MIN,
    format_integer_binary,
    format_integer_hex,
    format_integer_octal,
    format_integer_underscore,
    make_int64_cast_formatter,
    make_overflow_fallback_formatter,
    make_unsigned_overflow_fallback,
)
from literalizer._formatters.format_strings import (
    make_backslash_string_formatter,
)
from literalizer._formatters.record_strategy import (
    RecordDeclarationField,
    RecordFieldType,
    RecordLiteralField,
    RecordRenderer,
    RecordStrategy,
    build_record_strategy,
    identity_field_identifier_key,
    nested_record_sequence_type,
)
from literalizer._formatters.type_inference import (
    DictType,
    ListType,
    single_concrete_type,
)
from literalizer._heterogeneous import iter_wrapped_values
from literalizer._language import (
    NO_CALL_PARAMETER_LIMIT,
    NO_HETEROGENEOUS_BEHAVIOR,
    NON_KEBAB_REF_CASES,
    BareIntegerWidthStrategies,
    CallParameterShadowing,
    CallStubResult,
    CallStyle,
    CommentConfig,
    DateFormatConfig,
    DateFormatEnum,
    DatetimeFormatConfig,
    DatetimeFormatEnum,
    DeclarationStyleConfig,
    DictFormatConfig,
    FileWrapperContext,
    FloatSpecialsMixin,
    FormatValueMixin,
    HeterogeneousBehavior,
    IdentifierCase,
    JsonType,
    LanguageCls,
    ModifierCombination,
    NewVariableNameSyntax,
    NullableObjectCallStubResult,
    OrderedMapFormatConfig,
    PositionalCallStyle,
    RecordMapValueTypings,
    RenderedRecordLiteral,
    RoundTripCapability,
    SequenceFormatConfig,
    SetFormatConfig,
    StubReturn,
    TrailingCommaConfig,
    VariantMetadata,
    body_preamble_from_scalars,
    date_scalar_preamble,
    default_call_data_dependent_preamble,
    default_consumable_ref_value_inhibits_consuming_form,
    default_format_call_arg_ref_identifier,
    default_format_call_arg_ref_identifier_consumable,
    default_format_call_ref_identifier,
    default_format_call_statement,
    default_format_call_stub,
    default_format_call_target,
    default_format_call_variable_assignment,
    default_format_call_variable_declaration,
    default_sequence_binding_declarations,
    default_type_hint_collection_preamble_lines,
    default_wrap_calls_with_declarations,
    empty_record_shape_names,
    identity_call_arg,
    no_call_binding_body_preamble,
    no_call_binding_file_pragmas,
    no_data_preamble,
    no_format_integer_widened,
    no_leading_preamble,
    prepend_body_preamble,
    requires_declared_binding,
)
from literalizer._types import OrderedMap, Scalar, Value
from literalizer.exceptions import (
    InvalidRecordNameError,
    UnrepresentableInputError,
)

_NULL_OBJECT_STUB = NullableObjectCallStubResult(
    type_name="any",
    value="nil",
    conditional_template=None,
    comment_prefix="//",
)

_GO_I32_MIN = -(2**31)
_GO_I32_MAX = 2**31 - 1

_PASCAL_CASE_IDENTIFIER = re.compile(pattern=r"^[A-Z][A-Za-z0-9_]*$")
_TRAILING_LINE_WHITESPACE = re.compile(pattern=r"[ \t]+(?=\n)")

_format_string_go = make_backslash_string_formatter(
    quote_char='"',
    extra_replacements=[("\0", "\\x00"), ("\ufeff", "\\uFEFF")],
)


@beartype
def _reject_record_lists_with_empty_siblings(data: Value, /) -> None:
    """Reject Go record lists paired with an empty sibling without type
    information.
    """
    if isinstance(data, list):
        sibling_lists = [item for item in data if isinstance(item, list)]
        has_empty = any(len(item) == 0 for item in sibling_lists)
        populated = [item for item in sibling_lists if len(item) > 0]
        has_record_list = any(
            all(isinstance(element, dict) for element in item)
            for item in populated
        )
        if len(sibling_lists) == len(data) and has_empty and has_record_list:
            msg = (
                "Go RECORD cannot give a nested record list and its empty "
                "sibling one compatible declared type"
            )
            raise UnrepresentableInputError(msg)
        for child in data:
            _reject_record_lists_with_empty_siblings(child)
    elif isinstance(data, dict):
        for child in data.values():
            _reject_record_lists_with_empty_siblings(child)


@beartype
def _is_negative_zero(value: float) -> bool:
    """Return whether *value* is IEEE negative zero."""
    return value == 0 and math.copysign(1, value) < 0


@beartype
def _data_has_negative_zero(*, data: Value) -> bool:
    """Return whether a rendered value contains negative zero."""
    pending: list[Value] = [data]
    while len(pending) > 0:
        value = pending.pop()
        match value:
            case float():
                if _is_negative_zero(value=value):
                    return True
            case OrderedMap() | dict():
                pending.extend(value.values())
            case list() | set():
                pending.extend(value)
            case _:
                pass
    return False


@beartype
def _preserve_negative_zero(*, value: float, formatted: str) -> str:
    """Use a Go runtime expression for IEEE negative zero."""
    if _is_negative_zero(value=value):
        return "math.Copysign(0, -1)"
    return formatted


@beartype
def _format_float_repr(value: float) -> str:
    """Format a repr-style float without losing negative zero."""
    return _preserve_negative_zero(
        value=value,
        formatted=format_float_repr(value=value),
    )


@beartype
def _format_float_scientific(value: float) -> str:
    """Format a scientific float without losing negative zero."""
    return _preserve_negative_zero(
        value=value,
        formatted=format_float_scientific(value=value),
    )


@beartype
def _format_float_fixed(value: float) -> str:
    """Format a fixed float without losing negative zero."""
    return _preserve_negative_zero(
        value=value,
        formatted=format_float_fixed(value=value),
    )


@beartype
def _format_string_multiline(value: str) -> str:
    r"""Format *value* as a Go raw string, with a safe fallback."""
    if (
        "`" in value
        or "\r" in value
        or "\0" in value
        or "\ufeff" in value
        or _TRAILING_LINE_WHITESPACE.search(string=value) is not None
    ):
        return _format_string_go(value=value)
    return f"`{value}`"


@beartype
def _format_go_uint64_positive(value: int) -> str:
    """Format a positive value outside signed 64-bit range as a Go
    ``uint64`` typed conversion.

    A Go integer constant without an explicit type can hold arbitrary
    size, but its default promotion to ``int`` overflows.  Wrapping in
    ``uint64(...)`` forces a typed conversion.  The shared unsigned
    fallback rejects values above ``math.MaxUint64`` before this
    formatter is called.
    """
    return f"uint64({value})"


@beartype
def _go_call_preamble_stub(
    parts: Sequence[str],
    _params: Sequence[str],
    _stub_return: StubReturn,
    _args: Sequence[Value],
    /,
) -> tuple[str, ...]:
    """Return Go stub declarations for a call name."""
    return_type = _NULL_OBJECT_STUB.type_name
    return_value = _NULL_OBJECT_STUB.value
    if len(parts) == 1:
        return (
            (
                f"func {parts[0]}(args ...any)"
                f" {return_type} {{ return {return_value} }}"
            ),
        )
    root = parts[0]
    method = parts[-1]
    fields = parts[1:-1]
    if len(fields) == 0:
        type_name = f"{root}Type_"
        return (
            f"type {type_name} struct{{}}",
            (
                f"func ({type_name}) {method}(args ...any)"
                f" {return_type} {{ return {return_value} }}"
            ),
            f"var {root} {type_name}",
        )
    lines: list[str] = []
    inner_type = f"{fields[-1]}Type_"
    lines.append(f"type {inner_type} struct{{}}")
    lines.append(
        f"func ({inner_type}) {method}(args ...any)"
        f" {return_type} {{ return {return_value} }}"
    )
    prev_type = inner_type
    for i in range(len(fields) - 2, -1, -1):
        curr_type = f"{fields[i]}Type_"
        field = fields[i + 1]
        lines.append(f"type {curr_type} struct{{ {field} {prev_type} }}")
        prev_type = curr_type
    root_type = f"{root}Type_"
    lines.append(f"type {root_type} struct{{ {fields[0]} {prev_type} }}")
    lines.append(f"var {root} {root_type}")
    return tuple(lines)


@beartype
def _go_month_name(month: int) -> str:
    """Return the Go ``time.Month`` constant for a 1-based month
    number.
    """
    return (
        "time.January",
        "time.February",
        "time.March",
        "time.April",
        "time.May",
        "time.June",
        "time.July",
        "time.August",
        "time.September",
        "time.October",
        "time.November",
        "time.December",
    )[month - 1]


@beartype
def _format_date_go(value: dt.date) -> str:
    """Format a date as a Go ``time.Date(...)`` call."""
    month = _go_month_name(month=value.month)
    return (
        f"time.Date({value.year}, {month}, {value.day}, 0, 0, 0, 0, time.UTC)"
    )


@beartype
def _format_datetime_go(value: dt.datetime) -> str:
    """Format a datetime as a Go ``time.Date(...)`` call."""
    month = _go_month_name(month=value.month)
    nanoseconds = value.microsecond * 1000
    offset = value.utcoffset()
    offset_seconds = 0
    if offset is not None:
        if offset.microseconds != 0:
            msg = (
                "Go native datetime format cannot preserve subsecond "
                f"UTC offset {offset}"
            )
            raise UnrepresentableInputError(msg)
        offset_seconds = offset // dt.timedelta(seconds=1)
    location = "time.UTC"
    if offset_seconds != 0:
        location = f'time.FixedZone("", {offset_seconds})'
    return (
        f"time.Date({value.year}, {month}, {value.day}, "
        f"{value.hour}, {value.minute}, {value.second}, "
        f"{nanoseconds}, {location})"
    )


@beartype
def _format_time_go(value: dt.time) -> str:
    """Format a local time as a Go ``time.Time`` with a zero date."""
    nanoseconds = value.microsecond * 1000
    return (
        f"time.Date(0, time.January, 1, {value.hour}, {value.minute}, "
        f"{value.second}, {nanoseconds}, time.UTC)"
    )


@beartype
def _format_go_set_entry(_original: Value, item: str) -> str:
    """Format a Go set entry as a map entry with empty struct value.

    Example: ``"apple"`` → ``"apple": struct{}{}``.
    """
    return f"{item}: struct{{}}{{}}"


@beartype
def _go_record_field_identifier(key: str, /) -> str:
    """Return the exported Go struct field name for a dict *key*.

    The blank identifier names no field, so a struct literal cannot
    initialize one and the key is refused instead (issue #4505).
    """
    identifier = IdentifierCase.PASCAL.convert(name=key)
    if identifier == "_":
        msg = (
            f"Go cannot represent the dict key {key!r} as a struct field "
            "name: the blank identifier names no field, so a struct "
            "literal cannot initialize it"
        )
        raise UnrepresentableInputError(msg)
    return identifier


@beartype
def _go_record_literal(
    name: str,
    fields: Sequence[RecordLiteralField],
    /,
) -> RenderedRecordLiteral:
    """Render a Go ``Name{Field: value, ...}`` literal as structured
    pieces for the shared compact/multiline layout code.
    """
    return RenderedRecordLiteral(
        head=f"{name}{{",
        entries=tuple(
            f"{field.identifier}: {field.formatted}" for field in fields
        ),
        closer="}",
        compact_pad="",
    )


@beartype
@dataclasses.dataclass
class _GoWidenedMapNarrowing:
    """Per-pass cache of the widened fallback maps' narrow value type.

    ``value_type`` holds the single concrete Go type shared by every
    scalar inside the maps the ``RECORD`` strategy widened out of the
    record-shape mapping, or ``None`` when those scalars mix Go types
    and the ``map[string]any`` top type is required (issue #3608).
    Refreshed by the strategy's ``compute_wrap_ids`` hook, which the
    shared data checks run before any rendering; the widened-map opener
    and the record field-type hook read the cached decision within the
    same pass.
    """

    value_type: str | None


@beartype
def _apply_go_nil_safe_declaration(
    name: str,
    value: str,
    data: Value,
    modifiers: frozenset[enum.Enum],
    base_formatter: Callable[[str, str, Value, frozenset[enum.Enum]], str],
) -> str:
    """Format a Go variable declaration, guarding top-level
    ``nil``.
    """
    if data is None:
        return f"var {name} any = {value}"
    return base_formatter(name, value, data, modifiers)


@beartype
def _nil_safe_declaration(
    base_formatter: Callable[[str, str, Value, frozenset[enum.Enum]], str],
) -> Callable[[str, str, Value, frozenset[enum.Enum]], str]:
    """Wrap *base_formatter* so top-level ``nil`` gets a typed form.

    Go cannot infer a type from ``nil`` alone, so
    ``my_data := nil`` and ``var my_data = nil`` both fail to compile.
    Emit ``var {name} any = nil`` when the value is ``None``.
    """

    @beartype
    def _format(
        name: str,
        value: str,
        data: Value,
        modifiers: frozenset[enum.Enum],
    ) -> str:
        """Delegate to module-level implementation."""
        return _apply_go_nil_safe_declaration(
            name=name,
            value=value,
            data=data,
            modifiers=modifiers,
            base_formatter=base_formatter,
        )

    return _format


@beartype
def _format_constructor_target(class_name: str, /) -> str:
    """Return a Go ``NewClassName`` constructor call target."""
    return f"New{class_name}"


_constructor_target: Callable[[str], str] = _format_constructor_target


@beartype
def _go_nested_record_type(*, request: RecordFieldType) -> str | None:
    """Resolve a nested record or record-sequence field name."""
    if request.record_name is not None and request.record_name != "":
        nested_type = request.record_name
    else:
        nested_type = None
        if request.element_record_name is not None:
            nested_type = f"[]{request.element_record_name}"
    return nested_type


# Work around https://github.com/astral-sh/ty/issues/4573.
if TYPE_CHECKING:
    _BytesEnumMember = enum.member[Callable[[bytes], str]]
    _StringEnumMember = enum.member[Callable[[str], str]]
else:
    _BytesEnumMember = enum.member
    _StringEnumMember = enum.member


@beartype
@dataclasses.dataclass(frozen=True, kw_only=True)
class Go(metaclass=LanguageCls):
    """Go language specification.

    Args:
        date_format: How to format :class:`datetime.date` values.

            * ``date_formats.GO`` — ``time.Date`` call,
              e.g. ``time.Date(2024, time.January, 15, 0, 0, 0, 0,
              time.UTC)``.
            * ``date_formats.ISO`` — ISO 8601 quoted string,
              e.g. ``"2024-01-15"``.

        datetime_format: How to format :class:`datetime.datetime` values.

            * ``datetime_formats.GO`` — ``time.Date`` call,
              e.g. ``time.Date(2024, time.January, 15, 12, 30, 0, 0,
              time.UTC)``.
            * ``datetime_formats.ISO`` — ISO 8601 quoted string,
              e.g. ``"2024-01-15T12:30:00"``.

        record_map_value_typing: Value type for a ``RECORD`` strategy
            field whose map has no record shape of its own and so
            renders as a plain map.

            * ``record_map_value_typings.NARROW`` — the concrete type
              every widened scalar in this input shares, e.g.
              ``map[string]string``, falling back to ``map[string]any``
              when they span more than one type.  This is the default.
            * ``record_map_value_typings.WIDE`` — always
              ``map[string]any``.  Two inputs sharing one record shape
              then declare the field identically, so one input's
              literals compile against the other's ``struct``.
    """

    format_call_class_scope_stub = default_format_call_stub

    reserved_module_identifiers: ClassVar[frozenset[str]] = frozenset()
    immutable_variable_modifiers: ClassVar[frozenset[enum.Enum]] = frozenset()
    wrap_in_file_tolerates_pre_indent = True
    module_name_shares_variable_scope = False
    reserved_variable_identifier_pattern: ClassVar[re.Pattern[str] | None] = (
        None
    )
    reserved_call_parameter_identifiers: ClassVar[frozenset[str]] = frozenset()
    reserved_call_parameter_identifier_pattern: ClassVar[
        re.Pattern[str] | None
    ] = None
    uses_data_keyword_for_algebraic_constructors = False
    accepts_type_name_call_target = True
    declares_type_name_call_target = True
    dotted_call_root_shares_entrypoint_namespace = True
    reserved_bare_call_target_identifiers: ClassVar[frozenset[str]] = (
        frozenset()
    )
    reserved_call_target_head_identifiers: ClassVar[frozenset[str]] = (
        frozenset()
    )
    contextual_call_target_identifiers: ClassVar[frozenset[str]] = frozenset()
    call_parameter_shadowing = CallParameterShadowing.ALLOWED
    reserved_call_target_keywords_case_sensitive = True
    module_name_must_start_uppercase = False
    new_variable_name_syntax = NewVariableNameSyntax.ASCII
    max_variable_identifier_length: ClassVar[int | None] = None
    call_stub_result: ClassVar[CallStubResult | None] = _NULL_OBJECT_STUB
    call_literal_syntax: ClassVar[None] = None
    call_target_name_syntax: ClassVar[NewVariableNameSyntax | None] = None
    supports_multiline_dict_layout = True
    pools_map_integer_width = True

    format_integer_widened = no_format_integer_widened
    format_call_variable_declaration = default_format_call_variable_declaration
    format_call_variable_assignment = default_format_call_variable_assignment
    format_constructor_target: ClassVar["staticmethod[[str], str]"] = (
        staticmethod(_constructor_target)
    )
    sequence_binding_declarations = default_sequence_binding_declarations
    format_call_binding_body_preamble = no_call_binding_body_preamble
    format_call_binding_file_pragmas = no_call_binding_file_pragmas

    leading_preamble = no_leading_preamble
    extension = ".go"
    pygments_name = "go"
    stringifies_nested_collections = False
    supports_special_floats = True
    supports_variable_names = True
    supports_no_variable_wrap_in_file = False
    wraps_data_dependent_preamble_in_body = False
    dict_supports_heterogeneous_values = True
    supports_local_binding_documents = False
    supports_stateful_free_call_consumers = True
    supports_stateful_receiver_result_checks = True
    supports_native_invocations = False
    supports_dotted_calls = True
    has_free_function_calls = True
    declares_call_parameter_names = True
    reserved_variable_identifiers_case_sensitive: bool = True
    reserved_variable_identifiers: frozenset[str] = frozenset(
        {
            "_",
            "break",
            "case",
            "chan",
            "const",
            "continue",
            "default",
            "defer",
            "else",
            "fallthrough",
            "false",
            "for",
            "func",
            "go",
            "goto",
            "if",
            "import",
            # ``init`` must take no arguments and return nothing, and
            # cannot be referenced at all, so a generated stub named
            # after it neither declares nor calls (issue #4493).
            "init",
            "interface",
            "main",
            "map",
            "nil",
            "package",
            "range",
            "return",
            "select",
            "struct",
            "switch",
            "true",
            "type",
            "var",
        }
    )
    reserved_identifiers: ClassVar[frozenset[str]] = (
        reserved_variable_identifiers - (frozenset({"main"}))
    )
    allows_empty_call_parens = True
    supports_dotted_call_stub = True
    dotted_call_stub_indexes_colliding_helpers = False
    dotted_call_stub_requires_unique_parts = True
    call_returns_expression = True
    supports_json_call_result_binding = False
    supports_zero_parameter_calls = True
    max_call_parameters = NO_CALL_PARAMETER_LIMIT
    supports_inline_multiline_dict_args = True
    supports_standalone_comments_in_wrapped_calls = True
    supports_multi_param_call_wrapper_stub = True
    supports_variadic_calls = False
    supports_dict_literal_as_free_expression = True
    supports_module_name = False
    supports_empty_dict_key = False
    supports_call_style = True
    supports_bare_mapping_documents = False
    supports_json_object_documents = False
    supports_default_dict_key_type = True
    supports_default_dict_value_type = True
    supports_nullable_object_fallbacks = False
    supports_default_sequence_element_type = True
    supports_key_value_assignment_documents = False
    supports_default_set_element_type = True
    supports_default_ordered_map_value_type = True
    json_type_variant_name_suffix: ClassVar[str | None] = None
    supports_non_ascii_string_literals = True
    supports_multiline_string_literals = True
    supports_empty_sibling_sequence_type_hints = True
    supports_typed_dict_open = True
    language_id: ClassVar[str] = "go"
    variant_metadata: ClassVar[VariantMetadata] = VariantMetadata(
        round_trip_capabilities=frozenset(
            {
                RoundTripCapability.I64_BOUNDARIES,
                RoundTripCapability.INTERPOLATION_STRINGS,
                RoundTripCapability.EMBEDDED_NUL,
            }
        ),
        modifier_sequence_format_overrides={},
        string_literals_escape_null_byte=True,
        supports_ref_elements_in_tuple_strategy=False,
    )
    supports_record_struct_name_prefix = True
    supports_record_shape_names = True
    record_shape_names_emit_declarations = True
    supports_non_string_dict_keys = False
    checks_raw_control_dict_keys_separately = False

    format_call_arg: ClassVar["staticmethod[[Value, str], str]"] = (
        staticmethod(
            identity_call_arg,
        )
    )
    """Callable that rewrites a formatted direct call argument."""

    class DateFormats(DateFormatEnum):
        """Date format options for Go."""

        GO = DateFormatConfig(
            formatter=_format_date_go,
            preamble_lines=('import "time"',),
            type_produced=dt.date,
        )
        ISO = DateFormatConfig(
            formatter=format_date_iso, type_produced=str, preamble_lines=()
        )

    class DatetimeFormats(DatetimeFormatEnum):
        """Datetime format options for Go."""

        GO = DatetimeFormatConfig(
            formatter=_format_datetime_go,
            preamble_lines=('import "time"',),
            type_produced=dt.datetime,
        )
        ISO = DatetimeFormatConfig(
            formatter=format_datetime_iso,
            type_produced=str,
            preamble_lines=(),
        )

        EPOCH = DatetimeFormatConfig(
            formatter=format_datetime_epoch,
            type_produced=int,
            preamble_lines=(),
        )

    class BytesFormats(FormatValueMixin[Callable[[bytes], str]], enum.Enum):
        """Bytes formatting options."""

        HEX = _BytesEnumMember(value=format_bytes_hex)
        BASE64 = _BytesEnumMember(value=format_bytes_base64)

        def __call__(self, data: bytes, /) -> str:
            """Format bytes."""
            return self.value(data)

    class SequenceFormats(enum.Enum):
        """Sequence type options for Go."""

        SLICE = SequenceFormatConfig(
            length_is_part_of_type=False,
            sequence_open=fixed_open(open_str="[]any{"),
            close="}",
            supports_heterogeneity=True,
            single_element_trailing_comma=False,
            single_element_template=None,
            supports_trailing_comma=True,
            empty_sequence=None,
            preamble_lines=(),
            format_entry=passthrough_sequence_entry,
            typed_opener_fallback=None,
            uses_typed_literal_for_scalars=False,
            requires_uniform_record_shapes=False,
            declared_type=None,
            narrowed_empty_form=None,
        )

    class SetFormats(
        FormatValueMixin[Callable[[str], SetFormatConfig]], enum.Enum
    ):
        """Set type options for Go."""

        SET = enum.member(
            value=set_format_factory(
                open_template="map[{type}]struct{{}}{{",
                close="}}",
                empty_template=None,
                preamble_lines=(),
                set_opener_template="",
                supports_heterogeneity=True,
                supports_trailing_comma=True,
            )
        )

        def __call__(self, default_type: str) -> SetFormatConfig:
            """Create a set format config for the given type."""
            return self.value(default_type)

    class CommentFormats(enum.Enum):
        """Comment style options."""

        DOUBLE_SLASH = CommentConfig(
            prefix="//",
            suffix="",
        )
        BLOCK = CommentConfig(
            prefix="/*",
            suffix=" */",
        )

    class DeclarationStyles(enum.Enum):
        """Declaration style options."""

        SHORT = DeclarationStyleConfig(
            formatter=variable_declaration_formatter(
                template="{name} := {value}"
            ),
            supports_redefinition=True,
        )
        VAR = DeclarationStyleConfig(
            formatter=variable_declaration_formatter(
                template="var {name} = {value}"
            ),
            supports_redefinition=True,
        )

    class DictEntryStyles(enum.Enum):
        """Dict entry style options."""

        DEFAULT = enum.auto()

    class DictFormats(enum.Enum):
        """Dict/map format options."""

        DEFAULT = enum.auto()

    class EmptyDictKey(enum.Enum):
        """Empty dict key options."""

        ALLOW = enum.auto()

    class FloatFormats(
        FloatSpecialsMixin,
        enum.Enum,
        positive_infinity="math.Inf(1)",
        negative_infinity="math.Inf(-1)",
        nan="math.NaN()",
    ):
        """Float format options."""

        REPR = enum.member(value=_format_float_repr)
        SCIENTIFIC = enum.member(value=_format_float_scientific)
        FIXED = enum.member(value=_format_float_fixed)

    class IntegerFormats(enum.Enum):
        """Integer format options."""

        DECIMAL = MappingProxyType(
            mapping={
                "NONE": str,
                "UNDERSCORE": format_integer_underscore,
            }
        )
        HEX = MappingProxyType(
            mapping={
                "NONE": format_integer_hex,
                "UNDERSCORE": format_integer_hex,
            }
        )
        OCTAL = MappingProxyType(
            mapping={
                "NONE": format_integer_octal,
                "UNDERSCORE": format_integer_octal,
            }
        )
        BINARY = MappingProxyType(
            mapping={
                "NONE": format_integer_binary,
                "UNDERSCORE": format_integer_binary,
            }
        )

        def get_formatter(
            self,
            numeric_separator: enum.Enum,
        ) -> Callable[[int], str]:
            """Return the integer formatter for the given separator."""
            formatter: Callable[[int], str] = self.value[
                numeric_separator.name
            ]
            return formatter

    class NumericLiteralSuffixes(enum.Enum):
        """Numeric literal suffix options."""

        NONE = enum.auto()
        AUTO = enum.auto()

    class NumericSeparators(enum.Enum):
        """Numeric separator options."""

        NONE = enum.auto()
        UNDERSCORE = enum.auto()

    class NumericStyles(enum.Enum):
        """Numeric literal style options."""

        OVERLOADED = enum.auto()

    class StringFormats(FormatValueMixin[Callable[[str], str]], enum.Enum):
        """String format options."""

        DOUBLE = enum.member(value=_format_string_go)
        MULTILINE = _StringEnumMember(value=_format_string_multiline)

        def __call__(self, value: str, /) -> str:
            """Format a string."""
            return self.value(value)

    class TrailingCommas(enum.Enum):
        """Trailing comma options."""

        YES = TrailingCommaConfig(multiline_trailing_comma=True)

    date_formats = DateFormats
    datetime_formats = DatetimeFormats
    bytes_formats = BytesFormats
    sequence_formats = SequenceFormats
    set_formats = SetFormats
    comment_formats = CommentFormats

    class VariableTypeHints(enum.Enum):
        """Variable type hint options."""

        NEVER = enum.auto()
        SAFE = enum.auto()

    variable_type_hints_formats = VariableTypeHints
    declaration_styles = DeclarationStyles
    dict_entry_styles = DictEntryStyles
    dict_formats = DictFormats
    empty_dict_keys = EmptyDictKey
    float_formats = FloatFormats
    integer_formats = IntegerFormats
    integer_width_strategies = BareIntegerWidthStrategies
    record_map_value_typings = RecordMapValueTypings
    numeric_literal_suffixes = NumericLiteralSuffixes
    numeric_separators = NumericSeparators
    numeric_styles = NumericStyles
    string_formats = StringFormats
    trailing_commas = TrailingCommas

    class StatementTerminatorStyles(FormatValueMixin[str], enum.Enum):
        """Statement terminator options."""

        NONE = ""

        @property
        def statement_terminator(self) -> str:
            """Terminator appended to complete call statements."""
            return self.value

    statement_terminator_styles = StatementTerminatorStyles

    class CallStyles(enum.Enum):
        """Go call style options."""

        POSITIONAL = PositionalCallStyle(
            arg_separator=", ", parenthesize_each_arg=False
        )

    call_styles = CallStyles

    class Modifiers(enum.Enum):
        """C++/Java/C#-style declaration modifiers: this language has none."""

    modifiers = Modifiers

    class HeterogeneousStrategies(enum.Enum):
        """Strategy for dicts whose values span more than one Go type.

        ``ERROR`` keeps Go's strict-typing behavior (mixed-value dicts
        that cannot be represented raise).  ``RECORD`` renders each
        record-shaped dict (non-empty, string-keyed) as a generated
        ``struct`` declared in the preamble plus a matching struct
        literal, so fields may legitimately mix scalars and containers.
        """

        ERROR = enum.auto()
        RECORD = enum.auto()

    heterogeneous_strategies = HeterogeneousStrategies

    class JsonTypes(JsonType):
        """Empty: this language has no JSON value-type variants."""

    json_types = JsonTypes

    class BoolFormats(enum.Enum):
        """Empty: this language has no alternative boolean formats."""

    bool_formats = BoolFormats

    class VersionFormats(enum.Enum):
        """Version options for Go."""

        V1_18 = enum.auto()

    version_formats = VersionFormats

    modifier_combinations: ClassVar[tuple[ModifierCombination, ...]] = ()
    identifier_cases: ClassVar[tuple[IdentifierCase, ...]] = (
        IdentifierCase.PASCAL,
        IdentifierCase.CAMEL,
    )
    supported_ref_cases: ClassVar[frozenset[IdentifierCase]] = (
        NON_KEBAB_REF_CASES
    )

    def validate_spec_for_data(self, data: Value) -> None:
        """Reject Go format/data combinations that cannot type-check."""
        if (
            self.heterogeneous_strategy
            is type(self.heterogeneous_strategy).RECORD
        ):
            _reject_record_lists_with_empty_siblings(data)

    @cached_property
    @beartype
    def validate_call_arg(self) -> Callable[[Value], None]:
        """Apply the Go literal shape constraints to direct arguments."""
        return self.validate_spec_for_data

    format_call_statement = default_format_call_statement

    wrap_calls_with_declarations = default_wrap_calls_with_declarations

    @property
    def call_wrapper_entrypoint_name(self) -> str:
        """Return the generated complete-file entry-point name."""
        return "main"

    @staticmethod
    def wrap_in_file(
        content: str,
        context: FileWrapperContext,
    ) -> str:
        """Wrap a Go declaration in ``func main()``."""
        variable_name = context.variable_name
        body_preamble = context.body_preamble
        content = prepend_body_preamble(
            content=content,
            body_preamble=body_preamble,
        )
        use_line = ""
        if variable_name != "":
            use_line = f"\n_ = {variable_name}"
        return f"\nfunc main() {{\n{content}{use_line}\n}}"

    @staticmethod
    def wrap_combined_in_file(
        declaration: str,
        assignment: str,
        context: FileWrapperContext,
    ) -> str:
        """Wrap Go declaration + assignment in ``func main()``."""
        return Go.wrap_in_file(
            content=declaration + "\n" + assignment,
            context=context,
        )

    date_format: DateFormats = DateFormats.GO
    datetime_format: DatetimeFormats = DatetimeFormats.GO
    bytes_format: BytesFormats = BytesFormats.HEX
    sequence_format: SequenceFormats = SequenceFormats.SLICE
    set_format: SetFormats = SetFormats.SET
    default_set_element_type: str = "any"
    default_sequence_element_type: str = "any"
    default_dict_key_type: str = "string"
    default_dict_value_type: str = "any"
    default_ordered_map_value_type: str = "any"
    variable_type_hints: VariableTypeHints = VariableTypeHints.NEVER
    comment_format: CommentFormats = CommentFormats.DOUBLE_SLASH
    declaration_style: DeclarationStyles = DeclarationStyles.SHORT
    dict_entry_style: DictEntryStyles = DictEntryStyles.DEFAULT
    dict_format: DictFormats = DictFormats.DEFAULT
    float_format: FloatFormats = FloatFormats.REPR
    integer_format: IntegerFormats = IntegerFormats.DECIMAL
    integer_width_strategy: BareIntegerWidthStrategies = (
        BareIntegerWidthStrategies.BARE
    )
    numeric_literal_suffix: NumericLiteralSuffixes = (
        NumericLiteralSuffixes.NONE
    )
    numeric_separator: NumericSeparators = NumericSeparators.NONE
    numeric_style: NumericStyles = NumericStyles.OVERLOADED
    string_format: StringFormats = StringFormats.DOUBLE
    trailing_comma: TrailingCommas = TrailingCommas.YES
    statement_terminator_style: StatementTerminatorStyles = (
        StatementTerminatorStyles.NONE
    )
    call_style: CallStyles = CallStyles.POSITIONAL
    heterogeneous_strategy: HeterogeneousStrategies = (
        HeterogeneousStrategies.ERROR
    )
    record_struct_name_prefix: str = "Record"
    record_shape_names: Mapping[frozenset[str], str] = dataclasses.field(
        default_factory=empty_record_shape_names,
        hash=False,
    )
    record_map_value_typing: RecordMapValueTypings = (
        RecordMapValueTypings.NARROW
    )
    # Keep in sync with the `go` directive in the generated go.mod in
    # `.github/workflows/lint.yml`.
    language_version: VersionFormats = VersionFormats.V1_18
    indent: str = "\t"
    skip_null_dict_values: bool = False

    null_literal: ClassVar[str] = "nil"
    true_literal: ClassVar[str] = "true"
    false_literal: ClassVar[str] = "false"
    indent_closing_delimiter: ClassVar[bool] = False
    element_separator: ClassVar[str] = ", "
    supports_collection_comments: ClassVar[bool] = True
    supports_scalar_before_comments: ClassVar[bool] = False
    supports_scalar_inline_comments: ClassVar[bool] = True
    static_preamble: ClassVar[Sequence[str]] = ("package main",)
    static_body_preamble: ClassVar[Sequence[str]] = ()
    special_float_preamble: ClassVar[tuple[str, ...]] = ('import "math"',)

    def __post_init__(self) -> None:
        """Validate ``record_shape_names`` after construction."""
        self._validate_record_naming()

    def _validate_record_naming(self) -> None:
        """Validate ``record_shape_names`` for PascalCase identifier
        shape, collisions with the auto-generated ``{prefix}{N}``
        struct names, and duplicate target names.

        Ported from
        :meth:`literalizer.languages.Rust._validate_record_naming`.  Go
        has no ``heterogeneous_value_enum_name`` so that collision
        check does not apply, and Rust's reserved-keyword check is
        unnecessary here: every Go keyword and built-in identifier is
        lowercase, so the PascalCase requirement already rejects every
        one of them.
        """
        prefix = self.record_struct_name_prefix
        auto_name_pattern = re.compile(
            pattern=rf"^{re.escape(pattern=prefix)}\d+$",
        )
        seen_names: set[str] = set()
        for keys, name in self.record_shape_names.items():
            if _PASCAL_CASE_IDENTIFIER.match(string=name) is None:
                msg = (
                    f"record_shape_names entry for keys {sorted(keys)!r} "
                    f"maps to {name!r}, which is not a PascalCase Go "
                    f"identifier."
                )
                raise InvalidRecordNameError(msg)
            if auto_name_pattern.match(string=name) is not None:
                msg = (
                    f"record_shape_names entry for keys {sorted(keys)!r} "
                    f"maps to {name!r}, which collides with the "
                    f"auto-generated {prefix!r}-prefixed struct names."
                )
                raise InvalidRecordNameError(msg)
            if name in seen_names:
                msg = (
                    f"record_shape_names maps multiple key-sets to "
                    f"{name!r}; struct names must be unique."
                )
                raise InvalidRecordNameError(msg)
            seen_names.add(name)

    @cached_property
    @beartype
    def format_string(self) -> Callable[[str], str]:
        """Format a string value as a quoted literal."""
        return self.string_format

    @cached_property
    @beartype
    def format_sequence_entry(self) -> Callable[[Value, str], str]:
        """Format a sequence entry."""
        return passthrough_sequence_entry

    @cached_property
    @beartype
    def format_set_entry(self) -> Callable[[Value, str], str]:
        """Format a set entry."""
        return _format_go_set_entry

    @beartype
    def _go_integer_field_type(self, *, value: int) -> str:
        """Return the Go integer field type respecting the suffix
        policy.
        """
        suffix_is_auto = (
            self.numeric_literal_suffix
            is type(self.numeric_literal_suffix).AUTO
        )
        if value > I64_MAX:
            return "uint64"
        resolved_result_1: str = "int"
        if suffix_is_auto or value < _GO_I32_MIN or value > _GO_I32_MAX:
            resolved_result_1 = "int64"
        return resolved_result_1

    def _go_record_field_type(
        self,
        request: RecordFieldType,
        /,
    ) -> str:
        """Return the Go struct field type for a record field.

        A field whose value is itself a nested record-shaped dict uses
        that record's generated struct name.  A list or ordered-map
        field derives its type from the very collection opener the
        value formatter uses for that value (a record field is
        formatted with no sibling override, so the opener equals the
        one emitted, including a widening to ``[]any``); the opener's
        trailing ``{`` is dropped to leave the bare type, e.g.
        ``[]int{`` -> ``[]int``, ``[][2]any{`` -> ``[][2]any``.  A
        scalar field uses the same scalar mapping the openers are
        built on.  A positive integer beyond the signed 64-bit range is
        the one exception: its literal comes from the ``uint64(...)``
        overflow fallback (see
        :func:`make_unsigned_overflow_fallback`), so the field is typed
        ``uint64`` to match that typed conversion.

        A record-eligible dict with no generated record name was widened
        out of the record-shape mapping because its nested sibling family
        cannot share one shape (issue #2911); it uses ``map[string]any``,
        narrowed to ``map[string]T`` when every scalar across the
        widened maps shares one concrete Go type ``T`` (issue #3608).
        A set or a non-record dict (an empty or non-string-keyed dict)
        as a record field has no precise component type under the
        ``RECORD`` strategy.  Per the cross-language decision in #2317,
        Rust rejects such a field while Go widens it to the top type
        ``any`` (documented best effort), which the rendered literal
        still assigns into.
        """
        nested_type = _go_nested_record_type(request=request)
        if nested_type is not None:
            return nested_type
        value = request.value
        if (
            isinstance(value, dict)
            and not isinstance(value, OrderedMap)
            and bool(value)
            and all(isinstance(key, str) for key in value)
        ):
            return self._go_derecordized_map_field_type()
        match value:
            case None:
                return "any"
            case OrderedMap():
                opener = self.ordered_map_format_config.ordered_map_open(
                    value,
                )
            case list():
                opener = self.sequence_open(value)
            case int() if not isinstance(value, bool):
                return self._go_integer_field_type(value=value)
            case _:
                element_type = self._init_element_to_type(type(value))
                resolved_result_2: str = "any"
                if element_type is not None and element_type != "":
                    resolved_result_2 = element_type
                return resolved_result_2
        return opener[: -len("{")]

    def _go_render_declaration(
        self,
        name: str,
        fields: Sequence[RecordDeclarationField],
        /,
    ) -> str:
        """Render a Go ``type Name struct { ... }`` declaration."""
        lines = [f"type {name} struct {{"]
        lines += [
            f"{self.indent}{field.identifier} {field.type_name}"
            for field in fields
        ]
        lines.append("}")
        return "\n".join(lines)

    @cached_property
    @beartype
    def _record_renderer(self) -> RecordRenderer:
        """Go syntax hooks for the ``RECORD`` strategy."""
        return RecordRenderer(
            name_prefix=self.record_struct_name_prefix,
            record_shape_names=self.record_shape_names,
            field_identifier=_go_record_field_identifier,
            field_identifier_key=identity_field_identifier_key,
            field_type=self._go_record_field_type,
            render_declaration=self._go_render_declaration,
            render_literal=_go_record_literal,
            field_type_names_nested_records=False,
            suppressed_custom_names=frozenset(),
        )

    def _go_derecordized_map_field_type(self) -> str:
        """Return the declared field type for a widened fallback map.

        Spells the concrete value type when every scalar across the
        widened maps shares one Go type in the current pass and the
        ``map[string]any`` top type otherwise (issue #3608).
        """
        narrow_value_type = self._derecordized_map_narrowing.value_type
        if narrow_value_type is not None:
            return f"map[string]{narrow_value_type}"
        return "map[string]any"

    def _go_narrow_derecordized_map_value_type(
        self,
        *,
        data: Value,
        wrap_ids: frozenset[int],
    ) -> str | None:
        """Return the single Go type every widened-map scalar shares.

        Returns ``None`` when the widened maps genuinely mix scalar
        types (the ``map[string]any`` top type is then required), when
        there is nothing to widen, when any widened scalar only has the
        ``any`` top type (a ``nil`` value), or when
        ``record_map_value_typing`` asks for the top type whatever the
        data holds.
        """
        if self.record_map_value_typing is RecordMapValueTypings.WIDE:
            return None
        scalars = iter_wrapped_values(data=data, wrap_ids=wrap_ids)
        if len(scalars) == 0:
            return None
        scalar_types = {
            self._go_record_field_type(
                RecordFieldType(
                    value=scalar,
                    record_name=None,
                    element_record_name=None,
                ),
            )
            for scalar in scalars
        }
        return single_concrete_type(types=scalar_types, fallback_type="any")

    @cached_property
    @beartype
    def _derecordized_map_narrowing(self) -> _GoWidenedMapNarrowing:
        """Per-pass narrow-value-type cache for widened fallback maps."""
        return _GoWidenedMapNarrowing(value_type=None)

    @cached_property
    @beartype
    def _record_strategy(self) -> RecordStrategy:
        """Resolve the active strategy to its behavior + preamble.

        The ``RECORD`` strategy's widened fallback maps normally open
        with ``map[string]any{``; when every scalar across those maps
        shares one concrete Go type the opener and the declared field
        type narrow to that type instead (issue #3608), so the opener
        is deferred to render time through the per-pass narrowing
        cache refreshed by ``compute_wrap_ids``.
        """
        cls = type(self.heterogeneous_strategy)
        if self.heterogeneous_strategy is not cls.RECORD:
            return RecordStrategy(
                behavior=NO_HETEROGENEOUS_BEHAVIOR,
                preamble=no_data_preamble,
                record_name_for_value=None,
            )
        strategy = build_record_strategy(
            renderer=self._record_renderer,
            widen_unrecordizable_nested_sibling_maps=True,
            derecordized_map_open=None,
        )
        narrowing = self._derecordized_map_narrowing
        base_compute_wrap_ids = strategy.behavior.compute_wrap_ids

        @beartype
        def _compute_wrap_ids(data: Value, /) -> frozenset[int]:
            """Refresh the narrow-type cache alongside the wrap ids."""
            wrap_ids = base_compute_wrap_ids(data)
            narrowing.value_type = self._go_narrow_derecordized_map_value_type(
                data=data,
                wrap_ids=wrap_ids,
            )
            return wrap_ids

        @beartype
        def _widened_map_open() -> str:
            """Return the widened-map opener for the current pass."""
            if narrowing.value_type is not None:
                return f"map[string]{narrowing.value_type}{{"
            return "map[string]any{"

        return dataclasses.replace(
            strategy,
            behavior=dataclasses.replace(
                strategy.behavior,
                compute_wrap_ids=_compute_wrap_ids,
                dict_open_for_wrap_ids=_widened_map_open,
            ),
        )

    @cached_property
    @beartype
    def data_dependent_preamble(self) -> Callable[[Value], tuple[str, ...]]:
        """Return data-dependent preamble lines.

        Imports ``math`` when negative zero needs ``math.Copysign``.
        Under ``HeterogeneousStrategies.RECORD``, also emits one
        ``struct`` declaration per record shape present in the data.
        """
        record_preamble = self._record_strategy.preamble

        @beartype
        def _preamble(data: Value) -> tuple[str, ...]:
            """Add ``math`` only when negative zero needs it."""
            math_preamble: tuple[str, ...]
            if _data_has_negative_zero(data=data):
                math_preamble = ('import "math"',)
            else:
                math_preamble = ()
            return math_preamble + record_preamble(data)

        return _preamble

    @cached_property
    @beartype
    def heterogeneous_behavior(self) -> HeterogeneousBehavior:
        """Return the behavior for the chosen heterogeneous strategy."""
        return self._record_strategy.behavior

    @property
    def shares_direct_call_record_context(self) -> bool:
        """Render call arguments with the record names in their
        preamble.
        """
        return (
            self.heterogeneous_strategy
            is type(self.heterogeneous_strategy).RECORD
        )

    call_data_dependent_preamble = default_call_data_dependent_preamble

    type_hint_collection_preamble_lines = (
        default_type_hint_collection_preamble_lines
    )

    format_call_stub = default_format_call_stub

    @cached_property
    @beartype
    def format_call_preamble_stub(
        self,
    ) -> Callable[
        [Sequence[str], Sequence[str], StubReturn, Sequence[Value]],
        tuple[str, ...],
    ]:
        """Return file-scope stubs for a call expression."""
        return _go_call_preamble_stub

    format_call_target = default_format_call_target

    format_call_ref_identifier = default_format_call_ref_identifier

    format_call_arg_ref_identifier = default_format_call_arg_ref_identifier

    format_call_arg_ref_identifier_consumable = (
        default_format_call_arg_ref_identifier_consumable
    )

    consumable_ref_value_inhibits_consuming_form = (
        default_consumable_ref_value_inhibits_consuming_form
    )

    @cached_property
    @beartype
    def _init_element_to_type(
        self,
    ) -> Callable[[type[object] | ListType | DictType], str | None]:
        """Element-to-type resolver for the configured Go types."""
        _type_names: dict[type[object], str] = {
            dt.date: "time.Time",
            dt.datetime: "time.Time",
            str: "string",
        }
        suffix_is_auto = (
            self.numeric_literal_suffix
            is type(self.numeric_literal_suffix).AUTO
        )
        go_int_type = "int"
        if suffix_is_auto:
            go_int_type = "int64"
        _type_names[int] = go_int_type
        date_type = _type_names.get(self.date_format.value.type_produced)
        datetime_type = _type_names.get(
            self.datetime_format.value.type_produced,
        )
        return make_element_to_type(
            dict_value_to_type=None,
            str_type="string",
            bool_type="bool",
            int_type=go_int_type,
            float_type="float64",
            mixed_numeric_type="float64",
            bytes_type="string",
            date_type=date_type,
            datetime_type=datetime_type,
            time_type="time.Time",
            list_template="[]{inner}",
            enable_list_type=True,
            dict_type_template=f"map[{self.default_dict_key_type}]{{inner}}",
            fallback_value_type="any",
            wide_int_type="int64",
            beyond_i64_type="uint64",
        )

    def _epoch_normalized(self, value: Value, /) -> Value:
        """Infer collection types from the integer literals EPOCH
        emits.
        """
        match value:
            case dt.datetime() if (
                self.datetime_format.value.type_produced is int
            ):
                return datetime_epoch_seconds(value=value)
            case list():
                return [self._epoch_normalized(item) for item in value]
            case OrderedMap():
                return OrderedMap(
                    {
                        key: self._epoch_normalized(item)
                        for key, item in value.items()
                    }
                )
            case dict():
                return {
                    key: self._epoch_normalized(item)
                    for key, item in value.items()
                }
            case _:
                return value

    @cached_property
    @beartype
    def sequence_format_config(self) -> SequenceFormatConfig:
        """Configuration for the chosen sequence format."""
        return self.sequence_format.value

    @cached_property
    @beartype
    def set_format_config(self) -> SetFormatConfig:
        """Configuration for the chosen set format."""
        base_set_config: SetFormatConfig = self.set_format(
            default_type=self.default_set_element_type,
        )
        return base_set_config.with_typed_opener(
            type_to_opener=make_type_to_opener(
                element_to_type=self._init_element_to_type,
                opener_template="map[{type_name}]struct{{}}{{",
            ),
            fallback=base_set_config.set_open([]),
        )

    @cached_property
    @beartype
    def sequence_open(self) -> Callable[[list[Value]], str]:
        """Callable that returns the opening delimiter for a sequence.

        Under the ``RECORD`` strategy a list whose every element is
        rendered as one shared record type opens as
        ``[]RecordN{ RecordN{...}, ... }`` -- the struct literals all
        share that element type, so the slice spells it instead of
        widening.  A list that merely contains record-shaped dicts
        (mixed with other values, or left as maps) still opens as
        ``[]any{`` (the elements format as struct literals, not as the
        ``map[string]...`` the typed opener would otherwise infer).
        """
        base = typed_collection_open(
            type_to_opener=make_type_to_opener(
                element_to_type=self._init_element_to_type,
                opener_template="[]{type_name}{{",
            ),
            fallback=f"[]{self.default_sequence_element_type}{{",
        )
        unnormalized_base = base

        @beartype
        def _epoch_open(items: list[Value], /) -> str:
            """Open the slice with the types its formatted values have."""
            return unnormalized_base(
                [self._epoch_normalized(item) for item in items]
            )

        @beartype
        def _epoch_signature(items: list[Value], /) -> CollectionSignature:
            """Retain rendered-value inference for sibling widening."""
            return collection_signature(
                unnormalized_base,
                [self._epoch_normalized(item) for item in items],
            )

        base = signature_open(render=_epoch_open, infer=_epoch_signature)
        record_name_for_value = self._record_strategy.record_name_for_value
        if record_name_for_value is None:
            return base

        @beartype
        def _open(items: list[Value], /) -> str:
            """Use the shared record element type when every item is
            rendered as one record, else ``[]any{`` for lists holding
            record-shaped dicts.
            """
            nested_type = nested_record_sequence_type(
                value=items,
                record_name_for_value=record_name_for_value,
            )
            if nested_type is not None:
                depth, name = nested_type
                return f"{'[]' * depth}{name}{{"
            if any(
                isinstance(item, dict) and not isinstance(item, _ordereddict)
                for item in items
            ):
                return f"[]{self.default_sequence_element_type}{{"
            return base(items)

        @beartype
        def _signature(items: list[Value], /) -> CollectionSignature:
            """Retain the chosen record element type or shared
            fallback.
            """
            nested_type = nested_record_sequence_type(
                value=items, record_name_for_value=record_name_for_value
            )
            if nested_type is not None:
                depth, name = nested_type
                return CollectionSignature(
                    type_key="[]" * depth + name,
                    arity=None,
                    arity_decision=False,
                    fallback_decision=True,
                    narrowing_decision=True,
                    uses_fallback_decision=False,
                )
            if any(
                isinstance(item, dict) and not isinstance(item, _ordereddict)
                for item in items
            ):
                return collection_signature(base, [])
            return collection_signature(base, items)

        return signature_open(render=_open, infer=_signature)

    @cached_property
    @beartype
    def dict_format_config(self) -> DictFormatConfig:
        """Configuration for dict formatting."""
        type_to_opener = make_type_to_opener(
            element_to_type=self._init_element_to_type,
            opener_template=f"map[{self.default_dict_key_type}]{{type_name}}{{{{",
        )
        # The configured default supplies the element type of an empty
        # map. Populated maps with no inferable common type need a
        # carrier that can hold all their values.
        default_type = self.default_dict_value_type
        populated_fallback = (
            "interface{}" if default_type == "interface{}" else "any"
        )
        empty_open = typed_dict_open(
            type_to_opener=type_to_opener,
            fallback=f"map[{self.default_dict_key_type}]{default_type}{{",
        )
        populated_open = typed_dict_open(
            type_to_opener=type_to_opener,
            fallback=f"map[{self.default_dict_key_type}]{populated_fallback}{{",
        )

        @beartype
        def _normalized(items: dict[Scalar, Value], /) -> dict[Scalar, Value]:
            """Keep keys while inferring the types of rendered map
            values.
            """
            return {
                key: self._epoch_normalized(item)
                for key, item in items.items()
            }

        @beartype
        def _open(items: dict[Scalar, Value], /) -> str:
            """Open the map with the types its formatted values have."""
            opener = populated_open if len(items) > 0 else empty_open
            return opener(_normalized(items))

        @beartype
        def _signature(items: dict[Scalar, Value], /) -> CollectionSignature:
            """Retain rendered-value inference for sibling widening."""
            opener = populated_open if len(items) > 0 else empty_open
            return collection_signature(opener, _normalized(items))

        return DictFormatConfig(
            dict_open=signature_open(render=_open, infer=_signature),
            close="}",
            format_entry=dict_entry_with_separator(
                separator=": ",
                format_value=passthrough_sequence_entry,
            ),
            empty_dict=None,
            preamble_lines=(),
            narrowed_open="{",
            supports_trailing_comma=True,
            narrowed_empty_form=None,
        )

    @cached_property
    @beartype
    def trailing_comma_config(self) -> TrailingCommaConfig:
        """Configuration for trailing-comma behavior."""
        return self.trailing_comma.value

    @cached_property
    @beartype
    def format_bytes(self) -> Callable[[bytes], str]:
        """Callable that formats a bytes value as a string literal."""
        return self.bytes_format

    @cached_property
    @beartype
    def format_date(self) -> Callable[[dt.date], str]:
        """Callable that formats a date as a string literal."""
        return self.date_format

    @cached_property
    @beartype
    def format_datetime(self) -> Callable[[dt.datetime], str]:
        """Callable that formats a datetime as a string literal."""
        return self.datetime_format

    @cached_property
    @beartype
    def format_time(self) -> Callable[[dt.time], str]:
        """Callable that formats a time as a string literal."""
        return _format_time_go

    @cached_property
    @beartype
    def format_float(self) -> Callable[[float], str]:
        """Callable that formats a float value as a literal."""
        return self.float_format

    @cached_property
    @beartype
    def format_integer(self) -> Callable[[int], str]:
        """Callable that formats an int value as a literal."""
        base_int_formatter = self.integer_format.get_formatter(
            numeric_separator=self.numeric_separator,
        )
        suffix_is_auto = (
            self.numeric_literal_suffix
            is type(self.numeric_literal_suffix).AUTO
        )
        base: Callable[[int], str]
        base = base_int_formatter
        if suffix_is_auto:
            base = make_int64_cast_formatter(base=base_int_formatter)
        return make_overflow_fallback_formatter(
            base=base,
            fallback=make_unsigned_overflow_fallback(
                format_positive=_format_go_uint64_positive,
                language_name="Go",
            ),
            min_value=I64_MIN,
            max_value=I64_MAX,
        )

    @cached_property
    @beartype
    def format_integer_in_mixed_numeric_collection(
        self,
    ) -> Callable[[int], str] | None:
        """Leave integer constants inferred when their collection is
        ``float64``.

        ``AUTO`` normally writes ``int64(...)``.  Go cannot use that typed
        value in a ``float64`` slice or map literal, whereas the same bare
        integer constant converts to ``float64`` in context (issue #4762).
        """
        if (
            self.numeric_literal_suffix
            is not type(self.numeric_literal_suffix).AUTO
        ):
            return None
        return self.integer_format.get_formatter(
            numeric_separator=self.numeric_separator,
        )

    @cached_property
    @beartype
    def format_integer_beyond_i64(self) -> Callable[[int], str]:
        """Formatter for collections whose integers exceed signed 64-bit
        range.

        Such a collection opens as ``[]uint64`` / ``map[...]uint64``
        (see :attr:`_init_element_to_type`), so every element must fit
        the unsigned 64-bit element type.  Non-negative values within
        signed 64-bit range render as bare literals, values above it use
        the ``uint64(...)`` typed conversion, and negatives raise
        :class:`UnrepresentableIntegerError` because ``uint64`` has no
        signed representation.  The bare literal is used inside the typed
        slice or map literal without the scalar ``int64(...)`` cast,
        which would mismatch the ``uint64`` element type.
        """
        base_int_formatter = self.integer_format.get_formatter(
            numeric_separator=self.numeric_separator,
        )
        return make_overflow_fallback_formatter(
            base=base_int_formatter,
            fallback=make_unsigned_overflow_fallback(
                format_positive=_format_go_uint64_positive,
                language_name="Go",
            ),
            min_value=0,
            max_value=I64_MAX,
        )

    @cached_property
    @beartype
    def comment_config(self) -> CommentConfig:
        """Configuration for the language's comment syntax."""
        return self.comment_format.value

    @cached_property
    @beartype
    def ordered_map_format_config(self) -> OrderedMapFormatConfig:
        """Configuration for ordered-map formatting."""
        return OrderedMapFormatConfig(
            ordered_map_open=fixed_open(
                open_str=f"[][2]{self.default_ordered_map_value_type}{{"
            ),
            close="}",
            preamble_lines=(),
        )

    @cached_property
    @beartype
    def format_ordered_map_entry(self) -> Callable[[str, Value, str], str]:
        """Callable that formats one ordered-map entry."""
        return braced_dict_entry(format_value=passthrough_sequence_entry)

    @cached_property
    @beartype
    def statement_terminator(self) -> str:
        """String appended to each call expression."""
        return self.statement_terminator_style.statement_terminator

    @cached_property
    @beartype
    def format_variable_declaration(
        self,
    ) -> Callable[[str, str, Value, frozenset[enum.Enum]], str]:
        """Callable that formats a new variable declaration."""
        return _nil_safe_declaration(
            base_formatter=self.declaration_style.value.formatter,
        )

    assignment_declares_binding = requires_declared_binding
    reference_assignment_declares_binding = assignment_declares_binding
    call_assignment_declares_binding = False

    @cached_property
    @beartype
    def format_variable_assignment(
        self,
    ) -> Callable[[str, str, Value], str]:
        """Callable that formats an assignment to an existing variable."""
        return variable_formatter(template="{name} = {value}")

    @cached_property
    @beartype
    def scalar_preamble(self) -> dict[type[object], tuple[str, ...]]:
        """Per-instance scalar preamble computed from date/datetime format."""
        return date_scalar_preamble(
            date_format=self.date_format,
            datetime_format=self.datetime_format,
            extra={dt.time: ('import "time"',)},
        )

    @cached_property
    @beartype
    def scalar_body_preamble(self) -> dict[type[object], tuple[str, ...]]:
        """Per-instance scalar body preamble (Go needs none)."""
        return {}

    @cached_property
    @beartype
    def compute_body_preamble(
        self,
    ) -> Callable[[frozenset[type[object]], Value], tuple[str, ...]]:
        """Compute body-preamble lines from the scalar map."""
        return body_preamble_from_scalars(
            scalar_body_preamble=self.scalar_body_preamble,
            format_lines=tuple,
        )

    @cached_property
    @beartype
    def call_style_config(self) -> CallStyle:
        """Configuration for the chosen call style."""
        return self.call_style.value
